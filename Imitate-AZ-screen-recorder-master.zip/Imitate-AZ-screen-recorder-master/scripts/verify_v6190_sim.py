#!/usr/bin/env python3
# v6.7.190 静态断言:7 个 P0 + 5 个 P1(基于 189 真机日志独立清点方案)
import re, sys

ROOT = "/workspace/app/src/main/java/com/monkeycode/screenrecorder"
def rd(p):
    with open(p, encoding="utf-8") as f: return f.read()

eng = rd(f"{ROOT}/RecorderEngine.kt")
main = rd(f"{ROOT}/MainActivity.kt")
svc = rd(f"{ROOT}/ScreenRecorderService.kt")

fails = []
def ck(name, cond):
    if not cond: fails.append(name)
    print(("PASS " if cond else "FAIL ") + name)

# ===== P0-1 时长口径唯一(视频轨)=====
# v6.7.191 (P0-4) 已用 tailOverrunMs 取代 durationDivergedMs(后者是同源自减恒 0 的自证断言),
# 因此不再断言具体字段名,只断言"时长分叉诊断字段存在"。具体字段由 verify_v6191_sim.py 断言。
ck("P0-1 时长分叉诊断字段存在",
   "durationDivergedMs=" in eng or "tailOverrunMs=" in eng)
ck("P0-1 frame_accounting 三口径",
   'logDetail("frame_accounting"' in eng and "videoDurMs=$vDurMsAcc" in eng and "audioDurMs=$aDurMsAcc" in eng)
# 根因:calculateDuration 不得再 maxOf(video, audio)
calc = eng[eng.index("private fun calculateDuration"):eng.index("private data class SafCopyResult")]
ck("P0-1 不再 maxOf 音视频", "maxOf(durationUs" not in calc)
ck("P0-1 视频优先", "if (vSpanUs > 0L) vSpanUs else aSpanUs" in calc)

# ===== P0-2 帧会计恒等式可证伪 =====
ck("P0-2 framesDequeued", "private var framesDequeued = 0" in eng and "framesDequeued++" in eng)
ck("P0-2 dequeued/unattributed 输出",
   "dequeued=$framesDequeued" in eng and "unattributed=${framesDequeued - writtenFrames - attributedDrops}" in eng)
ck("P0-2 captured 语义移到写入成功处",
   eng.index("capturedFrames++") > eng.index("writeSampleData(videoTrackIndex"))
ck("P0-2 原采集侧自增已删除",
   "videoFrameSeq++\n                    capturedFrames++" not in eng)
ck("P0-2 未归因分支已命名",
   all(x in eng for x in ["dropEosOrIdle", "drop4GLimit", "dropSwitchFailed"]))
ck("P0-2 attributed 汇总", "attributedDrops = dropPaused + dropNonMonotonic + dropTooDense" in eng)
hvo = eng[eng.index("private fun handleVideoOutput"):eng.index("private fun handleOutputFormatChanged")]
ck("P0-2 入口计数", "framesDequeued++" in hvo)
ck("P0-2 frameWritten 归因尾部", "if (!frameWritten) dropEosOrIdle++" in hvo and "dropEosOrIdle++" in hvo)

# ===== P0-3 掉帧持续性证据 =====
ck("P0-3 streak 字段", "private var frameDropWindowStreak = 0" in eng)
ck("P0-3 门槛 800ms", "dMs >= 800L" in eng)
ck("P0-3 连续3窗口判定", "frameDropWindowStreak >= 3" in eng)
ck("P0-3 windowLow 清零", "frameDropWindowStreak = if (windowLow) frameDropWindowStreak + 1 else 0" in eng)
ck("P0-3 drop_window 日志", 'logDetail("drop_window"' in eng)
ck("P0-3 重置点", "this.frameDropWindowStreak = 0" in eng)

# ===== P0-4 采集帧率取当前模式 =====
ck("P0-4 当前模式", "val currentHz = disp?.refreshRate ?: 60f" in eng)
ck("P0-4 capture_fps_probe", "capture_fps_probe" in eng and "maxModeHz=" in eng)
ck("P0-4 赋值不用 maxOf", ".toFloat()" not in eng[eng.index("effectiveCaptureFps = try {"):eng.index("currentHz.coerceAtLeast(30f)")])
ck("P0-4 下限 30", "currentHz.coerceAtLeast(30f)" in eng)

# ===== P0-5 分辨率降帧率必须可见 =====
ck("P0-5 fpsOverridden", "fpsOverridden=" in main)
ck("P0-5 弹窗文案", main.count("帧率已调整") == 1)
ck("P0-5 弹窗带原值", "帧率已由 ${sel.frameRate}fps 调整为 ${maxFps}fps" in main)

# ===== P0-6 AV 重锚双向累积 =====
ck("P0-6 同号门已移除", "avDriftSameSignWindows" not in eng and "lastAvDriftSign" not in eng)
ck("P0-6 累积器字段", "private var avDriftAccumUs = 0L" in eng and "private var avDriftWindowCount = 0" in eng)
ck("P0-6 累积判定", "kotlin.math.abs(avDriftAccumUs) > AV_REANCHOR_US" in eng)
ck("P0-6 av_drift_window", 'logDetail("av_drift_window"' in eng)
ck("P0-6 触发后清零", "avDriftAccumUs = 0L" in eng)

# ===== P0-7 投影授权取消必须可见 =====
ck("P0-7 取消 Toast", "录屏授权被取消" in main)
ck("P0-7 数据缺失 Toast", "未获得录屏授权" in main)
ck("P0-7 resultOk 日志", "resultOk=" in main)
ck("P0-7 状态复位", "RecordState.IDLE" in main and "updateRecordingState()" in main)

# ===== P1-1 cleanup skip 日志降噪 =====
ck("P1-1 skip 降级 Log.d", 'Log.d(TAG, "cleanupAndStop skip' in svc)
ck("P1-1 skip 不再 writeLog", 'writeLog("cleanupAndStop skip' not in svc)

# ===== P1-2 dpi 口径统一 =====
ck("P1-2 virtual_display_dpi 日志", "virtual_display_dpi" in eng and "ignored=true" in eng)
ck("P1-2 服务不再硬编码 320", "densityDpi = qualityParams2?.dpi ?: resources.displayMetrics.densityDpi" in svc)
ck("P1-2 默认质量用真 dpi", "resources.displayMetrics.densityDpi)" in main)
ck("P1-2 分辨率对话框用真 dpi", "currentQuality.audioBitRate, resources.displayMetrics.densityDpi)" in main)

# ===== P1-3 视频轨先行 =====
ck("P1-3 等视频轨", "wait for video track first" in eng)
at = eng[eng.index("private fun tryAddAudioTrack"):eng.index("private fun drainVideoEncoder")]
ck("P1-3 守卫在 muxerStarted 之后",
   at.index("if (muxerStarted.get())") < at.index("if (videoTrackIndex < 0)"))

# ===== P1-4 码率三口径 =====
ck("P1-4 effectiveMuxBitrate", "effectiveMuxBitrate=$effectiveMuxBitrate" in eng)
ck("P1-4 产物码率算法", "finalFileSize * 8L / durMsForBr" in eng)

# ===== P1-5 基线钳制统一 =====
sb = eng[eng.index("private fun sanitizeBaseline"):eng.index("private fun maybeAdaptBaseline")]
ck("P1-5 sanitize 用自适应区间",
   "BASELINE_FALLBACK_C - BASELINE_ADAPT_RANGE_C" in sb
   and "BASELINE_FALLBACK_C + BASELINE_ADAPT_RANGE_C * 2" in sb)

# ===== 不变量:188h/189 已修好的部分不得回退 =====
ck("不变 onSegments 先于 onStopped", eng.count("callback?.onSegments") >= 3)
ck("不变 BOOST_FACTOR_MAX", "BOOST_FACTOR_MAX = 1.5" in eng)
ck("不变 restore_stale 不删 idx", "restore_stale_keep" in eng)
ck("不变 BASELINE_PHYSICAL_MAX_C=65", "BASELINE_PHYSICAL_MAX_C = 65" in eng)
ck("不变 SESSION_GATED_IDS", "SESSION_GATED_IDS" in main)
ck("不变 av 符号 +=", "audioPtsOffsetUs += step" in eng)

print()
if fails:
    print("FAILED:", fails); sys.exit(1)
print("ALL PASS")
