#!/usr/bin/env python3
"""v6.7.188g 静态校验:StorageGc 自动垃圾回收。"""
import pathlib, sys, re

ROOT = pathlib.Path(__file__).resolve().parent.parent
GC = (ROOT / "app/src/main/java/com/monkeycode/screenrecorder/StorageGc.kt").read_text(encoding="utf-8")
MAIN = (ROOT / "app/src/main/java/com/monkeycode/screenrecorder/MainActivity.kt").read_text(encoding="utf-8")
SVC = (ROOT / "app/src/main/java/com/monkeycode/screenrecorder/ScreenRecorderService.kt").read_text(encoding="utf-8")

fails = []
def chk(name, cond, detail=""):
    if cond:
        print(f"PASS  {name}")
    else:
        fails.append(name)
        print(f"FAIL  {name}  {detail}")

# S1: 文件存在且 package 正确
chk("S1a StorageGc.kt 存在", len(GC) > 0)
chk("S1b package com.monkeycode.screenrecorder", "package com.monkeycode.screenrecorder" in GC)

# S2: SafeDeleteUtil.isProtected
chk("S2 StorageGc 用 SafeDeleteUtil.isProtected", "SafeDeleteUtil.isProtected" in GC)

# S3: 多分片 segmentPaths 清理
chk("S3 StorageGc e.segmentPaths.forEach", "e.segmentPaths.forEach" in GC)

# S4: 同步历史
chk("S4a StorageGc hm.delete", "hm.delete {" in GC)
chk("S4b StorageGc hm.reload()", "hm.reload()" in GC)

# S5: 节流与上限
chk("S5a MIN_INTERVAL_MS", "MIN_INTERVAL_MS" in GC)
chk("S5b MAX_DELETE_PER_RUN", "MAX_DELETE_PER_RUN" in GC)

# S6: 排序与最旧优先
chk("S6a sortedBy { it.timestamp }", "sortedBy { it.timestamp }" in GC)
chk("S6b live.firstOrNull() 最旧优先", "live.firstOrNull()" in GC)

# S7: 不解析媒体
chk("S7a 无 MediaExtractor", "MediaExtractor" not in GC)
chk("S7b 无 MediaMuxer", "MediaMuxer" not in GC)
chk("S7c 无 Mp4Repairer", "Mp4Repairer" not in GC)
chk("S7d 无 FileInputStream", "FileInputStream" not in GC)

# S8: 两处挂钩
chk("S8a MainActivity 调 StorageGc.maybeGc", "StorageGc.maybeGc(" in MAIN)
chk("S8b ScreenRecorderService 调 StorageGc.maybeGc", "StorageGc.maybeGc(" in SVC)

# S9: GC 基于 RecordingHistoryManager.getAll(),无目录遍历
chk("S9a 用 hm.getAll()", "hm.getAll()" in GC)
chk("S9b 无 walkTopDown/listFiles", "walkTopDown" not in GC and "listFiles" not in GC)

# S10/S11 改良项 2 是可选,不做不算错 — 本次未执行,跳过

# 反向断言:不动 TS / 不拆进程 / 不动悬浮球
import os
MANIFEST = (ROOT / "app/src/main/AndroidManifest.xml").read_text(encoding="utf-8")
ENG = (ROOT / "app/src/main/java/com/monkeycode/screenrecorder/RecorderEngine.kt").read_text(encoding="utf-8")
OVERLAY = (ROOT / "app/src/main/java/com/monkeycode/screenrecorder/RecordOverlay.kt").read_text(encoding="utf-8")
chk("R1 Manifest 无 android:process", "android:process" not in MANIFEST)
chk("R2 RecorderEngine 无 MUXER_OUTPUT_MPEG_2_TS", "MUXER_OUTPUT_MPEG_2_TS" not in ENG)
chk("R3 RecordOverlay 保留 subActionLockUntil", "subActionLockUntil" in OVERLAY)
chk("R4 RecordOverlay 保留 alpha = 153", "alpha = 153" in OVERLAY)
chk("R5 RecordOverlay 保留 AUTO_RETRACT_MS", "AUTO_RETRACT_MS" in OVERLAY)

print()
print(f"FAILS: {len(fails)}")
if fails:
    for f in fails: print(" -", f)
sys.exit(1 if fails else 0)
