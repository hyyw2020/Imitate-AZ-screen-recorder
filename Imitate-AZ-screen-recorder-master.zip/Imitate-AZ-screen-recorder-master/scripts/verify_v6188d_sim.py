#!/usr/bin/env python3
"""v6.7.188d 静态校验:悬浮球修复 7 项。"""
import pathlib, sys, re

ROOT = pathlib.Path(__file__).resolve().parent.parent

def rd(rel):
    return (ROOT / rel).read_text(encoding="utf-8")

SERVICE = rd("app/src/main/java/com/monkeycode/screenrecorder/ScreenRecorderService.kt")
OVERLAY = rd("app/src/main/java/com/monkeycode/screenrecorder/RecordOverlay.kt")

fails = []
def chk(name, cond, detail=""):
    if cond:
        print(f"PASS  {name}")
    else:
        fails.append(name)
        print(f"FAIL  {name}  {detail}")

# 0. FLAG_ACTIVITY_NEW_TASK 至少 3 处(既有 500 行+ onSettingsClicked + 本次 2 处 = 4)
cnt = SERVICE.count("FLAG_ACTIVITY_NEW_TASK")
chk("0 FLAG_ACTIVITY_NEW_TASK ≥3 处", cnt >= 3, f"实际 {cnt}")
# 本次两处 addFlags 位置精确断言
chk("0a onStartClicked 加 FLAG_ACTIVITY_NEW_TASK",
    re.search(r'putExtra\(CaptureActivity\.EXTRA_MODE,\s*"record"\)\s*\n\s*// 从 Service.*?addFlags\(android\.content\.Intent\.FLAG_ACTIVITY_NEW_TASK\)', SERVICE, re.S) is not None)
chk("0b onScreenshotClicked 加 FLAG_ACTIVITY_NEW_TASK",
    re.search(r'putExtra\(CaptureActivity\.EXTRA_MODE,\s*"shot"\)\s*\n\s*addFlags\(android\.content\.Intent\.FLAG_ACTIVITY_NEW_TASK\)', SERVICE) is not None)

# 1. init 默认位:-(collapsedSizePx / 2) 与 0.45f
chk("1a init 左贴边半露 -collapsedSizePx/2",
    "x = -(collapsedSizePx / 2)" in OVERLAY)
chk("1b init 45% 屏高 0.45f",
    "sh * 0.45f" in OVERLAY or "screenHeightFromDisplay() * 0.45f" in OVERLAY)

# 2. snapToEdge 十字吸附
chk("2a Math.abs(normX) 存在",
    "Math.abs(normX)" in OVERLAY)
# 反向:minOf(leftDist, rightDist, topDist, bottomDist) 已删
chk("2b snapToEdge 无 minOf 四边距离",
    "minOf(leftDist, rightDist, topDist, bottomDist)" not in OVERLAY)
# 反向:leftDist/rightDist/topDist/bottomDist 变量已删
chk("2c 无 leftDist/rightDist/topDist/bottomDist 变量",
    all(v not in OVERLAY for v in ["val leftDist", "val rightDist", "val topDist", "val bottomDist"]))

# 3. 半露 + 死常量删除
chk("3a HIDDEN_PEEK_DP 已删",
    "HIDDEN_PEEK_DP" not in OVERLAY)
chk("3b hiddenPeekPx 已删",
    "hiddenPeekPx" not in OVERLAY)
chk("3c dockTargetX DOCK_LEFT 半露",
    "DOCK_LEFT -> -(leadW() / 2)" in OVERLAY)
chk("3d dockTargetX DOCK_RIGHT 半露",
    "screenWidthFromDisplay() - leadW() / 2" in OVERLAY)
chk("3e dockTargetY DOCK_TOP 半露",
    "DOCK_TOP -> -(leadH() / 2)" in OVERLAY)
chk("3f dockTargetY DOCK_BOTTOM 半露",
    "screenHeightFromDisplay() - leadH() / 2" in OVERLAY)
chk("3g clampPosition 用 dockInsetX/Y",
    "val dockInsetX = leadW() / 2" in OVERLAY and "val dockInsetY = leadH() / 2" in OVERLAY)

# 4. expand 假计时修复
chk("4 expand timerText 按 isRecording 显示",
    "timerText.visibility = if (isRecording) View.VISIBLE else View.INVISIBLE" in OVERLAY)

# 5. 子球①图标统一三角
chk("5a 无 size * 0.11f 红点",
    "size * 0.11f" not in OVERLAY)
# subPauseButton draw 中 drawPath(path, iconPaint) 至少 1 次
sub1 = OVERLAY.find("subPauseButton = createSubBubble(")
sub2 = OVERLAY.find("subStopButton = createSubBubble(", sub1)
sub1_body = OVERLAY[sub1:sub2] if sub2 > sub1 else OVERLAY[sub1:]
chk("5b subPauseButton draw 含 canvas.drawPath",
    "canvas.drawPath(path, iconPaint)" in sub1_body)
# 分支条件 !isRecording || isPaused 走三角
chk("5c subPauseButton 三角分支 !isRecording || isPaused",
    "if (!isRecording || isPaused)" in sub1_body)

# 6.1 alpha=153
chk("6a iconPaint alpha = 153",
    "alpha = 153" in OVERLAY)

# 6.2 subActionLockUntil 字段
chk("6b subActionLockUntil 声明",
    "private var subActionLockUntil = 0L" in OVERLAY)
# 6.3 onClick 加锁
chk("6c onClick 判定 now < subActionLockUntil",
    "if (now < subActionLockUntil) return@createSubBubble" in OVERLAY)
chk("6d onClick 赋值 subActionLockUntil = now + 8000L",
    "subActionLockUntil = now + 8000L" in OVERLAY)
# 6.4 updatePauseState 与 updateRecordingState 解锁
chk("6e updatePauseState 解锁 subActionLockUntil = 0L",
    re.search(r"fun updatePauseState\(.*?isPaused = paused\s*\n\s*subActionLockUntil = 0L", OVERLAY, re.S) is not None)
chk("6f updateRecordingState 解锁 subActionLockUntil = 0L",
    re.search(r"fun updateRecordingState\(.*?isRecording = recording\s*\n\s*subActionLockUntil = 0L", OVERLAY, re.S) is not None)
# 总出现次数
sub_lock_count = OVERLAY.count("subActionLockUntil")
chk("6g subActionLockUntil 出现 ≥5 次",
    sub_lock_count >= 5, f"实际 {sub_lock_count}")

# 保留:isDocked 守卫仍在
chk("7 isDocked 守卫保留 1 处",
    OVERLAY.count("if (isDocked) return@createSubBubble") >= 1)

print()
print(f"FAILS: {len(fails)}")
if fails:
    for f in fails: print(" -", f)
sys.exit(1 if fails else 0)
