#!/usr/bin/env python3
"""v6.7.188f 静态校验:双 moov 吞视频根因修复 + 探针硬化 + 失败保留 _interrupted。"""
import pathlib, sys, re

ROOT = pathlib.Path(__file__).resolve().parent.parent
MP4 = (ROOT / "app/src/main/java/com/monkeycode/screenrecorder/Mp4Repairer.kt").read_text(encoding="utf-8")
ENG = (ROOT / "app/src/main/java/com/monkeycode/screenrecorder/RecorderEngine.kt").read_text(encoding="utf-8")
REPAIR = (ROOT / "app/src/main/java/com/monkeycode/screenrecorder/RepairActivity.kt").read_text(encoding="utf-8")

fails = []
def chk(name, cond, detail=""):
    if cond:
        print(f"PASS  {name}")
    else:
        fails.append(name)
        print(f"FAIL  {name}  {detail}")

# S1: writeRepaired + copyRegion 存在
chk("S1a fun writeRepaired 1 处", MP4.count("private fun writeRepaired(") == 1)
chk("S1b fun copyRegion 1 处", MP4.count("private fun copyRegion(") == 1)

# S2: 旧复制块已删
# repair 与 repairByScan 函数体内不再出现 while (true)
def func_body(src, sig):
    s = src.find(sig)
    if s < 0: return ""
    e = src.find("\n    fun ", s + 1)
    if e < 0: e = len(src)
    return src[s:e]
repair_b = func_body(MP4, "fun repair(tmpPath")
repairB_b = func_body(MP4, "fun repairByScan(tmpPath")
chk("S2a repair 内无 while (true)", "while (true)" not in repair_b)
chk("S2b repairByScan 内无 while (true)", "while (true)" not in repairB_b)
chk("S2c out.write(moov) 全工程 1 处(writeRepaired 内)",
    MP4.count("out.write(moov)") == 1)
chk("S2d repair 内调 writeRepaired", "writeRepaired(tmp, mdat, moov, outPath)" in repair_b)
chk("S2e repairByScan 内调 writeRepaired", "writeRepaired(tmp, mdat, moov, outPath)" in repairB_b)

# S3: Mdat 加 ftypEnd
chk("S3a Mdat 类含 ftypEnd",
    re.search(r"private class Mdat\([^)]*ftypEnd", MP4) is not None)
chk("S3b scanMdat 返回 Mdat 带 ftypEnd 实参",
    re.search(r"return Mdat\([^)]*ftypEnd", MP4) is not None)

# S4: writeRepaired 逻辑
wr = func_body(MP4, "private fun writeRepaired(")
chk("S4a writeRepaired 含 copyRegion ftyp",
    "copyRegion(inRa, out, 0L, ftypEnd, buf)" in wr)
chk("S4b writeRepaired 含 copyRegion mdat",
    "copyRegion(inRa, out, mdatBoxStart, total - mdatBoxStart, buf)" in wr)
chk("S4c writeRepaired 内无 inRa.read(buf) 全量直拷",
    "inRa.read(buf)" not in wr)
chk("S4d writeRepaired 回退路径存在(copyRegion 整文件)",
    "copyRegion(inRa, out, 0L, total, buf)" in wr)

# S5: mergeSegments 未受影响
chk("S5 mergeSegments 存在", "fun mergeSegments" in MP4)

# S6: mdatBoxStart = (dataStart - 8)
chk("S6 mdatBoxStart = (dataStart - 8)",
    "val mdatBoxStart = (mdat.dataStart - 8)" in wr)

# S7: 探针不再判 durUs > 0L 作为 ok 条件(代码行内,注释里的不算)
# 提取 probeReferredMp4 函数体非注释行
pr = func_body(ENG, "private fun probeRepairedMp4(")
pr_code_lines = [l for l in pr.split("\n") if not l.strip().startswith("//")]
pr_code = "\n".join(pr_code_lines)
chk("S7 probe 代码(非注释)无 durUs > 0L",
    "durUs > 0L" not in pr_code)

# S8: probeRepairedMp4 新逻辑
pr = func_body(ENG, "private fun probeRepairedMp4(")
chk("S8a probe 内 val ok = hasVideo", "val ok = hasVideo" in pr)
chk("S8b probe 内 Triple(ok, mime, durUs)", "Triple(ok, mime, durUs)" in pr)
chk("S8c probe 失败打印 parse failed", "probeRepairedMp4: parse failed" in pr)
chk("S8d probe 内 hasVideo 变量", "var hasVideo = false" in pr)

# S9: mime.startsWith 用于类型过滤(保留),但不再作为 ok 判定的唯一条件
# 方案里 ok = hasVideo,不再依赖 mime.startsWith("video/") && durUs > 0L
# 断言:ok 由 hasVideo 决定,而非 mime.startsWith
chk("S9a ok 由 hasVideo 决定",
    "val ok = hasVideo" in pr_code)
# mime.startsWith 用于类型过滤的 if 分支仍存在
chk('S9b mime.startsWith("video/") 用于类型过滤(if 分支)',
    'm.startsWith("video/")' in pr_code)

# S10: restoreStale 探针失败保留 _interrupted
chk("S10a 无 restoreStale_probe_failed", "restoreStale_probe_failed" not in ENG)
chk("S10b 有 probe failed, kept as",
    "probe failed, kept as" in ENG)
chk("S10c 有 _interrupted.mp4 命名",
    '_interrupted.mp4' in ENG)

# S11: RepairActivity.repairAll 补路径
ra = func_body(REPAIR, "private fun repairAll()")
chk("S11a RepairActivity 有 restoredPaths",
    "val restoredPaths = ArrayList<String>()" in ra)
chk("S11b RepairActivity restoredPaths.add",
    "restoredPaths.add(playable.absolutePath)" in ra)
chk("S11c RepairActivity Log.i repaired ->",
    'Log.i("RepairActivity", "repaired ->' in ra)
chk("S11d RepairActivity Toast 带 restoredPaths.first()",
    "restoredPaths.first()" in ra)

# S12: _interrupted 不被 scanOrphans/findStaleRecordings 扫描循环主动匹配
# 用精确 end marker (下一 companion 方法起点) 避免误扫到后续函数
def func_body_precise(src, sig, next_marker):
    s = src.find(sig)
    if s < 0: return ""
    e = src.find(next_marker, s + 1)
    if e < 0: e = len(src)
    return src[s:e]
scan = func_body_precise(ENG, "fun scanOrphans(", "        fun findStaleRecordings(")
chk("S12a scanOrphans 用 .recording.tmp filter",
    '.endsWith(".recording.tmp")' in scan)
findb = func_body_precise(ENG, "fun findStaleRecordings(", "        fun restoreStale(")
chk("S12b findStaleRecordings 用 .recording.tmp filter",
    '.endsWith(".recording.tmp")' in findb)
chk("S12c scanOrphans 不主动匹配 _interrupted",
    '_interrupted' not in scan)
findb_lines = [l for l in findb.split("\n") if not l.strip().startswith("//") and not l.strip().startswith("*") and not l.strip().startswith("/*")]
findb_code = "\n".join(findb_lines)
chk("S12d findStaleRecordings 代码(非注释/KDoc)不主动匹配 _interrupted",
    '_interrupted' not in findb_code)

print()
print(f"FAILS: {len(fails)}")
if fails:
    for f in fails: print(" -", f)
sys.exit(1 if fails else 0)
