#!/usr/bin/env python3
# v6.7.184 验证:6 组合并补丁(A 四处/B 删死字段/C 落球/D 修假绿/E N1-N5 护栏)。
# 纯静态差分,不依赖真机;A2 算法正确性另用 python 移植实证(短跳场景)。
import re, sys, pathlib

ROOT = pathlib.Path(__file__).resolve().parent.parent
SRV = (ROOT/"app/src/main/java/com/monkeycode/screenrecorder/ScreenRecorderService.kt").read_text(encoding="utf-8")
ENG = (ROOT/"app/src/main/java/com/monkeycode/screenrecorder/RecorderEngine.kt").read_text(encoding="utf-8")
OVL = (ROOT/"app/src/main/java/com/monkeycode/screenrecorder/RecordOverlay.kt").read_text(encoding="utf-8")
ACT = (ROOT/"app/src/main/java/com/monkeycode/screenrecorder/MainActivity.kt").read_text(encoding="utf-8")
MAN = (ROOT/"app/src/main/AndroidManifest.xml").read_text(encoding="utf-8")
GRD = (ROOT/"app/build.gradle.kts").read_text(encoding="utf-8")

ok, bad = [], []
def ck(cond, msg):
    (ok if cond else bad).append(msg)

# ---------- 1. wakeLockHeld 接线 ----------
ck("@Volatile var wakeLockHeld" in ENG, "1a engine 有 wakeLockHeld 字段")
ck(re.search(r"@Volatile var wakeLockHeld = false\s*\n\s*private set", ENG, re.M) is not None, "1b wakeLockHeld 为 private set")
ck("fun setWakeLockHeld(held: Boolean)" in ENG, "1c engine 有 setWakeLockHeld setter")
ck('put("wakeLockHeld", wakeLockHeld)' in ENG, "1d buildReport 写出 wakeLockHeld")
ck("put(\"screenLockedMs\"" in ENG and "put(\"wakeLockHeld\"" in ENG, "1e 与 screenLockedMs 同在报告")
ck(len(re.findall(r"engine\?\.setWakeLockHeld\(", SRV)) >= 4, "1f service 至少 4 处同步 setWakeLockHeld")
ck("engine?.setWakeLockHeld(true)" in SRV, "1g acquire 成功同步 true")
ck("engine?.setWakeLockHeld(false)" in SRV, "1h 失败/释放同步 false")
# 分层:engine 不能直读 service 字段
ck("wakeLockAcquired" not in ENG, "1i engine 未直读 service 的 wakeLockAcquired(分层未破坏)")
# v6.7.184: Service 侧已删 wakeLockAcquired,状态唯一源收敛为 engine 镜像
ck("wakeLockAcquired" not in SRV, "1j Service 无 wakeLockAcquired 残留(状态唯一源在 engine)")
ck("engine?.setWakeLockHeld(it.isHeld)" in SRV, "1j2 renew 按 isHeld 回填 engine 镜像")
# v6.7.184: 删字段后,原"有读取点"断言已无对象,改为锁死"字段确实没了"
ck("wakeLockAcquired" not in (SRV + ENG), "1k wakeLockAcquired 双文件零残留(不再写而未读)")

# ---------- 2. navbarInsetPx else 复位 ----------
ovl_insets = OVL.split("override fun onApplyWindowInsets")[1].split("return insets")[0]
ck(ovl_insets.count("navbarInsetPx = 0") >= 2, "2a @R 与 <R 两分支都有 else 复位")
ck(ovl_insets.count("if (b.bottom > 0)") == 1, "2b @R 分支抬高路径保留")
ck(ovl_insets.count("if (bottomInset > 0)") == 1, "2c <R 分支抬高路径保留")
# else 复位必须在抬高 if 之后
ck(re.search(r"if \(b\.bottom > 0\).*?else \{\s*//[^}]*navbarInsetPx = 0", ovl_insets, re.S) is not None,
   "2d @R else 分支含 navbarInsetPx = 0")
ck(re.search(r"if \(bottomInset > 0\).*?else \{\s*//[^}]*navbarInsetPx = 0", ovl_insets, re.S) is not None,
    "2e <R else 分支含 navbarInsetPx = 0")
# v6.7.184: else 改为直接 setLead 落球后不再调 reClampOverNavbar,抬高路径仍 2 处
ck(ovl_insets.count("reClampOverNavbar()") >= 2, "2f 抬高路径仍调 reClampOverNavbar")
# v6.7.184: else 分支必须真的落球(setLead),否则"记账对了球不动"
ck(ovl_insets.count("setLead(leadX()") >= 2, "2g 两 else 分支都有落球 setLead")
ck(ovl_insets.count("val oldInset = navbarInsetPx") == 2, "2h 两 else 分支都先存旧 inset")
ck("safeUpdateViewLayout()" in ovl_insets, "2i 落球后触发重新布局")

# ---------- 3. checkFreeSpace 节流 ----------
ck("lastFreeSpaceCheckMs" in ENG, "3a 有节流时刻字段")
ck("lastFreeBelowMin" in ENG, "3b 有紧急档标志字段")
ck("fun checkFreeSpace()" in ENG and "fun doCheckFreeSpace()" in ENG, "3c 拆出 doCheckFreeSpace")
blk = ENG.split("fun checkFreeSpace()")[1].split("fun doCheckFreeSpace")[0]
ck(">= 5000" in blk, "3d 健康档 5s 周期")
ck("lastFreeBelowMin ||" in blk, "3e 紧急档或条件")
ck("ponytail:" in ENG.split("fun checkFreeSpace()")[1].split("doCheckFreeSpace")[0], "3f ponytail 标注天花板")
ck("lastFreeBelowMin = free < MIN_FREE_SPACE_BYTES" in ENG, "3g 紧急档按余量置位")
# 止损灵敏度:紧急档 1s 内可达(checkFreeSpace 每 1s 被 reportProgress 调用)
ck("if (nowMs - lastProgressReportMs < 1000) return" in ENG, "3h 调用频率仍 1s(紧急档不延迟)")

# ---------- 4. health 诊断串 5s ----------
ck("lastHealthSampleMs" in ENG, "4a 有 health 采样时刻字段")
ck(re.search(r"if \(nowMs - lastHealthSampleMs >= 5000L\)", ENG) is not None, "4b health 串门控 5s")
# av_pts_delta 环形采样必须在门控之外(否则分位数失真)
# v6.7.184: 让 seg 真正参与断言——门控块以 "}" 结束,addLast 必须在其后
seg = ENG.split('if (nowMs - lastHealthSampleMs >= 5000L)')[1].split("avDeltaRing.addLast(avDeltaUs)")[0]
seg_lines = [l for l in seg.strip().splitlines() if not l.strip().startswith("//")]
ck(len(seg_lines) >= 1 and seg_lines[-1].strip() == "}", "4c 5s 门控块以 } 收尾(addLast 在块外)")
ck("while (avDeltaRing.size > 7200) avDeltaRing.pollFirst()" in ENG, "4d 环形 7200 上限保留")
ck("lastHealthWallMs = nowMs" in ENG, "4e 漂移监控基准仍每 1s 更新")

# ---------- 5. 死代码清理 ----------
ck("batteryOptimizationLauncher" not in ACT, "5a batteryOptimizationLauncher 已删")
ck("未忽略电池优化，可继续录制" not in ACT, "5b 误导性 Toast 文案已改")
ck("checkBatteryOptimizationAndProceed" in ACT, "5c 只查不弹的函数仍在")
ck(len(re.findall(r"registerForActivityResult", ACT)) >= 3, "5d 其他 ActivityResult 未误删")
ck("isIgnoringBatteryOptimizations" in ACT, "5e 电池优化查询仍在(不需权限)")

# ---------- 红线 ----------
ck('uses-permission android:name="android.permission.WAKE_LOCK"' in MAN, "R1 Manifest 仍有 WAKE_LOCK")
ck("REQUEST_IGNORE_BATTERY_OPTIMIZATIONS" not in MAN, "R2 仍未申请电池豁免")
ck("android.permission.INTERNET" not in MAN, "R3 仍无 INTERNET 权限")
ck("versionCode = 313" in GRD and 'versionName = "6.7.184"' in GRD, "R4 版本号 313/6.7.184")
ck("muxerLock" in ENG, "R5 muxerLock 未动")
ck("fun releaseResources()" in ENG, "R6 release 释放链存在")
# v6.7.184: 原式裸 "A and B or C" 优先级陷阱,被 recoverUnfinished 恒真带绿,加括号锁语义
ck("screenLockedMs" in ENG and ("Mp4Repairer" in ENG or "recoverUnfinished" in ENG), "R7 崩溃保全链路未动")
ck('put("durationMs", durMs)' in ENG, "R8 报告原字段未破坏")

# ---------- N. v6.7.184 新增回归护栏 ----------
# N1 drift spanUs 公式: 必须是 n - n/10(时间中心距), 不是 n/10(每段跨度)
ck("(ord.size - ord.size / 10).coerceAtLeast(1) * 1_000_000.0" in ENG,
   "N1 spanUs 用 n-n/10(修 9 倍虚高)")
ck("(ord.size / 10).coerceAtLeast(1)" not in ENG, "N1b 旧 spanUs 公式已除")
# N2 sha256Quick 尾段: skip 目标 L-2*cap 且 while 循环扣减(短跳防护)
sha = ENG.split("private fun sha256Quick")[1].split("md.digest()")[0]
ck("f.length() - cap * 2" in sha, "N2 skip 目标为 L-2*cap")
ck("var toSkip" in sha and "toSkip -= s" in sha, "N2 skip 用 while 扣减(短跳防护)")
ck("ins.skip(f.length() - cap)" not in sha, "N2b 旧单条 skip 已除")
# N3 导航条 else 落球(与 2g 同源, 独立命名便于回归定位)
ck(ovl_insets.count("setLead(leadX()") >= 2, "N3 两 else 分支都落球")
# N4 wakeLockLostCount latch 全链接线
ck("@Volatile var wakeLockLostCount" in ENG, "N4a engine 有 wakeLockLostCount 字段")
ck("fun onWakeLockLost()" in ENG, "N4b engine 有 onWakeLockLost")
ck('put("wakeLockLostCount", wakeLockLostCount)' in ENG, "N4c 报告写出 wakeLockLostCount")
ck("engine?.onWakeLockLost()" in SRV, "N4d renew 检测丢失时调用")
ck("LOST detected during renew" in SRV, "N4e 丢失打日志(不静默)")
# N5 暂停期编码循环退避
ck("if (isPaused.get()) 100_000L else 2000L" in ENG, "N5a dequeue 超时暂停期退避 100s")
ck("Thread.sleep(if (isPaused.get()) 50L else 1L)" in ENG, "N5b sleep 暂停期 50ms")
# N5 安全性: reportProgress(续期源)必须仍在同一 while 循环体内, 退避不阻塞 1s 门。
# reportProgress 在 catch 之后仍属同一体, 故按行号区间校验: while 行 到 reportProgress 行
# 之间不得出现 while 的收尾 "}"(即循环提前结束)。
lines = ENG.splitlines()
w_idx = next(i for i,l in enumerate(lines) if "while (isRunning.get() && !forceStop.get() && !muxerVideoDone)" in l)
r_idx = next(i for i,l in enumerate(lines) if "reportProgress()" in l and i > w_idx)
between = lines[w_idx:r_idx]
ck(all(not l.strip().startswith("}") or "catch" not in l for l in between[-3:]),
   "N5c reportProgress 在退避 while 体内(续期不受退避影响)")
ck("if (isPaused.get()) 50L else 1L" in "".join(between), "N5d sleep 退避在 reportProgress 之前")

print(f"{len(ok)} passed, {len(bad)} failed")
for m in bad:
    print("FAIL", m)
sys.exit(1 if bad else 0)
