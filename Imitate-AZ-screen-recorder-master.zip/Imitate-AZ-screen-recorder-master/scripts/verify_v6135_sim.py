#!/usr/bin/env python3
"""v6.7.135 HEVC 打分开关语义修复验证.

镜像源码逻辑:
  - selectBestVideoEncoder(RecorderEngine.kt:1602):
      isHw +100, isVendor +50, isHevc → if(preferHevc) +200 else -50 (v6.7.135 压分)
      qcom/exynos/mediatek +30, google +10
    preferHevc 且 bitrate > HEVC_PREFERRED_BITRATE_CAP=80M 时优先 AVC。
  - 黑名单(:156)已移除 "hevc"(v6.7.134)。
  - PreferencesManager.loadQuality(:46) / QualityParams(:110) 默认 preferHevc=true。

验证:
  1. preferHevc=false 时 AVC 明确胜出(HEVC 压分 -50, 230→130 < 180)。
  2. preferHevc=true 时 HEVC 胜出(+200)。
  3. 默认开关为 true。
  4. 仅 HEVC 可用设备关闭开关时仍能选出编码器(不空选、不崩溃),靠 configureEncoderWithRetry 回退。
  5. 2K/4K 高码率档开关语义: 开走 HEVC, 关走 AVC。
  6. >80M 时 preferHevc 仍选 AVC(HEVC_PREFERRED_BITRATE_CAP)。
  7. 打分/选择阶段无硬排除 HEVC 候选(黑名单不含 hevc)。

运行: python3 scripts/verify_v6135_sim.py
退出码 0 = 全 PASS。
"""

BLACKLIST = ["vp9", "secure", "decoder", "omx.google", "omx.exynos."]
OLD_BLACKLIST = ["vp9", "hevc", "secure", "decoder", "omx.google", "omx.exynos."]
HEVC_PREFERRED_BITRATE_CAP = 80_000_000
DEFAULT_PREFER_HEVC = True  # v6.7.135: PreferencesManager:46 + QualityParams:110 默认 true

results = []
def check(name, cond, detail=""):
    results.append((name, bool(cond)))
    print(f"[{'PASS' if cond else 'FAIL'}] {name}" + (f" :: {detail}" if detail else ""))


def is_hardware_encoder(name):
    n = name.lower()
    return not any(s in n for s in ("omx.google.", "ffmpeg", "sw.", "software"))


def is_vendor(name):
    n = name.lower()
    return any(s in n for s in ("vendor", "omx.", "c2."))


def score_candidate(name, prefer_hevc):
    """镜像 selectBestVideoEncoder 打分(v6.7.135 压分逻辑,全部 contains ignoreCase)。"""
    n = name.lower()
    is_hevc = "hevc" in n
    is_hw = is_hardware_encoder(name)
    is_vend = is_vendor(name)
    score = 0
    if is_hw: score += 100
    if is_vend: score += 50
    if is_hevc:
        score += 200 if prefer_hevc else -50
    if "qcom" in n: score += 30
    if "exynos" in n: score += 30
    if "mediatek" in n: score += 30
    if "google" in n: score += 10
    return score, is_hevc


def select_best(candidates, prefer_hevc, bitrate):
    """镜像 selectBestVideoEncoder + 码率 cap 逻辑。"""
    scored = [(score_candidate(c, prefer_hevc), c) for c in candidates]
    scored.sort(key=lambda x: x[0][0], reverse=True)
    if prefer_hevc and bitrate > HEVC_PREFERRED_BITRATE_CAP:
        avc = next((c for s, c in scored if not s[1]), None)
        if avc: return avc, "cap-prefer-avc"
    if not scored: return None, "empty"
    return scored[0][1], "score"


def list_candidates(codec_list, blacklist=BLACKLIST):
    """镜像 listAllCodecCandidates。"""
    out = []
    for info in codec_list:
        if not info.get("is_encoder"): continue
        if any(p.lower() in info["name"].lower() for p in blacklist): continue
        if any(m.startswith("video/") for m in info.get("supported_types", [])):
            out.append(info["name"])
    return list(dict.fromkeys(out))


FLAGSHIP = [
    {"name": "OMX.qcom.video.encoder.avc", "is_encoder": True, "supported_types": ["video/avc"]},
    {"name": "OMX.qcom.video.encoder.hevc", "is_encoder": True, "supported_types": ["video/hevc"]},
    {"name": "c2.qti.hevc.encoder", "is_encoder": True, "supported_types": ["video/hevc"]},
    {"name": "OMX.google.h264.encoder", "is_encoder": True, "supported_types": ["video/avc"]},
    {"name": "OMX.google.hevc.encoder", "is_encoder": True, "supported_types": ["video/hevc"]},
]

HEVC_ONLY = [
    {"name": "OMX.qcom.video.encoder.hevc", "is_encoder": True, "supported_types": ["video/hevc"]},
]

# ---- 1. 打分值实证: 压分后 AVC 胜出 ----
s_hevc_off = score_candidate("OMX.qcom.video.encoder.hevc", False)[0]
s_avc = score_candidate("OMX.qcom.video.encoder.avc", False)[0]
check("preferHevc=false: HEVC 得分 130(100+50-50+30)", s_hevc_off == 130, f"实际 {s_hevc_off}")
check("AVC 得分 180(100+50+30)", s_avc == 180, f"实际 {s_avc}")
check("preferHevc=false: AVC(180) > HEVC(130) 明确胜出", s_avc > s_hevc_off,
      f"AVC={s_avc} HEVC={s_hevc_off}")

s_hevc_on = score_candidate("OMX.qcom.video.encoder.hevc", True)[0]
check("preferHevc=true: HEVC 得分 380(100+50+200+30) > AVC 180",
      s_hevc_on == 380 and s_hevc_on > s_avc, f"HEVC={s_hevc_on} AVC={s_avc}")

# ---- 2. 选择结果 ----
cands = list_candidates(FLAGSHIP)
sel_off, why_off = select_best(cands, False, 40_000_000)
check("关闭 HEVC 开关选中 AVC 编码器",
      "avc" in sel_off.lower() and "hevc" not in sel_off.lower(),
      f"选中: {sel_off} (原因: {why_off})")
check("选中具体为 OMX.qcom.video.encoder.avc", sel_off == "OMX.qcom.video.encoder.avc",
      f"实际: {sel_off}")

sel_on, _ = select_best(cands, True, 40_000_000)
check("开启 HEVC 开关选中 HEVC 编码器", "hevc" in sel_on.lower(), f"选中: {sel_on}")
check("开启选中硬编 HEVC(非软编 omx.google)", "omx.google" not in sel_on.lower(), f"选中: {sel_on}")

# ---- 3. 默认开关为 true ----
check("默认 preferHevc=true(PreferencesManager:46 / QualityParams:110)",
      DEFAULT_PREFER_HEVC is True, f"默认值: {DEFAULT_PREFER_HEVC}")

# ---- 4. 仅 HEVC 可用设备: 关闭开关仍能选出编码器(不空选/不崩溃) ----
# 源码侧: selectBestVideoEncoder(false) 返回 HEVC(唯一候选, score=100+50-50+30=130,无 AVC 对比),
# 随后 configureEncoderWithRetry:1358-1370 HEVC configure 失败自动切 AVC;若无 AVC 走 selectBestVideoEncoder(false) 兜底(:1316)。
h_only = list_candidates(HEVC_ONLY)
sel_h, _ = select_best(h_only, False, 40_000_000)
check("仅 HEVC 可用设备关闭开关仍选出编码器(不空选)", sel_h is not None,
      f"选中: {sel_h}")
check("该场景不崩溃(返回非 None,后续由 configureEncoderWithRetry 兜底)",
      sel_h == "OMX.qcom.video.encoder.hevc", f"选中: {sel_h}")

# ---- 5. 2K/4K 高码率档开关语义 ----
sel_2k_on, _ = select_best(cands, True, 70_000_000)
sel_2k_off, _ = select_best(cands, False, 70_000_000)
check("2K/70M 开启走 HEVC", "hevc" in sel_2k_on.lower(), f"选中: {sel_2k_on}")
check("2K/70M 关闭走 AVC", "avc" in sel_2k_off.lower() and "hevc" not in sel_2k_off.lower(),
      f"选中: {sel_2k_off}")
sel_4k_on, _ = select_best(cands, True, 80_000_000)
sel_4k_off, _ = select_best(cands, False, 80_000_000)
check("4K/80M 开启走 HEVC", "hevc" in sel_4k_on.lower(), f"选中: {sel_4k_on}")
check("4K/80M 关闭走 AVC", "avc" in sel_4k_off.lower() and "hevc" not in sel_4k_off.lower(),
      f"选中: {sel_4k_off}")

# ---- 6. >80M cap 分支保留 ----
sel_90, why_90 = select_best(cands, True, 90_000_000)
check("码率>80M 开启仍选 AVC(HEVC_PREFERRED_BITRATE_CAP 分支保留)",
      "avc" in sel_90.lower() and why_90 == "cap-prefer-avc",
      f"选中: {sel_90} (原因: {why_90})")

# ---- 7. 无硬排除: 黑名单不含 hevc,HEVC 候选不被打分阶段过滤 ----
check("黑名单不含 hevc(打分/选择阶段无硬排除)", "hevc" not in BLACKLIST, f"黑名单: {BLACKLIST}")
check("黑名单仍过滤 vp9/secure/decoder/omx.google/omx.exynos.",
      all(p in BLACKLIST for p in ["vp9", "secure", "decoder", "omx.google", "omx.exynos."]),
      f"黑名单: {BLACKLIST}")
check("HEVC 编码器在候选池(未被硬排除)",
      any("hevc" in c for c in cands),
      f"候选池 HEVC: {[c for c in cands if 'hevc' in c]}")

print("\n" + "=" * 60)
passed = sum(1 for _, ok in results if ok)
total = len(results)
print(f"结果: {passed}/{total} PASS")
if passed == total:
    print("SIM-VERIFY PASS (v6.7.135)")
    exit(0)
else:
    print("SIM-VERIFY FAIL")
    for name, ok in results:
        if not ok:
            print(f"  失败: {name}")
    exit(1)
