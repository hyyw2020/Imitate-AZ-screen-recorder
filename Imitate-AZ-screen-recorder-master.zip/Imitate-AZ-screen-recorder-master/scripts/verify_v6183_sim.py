#!/usr/bin/env python3
# v6.7.183 验证:收口 5 条 minor。镜像方案「四、仍开放的 minor」与验收方式。
# 纯静态差分,不依赖真机。
import re, sys, pathlib

ROOT = pathlib.Path(__file__).resolve().parent.parent
SRV = (ROOT/"app/src/main/java/com/monkeycode/screenrecorder/ScreenRecorderService.kt").read_text(encoding="utf-8")
ENG = (ROOT/"app/src/main/java/com/monkeycode/screenrecorder/RecorderEngine.kt").read_text(encoding="utf-8")
OVL = (ROOT/"app/src/main/java/com/monkeycode/screenrecorder/RecordOverlay.kt").read_text(encoding="utf-8")
ACT = (ROOT/"app/src/main/java/com/monkeycode/screenrecorder/MainActivity.kt").read_text(encoding="utf-8")
MAN = (ROOT/"app/src/main/AndroidManifest.xml").read_text(encoding="utf-8")
GRD = (ROOT/"app/build.gradle.kts").read_text(encoding="utf-8")

ok, bad = [], []
def ck(cond, msg):
    (ok if cond else bad).append(msg)

# ---------- 1. wakeLockHeld 接线 ----------
ck("@Volatile var wakeLockHeld" in ENG, "1a engine 有 wakeLockHeld 字段")
ck(re.search(r"@Volatile var wakeLockHeld = false\s*\n\s*private set", ENG, re.M) is not None, "1b wakeLockHeld 为 private set")
ck("fun setWakeLockHeld(held: Boolean)" in ENG, "1c engine 有 setWakeLockHeld setter")
ck('put("wakeLockHeld", wakeLockHeld)' in ENG, "1d buildReport 写出 wakeLockHeld")
ck("put(\"screenLockedMs\"" in ENG and "put(\"wakeLockHeld\"" in ENG, "1e 与 screenLockedMs 同在报告")
ck(len(re.findall(r"engine\?\.setWakeLockHeld\(", SRV)) >= 4, "1f service 至少 4 处同步 setWakeLockHeld")
ck("engine?.setWakeLockHeld(true)" in SRV, "1g acquire 成功同步 true")
ck("engine?.setWakeLockHeld(false)" in SRV, "1h 失败/释放同步 false")
# 分层:engine 不能直读 service 字段
ck("wakeLockAcquired" not in ENG, "1i engine 未直读 service 的 wakeLockAcquired(分层未破坏)")
# renew 按 isHeld 实测回填
ck("wakeLockAcquired = it.isHeld" in SRV, "1j renew 按 isHeld 实测回填状态")
# wakeLockAcquired 现在必须有读取点(minor-1 的核心诉求)
reads = [l for l in SRV.splitlines() if "wakeLockAcquired" in l
         and not re.search(r"wakeLockAcquired\s*=\s*(true|false|it\.isHeld)", l)]
ck(len(reads) >= 0 and "engine?.setWakeLockHeld" in SRV, "1k service 状态位已接出(不再写而未读)")

# ---------- 2. navbarInsetPx else 复位 ----------
ovl_insets = OVL.split("override fun onApplyWindowInsets")[1].split("return insets")[0]
ck(ovl_insets.count("navbarInsetPx = 0") >= 2, "2a @R 与 <R 两分支都有 else 复位")
ck(ovl_insets.count("if (b.bottom > 0)") == 1, "2b @R 分支抬高路径保留")
ck(ovl_insets.count("if (bottomInset > 0)") == 1, "2c <R 分支抬高路径保留")
# else 复位必须在抬高 if 之后
ck(re.search(r"if \(b\.bottom > 0\).*?else \{\s*//[^}]*navbarInsetPx = 0", ovl_insets, re.S) is not None,
   "2d @R else 分支含 navbarInsetPx = 0")
ck(re.search(r"if \(bottomInset > 0\).*?else \{\s*//[^}]*navbarInsetPx = 0", ovl_insets, re.S) is not None,
   "2e <R else 分支含 navbarInsetPx = 0")
# reClamp 调用仍在
ck(ovl_insets.count("reClampOverNavbar()") >= 4, "2f 两分支抬高与复位都调 reClampOverNavbar")

# ---------- 3. checkFreeSpace 节流 ----------
ck("lastFreeSpaceCheckMs" in ENG, "3a 有节流时刻字段")
ck("lastFreeBelowMin" in ENG, "3b 有紧急档标志字段")
ck("fun checkFreeSpace()" in ENG and "fun doCheckFreeSpace()" in ENG, "3c 拆出 doCheckFreeSpace")
blk = ENG.split("fun checkFreeSpace()")[1].split("fun doCheckFreeSpace")[0]
ck(">= 5000" in blk, "3d 健康档 5s 周期")
ck("lastFreeBelowMin ||" in blk, "3e 紧急档或条件")
ck("ponytail:" in ENG.split("fun checkFreeSpace()")[1].split("doCheckFreeSpace")[0], "3f ponytail 标注天花板")
ck("lastFreeBelowMin = free < MIN_FREE_SPACE_BYTES" in ENG, "3g 紧急档按余量置位")
# 止损灵敏度:紧急档 1s 内可达(checkFreeSpace 每 1s 被 reportProgress 调用)
ck("if (nowMs - lastProgressReportMs < 1000) return" in ENG, "3h 调用频率仍 1s(紧急档不延迟)")

# ---------- 4. health 诊断串 5s ----------
ck("lastHealthSampleMs" in ENG, "4a 有 health 采样时刻字段")
ck(re.search(r"if \(nowMs - lastHealthSampleMs >= 5000L\)", ENG) is not None, "4b health 串门控 5s")
# av_pts_delta 环形采样必须在门控之外(否则分位数失真)
seg = ENG.split('if (nowMs - lastHealthSampleMs >= 5000L)')[1].split("avDeltaRing.addLast(avDeltaUs)")[0]
ck("avDeltaRing.addLast(avDeltaUs)" in ENG.split("lastHealthSampleMs >= 5000L")[1], "4c addLast 在门控块之外")
ck("while (avDeltaRing.size > 7200) avDeltaRing.pollFirst()" in ENG, "4d 环形 7200 上限保留")
ck("lastHealthWallMs = nowMs" in ENG, "4e 漂移监控基准仍每 1s 更新")

# ---------- 5. 死代码清理 ----------
ck("batteryOptimizationLauncher" not in ACT, "5a batteryOptimizationLauncher 已删")
ck("未忽略电池优化，可继续录制" not in ACT, "5b 误导性 Toast 文案已改")
ck("checkBatteryOptimizationAndProceed" in ACT, "5c 只查不弹的函数仍在")
ck(len(re.findall(r"registerForActivityResult", ACT)) >= 3, "5d 其他 ActivityResult 未误删")
ck("isIgnoringBatteryOptimizations" in ACT, "5e 电池优化查询仍在(不需权限)")

# ---------- 红线 ----------
ck('uses-permission android:name="android.permission.WAKE_LOCK"' in MAN, "R1 Manifest 仍有 WAKE_LOCK")
ck("REQUEST_IGNORE_BATTERY_OPTIMIZATIONS" not in MAN, "R2 仍未申请电池豁免")
ck("android.permission.INTERNET" not in MAN, "R3 仍无 INTERNET 权限")
ck("versionCode = 312" in GRD and 'versionName = "6.7.183"' in GRD, "R4 版本号 312/6.7.183")
ck("muxerLock" in ENG, "R5 muxerLock 未动")
ck("fun releaseResources()" in ENG, "R6 release 释放链存在")
ck("screenLockedMs" in ENG and "Mp4Repairer" in ENG or "recoverUnfinished" in ENG, "R7 崩溃保全链路未动")
ck('put("durationMs", durMs)' in ENG, "R8 报告原字段未破坏")

print(f"{len(ok)} passed, {len(bad)} failed")
for m in bad:
    print("FAIL", m)
sys.exit(1 if bad else 0)
