#!/usr/bin/env python3
# v6.7.191 静态断言:7 个 P0(重锚方向/尾部裁剪切点/累积解耦/自证断言/PTS 熔断/
# effectiveCaptureFps 审计/reanchor 日志) + P0-6 .idx 保命 + P0-7 boost 地板
import re, sys

ROOT = "/workspace/app/src/main/java/com/monkeycode/screenrecorder"
def rd(p):
    with open(p, encoding="utf-8") as f: return f.read()

eng = rd(f"{ROOT}/RecorderEngine.kt")
main = rd(f"{ROOT}/MainActivity.kt")
svc = rd(f"{ROOT}/ScreenRecorderService.kt")

fails = []
def ck(name, cond):
    if not cond: fails.append(name)
    print(("PASS " if cond else "FAIL ") + name)

# ===== 结构守门:整文件括号平衡必须为 0 =====
# v6.7.191 开发中曾漏掉一个 "}",导致类体被整体降级为局部作用域,
# 编译器报出数百条 "Unresolved reference 'logDetail'" 且首错定位在 start()。
# 这条断言把那种失败从"数百条噪音"收敛为一条明确的 FAIL。
bal = 0
for line in eng.splitlines():
    for ch in line:
        if ch == "{": bal += 1
        elif ch == "}": bal -= 1
ck("结构 括号平衡为0", bal == 0)

# ===== P0-1 重锚方向修正(符号语义必须写在代码里)=====
# avDeltaUs = video - audio;为正 = 视频超前 = 音频滞后,需把音频 PTS 推大,故为 +=。
# computeAvDiffUs() 返回 (aFirst - vFirst),与本量符号相反,取反号会反向放大。
ck("P0-1 方向为 +=", "audioPtsOffsetUs += step" in eng)
ck("P0-1 符号语义注释", "avDeltaUs = video - audio" in eng or "video-audio" in eng)
ck("P0-1 与 computeAvDiffUs 取反说明", "取反号就是反向放大" in eng)
# 方向注释必须紧贴字段(在本仓里位于字段上方),避免日后有人照搬 computeAvDiffUs 语义改回 -="
_i = eng.index("audioPtsOffsetUs = 0L")
fld = eng[max(0, _i - 600):_i + 200]
ck("P0-1 字段旁符号注释", "avDeltaUs = video - audio" in fld)

# ===== P0-2 尾部裁剪切点(时长真值改用真正写入 muxer 的最后一帧)=====
ck("P0-2 lastMuxedVideoPtsUs 字段", "private var lastMuxedVideoPtsUs" in eng)
ck("P0-2 videoFirstMuxedPtsUs 字段", "private var videoFirstMuxedPtsUs" in eng)
ck("P0-2 写入成功后记录", eng.index("lastMuxedVideoPtsUs = wallClockVidPtsUs") > eng.index("writeSampleData(videoTrackIndex"))
ck("P0-2 首帧锚点条件置位", "if (videoFirstMuxedPtsUs < 0L)" in eng)
ck("P0-2 写入点注释指出 lastVideoFrameTimeUs 不可用", "lastVideoFrameTimeUs 在 shouldDropVideoPts" in eng)
calc = eng[eng.index("private fun calculateDuration"):eng.index("private data class SafCopyResult")]
ck("P0-2 时长用写入跨度", "lastMuxedVideoPtsUs - videoFirstMuxedPtsUs" in calc)
ck("P0-2 muxed 日志", "muxed=" in eng and "tailOverrunMs=" in eng)
# lastVideoFrameTimeUs 允许出现在 calculateDuration:它只用于 tailOverrunUs 诊断(P0-4),
# 且注释里也提到它。断言点是 durationUs 的赋值语句本身不再由它推导 ——
# 所以窗口取"从 vSpanUs 定义到 durationUs 赋值"这段纯代码,避开上方注释。
_vs = calc.index("val vSpanUs = ")
_du = calc.index("var durationUs = 0L")
ck("P0-2 durationUs 不取 lastVideoFrameTimeUs", "lastVideoFrameTimeUs" not in calc[_vs:_du])

# ===== P0-3 累积与触发解耦 =====
# 告警独立于重锚;累积移出 200ms 门;触发后清零;else 分支滞回清零防抖动。
ck("P0-3 avCumulativeWarned 独立", "avCumulativeWarned" in eng)
ck("P0-3 滞回清零", "kotlin.math.abs(avDriftAccumUs) < 50_000L" in eng)
ck("P0-3 触发后清零", "avDriftAccumUs = 0L" in eng)
ck("P0-3 累积器字段", "private var avDriftAccumUs = 0L" in eng)
ck("P0-3 av_drift_window 日志", 'logDetail("av_drift_window"' in eng)

# ===== P0-4 自证式断言改为跨坐标系 =====
# 190 的 durationDivergedMs 是同源自减(恒 0),属自证式断言,无诊断价值。
# 断言点是"不再作为日志字段输出"(源码里保留一条解释性注释说明为何替换,这不算回退)。
ck("P0-4 移除 durationDivergedMs 日志字段", "durationDivergedMs=" not in eng)
ck("P0-4 tailOverrunMs 为跨坐标系", "tailOverrunMs" in eng)
ck("P0-4 自证断言说明注释", "同源自减" in eng)

# ===== P0-5 PTS 钳制熔断 =====
ck("P0-5 pts_clock_fuse 日志", 'logDetail("pts_clock_fuse"' in eng)
ck("P0-5 熔断计数字段", "ptsClockFuseCount" in eng)
ck("P0-5 熔断阈值 3 个帧间隔", "frameIntervalUs0 * 3" in eng)
ck("P0-5 熔断走墙钟", "ptsClockFuseCount++" in eng)
ck("P0-5 熔断说明注释", "虚高熔断" in eng)
ck("P0-5 learn_report 输出熔断数", "ptsClockFuse=" in eng)
# 熔断分支必须显式返回 Long(语句与表达式混排会让分支推断为 Unit 与其余分支冲突)
fuse = eng[eng.index("val selfPtsUs = if (rawPtsUs >= lastWrittenPtsUs)"):eng.index("lastVideoFrameTimeUs = selfPtsUs")]
ck("P0-5 三分支齐全", fuse.count("} else") >= 2)
ck("P0-5 熔断分支语句独立成行",
   "ptsClockFuseCount++\n" in fuse and "count=$ptsClockFuseCount\")\n" in fuse)

# ===== P0-4(方案编号) effectiveCaptureFps 消费审计 =====
# 消费点必须逐个标注口径,避免 120 vs 60 的假值继续污染基数。
ck("P0-4e capture_fps_probe", "capture_fps_probe" in eng and "maxModeHz=" in eng)
ck("P0-4e 当前模式而非最高模式", "val currentHz = disp?.refreshRate ?: 60f" in eng)
ck("P0-4e 消费点审计标记", "审计" in eng and "effectiveCaptureFps" in eng)

# ===== P0-6 reanchor 日志增强 =====
ck("P0-6 reanchor 计数日志", "reanchor=" in eng)
ck("P0-6 av_drift_window 字段", "deltaUs=" in eng and "accumUs=" in eng)
ck("P0-6 偏移量输出", "offsetMs=" in eng)

# ===== P0-6(方案) 单片路径先 probe 再删 .idx =====
# .idx 是 restoreStale 重建 moov 的唯一索引;旧实现在 SAF 拷贝前就删,拷贝失败即不可恢复。
ck("P0-6s segment_single_probe", 'logDetail("segment_single_probe"' in eng)
ck("P0-6s 不可播则保留 idx", 'logDetail("segment_single_keep_idx"' in eng)
mk = eng[eng.index("private fun mergeSegmentsToFinal"):eng.index("private fun ", eng.index("private fun mergeSegmentsToFinal") + 10)]
ck("P0-6s probe 先于删 idx", mk.index("segment_single_probe") < mk.index("merge_single_idx"))
ck("P0-6s 保留分支有 return", "segment_single_keep_idx" in mk and mk.count("return") >= 3)
ck("P0-6s 多片分支先 probe 再删", eng.index("probeRepairedMp4(out)") < eng.index("merge_seg_idx"))

# ===== P0-7 boost 尊重降档地板 =====
ck("P0-7 boost_skip_floor 日志", 'logDetail("boost_skip_floor"' in eng)
ck("P0-7 约束下沉到 applyBoost",
   "if (downgradeActive && downgradeFloor > 0L)" in eng)
ck("P0-7 不修改降档地板本身",
   "boost_skip_floor" in eng and "downgradeFloor > 0L" in eng)
ab = eng[eng.index("private fun applyBoost(factor"):eng.index("private fun checkFrameRateHealth")]
ck("P0-7 守卫在函数内", "downgradeMinBitrate" in ab)
ck("P0-7 地板不变式未被改写", "downgradeMinBitrate = target.toLong()" in ab)

# ===== P0-4(方案) 停顿时间/帧双账 =====
ck("P0-4t stallPtsTotalUs 字段", "private var stallPtsTotalUs = 0L" in eng)
ck("P0-4t stallMissingFrames 字段", "private var stallMissingFrames = 0L" in eng)
ck("P0-4t 双口径汇总", "lostWall=" in eng and "lostPts=" in eng and "missingFrames=" in eng)
ck("P0-4t 旧单口径已移除", '"lost=${(stallTotalUs' not in eng)
ck("P0-4t PTS 间隔口径注释", "只有 ptsGap 才等于" in eng)
ck("P0-4t 字符串插值正确", "ptsGap=${stallPtsGapUs}us" in eng and "stallPtsGapUsus" not in eng)
ck("P0-4t 缺帧数下限为 0", "(stallExpectedFrames - 1L).coerceAtLeast(0L)" in eng)

# ===== 重置区:新增统计必须跨录制归零 =====
rst = eng[eng.index("this.ptsClockFuseCount = 0"):eng.index("this.ptsClockFuseCount = 0") + 300]
ck("重置 stallPtsTotalUs", "this.stallPtsTotalUs = 0L" in rst)
ck("重置 stallMissingFrames", "this.stallMissingFrames = 0L" in rst)
ck("重置 videoFirstPtsUs", "this.videoFirstPtsUs = -1L" in eng)
ck("重置 videoFirstMuxedPtsUs", "this.videoFirstMuxedPtsUs = -1L" in eng)
ck("重置 lastMuxedVideoPtsUs", "this.lastMuxedVideoPtsUs = 0L" in eng)

# ===== 不变量:188h/189/190 已修好的部分不得回退 =====
ck("不变 BOOST_FACTOR_MAX", "BOOST_FACTOR_MAX = 1.5" in eng)
ck("不变 restore_stale 不删 idx", "restore_stale_keep" in eng)
ck("不变 BASELINE_PHYSICAL_MAX_C=65", "BASELINE_PHYSICAL_MAX_C = 65" in eng)
ck("不变 SESSION_GATED_IDS", "SESSION_GATED_IDS" in main)
ck("不变 onSegments 先于 onStopped", eng.count("callback?.onSegments") >= 3)
ck("不变 framesDequeued 恒等式", "unattributed=${framesDequeued - writtenFrames - attributedDrops}" in eng)
ck("不变 streak 连续3窗口", "frameDropWindowStreak >= 3" in eng)
ck("不变 effectiveCaptureFps 下限 30", "currentHz.coerceAtLeast(30f)" in eng)
ck("不变 投影取消 Toast", "录屏授权被取消" in main)
ck("不变 cleanup skip 降噪", 'Log.d(TAG, "cleanupAndStop skip' in svc)
ck("不变 视频轨先行", "wait for video track first" in eng)
ck("不变 effectiveMuxBitrate", "effectiveMuxBitrate=$effectiveMuxBitrate" in eng)
ck("不变 sanitize 自适应区间", "BASELINE_FALLBACK_C - BASELINE_ADAPT_RANGE_C" in eng)
ck("不变 capture_fps_probe", "capture_fps_probe" in eng)

print()
if fails:
    print("FAILED:", fails); sys.exit(1)
print("ALL PASS")
