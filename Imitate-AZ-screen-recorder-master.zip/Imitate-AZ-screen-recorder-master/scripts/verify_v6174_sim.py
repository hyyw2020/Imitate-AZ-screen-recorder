#!/usr/bin/env python3
"""v6.7.174 异形屏适配(P0/P1-b/P2-b)验证.

镜像源码逻辑:
  - P0-a RecorderEngine.setupVirtualDisplay: getRealScreenSize 统一 helper +
    scale=cfg.width/物理短边, vdDpi=(realDpi*scale).coerceAtLeast(120)。
  - P0-b ScreenRecorderApp.realScreenSize(context): API30+ WindowMetrics 优先,
    <30 getRealSize 兜底 1080x1920。
  - P2-b BitrateSchedulerConfig.autoBitrate: 新增超长比屏(lang/short>=2.2)补偿 ratioUltraLong=1.1。

验证:
  1. autoBitrate 默认 16:9(1080p) 码率 = 基准×1.6,超长比项=1.0(不补偿)。
  2. 同档位 20:9(1080x2400) 码率 = 16:9 的 110%(ratioUltraLong 生效)。
  3. 未超阈值(19.5:9≈2.167<2.2)不补偿。
  4. 超长比补偿仍受 uiMaxBitrate(80M)封顶。
  5. 4K(16:9)超长比对照:2K fit 幅值不受 aspect 影响(系数按 short 落档 + 补偿)。
  6. vdDpi 折算: scale<1 时 dpi 成比例缩小,coerceAtLeast(120) 兜底。

运行: python3 scripts/verify_v6174_sim.py
退出码 0 = 全 PASS。
"""

BASE = 15_000_000
RATIO = {480: 0.4, 720: 0.8, 1080: 1.6, 1440: 4.666, 2160: 4.866}
FPS60 = 1.428
UI_MAX = 80_000_000
ULTRA_TH = 2.2
ULTRA_R = 1.1


def auto_bitrate(width, height, fps=30, hevc=False, hdr=False):
    short = height if width <= 0 else min(width, height)
    # 镜像源码 when: 从高向低命中(>=2160 4.866, >=1440 4.666, >=1080 1.6, ...)
    res_ratio = RATIO[2160]
    for k in sorted(RATIO, reverse=True):
        if short >= k:
            res_ratio = RATIO[k]
            break
    fps_ratio = FPS60 if fps >= 60 else 1.0
    hevc_ratio = 1.0
    hdr_ratio = 1.0
    ultra = 1.0
    if width > 0 and height > 0:
        long_ = max(width, height)
        short_ = min(width, height)
        if short_ > 0 and long_ / short_ >= ULTRA_TH:
            ultra = ULTRA_R
    raw = int(BASE * res_ratio * fps_ratio * hevc_ratio * hdr_ratio * ultra)
    return min(raw, UI_MAX)


def vd_dpi(physical_short, cfg_width, cfg_height, real_dpi):
    # v6.7.175: 分子用画布短边(横竖屏方向无关)。旧逻辑直接 cfg_width,横屏(画布宽=长边)会算偏大。
    canvas_short = min(cfg_width, cfg_height)
    scale = canvas_short / physical_short
    if scale >= 1:
        return real_dpi
    return max(int(real_dpi * scale), 120)


results = []
def check(name, cond, detail=""):
    results.append((name, bool(cond)))
    print(f"[{'PASS' if cond else 'FAIL'}] {name}" + (f" :: {detail}" if detail else ""))


# ---- 1. 16:9 不补偿 ----
b169 = auto_bitrate(1920, 1080)
check("16:9 1080p 码率 = 基准×1.6", b169 == int(BASE * RATIO[1080]), f"{b169}")
check("16:9 超长比项=1.0(不补偿)", b169 == int(BASE * RATIO[1080] * 1.0), f"{b169}")

# ---- 2. 20:9 补偿 110% ----
b209 = auto_bitrate(1080, 2400)
check("20:9 1080p 码率 = 16:9 的 110%", b209 == int(b169 * ULTRA_R), f"{b209} vs {b169}")
check("20:9 超长比补偿生效", b209 > b169, f"{b209}>{b169}")

# ---- 3. 19.5:9 未超阈值(2.167<2.2) ----
b195 = auto_bitrate(1080, 2340)
check("19.5:9(2.167<2.2)不补偿", b195 == b169, f"{b195}=={b169}")

# ---- 4. 超长比补偿后不破封顶 ----
b4k_ultra = auto_bitrate(2160, 9600)
check("超长比 4K 补偿仍 ≤ 80M 封顶", b4k_ultra <= UI_MAX, f"{b4k_ultra}")

# ---- 5. 档位按 short 落 + 补偿(1440x3200≈20:9) ----
b1440 = auto_bitrate(1440, 3200)
check("1440p 20:9 落在 2K 档并 110% 补偿", b1440 == int(BASE * RATIO[1440] * ULTRA_R), f"{b1440}")

# ---- 6. vdDpi 折算 ----
check("scale>=1 时 dpi 不缩(1.0x)", vd_dpi(1080, 2400, 2400, 440) == 440, "原始 dpi 透传")
check("scale<1 时 dpi 成比例降(480/1080)", vd_dpi(1080, 480, 2400, 440) == int(440 * 480 / 1080), f"{vd_dpi(1080,480,2400,440)}")
check("scale 过小兜底 120(120dp)", vd_dpi(1440, 320, 2400, 440) >= 120, f"{vd_dpi(1440,320,2400,440)}")
# v6.7.175: 横屏修复验证 —— 横屏画布(宽>高)取下短边做分子,scale 应为画布短边/物理短边,不再用画布长边。
check("横屏画布宽=2400 高=480: 分子取短边480,scale=0.444", vd_dpi(1080, 2400, 480, 440) == int(440 * 480 / 1080), f"{vd_dpi(1080,2400,480,440)}")
check("旧逻辑(直接用宽 2400)若保留会在横屏算偏大(对照断言)", vd_dpi(1080, 2400, 480, 440) != int(440 * 2400 / 1080), "旧 bug 分支已被短边分母取代")

print("\n" + "=" * 60)
passed = sum(1 for _, ok in results if ok)
total = len(results)
print(f"结果: {passed}/{total} PASS")
if passed == total:
    print("SIM-VERIFY PASS (v6.7.174)")
    exit(0)
else:
    print("SIM-VERIFY FAIL")
    for name, ok in results:
        if not ok:
            print(f"  失败: {name}")
    exit(1)