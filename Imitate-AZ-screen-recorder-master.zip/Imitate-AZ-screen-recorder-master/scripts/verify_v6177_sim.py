#!/usr/bin/env python3
"""v6.7.177 增量 A(全局限额)+ C(B帧钉死)验证.

镜像源码逻辑:
  - A-4 写路径限额检测 (RecorderEngine :6058-6079):
      autoStopReason==null 且 cfg!=null 且 (recLimitBytes>0 || recLimitDurationMs>0)
      时,按 1s 节流(elapsedRealtime)采样 totalBytes=getTotalSegmentBytes() 与
      elapsedMs=nowMs-recordingT0Us。命中规则(bytes 优先于 duration):
        recLimitBytes>0 且 totalBytes>=recLimitBytes      -> "limitBytes"
        elif recLimitDurationMs>0 且 elapsedMs>=recLimitDurationMs -> "limitDuration"
  - A-6 stopAsync 最终原因 (RecorderEngine :4104): finalStopReason = autoStopReason ?: "user"
    —— 自动收尾原因优先于默认 "user",手动停止(autoStopReason==null)仍是 "user"。
  - C-1 createVideoFormat (RecorderEngine :2023): setInteger(KEY_MAX_B_FRAMES, 0),
    包 try/catch,编码器忽略时不崩。
  - C-2 handleOutputFormatChanged 回读 (:6214-6215):
      actualB = if newFormat.containsKey(KEY_MAX_B_FRAMES) else 0,缺失兜底 0。

验证不变式:
  1. 双 0(默认) -> 不检测、autoStopReason 保持 null、原因仍是 "user"。
  2. 仅字节限额且未达 -> 不触发。
  3. 字节达标 -> "limitBytes"(即使时长也达标,bytes 优先)。
  4. 仅时长达标 -> "limitDuration"。
  5. 1s 节流:同 1s 内多次采样只判定一次,不重复覆盖。
  6. autoStopReason 首次置位后不再被覆盖(即使后续仍命中另一条件)。
  7. C 回读:format 缺失 KEY_MAX_B_FRAMES 时 actualB=0(不抛异常)。
  8. C 回读:format 含 KEY_MAX_B_FRAMES=0 时 actualB=0(钉死生效)。

运行: python3 scripts/verify_v6177_sim.py
退出码 0 = 全 PASS。
"""

results = []
def check(name, cond, detail=""):
    results.append((name, bool(cond)))
    print(f"[{'PASS' if cond else 'FAIL'}] {name}" + (f" :: {detail}" if detail else ""))


def limit_check(auto_stop_reason, rec_limit_bytes, rec_limit_duration_ms,
                total_bytes, elapsed_ms, now_ms, limit_check_last_ms):
    """镜像 A-4:返回 (autoStopReason, limitCheckLastMs)。"""
    if auto_stop_reason is not None:
        return auto_stop_reason, limit_check_last_ms
    if rec_limit_bytes <= 0 and rec_limit_duration_ms <= 0:
        return auto_stop_reason, limit_check_last_ms
    if now_ms - limit_check_last_ms < 1000:      # 1s 节流
        return auto_stop_reason, limit_check_last_ms
    limit_check_last_ms = now_ms
    if rec_limit_bytes > 0 and total_bytes >= rec_limit_bytes:
        auto_stop_reason = "limitBytes"
    elif rec_limit_duration_ms > 0 and elapsed_ms >= rec_limit_duration_ms:
        auto_stop_reason = "limitDuration"
    return auto_stop_reason, limit_check_last_ms


def final_stop_reason(auto_stop_reason):
    """镜像 A-6 :4104。"""
    return auto_stop_reason if auto_stop_reason is not None else "user"


def readback_bframes(new_format):
    """镜像 C-2 :6214-6215。"""
    return new_format.get("KEY_MAX_B_FRAMES", 0)


# 1. 双 0 默认 -> 不触发,原因仍 user
r, _ = limit_check(None, 0, 0, total_bytes=10 ** 12, elapsed_ms=10 ** 9, now_ms=5000, limit_check_last_ms=0)
check("默认双0不触发检测", r is None and final_stop_reason(r) == "user")

# 2. 仅字节限额未达 -> 不触发
r, _ = limit_check(None, 1000, 0, total_bytes=500, elapsed_ms=99999, now_ms=5000, limit_check_last_ms=0)
check("字节未达不触发", r is None)

# 3. 字节达标 -> limitBytes,且优先于时长
r, _ = limit_check(None, 1000, 1000, total_bytes=1500, elapsed_ms=2000, now_ms=5000, limit_check_last_ms=0)
check("字节达标触发 limitBytes(优先于时长)", r == "limitBytes")

# 4. 仅时长达标 -> limitDuration
r, _ = limit_check(None, 0, 1000, total_bytes=500, elapsed_ms=2000, now_ms=5000, limit_check_last_ms=0)
check("时长达标触发 limitDuration", r == "limitDuration")

# 5. 1s 节流:同 1s 内第二次采样不重复判定
r1, t1 = limit_check(None, 0, 0, 10 ** 12, 10 ** 9, now_ms=5000, limit_check_last_ms=0)
r2, t2 = limit_check(None, 0, 0, 10 ** 12, 10 ** 9, now_ms=5500, limit_check_last_ms=t1)
check("1s 节流抑制重复判定", r1 is None and r2 is None and t2 == t1)

# 6. 首次置位后不被覆盖(先命中 bytes,后续再采样不改成 duration)
r1, t1 = limit_check(None, 1000, 0, total_bytes=2000, elapsed_ms=999999, now_ms=5000, limit_check_last_ms=0)
r2, _ = limit_check(r1, 0, 1000, total_bytes=0, elapsed_ms=999999, now_ms=9000, limit_check_last_ms=t1)
check("reason 首次置位后不被覆盖", r1 == "limitBytes" and r2 == "limitBytes")

# 7. C 回读:缺失 key 兜底 0(不抛异常)
check("回读缺失 KEY_MAX_B_FRAMES 兜底 0", readback_bframes({}) == 0)

# 8. C 回读:含 key=0 时 actualB=0(钉死生效)
check("回读 KEY_MAX_B_FRAMES=0 生效", readback_bframes({"KEY_MAX_B_FRAMES": 0}) == 0)

# 9. 手动停止(autoStopReason 始终 null) -> "user"
check("手动停止原因仍 user", final_stop_reason(None) == "user")

# 10. 自动收尾(VD 断开)原因 vdStopped 优先
check("VD 断开收尾原因 vdStopped", final_stop_reason("vdStopped") == "vdStopped")

# 11. 双限额均设:时长先达也仍按 bytes 优先判定(仅当 bytes 同时达标)
r, _ = limit_check(None, 100, 500, total_bytes=50, elapsed_ms=600, now_ms=5000, limit_check_last_ms=0)
check("bytes 未达时时长达标触发 limitDuration", r == "limitDuration")

# 12. 边界:totalBytes == 限额(>=) 触发
r, _ = limit_check(None, 1000, 0, total_bytes=1000, elapsed_ms=0, now_ms=5000, limit_check_last_ms=0)
check("bytes 等于限额(>=)触发", r == "limitBytes")

# 13. 边界:elapsedMs == 限额(>=) 触发
r, _ = limit_check(None, 0, 1000, total_bytes=0, elapsed_ms=1000, now_ms=5000, limit_check_last_ms=0)
check("时长等于限额(>=)触发", r == "limitDuration")

failed = [n for n, ok in results if not ok]
print(f"\n{len(results) - len(failed)}/{len(results)} PASS")
if failed:
    print("FAIL: " + ", ".join(failed))
raise SystemExit(1 if failed else 0)
