#!/usr/bin/env python3
"""v6.7.176 BUG-边角-1 修复验证: 末段 .idx 命名对齐。

镜像源码逻辑:
  - switchSegment (非末段封口, :4842-4849): oldF.renameTo(finalF) 后
    File(oldFile+".idx").renameTo(File(finalF.absolutePath+".idx"))。
  - closeLastSegment (末段封口, :5081+ 修复后): oldF.renameTo(finalF) 后
    File(oldF.absolutePath+".idx").renameTo(File(finalF.absolutePath+".idx"))。
  - idxFileFor(seq) (:5059-5063): 返回 segFinalName(seq)+".idx"。

修复前 bug: closeLastSegment 只改 .mp4,末段索引停留 seg_N.mp4.tmp.idx,
idxFileFor 查 seg_N.mp4.idx → mergeSegmentsToFinal 对末段找不到 → 合并失败碎片残留。

验证不变式: closeLastSegment 修复后,末段最终 .idx 目标 = finalName+".idx" = idxFileFor(seq)。
即 merge 按 idxFileFor 查,能够定位到末段索引 —— 命名收敛为一套。

运行: python3 scripts/verify_v6176_sim.py
退出码 0 = 全 PASS。
"""

results = []
def check(name, cond, detail=""):
    results.append((name, bool(cond)))
    print(f"[{'PASS' if cond else 'FAIL'}] {name}" + (f" :: {detail}" if detail else ""))


BASE = "/sdcard/Android/data/app/Movies"

def seg_old_path(base, seq):
    # 写入期分片名: seg_<seq>.mp4.tmp
    return f"{base}/seg_{seq}.mp4.tmp"

def seg_final_name(base, seq):
    # segFinalName: 封口后最终名
    return f"{base}/seg_{seq}.mp4"

def idx_file_for(base, seq):
    # idxFileFor(seq): 永远 finalName+".idx"
    return seg_final_name(base, seq) + ".idx"

def switch_segment_rename(old_file_mp4, final_mp4, seq):
    """非末段封口 (switchSegment): mp4 + idx 同步改名。"""
    old_idx = old_file_mp4 + ".idx"
    new_idx = final_mp4 + ".idx"
    return new_idx  # 改名后 idx 所在路径

def close_last_segment_fixed(old_mp4, final_mp4, seq):
    """修复后的末段封口 (closeLastSegment): mp4 + idx 同步改名。"""
    old_idx = old_mp4 + ".idx"
    new_idx = final_mp4 + ".idx"
    return new_idx

# ---- 不变式: 修复后末段 idx 目标 == idxFileFor ----
base = BASE
seq = 3
old_mp4 = seg_old_path(base, seq)
final_mp4 = seg_final_name(base, seq)

fixed_idx = close_last_segment_fixed(old_mp4, final_mp4, seq)
check("修复后末段 .idx 目标 == idxFileFor(seq)(merge 能定位末段索引)",
      fixed_idx == idx_file_for(base, seq),
      f"idx={fixed_idx}")

# ---- 恒等: switchSegment 与 closeLastSegment 修复后行为一致(同构) ----
sw_idx = switch_segment_rename(old_mp4, final_mp4, seq)
check("末段与非末段 .idx 改名目标同构(全部分段命名收拢为一套)",
      sw_idx == fixed_idx == idx_file_for(base, seq))

# ---- 修复前 bug 复现: 旧 closeLastSegment 不改 idx ----
def close_last_segment_old(old_mp4, final_mp4, seq):
    return old_mp4 + ".idx"  # 只回 old idx, 不动

old_behavior_idx = close_last_segment_old(old_mp4, final_mp4, seq)
check("旧逻辑(不改 idx)目标 tmp.idx != idxFileFor —— 证明 bug 存在被本修复取代",
      old_behavior_idx != idx_file_for(base, seq))

# ---- 拒绝 .tmp 残留: 修复后不再有任何末段 .tmp.idx 孤儿 ----
check("修复后 old_mp4+'.idx'(tmp.idx) 不再是末段索引地址(idxFileFor 不再指向它)",
      idx_file_for(base, seq) != old_mp4 + ".idx")

# ---- segFinalName 唯一性: 不同 seq 的 idx 不冲突 ----
idxs = {close_last_segment_fixed(seg_old_path(base, s), seg_final_name(base, s), s) for s in range(1, 6)}
check("5 段各自 idx 路径唯一(互不覆盖)", len(idxs) == 5)

print("\n" + "=" * 60)
passed = sum(1 for _, ok in results if ok)
total = len(results)
print(f"结果: {passed}/{total} PASS")
if passed == total:
    print("SIM-VERIFY PASS (v6.7.176)")
    exit(0)
else:
    print("SIM-VERIFY FAIL")
    for name, ok in results:
        if not ok:
            print(f"  失败: {name}")
    exit(1)