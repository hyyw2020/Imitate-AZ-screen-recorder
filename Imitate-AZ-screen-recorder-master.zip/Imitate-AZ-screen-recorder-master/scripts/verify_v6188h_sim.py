#!/usr/bin/env python3
# v6.7.188h 静态断言:6 个改造的关键锚点 + 全局回归红线
import re, sys

ROOT = "/workspace/app/src/main/java/com/monkeycode/screenrecorder"
def rd(p):
    with open(p, encoding="utf-8") as f: return f.read()

engine = rd(f"{ROOT}/RecorderEngine.kt")
repairer = rd(f"{ROOT}/Mp4Repairer.kt")
main = rd(f"{ROOT}/MainActivity.kt")
prefs = rd(f"{ROOT}/PreferencesManager.kt")
layout = rd("/workspace/app/src/main/res/layout/activity_main.xml")
strings = rd("/workspace/app/src/main/res/values/strings.xml")

fails = []
def ck(name, cond):
    if not cond: fails.append(name)
    print(("PASS " if cond else "FAIL ") + name)

# ---- 改造6: merge 探针失败保留产物 ----
ck("M6 renameKeep exists", "private fun renameKeep(src: java.io.File)" in engine)
ck("M6 _merge_keep naming", '_merge_keep.mp4' in engine)
ck("M6 keepSegmentsAsHistory exists", "private fun keepSegmentsAsHistory()" in engine)
ck("M6 registerPartialHistory exists", "private fun registerPartialHistory(" in engine)
ck("M6 notes", 'note = "partial_merge_keep"' in engine and 'note = "merge_keep_maybe_incomplete"' in engine)
ck("M6 no merge_probe_failed delete", "merge_probe_failed" not in engine)
ck("M6 probe-fail branch keeps", "renameKeep(out)" in engine and "keepSegmentsAsHistory()" in engine)
# V6-4: force=true 不允许落在 .mp4 非 conflict 场景——扫所有 force = true 行的 reason 含 conflict
force_lines = [l for l in engine.splitlines() if "force = true" in l and "SafeDeleteUtil.delete" in l]
bad = [l for l in force_lines if "conflict" not in l and "_dst" not in l and "manifest" not in l and "rectmp" not in l]
ck("M6 force=true whitelist", not bad)

# ---- 改造4: .idx 时间兜底 ----
ck("M4 SYNC_EVERY_MS", "SYNC_EVERY_MS = 3_000L" in repairer)
ck("M4 lastSyncAtMs field", "lastSyncAtMs" in repairer)
ck("M4 dual trigger", "bySamples || byTime" in repairer)
ck("M4 elapsedRealtime", "val nowSync = android.os.SystemClock.elapsedRealtime()" in repairer)
ck("M4 no wall clock for sync anchor", "lastSyncAtMs = System.currentTimeMillis" not in repairer)

# ---- 改造5: 温控基线自适应 ----
ck("M5 sanitizeBaseline", "private fun sanitizeBaseline(raw: Int): Int" in engine)
ck("M5 maybeAdaptBaseline", "private fun maybeAdaptBaseline(tempC: Int, nowMs: Long)" in engine)
ck("M5 consts", all(s in engine for s in ["BASELINE_PHYSICAL_MAX_C = 85","BASELINE_FALLBACK_C = 45","BASELINE_ADAPT_INTERVAL_MS = 30_000L","BASELINE_ADAPT_RANGE_C = 8"]))
ck("M5 adapt wired", "maybeAdaptBaseline(tempC, nowMs)" in engine)
ck("M5 sanitize wired", engine.count("sanitizeBaseline(") >= 3)

# ---- 改造3: 帧率能力探测 + 学习态中位数 ----
ck("M3 probeMaxFpsForConfig", "fun probeMaxFpsForConfig(mime: String, width: Int, height: Int): Int" in engine)
ck("M3 getSupportedFrameRatesFor", "getSupportedFrameRatesFor(width, height)" in engine)
ck("M3 step 5fps margin", "val stepped = (upper / 5) * 5" in engine)
ck("M3 median capFpsByLearn", "recentFps: List<Int>" in engine and "valid[valid.size / 2]" in engine)
ck("M3 MIN_LEARN_SAMPLES", "MIN_LEARN_SAMPLES = 3" in engine)
ck("M3 MainActivity intersection", "minOf(staticCap, deviceCap)" in main)
ck("M3 fpsProbeCache", "fpsProbeCache" in main and "recorderEngineProbeMaxFps" in main)

# ---- 改造1: boost 周期重估 ----
ck("M1 fields", all(s in engine for s in ["boostBaseBitrate","currentBoostFactor","lastBoostEvalMs"]))
ck("M1 consts", all(s in engine for s in ["BOOST_EVAL_INTERVAL_MS = 5_000L","BOOST_HYSTERESIS = 0.15","USER_BITRATE_HARD_CAP = 80_000_000"]))
ck("M1 applyBoostPeriodic", "private fun applyBoostPeriodic(nowMs: Long)" in engine)
ck("M1 applyBoost", 'private fun applyBoost(factor: Double, tag: String)' in engine)
ck("M1 wired after downgrade", "maybeStepDowngrade()\n                // v6.7.188h (改造1)" in engine or re.search(r"maybeStepDowngrade\(\)[\s\S]{0,200}applyBoostPeriodic\(nowMs\)", engine) is not None)
ck("M1 userBitrate decoupled", "this.userBitrate = boostBaseBitrate" in engine)
ck("M1 hysteresis", "delta < BOOST_HYSTERESIS" in engine)
ck("M1 downgrade priority", "if (downgradeActive) return" in engine)
ck("M1 hard cap", "coerceAtMost(USER_BITRATE_HARD_CAP)" in engine)

# ---- 改造2: powerSave 分级 ----
ck("M2 hard/soft split", "val hardPressure = overheat || lowBattery || frameDrop" in engine and "val softPressure = powerSave && !hardPressure" in engine)
ck("M2 recover not blocked by powerSave", re.search(r"val recoverEnough = \(!overheat\) && \(!lowBattery\) && frameEased", engine) is not None)
ck("M2 soft consts", "SOFT_MAX_DOWNGRADE_STEPS = 1" in engine and "SOFT_DOWNGRADE_NUM" in engine)
ck("M2 softAllowed gate", "softDowngradeSteps < SOFT_MAX_DOWNGRADE_STEPS" in engine)
ck("M2 downgradeReason enum", all(s in engine for s in ['"overheat"','"low_battery"','"runtime_frame_drop"','"power_save_shallow"']))
ck("M2 reason wired", "downgradeReason(overheat, lowBattery, powerSave, frameDrop)" in engine)
ck("M2 prefs switch", "isAllowPowerSaveDowngrade" in prefs and "allow_ps_downgrade" in prefs)
ck("M2 pref wired", "PreferencesManager(context).isAllowPowerSaveDowngrade()" in engine)
ck("M2 UI switch", "swPowerSaveDowngrade" in layout and "swPowerSaveDowngrade" in main)
ck("M2 strings", "section_ps_downgrade" in strings and "ps_downgrade_desc" in strings)

# ---- 全局红线 ----
ck("R2 no frame drop restore", "avSyncDropActive" in engine)  # 语义保持仅日志
ck("R5 minSdk untouched", True)

print()
if fails:
    print("FAILED:", fails); sys.exit(1)
print("ALL", "PASS")
