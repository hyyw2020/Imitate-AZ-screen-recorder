#!/usr/bin/env python3
"""v6.7.188c-fix 静态校验:虚假"已保存"+ 自动收回 + 贴边禁点。
继承 verify_v6188c_sim.py 全部断言,追加 F1-F6。"""
import pathlib, subprocess, sys, re

ROOT = pathlib.Path(__file__).resolve().parent.parent
SRC = ROOT / "app/src/main/java/com/monkeycode/screenrecorder"

def rd(rel):
    return (ROOT / rel).read_text(encoding="utf-8")

SERVICE = rd("app/src/main/java/com/monkeycode/screenrecorder/ScreenRecorderService.kt")
MAIN = rd("app/src/main/java/com/monkeycode/screenrecorder/MainActivity.kt")
OVERLAY = rd("app/src/main/java/com/monkeycode/screenrecorder/RecordOverlay.kt")

fails = []
def chk(name, cond, detail=""):
    if cond:
        print(f"PASS  {name}")
    else:
        fails.append(name)
        print(f"FAIL  {name}  {detail}")

# F1 常量
chk("F1a EXTRA_SAVED 常量存在",
    'const val EXTRA_SAVED = "com.monkeycode.screenrecorder.extra.SAVED"' in SERVICE)

# F2 sessionRecorded 字段
chk("F2 sessionRecorded 字段(@Volatile private var)",
    re.search(r"@Volatile\s+private\s+var\s+sessionRecorded\s*=\s*false", SERVICE) is not None)

# F3 handleStart 起点复位
m = re.search(r"setState\(RecordState\.STARTING\)\s*\n\s*sessionRecorded = false", SERVICE)
chk("F3 handleStart 起点复位", m is not None)

# F4 recordToHistory 置 true
m = re.search(
    r"private fun recordToHistory\(.*?\)\s*\{[^}]{0,200}?sessionRecorded = true",
    SERVICE, re.S)
chk("F4 recordToHistory 置位", m is not None)

# F5 cleanupAndStop 广播带出 + 复位
m = re.search(
    r"sendBroadcast\(Intent\(ACTION_RECORDING_STOPPED\)\.setPackage\(packageName\)\s*\n\s*\.putExtra\(EXTRA_SAVED,\s*sessionRecorded\)\)",
    SERVICE)
chk("F5a cleanupAndStop 广播带 EXTRA_SAVED", m is not None)
m2 = re.search(r"writeLog\(\"broadcast recording stopped error", SERVICE)
chk("F5b cleanupAndStop 广播错误日志存在(锚点)", m2 is not None)
# sessionRecorded = false 在广播之后
if m and m2:
    idx_send = SERVICE.find(".putExtra(EXTRA_SAVED, sessionRecorded)")
    idx_reset = SERVICE.find("sessionRecorded = false   // v6.7.188c-fix", idx_send)
    chk("F5c cleanupAndStop 广播后复位", idx_reset > idx_send and idx_reset > 0)
else:
    chk("F5c cleanupAndStop 广播后复位", False, "锚点缺失")

# F6 主 Activity 透传 + saved 守卫
chk("F6a MainActivity 广播接收透传 EXTRA_SAVED",
    "onRecordingStopped(intent.getBooleanExtra(ScreenRecorderService.EXTRA_SAVED, false))" in MAIN)
chk("F6b onRecordingStopped 签名(saved: Boolean = false)",
    "fun onRecordingStopped(saved: Boolean = false)" in MAIN)
chk("F6c onRecordingStopped 条件 saved && lastError 空",
    "if (saved && ScreenRecorderApp.lastError.isNullOrBlank())" in MAIN)

# F7 自动收回
chk("F7a AUTO_RETRACT_MS 常量",
    "private val AUTO_RETRACT_MS = 3000L" in OVERLAY)
chk("F7b updateRecordingState 内 postDelayed(collapseRunnable, AUTO_RETRACT_MS)",
    "mainHandler.postDelayed(collapseRunnable, AUTO_RETRACT_MS)" in OVERLAY)

# F8 贴边禁点
chk("F8 subPauseButton onClick isDocked 守卫",
    re.search(r"onClick\s*=\s*\{\s*\n\s*// v6\.7\.188c-fix:\s*贴边态禁操作子球①[^\n]*\n\s*if \(isDocked\) return@createSubBubble",
              OVERLAY) is not None)

# F9 ACTION_RECORDING_STOPPED 广播共 3 处(688 rejected / 972 already_stopped / 1986 saved)
# 匹配 Intent(ACTION_RECORDING_STOPPED) 而非 sendBroadcast 后紧跟的
intent_sites = [m.start() for m in re.finditer(r"Intent\(ACTION_RECORDING_STOPPED\)", SERVICE)]
chk("F9a Intent(ACTION_RECORDING_STOPPED) 共 3 处", len(intent_sites) == 3,
    f"实际 {len(intent_sites)} 处")
# 前两处不带 EXTRA_SAVED(默认 false → 不弹"已保存")
for s in intent_sites[:-1]:
    tail = SERVICE[s:s+400]
    chk(f"F9b Intent@{s} 不带 EXTRA_SAVED",
        "EXTRA_SAVED" not in tail)

# F10 IDLE-stop 路径:handleStop:998 分支不额外置 sessionRecorded = true
# 只需断言 handleStop 函数体不含 sessionRecorded = true
hstop_start = SERVICE.find("private fun handleStop(")
hstop_end = SERVICE.find("\n    private fun ", hstop_start + 1)
if hstop_start >= 0 and hstop_end > hstop_start:
    hstop_body = SERVICE[hstop_start:hstop_end]
    chk("F10 handleStop 内不置 sessionRecorded=true",
        "sessionRecorded = true" not in hstop_body)
else:
    chk("F10 handleStop 内不置 sessionRecorded=true", False, "handleStop 定位失败")

# F11 广播 EXTRA_SAVED 只在 cleanupAndStop 一处 putExtra
put_count = SERVICE.count(".putExtra(EXTRA_SAVED, sessionRecorded)")
chk("F11 EXTRA_SAVED 只 putExtra 一次", put_count == 1,
    f"实际 {put_count}")

print()
print(f"FAILS: {len(fails)}")
if fails:
    for f in fails: print(" -", f)
sys.exit(1 if fails else 0)
