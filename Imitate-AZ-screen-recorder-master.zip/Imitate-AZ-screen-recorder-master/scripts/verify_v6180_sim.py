#!/usr/bin/env python3
# v6.7.180 验证:锁屏录制 + 屏幕常亮 + 暗色主题纯黑。
# 镜像方案「四、验证方式」的静态差分部分,不依赖真机。
import os
import re
import sys

ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
B = os.path.join(ROOT, "app/src/main/java/com/monkeycode/screenrecorder")
OVERLAY = os.path.join(B, "RecordOverlay.kt")
MA = os.path.join(B, "MainActivity.kt")
SVC = os.path.join(B, "ScreenRecorderService.kt")
ENGINE = os.path.join(B, "RecorderEngine.kt")
NIGHT = os.path.join(ROOT, "app/src/main/res/values-night/colors.xml")
THEMES = os.path.join(ROOT, "app/src/main/res/values/themes.xml")
COLORS = os.path.join(ROOT, "app/src/main/res/values/colors.xml")
JAVA_SRC = os.path.join(ROOT, "app/src/main/java")

passed = failed = 0


def check(name, cond):
    global passed, failed
    print(("PASS " if cond else "FAIL ") + name)
    if cond:
        passed += 1
    else:
        failed += 1


def read(p):
    with open(p, encoding="utf-8") as f:
        return f.read()


def body_of(src, fn_name):
    idx = src.find(f"fun {fn_name}(")
    if idx < 0:
        return None
    s = src.find("{", idx)
    depth = 0
    for i in range(s, len(src)):
        if src[i] == "{":
            depth += 1
        elif src[i] == "}":
            depth -= 1
            if depth == 0:
                return src[s + 1:i]
    return None


def rglob_py(root, ext):
    out = []
    for dp, dn, fn in os.walk(root):
        for f in fn:
            if f.endswith(ext):
                out.append(os.path.join(dp, f))
    return out


ov = read(OVERLAY)
ma = read(MA)
svc = read(SVC)
eng = read(ENGINE)
night = read(NIGHT)
themes = read(THEMES)
colors = read(COLORS)

# --- 改动1: 悬浮球窗口 FLAG_KEEP_SCREEN_ON ---
w = body_of(ov, "buildWindowFlags")
check("buildWindowFlags 含 FLAG_KEEP_SCREEN_ON", w is not None and "FLAG_KEEP_SCREEN_ON" in w)
check("原有三个标志未丢失",
      w is not None and all(x in w for x in
                            ("FLAG_NOT_FOCUSABLE", "FLAG_NOT_TOUCH_MODAL", "FLAG_LAYOUT_NO_LIMITS")))
check("FLAG_LAYOUT_IN_SCREEN 仍在 <R 分支", w is not None and "FLAG_LAYOUT_IN_SCREEN" in w)

# --- 改动2: MainActivity 窗口双保险 ---
on_r = body_of(ma, "onResume")
on_s = body_of(ma, "onStop")
check("onResume 录制态加 KEEP_SCREEN_ON",
      on_r is not None and "FLAG_KEEP_SCREEN_ON" in on_r
      and "RecordState.RECORDING" in on_r)
check("onStop 清 KEEP_SCREEN_ON", on_s is not None and "clearFlags" in on_s
      and "FLAG_KEEP_SCREEN_ON" in on_s)
check("MainActivity 已 import WindowManager", "import android.view.WindowManager" in ma)

# --- 改动3: 屏幕状态接收器(核心:锁屏只观测不停止) ---
check("新增 screenStateReceiver 字段", "screenStateReceiver" in svc)
rec = body_of(svc, "registerScreenStateReceiver")
check("registerScreenStateReceiver 存在", rec is not None)
unrec = body_of(svc, "unregisterScreenStateReceiver")
check("unregisterScreenStateReceiver 存在", unrec is not None)
check("接收器监听 SCREEN_OFF", rec is not None and "ACTION_SCREEN_OFF" in rec)
check("接收器监听 SCREEN_ON", rec is not None and "ACTION_SCREEN_ON" in rec)
check("SCREEN_OFF 只 markScreenLocked", rec is not None and "markScreenLocked" in rec)
check("SCREEN_ON 只 markScreenUnlocked", rec is not None and "markScreenUnlocked" in rec)
# 关键安全断言:接收器内绝不调用停止链路
check("接收器内无 stopAsync", rec is not None and "stopAsync" not in rec)
check("接收器内无 handleStop", rec is not None and "handleStop" not in rec)
check("接收器内无 cleanupAndStop", rec is not None and "cleanupAndStop" not in rec)
check("注册点紧跟 engine.start", re.search(r"engine\.start\(engineConfig,\s*projection\)\s*\n\s*registerScreenStateReceiver\(\)", svc) is not None)
check("cleanupAndStop 注销接收器", "unregisterScreenStateReceiver()" in body_of(svc, "cleanupAndStop"))
check("onDestroy 兜底注销", "unregisterScreenStateReceiver()" in body_of(svc, "onDestroy"))

# --- 改动4: RecorderEngine 打点 ---
check("screenLockedAtMs 字段", "screenLockedAtMs" in eng)
check("screenLockedTotalMs 字段", "screenLockedTotalMs" in eng)
mk_on = body_of(eng, "markScreenLocked")
mk_off = body_of(eng, "markScreenUnlocked")
check("markScreenLocked 记录时刻", mk_on is not None and "elapsedRealtime" in mk_on)
check("markScreenUnlocked 累加并复位", mk_off is not None
      and "screenLockedTotalMs +=" in mk_off and "screenLockedAtMs = -1" in mk_off)
# 打点必须是幂等防重入:已在锁屏态不重复起点
check("markScreenLocked 防重入(screenLockedAtMs<0 才置位)",
      mk_on is not None and "screenLockedAtMs < 0" in mk_on)
check("RECORD_SUMMARY 汇报 screenLockedMs", 'put("screenLockedMs", screenLockedTotalMs)' in eng)
# 关键:打点不丢帧、不停止、不改码率——两方法内不得有写入/停止动作
check("markScreen* 内无 drop/丢帧动作",
      mk_on is not None and mk_off is not None
      and "sample()" not in mk_on and "sample()" not in mk_off
      and "dequeueInputBuffer" not in mk_on and "dequeueInputBuffer" not in mk_off)

# --- 改动5: 暗色主题纯黑 ---
check("values-night background = #000000", re.search(r'<color name="background">#000000</color>', night) is not None)
check("values-night card_bg = #0A0A0A", re.search(r'<color name="card_bg">#0A0A0A</color>', night) is not None)
check("values-night dark_background 别名同步纯黑",
      re.search(r'<color name="dark_background">#000000</color>', night) is not None)
check("values-night dark_card 别名同步", re.search(r'<color name="dark_card">#0A0A0A</color>', night) is not None)
check("themes.xml dark_background 纯黑",
      re.search(r'<color name="dark_background">#000000</color>', themes) is not None)
check("themes.xml dark_card 纯黑", re.search(r'<color name="dark_card">#0A0A0A</color>', themes) is not None)
check("悬浮球表面去蓝偏 float_surface_dark",
      re.search(r'<color name="float_surface_dark">#CC1C1C1C</color>', colors) is not None)
check("悬浮球表面去蓝偏 float_sub_bg_dark",
      re.search(r'<color name="float_sub_bg_dark">#D91C1C1C</color>', colors) is not None)
# 层级与对比度保留:描边与浅字未动
check("card_border 保留(纯黑上可见描边)", "#3A3D50" in night)
check("text_primary 保留", "#E0E0E0" in night)
check("primary 品牌色保留 #4C6EF5", "#4C6EF5" in night)
# 旧蓝偏值不得作为 <color> 实际定义残留(注释中说明改动的引用不算)
color_def = re.compile(r'<color name="[^"]*">\s*#\w{6,8}\s*</color>')
night_vals = {m.upper() for m in re.findall(r'<color name="[^"]*">(#\w{6,8})</color>', night)}
themes_vals = {m.upper() for m in re.findall(r'<color name="[^"]*">(#\w{6,8})</color>', themes)}
check("旧藏青值未作为实际色值残留(values-night)",
      not ({"#13141F", "#1F2130"} & night_vals))
check("旧藏青值未作为实际色值残留(themes.xml)",
      not ({"#1A1B2E", "#25273A"} & themes_vals))

# --- 全局:主题改动必须覆盖代码路径,无硬编码蓝偏 ---
bluish = re.compile(r"0x[0-9a-f]{6,8}\b", re.IGNORECASE)
hits = []
for p in rglob_py(JAVA_SRC, ".kt"):
    for i, line in enumerate(read(p).splitlines(), 1):
        for m in bluish.finditer(line):
            tail = m.group(0).lower()[-8:]
            if tail in ("13141f", "1a1b2e", "1f2130", "25273a", "1c1c1e"):
                hits.append(f"{os.path.basename(p)}:{i}")
check("代码中无硬编码旧蓝偏背景色", not hits)

# --- 与 v6.7.179 已落地改动不冲突 ---
check("onResume 仍无条件 loadRecentHistory(v6.7.179)",
      on_r is not None and "loadRecentHistory()" in on_r)
check("WakeLock 仍为 0(v6.7.179 已删,本方案不恢复)", "newWakeLock" not in svc)
check("manifest 仍无 REQUEST_IGNORE_BATTERY_OPTIMIZATIONS",
      "REQUEST_IGNORE_BATTERY_OPTIMIZATIONS" not in
      read(os.path.join(ROOT, "app/src/main/AndroidManifest.xml")))

print(f"\n{passed} passed, {failed} failed")
if hits:
    print("硬编码命中:", hits)
sys.exit(1 if failed else 0)
