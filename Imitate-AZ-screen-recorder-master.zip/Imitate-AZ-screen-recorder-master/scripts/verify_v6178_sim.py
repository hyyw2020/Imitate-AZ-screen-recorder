#!/usr/bin/env python3
# v6.7.178 pts_hist / av_quantiles / bitrate boost 定基收敛 验证
# 镜像 RecorderEngine.kt ⑤-d / ⑤-e / ⑦ 的纯逻辑,不依赖 Android。
import sys

VIDEO_PTS_MIN_TICK_US = 1_000_000 // 90_000  # = 11


def build_hist(pts_list, fps):
    burst = lt20 = t30 = hi = gt80 = 0
    mx = 0
    last = -1
    for p in pts_list:
        if last >= 0:
            step = p - last
            if step <= VIDEO_PTS_MIN_TICK_US:
                burst += 1
            elif step < 20_000:
                lt20 += 1
            elif step < 40_000:
                t30 += 1
            elif step < 80_000:
                hi += 1
            else:
                gt80 += 1
            if step > mx:
                mx = step
        last = p
    return dict(burst=burst, lt20=lt20, t30=t30, hi=hi, gt80=gt80,
                max_us=mx, target_us=1_000_000 // fps if fps > 0 else 0)


def av_quantiles(samples):
    """镜像 ⑤-d:分位数 + 漂移率 ppm。1Hz 采样,序号即秒。"""
    if len(samples) < 10:
        return None
    srt = sorted(samples)
    def qt(p):
        return srt[min(int((len(srt) - 1) * p), len(srt) - 1)]
    head = sum(samples[:len(samples) // 10]) / (len(samples) // 10)
    tail = sum(samples[-(len(samples) // 10):]) / (len(samples) // 10)
    span_us = max(len(samples) // 10, 1) * 1_000_000.0
    ppm = int((tail - head) / span_us * 1_000_000)
    return dict(n=len(samples), min=srt[0], p50=qt(0.5), p95=qt(0.95),
                p99=qt(0.99), max=srt[-1], drift_ppm=ppm)


def boost_factor(measured_fps, cfg_fps):
    """镜像 ⑦:min(实测, 目标*1.5) 定基,上限 2.5。"""
    if cfg_fps <= 0:
        return 1.0
    basis = min(measured_fps, cfg_fps * 1.5)
    return min(basis / cfg_fps, 2.5)


def fps_cap_ignored(actual_fps, target_fps):
    return target_fps > 0 and actual_fps > target_fps * 1.2


R = []
def check(name, cond, detail=""):
    R.append((name, bool(cond)))
    print(f"[{'PASS' if cond else 'FAIL'}] {name}" + (f" :: {detail}" if detail else ""))


# ⑤-e 1: 30fps 理想,每步 33333µs 全落 20-40ms
h = build_hist([i * 33333 for i in range(1, 201)], 30)
check("pts_hist 30fps 理想全落 20-40ms", h['t30'] == 199 and h['burst'] == 0 and h['lt20'] == 0, h)

# ⑤-e 2: 53fps 实况,每步 18868µs 全落 <20ms(证实驱动无视 30fps 限速)
h = build_hist([i * 18868 for i in range(1, 201)], 30)
check("pts_hist 53fps 实况全落 <20ms", h['lt20'] == 199, h)

# ⑤-e 3: 卡顿恢复产生一次 burst
pts = [i * 33333 for i in range(1, 100)]
pts.append(pts[-1] + 11)
pts += [pts[-1] + 33333 * (i + 1) for i in range(1, 101)]
h = build_hist(pts, 30)
check("pts_hist 卡顿恢复 burst=1", h['burst'] == 1, h)

# ⑤-e 4: 最小钳制被用满(step=11 恰好等于 MIN_TICK 也计 burst)
h = build_hist([0, 11, 22, 33], 30)
check("pts_hist step=MIN_TICK 计 burst", h['burst'] == 3 and h['lt20'] == 0, h)

# ⑤-e 5: 空序列与单帧不出计数
h = build_hist([], 30)
check("pts_hist 空序列零计数", h['burst'] == 0 and h['max_us'] == 0, h)
h = build_hist([123456], 30)
check("pts_hist 单帧零计数", h['burst'] == 0 and h['max_us'] == 0, h)

# ⑤-e 6: target 基准自洽
h = build_hist([i * 33333 for i in range(1, 201)], 30)
check("pts_hist target=33333µs@30fps", h['target_us'] == 33333, h)
h = build_hist([0], 0)
check("pts_hist fps=0 target=0", h['target_us'] == 0, h)

# ⑤-d 1: 稳定锚定(恒定 delta)→ drift_ppm=0
q = av_quantiles([50_000] * 120)
check("av_quantiles 恒定值漂移 0", q and q['drift_ppm'] == 0 and q['p50'] == 50_000, q)

# ⑤-d 2: 线性漂移 1ms/s → 头尾均值差按 span=60s 折算,ppm=1_000_000/60≈16700
# 取 60 条(1Hz=60s),线性 0→60000µs:头均值≈3000,尾均值≈57000,span=6s → ppm=9000000?
# 直接按源码公式校验:drift_ppm = (tailAvg-headAvg)/spanUs*1e6,spanUs=6s
n = 60
samples = [int(i * 1000) for i in range(n)]      # 每样本 +1ms,1Hz → 1ms/s 漂移
q = av_quantiles(samples)
expected_ppm = int(round((sum(samples[-6:]) / 6 - sum(samples[:6]) / 6) / (6 * 1_000_000.0) * 1_000_000))
check("av_quantiles 线性漂移 ppm 自洽", q and q['drift_ppm'] == expected_ppm,
      f"got={q['drift_ppm']} expected={expected_ppm}")

# ⑤-d 3: 样本不足 10 条不出统计
check("av_quantiles 不足 10 条返回 None", av_quantiles([1] * 9) is None)

# ⑤-d 4: 分位数单调
q = av_quantiles(list(range(0, 120)))
check("av_quantiles p50<=p95<=p99", q and q['p50'] <= q['p95'] <= q['p99'], q)

# ⑤-d 5: 头尾均值方向正确(负漂移 → 负 ppm)
samples = [int(10_000 - i * (10_000 / 60)) for i in range(120)]
q = av_quantiles(samples)
check("av_quantiles 负漂移 ppm<0", q and q['drift_ppm'] < 0, q)

# ⑦ 1: 定基收敛,30fps 目标 + 53fps 实测 → 不再顶到 2.5
check("boost 30fps 目标 53fps 实测 收敛到 1.5",
      abs(boost_factor(53.0, 30) - 1.5) < 1e-9, boost_factor(53.0, 30))

# ⑦ 2: 收敛后余量仍大于 1(画质有垫)
check("boost 收敛值 >1", boost_factor(53.0, 30) > 1.0)

# ⑦ 3: 120Hz 屏 60fps 实测 vs 60fps 目标 → 不放大
check("boost 实测=目标 不放大", abs(boost_factor(60.0, 60) - 1.0) < 1e-9)

# ⑦ 4: 下限保护,cfg=0 不除零
check("boost cfg=0 返回 1.0", boost_factor(120.0, 0) == 1.0)

# ⑦ 5: 上限 2.5 仍保留(实测极小时 basis 被 cfg*1.5 拉高到 1.5,不会超 1.5)
check("boost 任何实测下不超过 1.5", boost_factor(999.0, 30) <= 1.5, boost_factor(999.0, 30))
check("boost 低实测不被拉高", boost_factor(20.0, 30) == 20.0 / 30.0, boost_factor(20.0, 30))

# ⑦ 6: fps_cap_ignored 信号
check("fps_cap_ignored 53 vs 30 触发", fps_cap_ignored(53, 30) is True)
check("fps_cap_ignored 37 vs 30 触发(>20%)", fps_cap_ignored(37, 30) is True)
check("fps_cap_ignored 36 vs 30 不触发(恰在 1.2 边界)", fps_cap_ignored(36, 30) is False)
check("fps_cap_ignored 实测低于目标不触发", fps_cap_ignored(28, 30) is False)
check("fps_cap_ignored target=0 不触发", fps_cap_ignored(53, 0) is False)

failed = [n for n, ok in R if not ok]
print(f"\n{len(R) - len(failed)}/{len(R)} PASS")
if failed:
    print("FAIL: " + ", ".join(failed))
sys.exit(1 if failed else 0)
