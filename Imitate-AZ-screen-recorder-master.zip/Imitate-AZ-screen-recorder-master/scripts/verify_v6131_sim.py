#!/usr/bin/env python3
"""v6.7.131 码率规格对齐 + 丢帧 off-by-one 修复 模拟验证.

镜像源码三块逻辑(无真机,纯 JVM/Python 等价模拟):
  1. clampToCapabilities 的码率钳制(RecorderEngine.kt:1554-1558):
     bitrate > hardware.upper -> 钳到 upper;<= upper 一律尊重。
  2. 丢帧 off-by-one 修复(RecorderEngine.kt:78-79, 丢帧分支 :4796):
     clock >= DROP_EVERY 才丢,即每 (N+1) 帧丢 1,保留 N/(N+1)。
     DROP_EVERY_45=3 -> 每4帧丢1 -> 75% -> 60fps 源 -> 45fps
     DROP_EVERY_30=1 -> 每2帧丢1 -> 50% -> 60fps 源 -> 30fps
  3. 分辨率-帧率上限联动(MainActivity.kt maxFpsForResolution):
     短边 >=2160 -> 60(4K); >=1440 -> 120(2K); else -> 144(1080P及以下)。

运行: python3 scripts/verify_v6131_sim.py
退出码 0 = 全 PASS;非 0 = 有场景失败。
"""

# ---- UI 档位数组镜像 (MainActivity.kt:661-662) ----
BITRATE_OPTIONS_MB = [0, 64, 48, 40, 32, 25, 20, 16, 12, 10, 8, 6, 4, 2, 1]
UI_MAX_MB = max(b for b in BITRATE_OPTIONS_MB if b > 0)

# ---- 丢帧常量镜像 (RecorderEngine.kt:78-79) ----
DROP_EVERY_45 = 3
DROP_EVERY_30 = 1

results = []


def check(name, cond, detail=""):
    results.append((name, bool(cond), detail))
    status = "PASS" if cond else "FAIL"
    print(f"[{status}] {name}" + (f" :: {detail}" if detail else ""))


# ============================================================
# 1. clampToCapabilities 码率钳制 (镜像 :1554-1558)
# ============================================================
def clamp_bitrate(bitrate, hw_upper):
    if bitrate > hw_upper:
        return hw_upper
    return bitrate


# 4K/64M 在不同硬件上限下钳到上限
check("clamp 4K/64M -> hw80M 不钳", clamp_bitrate(64_000_000, 80_000_000) == 64_000_000,
      "64M <= 80M,尊重用户")
check("clamp 4K/64M -> hw60M 钳到60M", clamp_bitrate(64_000_000, 60_000_000) == 60_000_000,
      "64M > 60M,钳到硬件上限")
check("clamp 4K/64M -> hw48M 钳到48M", clamp_bitrate(64_000_000, 48_000_000) == 48_000_000,
      "老设备48M上限,64M被钳")
check("clamp 4K/64M -> hw32M 钳到32M", clamp_bitrate(64_000_000, 32_000_000) == 32_000_000,
      "低端4K32M上限,64M被钳")
check("clamp 2K/25M -> hw40M 不钳", clamp_bitrate(25_000_000, 40_000_000) == 25_000_000,
      "2K默认25M <= 40M,尊重")
check("clamp 1080P/16M -> hw20M 不钳", clamp_bitrate(16_000_000, 20_000_000) == 16_000_000,
      "1080P16M尊重")

# 64M 档在哪些硬件上限下会被钳(如实报告约束5)
clamped_hw = [h for h in [80_000_000, 64_000_000, 60_000_000, 48_000_000, 32_000_000, 20_000_000]
              if clamp_bitrate(64_000_000, h) != 64_000_000]
check("64M 档被钳硬件上限集合",
      clamped_hw == [60_000_000, 48_000_000, 32_000_000, 20_000_000],
      f"hw<64M 时64M被钳: {[h//1_000_000 for h in clamped_hw]}M")

# ============================================================
# 2. 丢帧 off-by-one 修复数学 (镜像 :4796 丢帧分支)
# ============================================================
def simulate_drop(source_fps, drop_every, target_label, keyframe_interval=60):
    """模拟一帧序列的丢帧。drop_every=N 表示 clock>=N 才丢(每 N+1 帧丢 1)。
    关键帧(BUFFER_FLAG_KEY_FRAME)不丢,且重置 clock(镜像源码 else 分支 clock=0)。
    keyframe_interval=60: 每秒 1 个关键帧(GOP=1s),60fps 下每 60 帧 1 个关键帧,
    镜像源码 KEY_I_FRAME_INTERVAL=1。非关键帧(占 59/60)按 drop_every 节奏丢。"""
    frames = source_fps * 3  # 3 秒 60fps = 180 帧
    written = 0
    dropped = 0
    clock = 0
    keyframes = 0
    keyframes_written = 0
    for i in range(frames):
        is_key = (i % keyframe_interval == 0)
        if is_key:
            keyframes += 1
            keyframes_written += 1
            written += 1
            clock = 0  # 关键帧走 else 分支,重置 clock
            continue
        # 非关键帧 + 非首帧: 按 drop_every 节奏丢
        if clock >= drop_every:
            dropped += 1
            clock = 0
        else:
            written += 1
            clock += 1
    actual_fps = written / 3.0
    return actual_fps, written, dropped, keyframes, keyframes_written


actual45, w45, d45, kf45, kfw45 = simulate_drop(60, DROP_EVERY_45, "45fps")
check("丢帧 60->45 目标(actual≈45)", 44.0 <= actual45 <= 46.0,
      f"实际 {actual45:.1f}fps, 写{w45}丢{d45}, 关键帧{kf45}全写{kfw45}")

actual30, w30, d30, kf30, kfw30 = simulate_drop(60, DROP_EVERY_30, "30fps")
check("丢帧 60->30 目标(actual≈30)", 29.0 <= actual30 <= 31.0,
      f"实际 {actual30:.1f}fps, 写{w30}丢{d30}, 关键帧{kf30}全写{kfw30}")

# 旧值回归对照: 证明旧 DROP_EVERY_45=4/DROP_EVERY_30=2 达不到目标。
# 关键帧打断节奏(GOP=60)使旧值实测略高于纯数学(48/40),但明确不达 45/30 目标。
old45, *_ = simulate_drop(60, 4, "old45")
old30, *_ = simulate_drop(60, 2, "old30")
check("旧值45档不达45(实为48~49)", old45 > 46.0, f"旧值实际{old45:.1f}fps")
check("旧值30档不达30(实为40~41)", old30 > 38.0, f"旧值实际{old30:.1f}fps")
check("新值修复了旧值偏差",
      abs(actual45 - 45.0) < abs(old45 - 45.0) and abs(actual30 - 30.0) < abs(old30 - 30.0),
      f"45档偏差 {old45-45:.1f}->{actual45-45:.1f}, 30档 {old30-30:.1f}->{actual30-30:.1f}")

# 关键帧不被丢(源码 BUFFER_FLAG_KEY_FRAME 必写)
check("关键帧必写", kf45 == kfw45 and kf30 == kfw30,
      f"45档关键帧 {kfw45}/{kf45} 全写, 30档 {kfw30}/{kf30} 全写")

# ============================================================
# 3. 分辨率-帧率上限联动 (镜像 MainActivity maxFpsForResolution)
# ============================================================
def max_fps_for_resolution(w, h):
    short = min(w, h)
    if short >= 2160:
        return 60
    if short >= 1440:
        return 120
    return 144


check("1080p(1920x1080) 上限144", max_fps_for_resolution(1920, 1080) == 144)
check("720p(1280x720) 上限144", max_fps_for_resolution(1280, 720) == 144)
check("2K(2560x1440) 上限120", max_fps_for_resolution(2560, 1440) == 120)
check("4K(3840x2160) 上限60", max_fps_for_resolution(3840, 2160) == 60)
check("竖屏1080(1080x1920) 上限144", max_fps_for_resolution(1080, 1920) == 144,
      "短边1080,不误判为4K")
check("竖屏4K(2160x3840) 上限60", max_fps_for_resolution(2160, 3840) == 60,
      "短边2160,正确判4K")


def fps_options_for_res(w, h, all_opts):
    return [o for o in all_opts if o == 0 or o <= max_fps_for_resolution(w, h)]


ALL_FPS = [0, 144, 120, 90, 60, 50, 40, 30, 25, 20, 15]
opts4k = fps_options_for_res(3840, 2160, ALL_FPS)
check("4K 帧率对话框裁掉>60档",
      144 not in opts4k and 120 not in opts4k and 90 not in opts4k and 60 in opts4k,
      f"4K可选: {opts4k}")
opts2k = fps_options_for_res(2560, 1440, ALL_FPS)
check("2K 帧率对话框裁掉>120档",
      144 not in opts2k and 120 in opts2k,
      f"2K可选: {opts2k}")
opts1080 = fps_options_for_res(1920, 1080, ALL_FPS)
check("1080P 帧率对话框全档", opts1080 == ALL_FPS, f"1080P可选: {opts1080}")

# ============================================================
# 4. UI 码率档位范围
# ============================================================
check("UI 码率最高档 64Mbps", UI_MAX_MB == 64, f"最高 {UI_MAX_MB}M")
check("UI 档位含 64/48/40/32/25 阶梯",
      all(x in BITRATE_OPTIONS_MB for x in [64, 48, 40, 32, 25]))
check("UI 档位向下兼容含 16/12/10/8/6/4/2/1",
      all(x in BITRATE_OPTIONS_MB for x in [16, 12, 10, 8, 6, 4, 2, 1]))

# ============================================================
# 汇总
# ============================================================
print("\n" + "=" * 60)
passed = sum(1 for _, ok, _ in results if ok)
total = len(results)
print(f"结果: {passed}/{total} PASS")
if passed == total:
    print("SIM-VERIFY PASS (v6.7.131)")
    exit(0)
else:
    print("SIM-VERIFY FAIL")
    for name, ok, detail in results:
        if not ok:
            print(f"  失败: {name} :: {detail}")
    exit(1)
