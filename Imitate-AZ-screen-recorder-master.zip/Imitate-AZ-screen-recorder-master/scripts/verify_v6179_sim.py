#!/usr/bin/env python3
# v6.7.179 验证:历史面板刷新不变式 + WakeLock 移除后的电池检查直通逻辑。
# 镜像 MainActivity.onResume / onRecordingStopped / checkBatteryOptimizationAndProceed 的纯逻辑。
import os
import re
import sys

ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
SRC = os.path.join(ROOT, "app/src/main/java/com/monkeycode/screenrecorder/MainActivity.kt")
SVC = os.path.join(ROOT, "app/src/main/java/com/monkeycode/screenrecorder/ScreenRecorderService.kt")
MANIFEST = os.path.join(ROOT, "app/src/main/AndroidManifest.xml")
ENGINE = os.path.join(ROOT, "app/src/main/java/com/monkeycode/screenrecorder/RecorderEngine.kt")

passed = 0
failed = 0


def check(name, cond):
    global passed, failed
    if cond:
        passed += 1
        print(f"PASS {name}")
    else:
        failed += 1
        print(f"FAIL {name}")


def read(path):
    with open(path, encoding="utf-8") as f:
        return f.read()


def body_of(src, fn_name):
    """取函数体(按大括号配平),忽略字符串内的括号噪声风险:仅对本仓库已确认无嵌套注释括号的函数安全。"""
    idx = src.find(f"fun {fn_name}(")
    if idx < 0:
        return None
    s = src.find("{", idx)
    depth = 0
    for i in range(s, len(src)):
        if src[i] == "{":
            depth += 1
        elif src[i] == "}":
            depth -= 1
            if depth == 0:
                return src[s + 1:i]
    return None


ma = read(SRC)
svc = read(SVC)
manifest = read(MANIFEST)
engine = read(ENGINE)

# --- 历史面板刷新不变式 ---
# 场景:receiver 在 onPause/onStop 注销,恢复前台后 onResume 必须无条件重载列表。
on_resume = body_of(ma, "onResume")
check("onResume 存在", on_resume is not None)
check("onResume 无条件调用 loadRecentHistory", on_resume is not None and "loadRecentHistory()" in on_resume)
check("onResume 的 loadRecentHistory 无 if 守卫(在 updateRecordingState 之后直接调用)",
      on_resume is not None and "updateRecordingState()" in on_resume
      and on_resume.index("loadRecentHistory()") > on_resume.index("updateRecordingState()"))

on_stopped = body_of(ma, "onRecordingStopped")
check("onRecordingStopped 末尾收口 loadRecentHistory",
      on_stopped is not None and "loadRecentHistory()" in on_stopped
      and on_stopped.rstrip().endswith("loadRecentHistory()"))

# receiver 生命周期守卫仍在,避免 onResume 之外重复注册
check("isReceiverRegistered 守卫仍在", "if (!isReceiverRegistered) {" in ma)
check("onPause 注销 receiver", "unregisterReceiver(historyReceiver)" in ma)
check("ACTION_HISTORY_CHANGED 仍在过滤器内", "addAction(ScreenRecorderService.ACTION_HISTORY_CHANGED)" in ma)

# --- WakeLock 移除 ---
check("无 newWakeLock 调用", "newWakeLock" not in svc)
check("无 wakeLock 字段", not re.search(r"private\s+var\s+wakeLock", svc))
check("无 acquireWakeLock/renewWakeLock/releaseWakeLock 定义",
      "fun acquireWakeLock" not in svc and "fun renewWakeLock" not in svc
      and "fun releaseWakeLock" not in svc)
check("无 WAKE_LOCK 常量", "WAKE_LOCK_TAG" not in svc and "WAKE_LOCK_TIMEOUT_MS" not in svc)

# --- 权限移除 ---
check("manifest 无 REQUEST_IGNORE_BATTERY_OPTIMIZATIONS",
      "REQUEST_IGNORE_BATTERY_OPTIMIZATIONS" not in manifest)
check("manifest 无 WAKE_LOCK 权限", 'android.permission.WAKE_LOCK' not in manifest)
check("manifest 无 INTERNET 权限", 'android.permission.INTERNET' not in manifest)

# --- 电池检查直通:删权限后不再 launch ACTION_REQUEST_IGNORE_BATTERY_OPTIMIZATIONS ---
bat = body_of(ma, "checkBatteryOptimizationAndProceed")
check("电池检查函数存在", bat is not None)
check("删权限后不再 launch 系统电池优化弹窗",
      bat is not None and "batteryOptimizationLauncher.launch" not in bat
      and "Settings.ACTION_REQUEST_IGNORE_BATTERY_OPTIMIZATIONS" not in bat)
check("电池检查始终直通 checkNotificationAndProceed",
      bat is not None and "checkNotificationAndProceed()" in bat)
check("未豁免时仅 Toast 提示不阻断",
      bat is not None and "未忽略电池优化" in bat)

# --- 色彩元数据显式声明(改动7,已存在故仅核验) ---
vfmt = body_of(engine, "createVideoFormat")
check("createVideoFormat 显式 KEY_COLOR_STANDARD",
      vfmt is not None and "MediaFormat.KEY_COLOR_STANDARD" in vfmt)
check("createVideoFormat 显式 KEY_COLOR_TRANSFER",
      vfmt is not None and "MediaFormat.KEY_COLOR_TRANSFER" in vfmt)
check("createVideoFormat 显式 KEY_COLOR_RANGE",
      vfmt is not None and "MediaFormat.KEY_COLOR_RANGE" in vfmt)
check("KEY_MAX_B_FRAMES 拼写正确(非 KEY_MAX_BFRAMES)",
      "KEY_MAX_B_FRAMES" in engine and "KEY_MAX_BFRAMES" not in engine)

print(f"\n{passed} passed, {failed} failed")
sys.exit(1 if failed else 0)
