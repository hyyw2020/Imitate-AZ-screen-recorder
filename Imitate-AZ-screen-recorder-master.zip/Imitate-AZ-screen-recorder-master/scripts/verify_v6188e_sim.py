#!/usr/bin/env python3
"""v6.7.188e 静态校验:悬浮球吸附逻辑重写(纯水平 A/B 方案)。"""
import pathlib, sys, re

ROOT = pathlib.Path(__file__).resolve().parent.parent
OVERLAY = (ROOT / "app/src/main/java/com/monkeycode/screenrecorder/RecordOverlay.kt").read_text(encoding="utf-8")

fails = []
def chk(name, cond, detail=""):
    if cond:
        print(f"PASS  {name}")
    else:
        fails.append(name)
        print(f"FAIL  {name}  {detail}")

# S1: snapToEdge 方法体内不再含 normY / DOCK_TOP / DOCK_BOTTOM 判定
snap_start = OVERLAY.find("private fun snapToEdge(")
snap_end = OVERLAY.find("\n    private fun dockTargetY(", snap_start)
snap_body = OVERLAY[snap_start:snap_end]
chk("S1a snapToEdge 内无 normY", "normY" not in snap_body)
chk("S1b snapToEdge 内无 DOCK_TOP", "DOCK_TOP" not in snap_body)
chk("S1c snapToEdge 内无 DOCK_BOTTOM", "DOCK_BOTTOM" not in snap_body)
chk("S1d snapToEdge 内含 DOCK_LEFT", "DOCK_LEFT" in snap_body)
chk("S1e snapToEdge 内含 DOCK_RIGHT", "DOCK_RIGHT" in snap_body)
chk("S1f snapToEdge 内含 Math.random()", "Math.random()" in snap_body)
chk("S1g snapToEdge 内含 isCenterLine", "isCenterLine" in snap_body)

# S2: eps 阈值
chk("S2a epsPx = 1.0", "val epsPx = 1.0" in snap_body)
chk("S2b Math.abs(dx) <= epsPx", "Math.abs(dx) <= epsPx" in snap_body)

# S3: A 方案
chk("S3a dx < 0 (左)", "dx < 0" in snap_body)
chk("S3b else DOCK_RIGHT (右)", "else DOCK_RIGHT" in snap_body)

# S4: B 方案随机
chk("S4 Math.random() < 0.5", "Math.random() < 0.5" in snap_body)

# S5: dockTargetY 回中心
dt_start = OVERLAY.find("private fun dockTargetY(")
dt_end = OVERLAY.find("\n    private fun screenWidthFromDisplay", dt_start)
dt_body = OVERLAY[dt_start:dt_end]
chk("S5a dockTargetY 含 H/2 - leadH()/2",
    "screenHeightFromDisplay() / 2 - leadH() / 2" in dt_body)
chk("S5b dockTargetY 内无 DOCK_TOP 分支", "DOCK_TOP" not in dt_body)
chk("S5c dockTargetY 内无 DOCK_BOTTOM 分支", "DOCK_BOTTOM" not in dt_body)

# S6: SNAP_DURATION_MS = 200L
chk("S6a SNAP_DURATION_MS = 200L", "SNAP_DURATION_MS = 200L" in OVERLAY)
chk("S6b 无 SNAP_DURATION_MS = 220L", "SNAP_DURATION_MS = 220L" not in OVERLAY)

# S7: startSnapAnim 无 invalidate 实际调用 + 有 commitLeadNow + DecelerateInterpolator
ss_start = OVERLAY.find("private fun startSnapAnim(")
ss_end = OVERLAY.find("\n    private fun snapToEdge(", ss_start)
ss_body = OVERLAY[ss_start:ss_end]
# 排除注释行,只看实际代码
ss_code_lines = [l for l in ss_body.split("\n") if not l.strip().startswith("//")]
ss_code = "\n".join(ss_code_lines)
chk("S7a startSnapAnim 含 commitLeadNow", "commitLeadNow" in ss_code)
chk("S7b startSnapAnim 内无 invalidate() 实际调用",
    "invalidate()" not in ss_code, "实际代码含 invalidate()")
chk("S7c startSnapAnim 含 DecelerateInterpolator",
    "DecelerateInterpolator" in ss_code)

# L: DOCK_TOP/BOTTOM 常量保留但标注
chk("L1 DOCK_TOP 常量保留", "private const val DOCK_TOP = 2" in OVERLAY)
chk("L2 DOCK_BOTTOM 常量保留", "private const val DOCK_BOTTOM = 3" in OVERLAY)
chk("L3 DOCK_TOP 前注释含 v6.7.188e 说明",
    re.search(r"v6\.7\.188e:\s*纯水平吸附后\s*snapToEdge\s*不再产出.*?DOCK_TOP = 2", OVERLAY, re.S) is not None)

print()
print(f"FAILS: {len(fails)}")
if fails:
    for f in fails: print(" -", f)
sys.exit(1 if fails else 0)
