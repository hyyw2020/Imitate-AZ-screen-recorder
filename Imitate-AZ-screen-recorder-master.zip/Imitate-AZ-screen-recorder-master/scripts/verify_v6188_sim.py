#!/usr/bin/env python3
# v6.7.188 验证: AZ 6.9.10 一体四子球最终落库(常驻开关 + ①三态挂载回填 + 空闲视觉 + 死代码删除 + 仅重绘①)。
# 在 v6187 全量 121 条断言之上增加 P1~P5。纯静态差分,不依赖真机。
import re, sys, pathlib

ROOT = pathlib.Path(__file__).resolve().parent.parent
SRV = (ROOT/"app/src/main/java/com/monkeycode/screenrecorder/ScreenRecorderService.kt").read_text(encoding="utf-8")
ENG = (ROOT/"app/src/main/java/com/monkeycode/screenrecorder/RecorderEngine.kt").read_text(encoding="utf-8")
OVL = (ROOT/"app/src/main/java/com/monkeycode/screenrecorder/RecordOverlay.kt").read_text(encoding="utf-8")
ACT = (ROOT/"app/src/main/java/com/monkeycode/screenrecorder/MainActivity.kt").read_text(encoding="utf-8")
MAN = (ROOT/"app/src/main/AndroidManifest.xml").read_text(encoding="utf-8")
GRD = (ROOT/"app/build.gradle.kts").read_text(encoding="utf-8")
SHOT = (ROOT/"app/src/main/java/com/monkeycode/screenrecorder/ScreenshotHelper.kt").read_text(encoding="utf-8")
REC = (ROOT/"app/src/main/java/com/monkeycode/screenrecorder/RecorderEngine.kt").read_text(encoding="utf-8")
OVL = (ROOT/"app/src/main/java/com/monkeycode/screenrecorder/RecordOverlay.kt").read_text(encoding="utf-8")
SVC = (ROOT/"app/src/main/java/com/monkeycode/screenrecorder/ScreenRecorderService.kt").read_text(encoding="utf-8")
MAN = (ROOT/"app/src/main/AndroidManifest.xml").read_text(encoding="utf-8")
CA = (ROOT/"app/src/main/java/com/monkeycode/screenrecorder/CaptureActivity.kt").read_text(encoding="utf-8")

ok, bad = [], []
def ck(cond, msg):
    (ok if cond else bad).append(msg)

# ---------- 1. wakeLockHeld 接线 ----------
ck("@Volatile var wakeLockHeld" in ENG, "1a engine 有 wakeLockHeld 字段")
ck(re.search(r"@Volatile var wakeLockHeld = false\s*\n\s*private set", ENG, re.M) is not None, "1b wakeLockHeld 为 private set")
ck("fun setWakeLockHeld(held: Boolean)" in ENG, "1c engine 有 setWakeLockHeld setter")
ck('put("wakeLockHeld", wakeLockHeld)' in ENG, "1d buildReport 写出 wakeLockHeld")
ck("put(\"screenLockedMs\"" in ENG and "put(\"wakeLockHeld\"" in ENG, "1e 与 screenLockedMs 同在报告")
ck(len(re.findall(r"engine\?\.setWakeLockHeld\(", SRV)) >= 4, "1f service 至少 4 处同步 setWakeLockHeld")
ck("engine?.setWakeLockHeld(true)" in SRV, "1g acquire 成功同步 true")
ck("engine?.setWakeLockHeld(false)" in SRV, "1h 失败/释放同步 false")
# 分层:engine 不能直读 service 字段
ck("wakeLockAcquired" not in ENG, "1i engine 未直读 service 的 wakeLockAcquired(分层未破坏)")
# v6.7.184: Service 侧已删 wakeLockAcquired,状态唯一源收敛为 engine 镜像
ck("wakeLockAcquired" not in SRV, "1j Service 无 wakeLockAcquired 残留(状态唯一源在 engine)")
ck("engine?.setWakeLockHeld(it.isHeld)" in SRV, "1j2 renew 按 isHeld 回填 engine 镜像")
# v6.7.184: 删字段后,原"有读取点"断言已无对象,改为锁死"字段确实没了"
ck("wakeLockAcquired" not in (SRV + ENG), "1k wakeLockAcquired 双文件零残留(不再写而未读)")

# ---------- 2. navbarInsetPx else 复位 ----------
ovl_insets = OVL.split("override fun onApplyWindowInsets")[1].split("return insets")[0]
ck(ovl_insets.count("navbarInsetPx = 0") >= 2, "2a @R 与 <R 两分支都有 else 复位")
ck(ovl_insets.count("if (b.bottom > 0)") == 1, "2b @R 分支抬高路径保留")
ck(ovl_insets.count("if (bottomInset > 0)") == 1, "2c <R 分支抬高路径保留")
# else 复位必须在抬高 if 之后
ck(re.search(r"if \(b\.bottom > 0\).*?else \{\s*//[^}]*navbarInsetPx = 0", ovl_insets, re.S) is not None,
   "2d @R else 分支含 navbarInsetPx = 0")
ck(re.search(r"if \(bottomInset > 0\).*?else \{\s*//[^}]*navbarInsetPx = 0", ovl_insets, re.S) is not None,
    "2e <R else 分支含 navbarInsetPx = 0")
# v6.7.184: else 改为直接 setLead 落球后不再调 reClampOverNavbar,抬高路径仍 2 处
ck(ovl_insets.count("reClampOverNavbar()") >= 2, "2f 抬高路径仍调 reClampOverNavbar")
# v6.7.184: else 分支必须真的落球(setLead),否则"记账对了球不动"
ck(ovl_insets.count("setLead(leadX()") >= 2, "2g 两 else 分支都有落球 setLead")
ck(ovl_insets.count("val oldInset = navbarInsetPx") == 2, "2h 两 else 分支都先存旧 inset")
ck("safeUpdateViewLayout()" in ovl_insets, "2i 落球后触发重新布局")

# ---------- 3. checkFreeSpace 节流 ----------
ck("lastFreeSpaceCheckMs" in ENG, "3a 有节流时刻字段")
ck("lastFreeBelowMin" in ENG, "3b 有紧急档标志字段")
ck("fun checkFreeSpace()" in ENG and "fun doCheckFreeSpace()" in ENG, "3c 拆出 doCheckFreeSpace")
blk = ENG.split("fun checkFreeSpace()")[1].split("fun doCheckFreeSpace")[0]
ck(">= 5000" in blk, "3d 健康档 5s 周期")
ck("lastFreeBelowMin ||" in blk, "3e 紧急档或条件")
ck("ponytail:" in ENG.split("fun checkFreeSpace()")[1].split("doCheckFreeSpace")[0], "3f ponytail 标注天花板")
ck("lastFreeBelowMin = free < MIN_FREE_SPACE_BYTES" in ENG, "3g 紧急档按余量置位")
# 止损灵敏度:紧急档 1s 内可达(checkFreeSpace 每 1s 被 reportProgress 调用)
ck("if (nowMs - lastProgressReportMs < 1000) return" in ENG, "3h 调用频率仍 1s(紧急档不延迟)")

# ---------- 4. health 诊断串 5s ----------
ck("lastHealthSampleMs" in ENG, "4a 有 health 采样时刻字段")
ck(re.search(r"if \(nowMs - lastHealthSampleMs >= 5000L\)", ENG) is not None, "4b health 串门控 5s")
# av_pts_delta 环形采样必须在门控之外(否则分位数失真)
# v6.7.184: 让 seg 真正参与断言——门控块以 "}" 结束,addLast 必须在其后
seg = ENG.split('if (nowMs - lastHealthSampleMs >= 5000L)')[1].split("avDeltaRing.addLast(avDeltaUs)")[0]
seg_lines = [l for l in seg.strip().splitlines() if not l.strip().startswith("//")]
ck(len(seg_lines) >= 1 and seg_lines[-1].strip() == "}", "4c 5s 门控块以 } 收尾(addLast 在块外)")
ck("while (avDeltaRing.size > 7200) avDeltaRing.pollFirst()" in ENG, "4d 环形 7200 上限保留")
ck("lastHealthWallMs = nowMs" in ENG, "4e 漂移监控基准仍每 1s 更新")

# ---------- 5. 死代码清理 ----------
ck("batteryOptimizationLauncher" not in ACT, "5a batteryOptimizationLauncher 已删")
ck("未忽略电池优化，可继续录制" not in ACT, "5b 误导性 Toast 文案已改")
ck("checkBatteryOptimizationAndProceed" in ACT, "5c 只查不弹的函数仍在")
ck(len(re.findall(r"registerForActivityResult", ACT)) >= 3, "5d 其他 ActivityResult 未误删")
ck("isIgnoringBatteryOptimizations" in ACT, "5e 电池优化查询仍在(不需权限)")

# ---------- 红线 ----------
ck('uses-permission android:name="android.permission.WAKE_LOCK"' in MAN, "R1 Manifest 仍有 WAKE_LOCK")
ck("REQUEST_IGNORE_BATTERY_OPTIMIZATIONS" not in MAN, "R2 仍未申请电池豁免")
ck("android.permission.INTERNET" not in MAN, "R3 仍无 INTERNET 权限")
ck("versionCode = 317" in GRD and 'versionName = "6.7.188"' in GRD, "R4 版本号 317/6.7.188")
ck("muxerLock" in ENG, "R5 muxerLock 未动")
ck("fun releaseResources()" in ENG, "R6 release 释放链存在")
# v6.7.184: 原式裸 "A and B or C" 优先级陷阱,被 recoverUnfinished 恒真带绿,加括号锁语义
ck("screenLockedMs" in ENG and ("Mp4Repairer" in ENG or "recoverUnfinished" in ENG), "R7 崩溃保全链路未动")
ck('put("durationMs", durMs)' in ENG, "R8 报告原字段未破坏")

# ---------- N. v6.7.184 新增回归护栏 ----------
# N1 drift spanUs 公式: 必须是 n - n/10(时间中心距), 不是 n/10(每段跨度)
ck("(ord.size - ord.size / 10).coerceAtLeast(1) * 1_000_000.0" in ENG,
   "N1 spanUs 用 n-n/10(修 9 倍虚高)")
ck("(ord.size / 10).coerceAtLeast(1)" not in ENG, "N1b 旧 spanUs 公式已除")
# N2 sha256Quick 尾段: skip 目标 L-2*cap 且 while 循环扣减(短跳防护)
sha = ENG.split("private fun sha256Quick")[1].split("md.digest()")[0]
ck("f.length() - cap * 2" in sha, "N2 skip 目标为 L-2*cap")
ck("var toSkip" in sha and "toSkip -= s" in sha, "N2 skip 用 while 扣减(短跳防护)")
ck("ins.skip(f.length() - cap)" not in sha, "N2b 旧单条 skip 已除")
# N3 导航条 else 落球(与 2g 同源, 独立命名便于回归定位)
ck(ovl_insets.count("setLead(leadX()") >= 2, "N3 两 else 分支都落球")
# N4 wakeLockLostCount latch 全链接线
ck("@Volatile var wakeLockLostCount" in ENG, "N4a engine 有 wakeLockLostCount 字段")
ck("fun onWakeLockLost()" in ENG, "N4b engine 有 onWakeLockLost")
ck('put("wakeLockLostCount", wakeLockLostCount)' in ENG, "N4c 报告写出 wakeLockLostCount")
ck("engine?.onWakeLockLost()" in SRV, "N4d renew 检测丢失时调用")
ck("LOST detected during renew" in SRV, "N4e 丢失打日志(不静默)")
# N5 暂停期编码循环退避
ck("if (isPaused.get()) 100_000L else 2000L" in ENG, "N5a dequeue 超时暂停期退避 100s")
ck("Thread.sleep(if (isPaused.get()) 50L else 1L)" in ENG, "N5b sleep 暂停期 50ms")
# N5 安全性: reportProgress(续期源)必须仍在同一 while 循环体内, 退避不阻塞 1s 门。
# reportProgress 在 catch 之后仍属同一体, 故按行号区间校验: while 行 到 reportProgress 行
# 之间不得出现 while 的收尾 "}"(即循环提前结束)。
lines = ENG.splitlines()
w_idx = next(i for i,l in enumerate(lines) if "while (isRunning.get() && !forceStop.get() && !muxerVideoDone)" in l)
r_idx = next(i for i,l in enumerate(lines) if "reportProgress()" in l and i > w_idx)
between = lines[w_idx:r_idx]
ck(all(not l.strip().startswith("}") or "catch" not in l for l in between[-3:]),
   "N5c reportProgress 在退避 while 体内(续期不受退避影响)")
ck("if (isPaused.get()) 50L else 1L" in "".join(between), "N5d sleep 退避在 reportProgress 之前")

# ---------- N6. v6.7.185 截屏 Image is already closed 修复 ----------
# 去掉注释与字符串后判"真实代码调用",避免注释里提到 restore()/reader.close() 造成误判
def _code_only(t):
    t = re.sub(r'"([^"\\]|\\.)*"', '', t)
    t = re.sub(r'//[^\n]*', '', t)
    t = re.sub(r'/\*.*?\*/', '', t, flags=re.S)
    return t

shot_code = _code_only(SHOT)
# N6 断言限定在 captureDuringRecording 块内(v6.7.187 新增 captureStandalone 也含 reader.close,
# 全局计数会误判)
cd_block = SHOT.split("fun captureDuringRecording")[1].split("private fun imageToBitmap")[0] if "fun captureDuringRecording" in SHOT else ""
cd_code = _code_only(cd_block)
# N6a: restore() 已彻底拆掉,不再存在把"恢复投帧"与"关 reader"绑在一起的形态
ck("restore()" not in cd_code, "N6a restore() 已删除(拆成 resumeVd + closeReader)")
ck("val resumeVd" in cd_block and "val closeReader" in cd_block, "N6b 拆出 resumeVd 与 closeReader 两个 lambda")
ck("vd.setSurface(restoreTarget)" in cd_block, "N6b2 resumeVd 仍负责切回投帧")
# reader.close() 只允许出现在 closeReader lambda 内
ck(cd_code.count("reader.close()") == 1, "N6c reader.close() 仅存于 closeReader(无裸调用)")
# N6d: 回调里 acquire 后立刻 resumeVd, 且回调块内不得出现 reader.close
cb = cd_block.split("reader.setOnImageAvailableListener")[1].split("}, shotHandler)")[0] if "reader.setOnImageAvailableListener" in cd_block else ""
cb_no_comment = _code_only(cb)
ck("resumeVd()" in cb, "N6d 回调内立即 resumeVd(录制不空窗)")
ck("reader.close()" not in cb_no_comment, "N6d2 回调内无同步关 reader(旧 bug 形态已除)")
# N6e: imageToBitmap 必须在 closeReader 之前(时序根因)
bmp_i = SHOT.index("imageToBitmap(img")
close_i = SHOT.index("closeReader()   ", bmp_i) if "closeReader()   " in SHOT[bmp_i:] else SHOT.index("closeReader()", bmp_i + 20)
ck(bmp_i < close_i, "N6e imageToBitmap 早于 closeReader(时序正确)")
# N6f: 三处收尾路径都要关 reader(acquire_null / setSurface 失败 / 超时)
ck(shot_code.count("closeReader()") >= 4, "N6f 全部收尾路径都调 closeReader(定义+acquire_null+setSurface失败+超时+finally)")
# N6g: 保留原有失败原因诊断,不回退
ck('screenshot_fail reason=save_error' in SHOT, "N6g save_error 诊断保留")
ck('screenshot_fail reason=acquire_null' in SHOT, "N6h acquire_null 诊断保留")
ck('screenshot_fail reason=timeout' in SHOT, "N6i timeout 诊断保留")

# ---------- N7. v6.7.186 seg_N.mp4.idx 残留修复 ----------
# recoverSegmentManifests 发现段必须"manifest 无关",且必须有 .idx 兜底清扫
def _seg_block(t):
    # 取 recoverSegmentManifests 起, 到下一个 private fun 止(注意: 必须先切出段再找边界)
    if "private fun recoverSegmentManifests" not in t:
        return ""
    seg = t[t.index("private fun recoverSegmentManifests"):]
    end = seg.find("    private fun ", 20)
    return seg if end < 0 else seg[:end]

rb = _seg_block(REC)
rb_code = _code_only(rb)

# N7a: 旧 orphanTmp 单点回退已删(它只找 seg_1.mp4.tmp,封口片改名后必漏)
ck("orphanTmp" not in rb_code, "N7a orphanTmp 回退已删(旧单点发现失效)")
# N7b: manifest 丢失时改为扫目录,正则同时覆盖 seg_N.mp4 与 seg_N.mp4.tmp
ck('Regex("seg_\\\\d+\\\\.mp4(\\\\.tmp)?$")' in rb, "N7b 扫目录正则覆盖封口/未封口分片")
ck('dir.listFiles()?.filter' in rb, "N7b2 用 listFiles 扫目录补回分片")
# N7c: 发现解耦——扫目录不依赖 manifest/rec.segments 有内容
ck("if (!hasManifest && rec.segments.isEmpty()) {" in rb, "N7c 扫目录仅在 manifest 缺失分支触发(不干扰主路径)")
# N7d: manifest 主路径权威顺序保留
ck("for (seg in rec.segments) addPair(File(seg.path))" in rb, "N7d manifest 主路径 addPair 保留")
ck("val currentTmp = segFileAt" in rb, "N7d2 当前未封口片发现保留")
# N7e: .idx 兜底清扫两处(空 pairs 分支 + 合并/降级块统一收尾)
ck(rb.count('seg_recover_idx_sweep') == 2, "N7e .idx 兜底清扫两处(空pairs + 统一收尾)")
ck('it.name.endsWith(".idx")' in rb, "N7e2 清扫按 .idx 后缀匹配(覆盖孤儿 idx)")
# N7f: 空 pairs 分支不再裸 continue,先清扫再 continue
empty_br = rb.split('if (pairs.isEmpty()) {')[1].split('continue')[0] if 'if (pairs.isEmpty()) {' in rb else ""
ck('seg_recover_idx_sweep' in empty_br, "N7f 空 pairs 分支先清扫 .idx 再 continue(旧裸 continue 已除)")
# N7g: 统一收尾清扫位于合并/降级 if/else 块结束之后(覆盖两分支漏清)
tail = rb.split('segment recovery merge failed, kept fragments')[1] if 'segment recovery merge failed, kept fragments' in rb else ""
ck('seg_recover_idx_sweep' in tail, "N7g 合并/降级块结束后有统一清扫(覆盖两分支)")

# ---------- N8. v6.7.187 AZ 一体四子球 ----------
ovl_code = _code_only(OVL)
svc_code = _code_only(SVC)

# N8a: 子球①三态字段与内容描述
ck("var isRecording = false" in OVL, "N8a isRecording 字段存在")
ck("R.string.float_start" in OVL, "N8a2 非录制态 contentDesc 用 float_start")
ck('if (!isRecording) R.string.float_start' in OVL, "N8a3 三态描述分支: start/resume/pause")
# N8b: 子球①点击三态分发
ck("!isRecording -> listener.onStartClicked()" in OVL, "N8b1 非录制态点击分发 onStartClicked")
ck("isPaused -> listener.onResumeClicked()" in ovl_code, "N8b2 暂停态分发 onResumeClicked")
ck("else -> listener.onPauseClicked()" in ovl_code, "N8b3 录制态分发 onPauseClicked")
# N8c: 实心红圆点绘制分支(开始录制视觉)
ck("if (!isRecording)" in OVL and "drawCircle" in OVL, "N8c 非录制态画实心红圆点")
ck("color = colorStop" in OVL, "N8c2 红圆点与停止方块同色系")
# N8d: updateRecordingState 镜像 updatePauseState
ck("fun updateRecordingState(recording: Boolean)" in OVL, "N8d updateRecordingState 存在")
ck("if (!recording) isPaused = false" in OVL, "N8d2 退出录制态复位 isPaused(避免残留三角)")
ck("updatePauseState" in OVL and "updateRecordingState" in OVL, "N8d3 两函数并存")
# N8e: Listener 接口新增方法
ck("fun onStartClicked()" in OVL, "N8e RecordOverlayListener 声明 onStartClicked")
ck("override fun onStartClicked()" in SVC, "N8e2 Service 实现 onStartClicked")
# N8f: 仅 IDLE/FAILED 态可发起(非录制态守卫)
ck("st != RecordState.IDLE && st != RecordState.FAILED" in SVC, "N8f onStartClicked 仅 IDLE/FAILED 可发起")
# N8g: 非录制态截图走独立投影(不再弹"请先录屏"死路)
ck("CaptureActivity::class.java" in SVC and 'EXTRA_MODE, "shot"' in SVC, "N8g 非录制态截图起 CaptureActivity(shot)")
ck('EXTRA_MODE, "record"' in SVC, "N8h 子球①起 CaptureActivity(record)")
ck("请在录制中，请先发起录屏" not in SVC, "N8g2 旧'请先录屏'死路文案已除")
# N8i: setState 刷新录制态三态
ck("updateRecordingState(recNow)" in SVC, "N8i setState 内刷新 updateRecordingState")
ck("floatOverlayMirror" in SVC, "N8i3 镜像字段桥接 companion->实例(companion 内无法访问实例字段)")
ck("newState == RecordState.RECORDING || newState == RecordState.PAUSED" in SVC, "N8i2 recNow = RECORDING||PAUSED")
# N8j: CaptureActivity + Manifest + 透明主题
ck("class CaptureActivity : AppCompatActivity()" in CA, "N8j1 CaptureActivity 继承 AppCompatActivity(registerForActivityResult 需要)")
ck('registerForActivityResult' in CA, "N8j2 使用 registerForActivityResult 承载授权回调")
ck("ScreenRecorderApp.pendingResultCode = resultCode" in CA, "N8j3 深拷贝 data 存入全局 pending")
ck("ScreenshotHelper.captureStandalone(this, resultCode, data)" in CA, "N8j4 shot 模式走 captureStandalone")
ck("android:name=\".CaptureActivity\"" in MAN, "N8j5 Manifest 注册 CaptureActivity")
ck("android:theme=\"@style/Theme.ScreenRecorder.Transparent\"" in MAN, "N8j6 透明主题")
ck("android:excludeFromRecents=" in MAN and "android:noHistory=" in MAN, "N8j7 不进多任务/不留历史")
ck("android:taskAffinity=\"\"" in MAN, "N8j8 独立任务亲和(不混入主任务栈)")
# N8k: captureStandalone 生命周期三重清理防泄漏
ck("fun captureStandalone(" in SHOT, "N8k1 captureStandalone 存在")
ck("VIRTUAL_DISPLAY_FLAG_AUTO_MIRROR" in SHOT, "N8k2 一次性 VD 用 AUTO_MIRROR")
ck("try { mp.stop() } catch" in SHOT, "N8k3 抓完立即 stop projection")
ck("try { reader.close() } catch" in SHOT, "N8k4 抓完关闭 reader")
ck("if (vdCreated) vdRef?.release()" in SHOT, "N8k5 抓完释放 VD")
ck("screenshot_fail reason=create_vd" in SHOT, "N8k6 create VD 失败有诊断")
ck("screenshot_fail reason=timeout" in SHOT, "N8k7 超时兜底释放(同录制中截图)")
ck("GRAB_TIMEOUT_MS" in SHOT and "2, 2," in SHOT, "N8k8 复用 2x2 强制合成 + 超时兜底")
# N8l: MainActivity 入口替换 (v6.7.187 时代:cardSuperShot 存在; v6.7.188 已改开关)
MAIN = (ROOT/"app/src/main/java/com/monkeycode/screenrecorder/MainActivity.kt").read_text(encoding="utf-8")
if "cardSuperShot" in MAIN:
    ck("CaptureActivity::class.java" in MAIN and 'putExtra("mode", "shot")' in MAIN, "N8l cardSuperShot 非录制态起独立截图")
ck("先开始录制，再用悬浮球第四颗子球截图" not in MAIN, "N8l2 旧死路提示已除")

# ---------- v6.7.188 P1-P5 常驻悬浮球 + 三态修复 + 空闲视觉 ----------
OVL2 = OVL
SVC2 = SRV
LA = (ROOT/"app/src/main/res/layout/activity_main.xml").read_text(encoding="utf-8")
ST = (ROOT/"app/src/main/res/values/strings.xml").read_text(encoding="utf-8")
PREF = (ROOT/"app/src/main/java/com/monkeycode/screenrecorder/PreferencesManager.kt").read_text(encoding="utf-8")

# P1 【1】performAttach 挂载后按 recordState 回填三态
pa_seg = OVL2[OVL2.index("private fun performAttach()"):]
pa_seg = pa_seg[:pa_seg.index("android.util.Log.i(TAG, \"attach success\")")]
ck("ScreenRecorderApp.recordState" in pa_seg, "P1a performAttach 读 ScreenRecorderApp.recordState 作唯一真相源")
ck("RecordState.RECORDING" in pa_seg and "RecordState.PAUSED" in pa_seg, "P1b 三态判 RECORDING/PAUSED")
ck("subPauseButton.invalidate()" in pa_seg, "P1c 挂载后 invalidate ①")
ck("timerText.visibility = View.INVISIBLE" in pa_seg, "P1d 非录制态 timerText INVISIBLE")
ck("badgeView.visibility = View.GONE" in pa_seg, "P1e 非录制态 badgeView GONE")
# 不能用 ScreenRecorderApp.RecordState(它是顶层 enum)
ck("ScreenRecorderApp.RecordState" not in OVL2, "P1f RecordState 是顶层 enum,不误用嵌套")

# P2 【2】主页开关 + 常驻通知 + 三态收球分支
ck('const val ACTION_SHOW_OVERLAY' in SVC2, "P2a ACTION_SHOW_OVERLAY 常量")
ck('const val ACTION_HIDE_OVERLAY' in SVC2, "P2b ACTION_HIDE_OVERLAY 常量")
ck("private var overlayPersistent = false" in SVC2, "P2c overlayPersistent 字段")
ck("postPersistentOverlayNotification()" in SVC2, "P2d postPersistentOverlayNotification 存在")
ck("CHANNEL_OVERLAY" in SVC2 and "NOTIFICATION_ID_OVERLAY" in SVC2, "P2e 独立 channel/id")
ck("ACTION_SHOW_OVERLAY ->" in SVC2, "P2f when 处理 SHOW_OVERLAY")
ck("ACTION_HIDE_OVERLAY ->" in SVC2, "P2g when 处理 HIDE_OVERLAY")
ck("postPersistentOverlayNotification()" in SVC2 and "showFloatOverlay()" in SVC2, "P2h SHOW_OVERLAY 拉起常驻球+通知")
ck("dismissFloatOverlay()" in SVC2, "P2i HIDE_OVERLAY 收球")
ck("stopSelf()" in SVC2, "P2j HIDE_OVERLAY 停服务")
ck("if (!overlayPersistent)" in SVC2, "P2k cleanupAndStop 按 overlayPersistent 分支")
ck("NotificationCompat" in SVC2, "P2l 用 NotificationCompat 构建常驻通知")
ck("ic_recording_mono" in SVC2, "P2m 常驻通知小图标复用现有")
ck("MainActivity::class.java" in SVC2, "P2n 常驻通知点回主页")
ck("setContentTitle(\"悬浮球常驻中\")" in SVC2, "P2o 常驻通知标题")
ck("setContentText(\"不录制，可随时开始/暂停/截图\")" in SVC2, "P2p 常驻通知描述")
ck('hidePi' in SVC2 and 'hideAction' in SVC2, "P2q 常驻通知带隐藏动作")
ck("notificationManager.cancel(NOTIFICATION_ID_RECORDING)" in SVC2, "P2r 常驻时只清录制通知,不动常驻通知")

ck("cardShowOverlay" in LA, "P2s 布局 cardShowOverlay")
ck("swShowOverlay" in LA, "P2t 布局 swShowOverlay")
ck("section_show_overlay" in ST and "show_overlay_desc" in ST, "P2u strings 新增")
ck("section_super_shot" not in ST, "P2v strings 删 super_shot")
ck("PreferencesManager.isShowOverlayEnabled(this)" not in MAIN, "P2w 不用静态偏好(项目用实例 prefs)")
ck("prefsManager.isShowOverlayEnabled()" in MAIN, "P2x MainActivity 用实例 isShowOverlayEnabled")
ck("prefsManager.setShowOverlayEnabled(true)" in MAIN, "P2y MainActivity 打开时持久化 true")
ck("prefsManager.setShowOverlayEnabled(false)" in MAIN, "P2z MainActivity 关闭时持久化 false")
ck("ACTION_SHOW_OVERLAY" in MAIN, "P2{ MainActivity 发 SHOW_OVERLAY")
ck("ACTION_HIDE_OVERLAY" in MAIN, "P2| MainActivity 发 HIDE_OVERLAY")
ck("fun isShowOverlayEnabled" in PREF and 'prefs.getBoolean("show_overlay", false)' in PREF, "P2} prefs isShowOverlayEnabled")
ck("fun setShowOverlayEnabled" in PREF and 'prefs.edit().putBoolean("show_overlay"' in PREF, "P2~ prefs setShowOverlayEnabled")

# P3 【3】删 selfCheckLearnFpsCap
ck("selfCheckLearnFpsCap" not in REC, "P3a selfCheckLearnFpsCap 已删")
ck("fun capFpsByLearn" in REC, "P3b capFpsByLearn 保留")
ck("capFpsByLearn(" in REC and REC.count("capFpsByLearn(") >= 2, "P3c capFpsByLearn 至少 2 处(定义+生产调用)")

# P4 【4】仅重绘①
def block_of(src, anchor_start, anchor_end=None):
    a = src.index(anchor_start)
    return src[a:(src.index(anchor_end, a) if anchor_end else len(src))]

upd_rec = block_of(OVL2, "fun updateRecordingState(recording: Boolean)", "fun updateTimer")
upd_pau = block_of(OVL2, "fun updatePauseState(paused: Boolean)", "fun updateRecordingState")
ck("subPauseButton.invalidate()" in upd_rec, "P4a updateRecordingState 仅 invalidate ①")
ck("subBubbles.forEach" not in upd_rec, "P4b updateRecordingState 不再全量刷")
ck("subPauseButton.invalidate()" in upd_pau, "P4c updatePauseState 仅 invalidate ①")
ck("subBubbles.forEach" not in upd_pau, "P4d updatePauseState 不再全量刷")

# P5 【5】空闲视觉:timerText INVISIBLE / badgeView 按 isRecording 门控
tt = OVL2[OVL2.index("timerText = TextView(context)"):]
tt = tt[:tt.index("subPauseButton = createSubBubble")]
ck("visibility = View.INVISIBLE" in tt, "P5a timerText 创建即 INVISIBLE")
onL = OVL2[OVL2.index("override fun onLayout("):]
onL = onL[:onL.index("onApplyWindowInsets", onL.index("onLayout"))]
ck("if (isExpanded || !isRecording)" in onL and "View.GONE" in onL, "P5b onLayout badge 按 isRecording 门控")
ck("if (!recording) {" in upd_rec and "timerText.visibility = View.INVISIBLE" in upd_rec, "P5c updateRecordingState 非录制隐藏 timer")
ck("timerText.visibility = View.VISIBLE" in upd_rec, "P5d updateRecordingState 录制点亮 timer")
ck("badgeView.visibility = View.GONE" in upd_rec, "P5e updateRecordingState 非录制隐藏 badge")

# P6 版本
ck('versionCode = 317' in GRD and 'versionName = "6.7.188"' in GRD, "P6 build.gradle 版本 6.7.188")

print(f"{len(ok)} passed, {len(bad)} failed")
for m in bad:
    print("FAIL", m)
sys.exit(1 if bad else 0)
