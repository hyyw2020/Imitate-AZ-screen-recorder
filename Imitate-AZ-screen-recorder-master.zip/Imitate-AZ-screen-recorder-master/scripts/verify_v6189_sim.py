#!/usr/bin/env python3
# v6.7.189 静态断言:16 项引擎/日志改进 + 4 项 UI 门禁
import re, sys

ROOT = "/workspace/app/src/main/java/com/monkeycode/screenrecorder"
def rd(p):
    with open(p, encoding="utf-8") as f: return f.read()

eng = rd(f"{ROOT}/RecorderEngine.kt")
svc = rd(f"{ROOT}/ScreenRecorderService.kt")
main = rd(f"{ROOT}/MainActivity.kt")
diag = rd(f"{ROOT}/DiagLog.kt")
ovl = rd(f"{ROOT}/RecordOverlay.kt")
safe = rd(f"{ROOT}/SafeDeleteUtil.kt")

fails = []
def ck(name, cond):
    if not cond: fails.append(name)
    print(("PASS " if cond else "FAIL ") + name)

def body(src, start_marker, end_marker):
    i = src.index(start_marker)
    j = src.index(end_marker, i)
    return src[i:j]

# S1/S2: onSegments 恰 3 处且 stopAsync 内含一处
ck("S1 onSegments==3", eng.count("callback?.onSegments") == 3)
sa = body(eng, "fun stopAsync(", "private fun logLearnReport")
ck("S2 onSegments in stopAsync", "callback?.onSegments" in sa and "getSegmentPaths()" in sa)
# S3: Service 无 >1 门限
ck("S3 no >1 gate", "segments.size > 1" not in svc and "engine onSegments count=" in svc)
# S4/S5
ck("S4 segment_merge_fail==1", eng.count("segment_merge_fail") == 1)
ck("S5 keepSegmentsAsHistory>=2", eng.count("keepSegmentsAsHistory()") >= 2)
ck("S5b inputsDiag", eng.count("inputsDiag") >= 2)
# S6: boost 函数体内无 effectiveCaptureFps
boost = body(eng, "private fun applyBoostPeriodic", "private fun checkFrameRateHealth")
ck("S6 no effectiveCaptureFps in boost", "effectiveCaptureFps" not in boost)
# S7/S8
ck("S7 BOOST_FACTOR_MAX", eng.count("BOOST_FACTOR_MAX") == 2 and "BOOST_FACTOR_MAX = 1.5" in eng)
ck("S8 bitrate_boost_ineffective==1", eng.count("bitrate_boost_ineffective") == 1)
ck("S8b denom targetFps", "val denom = if (targetFps > 0) targetFps else cfg.fps" in eng)
# S9/S10
ck("S9 no interrupted_idx delete", "restoreStale_interrupted_idx" not in eng)
ck("S10 restore_stale_summary>=2", eng.count("restore_stale_summary") >= 2)
ck("S10b restore_stale_keep", "restore_stale_keep" in eng and "idxKept" in eng)
ck("S10c SafeDeleteUtil guard", "interrupted_kept" in safe and "_interrupted" in safe)
# S11/S12: 采样判定分离
ck("S11 sampler owns raw read", "readThermalZoneMaxC()" in eng and "readThermalTempC" not in eng)
ck("S12 thermalTempC()>=2", eng.count("thermalTempC()") >= 2)
ck("S12b thermal consts", "THERMAL_MEDIAN_N = 5" in eng and "THERMAL_SPIKE_C = 15" in eng)
ck("S12c thermal_summary", "thermal_summary" in eng)
# S13/S14
ck("S13 BASELINE_PHYSICAL_MAX_C==65", "BASELINE_PHYSICAL_MAX_C = 65" in eng)
ck("S13b no THERMAL_DOWNGRADE_C reason", "temp>=${THERMAL_DOWNGRADE_C}" not in eng)
ck("S14 coerceIn bounds==1", eng.count("coerceIn(lowerBound, upperBound)") == 1)
ck("S14b reason truth", "overheat(temp>=baseline+" in eng and "battery<20(actual=" in eng)
# S15
ck("S15 outputFile=newFile", eng.count("outputFile = File(newFile)") == 1)
ck("S15b reportProgress fallback", "getTotalSegmentBytes().takeIf" in eng)
# S16/S17
ck("S16 FPS_CAP_FLOOR==2 val=30", eng.count("FPS_CAP_FLOOR") == 2 and "FPS_CAP_FLOOR = 30" in eng)
ck("S17 learn_reseed==2", eng.count("learn_reseed") == 2)
# S18
ck("S18 SEG_IDR consts", "SEG_IDR_PRE_REQUEST_MS = 800L" in eng and "SEG_IDR_WAIT_MS = 500L" in eng)
ck("S18b segIdrWaitStartMs>=3", eng.count("segIdrWaitStartMs") >= 3)
ck("S18c pre-request wired", "segIdrPreRequested = true" in eng and "SEGMENT_DURATION_MS - SEG_IDR_PRE_REQUEST_MS" in eng)
# S19
ck("S19 av_reanchor>=2", eng.count("av_reanchor") >= 2)
ck("S19b audioPtsOffsetUs>=3", eng.count("audioPtsOffsetUs") >= 3)
ck("S19c AV consts", "AV_REANCHOR_US = 250_000L" in eng and "AV_REANCHOR_WINDOWS = 3" in eng)
ck("S19d av_summary", "av_summary" in eng)
# S20
ck("S20 stall logs", eng.count("stall_summary") >= 1 and eng.count("capture_stall_window") >= 1)
ck("S20b STALL_WINDOW_MAX==2", eng.count("STALL_WINDOW_MAX") == 2)
# S21
ck("S21 audio_silent_warning==1", eng.count("audio_silent_warning") == 1)
ck("S21b AUDIO_SILENT_WARN_MS==2", eng.count("AUDIO_SILENT_WARN_MS") == 2)
# S22
ck("S22 resetMoveGap", diag.count("fun resetMoveGap") == 1 and ovl.count("DiagLog.resetMoveGap()") == 1)
# S23
ck("S23 cleanupDoneForSession>=3", svc.count("cleanupDoneForSession") >= 3)
ck("S23b newSession in handleStart", "newSession()" in body(svc, "private fun handleStart", "prepareRetryCount"))
# S24/S25
# v6.7.191: frame_accounting 字符串在注释里也被引用(P0-4 双账交叉验证说明),
# 原断言"整个文件只出现 1 次"过严,改为断言真正的日志调用点唯一。
ck("S24 frame_accounting 日志调用唯一", eng.count('logDetail("frame_accounting"') == 1)
ck("S24b drop counters", eng.count("dropTooDense") >= 2 and eng.count("dropNonMonotonic") >= 2)
ck("S25 stop_timing==1", eng.count("stop_timing") == 1)
ck("S25b capture round", eng.count("kotlin.math.round(effectiveCaptureFps") == 1)

# UI 门禁 S1-S18
ck("U1 SESSION_GATED_IDS", "private val SESSION_GATED_IDS = intArrayOf(" in main)
arr = main[main.index("SESSION_GATED_IDS = intArrayOf("):]
arr = arr[:arr.index("\n    )")]
ck("U2 24 ids", len(re.findall(r"R\.id\.\w+", arr)) == 24)
for needle in ["settingsItemHevc","settingsItemTheme","settingsItemCountdown","settingsItemDuration",
               "settingsItemShake","settingsItemOverlayAlpha","settingsItemCompressQuality",
               "swShowOverlay","swPowerSaveDowngrade","flAudioGrid"]:
    ck("U2 id " + needle, needle in arr)
ck("U3 for-loop gate", "for (id in SESSION_GATED_IDS)" in main)
ck("U4 no old-style isEnabled lines", "findViewById<View>(R.id.btnExportLog).isEnabled" not in main)
ck("U5 session_gate log", "session_gate" in main and "disabledNow=" in main)
ck("U7 bindClick/bindCheck", "private fun bindClick(" in main and "private fun bindCheck(" in main)
ck("U8 blocked logs", "click_blocked" in main and "check_blocked" in main)
ck("U9 hevc via bindClick", "bindClick(R.id.settingsItemHevc)" in main)
ck("U10 switches via bindCheck", "bindCheck(R.id.swShowOverlay" in main and
   "bindCheck(R.id.swPowerSaveDowngrade" in main and "bindCheck(R.id.swResumeProtect" in main)
ck("U13 theme guard", "theme_blocked" in main)
ck("U16 gate_manifest", "gate_manifest ids=" in main)
ck("U17 state_change", "state_change st=" in main and "allowed=btnStart,btnPause" in main)
ck("U18 gated= appended", "gated=${SESSION_GATED_IDS.size}" in main)

print()
if fails:
    print("FAILED:", fails); sys.exit(1)
print("ALL PASS")
