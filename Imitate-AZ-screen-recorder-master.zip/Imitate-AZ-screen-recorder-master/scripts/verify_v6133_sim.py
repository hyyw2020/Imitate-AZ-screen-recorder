#!/usr/bin/env python3
"""v6.7.133 自动保留(废横幅)模拟验证.

镜像源码逻辑,用真实临时文件构造场景:
  1. findStaleRecordings(RecorderEngine.kt:407): 30s 活跃窗短路 + 扫描 .recording.tmp + 开关关静默删。
  2. autoRestoreStaleRecordings(MainActivity.kt): 逐条 restoreStale -> 成功写历史/失败保留 _interrupted。
  3. parseRecordingTimestamp(MainActivity.kt): 从 ScreenRecord_yyyyMMdd_HHmmss 解析原始时间戳。
  4. 历史按真实录制时间排序(被杀旧录制不排到新录制上方)。

运行: python3 scripts/verify_v6133_sim.py
退出码 0 = 全 PASS。
"""
import os, shutil, tempfile, time, re
from datetime import datetime

STALE_ACTIVE_WINDOW_MS = 30_000
KEEP_STALE = 3

results = []
def check(name, cond, detail=""):
    results.append((name, bool(cond)))
    print(f"[{'PASS' if cond else 'FAIL'}] {name}" + (f" :: {detail}" if detail else ""))


def parse_recording_timestamp(filename):
    """镜像 MainActivity.parseRecordingTimestamp"""
    base = filename[:-len(".recording.tmp")] if filename.endswith(".recording.tmp") else filename
    m = re.search(r"(?:_)?(\d{8})_(\d{6})", base)
    if not m:
        return -1
    try:
        return int(datetime.strptime(m.group(1) + "_" + m.group(2), "%Y%m%d_%H%M%S").timestamp() * 1000)
    except Exception:
        return -1


def find_stale_recordings(base_dir, enabled, exported=None, now_ms=None):
    """镜像 RecorderEngine.findStaleRecordings。30s 活跃窗短路 + 扫描 + 开关关静默删。"""
    if exported is None:
        exported = set()
    if now_ms is None:
        now_ms = time.time() * 1000
    found = []
    # 先找"正在写入"的 tmp(30s 内修改), 有则跳过
    active = None
    for root, dirs, files in os.walk(base_dir):
        for fn in files:
            fp = os.path.join(root, fn)
            if fn.endswith(".recording.tmp"):
                age = now_ms - (os.path.getmtime(fp) * 1000)
                if age < STALE_ACTIVE_WINDOW_MS:
                    active = fp
    if active:
        return []
    # 扫描
    for root, dirs, files in os.walk(base_dir):
        for fn in files:
            if fn.endswith(".recording.tmp"):
                fp = os.path.join(root, fn)
                if fp in exported:
                    try: os.remove(fp)
                    except: pass
                else:
                    found.append(fp)
    found.sort(key=lambda f: os.path.getmtime(f), reverse=True)
    # 保留 KEEP_STALE 个, 更旧的删
    for f in found[KEEP_STALE:]:
        _delete_stale(f)
    keep = found[:KEEP_STALE]
    if not keep:
        return []
    if not enabled:
        # 开关关: 静默删除全部残留
        to_del = []
        for f in keep:
            idx = f + ".idx"
            try:
                os.remove(f)
                if os.path.exists(idx):
                    os.remove(idx)
                to_del.append(f)
            except: pass
        keep = [f for f in keep if f not in to_del]
    return keep


def _delete_stale(f):
    idx = f + ".idx"
    try: os.remove(f)
    except: pass
    if os.path.exists(idx):
        try: os.remove(idx)
        except: pass


def auto_restore(base_dir, enabled):
    """镜像 MainActivity.autoRestoreStaleRecordings。返回 (entries, kept_files)。
    entries = [{fileName, timestamp}], kept_files = 修复失败保留的 _interrupted.mp4。"""
    stale = find_stale_recordings(base_dir, enabled)
    entries = []
    kept = []
    for f in stale:
        # restoreStale: 有 .idx 则重建为 _restored.mp4(playable), 否则保留 _interrupted.mp4
        idx = f + ".idx"
        if os.path.exists(idx):
            playable = f[:-len(".recording.tmp")] + "_restored.mp4"
            os.rename(f, playable)
            entries.append({
                "fileName": os.path.basename(playable),
                "timestamp": parse_recording_timestamp(os.path.basename(f)),
                "has_timestamp": parse_recording_timestamp(os.path.basename(f)) > 0,
            })
        else:
            kept_path = f[:-len(".recording.tmp")] + "_interrupted.mp4"
            os.rename(f, kept_path)
            kept.append(kept_path)
    return entries, kept


# ============================================================
# 场景1: 两个被杀残留(均有 .idx), 重启后自动恢复进历史, 按原始录制时间排序
# ============================================================
tmpdir = tempfile.mkdtemp()
try:
    # 旧录制: ScreenRecord_20260901_100000 (9月1日)
    old_rec = os.path.join(tmpdir, "ScreenRecord_20260901_100000.recording.tmp")
    new_rec = os.path.join(tmpdir, "ScreenRecord_20260907_153000.recording.tmp")  # 新录制: 9月7日
    with open(old_rec, "wb") as f: f.write(b"old data")
    with open(new_rec, "wb") as f: f.write(b"new data")
    with open(old_rec + ".idx", "wb") as f: f.write(b"idx")
    with open(new_rec + ".idx", "wb") as f: f.write(b"idx")
    # 把两个 tmp 的 mtime 设到很久以前(被杀时), 避免 30s 短路
    past = (time.time() - 86400)  # 1 天前
    os.utime(old_rec, (past, past))
    os.utime(new_rec, (past, past))

    entries, kept = auto_restore(tmpdir, enabled=True)
    check("场景1 自动恢复 2 条(无 UI 点击)", len(entries) == 2, f"恢复 {len(entries)} 条")
    check("场景1 全部成功(playable)", all(e["has_timestamp"] for e in entries),
          f"时间戳解析成功 {[e['timestamp'] for e in entries]}")
    check("场景1 无失败保留", len(kept) == 0, f"保留 {len(kept)} 个 _interrupted")

    # 历史按 timestamp 升序排序(旧在前, 新在后)——关键: 被杀旧录制不排到新录制上方
    entries_sorted = sorted(entries, key=lambda e: e["timestamp"])
    check("场景1 历史按真实录制时间排序(旧在前新在后)",
          entries_sorted[0]["timestamp"] < entries_sorted[1]["timestamp"],
          f"排序后 {[e['timestamp'] for e in entries_sorted]}")
    old_ts = parse_recording_timestamp("ScreenRecord_20260901_100000.recording.tmp")
    new_ts = parse_recording_timestamp("ScreenRecord_20260907_153000.recording.tmp")
    check("场景1 旧录制时间戳=9月1日10:00", entries_sorted[0]["timestamp"] == old_ts,
          f"期望 {old_ts} 实际 {entries_sorted[0]['timestamp']}")
    check("场景1 新录制时间戳=9月7日15:30", entries_sorted[1]["timestamp"] == new_ts,
          f"期望 {new_ts} 实际 {entries_sorted[1]['timestamp']}")

    # ============================================================
    # 场景2: 开关关闭时残留被静默删除, 不残留文件
    # ============================================================
    rec_off = os.path.join(tmpdir, "ScreenRecord_20260903_120000.recording.tmp")
    with open(rec_off, "wb") as f: f.write(b"off data")
    with open(rec_off + ".idx", "wb") as f: f.write(b"idx")
    os.utime(rec_off, (past, past))

    entries2, kept2 = auto_restore(tmpdir, enabled=False)
    check("场景2 开关关闭: 不恢复进历史", len(entries2) == 0, f"恢复 {len(entries2)} 条")
    check("场景2 开关关闭: 不保留 _interrupted", len(kept2) == 0, f"保留 {len(kept2)} 个")
    check("场景2 开关关闭: 残留文件已删除",
          not os.path.exists(rec_off) and not os.path.exists(rec_off + ".idx"),
          "tmp 与 .idx 均已删除")

    # ============================================================
    # 场景3: 30s 活跃窗短路——正在写入的 tmp 不被扫描/删除
    # ============================================================
    active_rec = os.path.join(tmpdir, "ScreenRecord_20260908_090000.recording.tmp")
    with open(active_rec, "wb") as f: f.write(b"active")  # mtime=now, 30s 内
    with open(active_rec + ".idx", "wb") as f: f.write(b"idx")
    stale = find_stale_recordings(tmpdir, enabled=True)
    check("场景3 活跃 tmp 存在时扫描返回空(短路)", stale == [], f"返回 {stale}")
    check("场景3 活跃 tmp 未被改名/删除", os.path.exists(active_rec),
          "正在写入的 tmp 保留原样")

    # 清理活跃 tmp 后, 旧残留可被正常扫描
    os.remove(active_rec)
    os.remove(active_rec + ".idx")
    # 制造一个旧残留
    old2 = os.path.join(tmpdir, "ScreenRecord_20260902_080000.recording.tmp")
    with open(old2, "wb") as f: f.write(b"old2")
    os.utime(old2, (past, past))
    stale2 = find_stale_recordings(tmpdir, enabled=True)
    check("场景3 无活跃 tmp 时旧残留可正常扫描", old2 in stale2, f"找到 {stale2}")

    # ============================================================
    # 场景4: 时间戳解析回退(文件名无时间模式 -> -1)
    # ============================================================
    check("时间戳解析: 无模式文件名返回 -1", parse_recording_timestamp("random_name.recording.tmp") == -1)
    check("时间戳解析: ScreenRecord_yyyyMMdd_HHmmss 正确",
          parse_recording_timestamp("ScreenRecord_20260908_120000.recording.tmp") ==
          parse_recording_timestamp("ScreenRecord_20260908_120000"))

finally:
    shutil.rmtree(tmpdir, ignore_errors=True)

print("\n" + "=" * 60)
passed = sum(1 for _, ok in results if ok)
total = len(results)
print(f"结果: {passed}/{total} PASS")
if passed == total:
    print("SIM-VERIFY PASS (v6.7.133)")
    exit(0)
else:
    print("SIM-VERIFY FAIL")
    for name, ok in results:
        if not ok:
            print(f"  失败: {name}")
    exit(1)
