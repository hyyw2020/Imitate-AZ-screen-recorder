#!/usr/bin/env python3
# v6.7.182 验证:补 WAKE_LOCK 权限根治持锁静默失效 + 持锁失败显式告警。
# 镜像方案「五、验收方式」的静态差分部分,不依赖真机。
import os
import re
import sys

ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
B = os.path.join(ROOT, "app/src/main/java/com/monkeycode/screenrecorder")
SVC = os.path.join(B, "ScreenRecorderService.kt")
ENGINE = os.path.join(B, "RecorderEngine.kt")
MANIFEST = os.path.join(ROOT, "app/src/main/AndroidManifest.xml")

passed = failed = 0


def check(name, cond):
    global passed, failed
    print(("PASS " if cond else "FAIL ") + name)
    if cond:
        passed += 1
    else:
        failed += 1


def read(p):
    with open(p, encoding="utf-8") as f:
        return f.read()


def body_of(src, fn_name):
    idx = src.find(f"fun {fn_name}(")
    if idx < 0:
        return None
    s = src.find("{", idx)
    depth = 0
    for i in range(s, len(src)):
        if src[i] == "{":
            depth += 1
        elif src[i] == "}":
            depth -= 1
            if depth == 0:
                return src[s + 1:i]
    return None


svc = read(SVC)
eng = read(ENGINE)
manifest = read(MANIFEST)

# --- 核心:PARTIAL_WAKE_LOCK 已恢复 ---
check("PowerManager.WakeLock 字段存在", re.search(r"private\s+var\s+wakeLock:\s*PowerManager\.WakeLock\?", svc) is not None)
check("WAKE_LOCK_TAG 常量存在", "WAKE_LOCK_TAG" in svc)
check("WAKE_LOCK_TIMEOUT_MS = 30 分钟", "WAKE_LOCK_TIMEOUT_MS = 30L * 60 * 1000L" in svc)

acq = body_of(svc, "acquireWakeLock")
ren = body_of(svc, "renewWakeLock")
rel = body_of(svc, "releaseWakeLock")
check("acquireWakeLock 存在", acq is not None)
check("renewWakeLock 存在", ren is not None)
check("releaseWakeLock 存在", rel is not None)
# 必须是 PARTIAL,不能是 SCREEN_BRIGHT/SCREEN_DIM/FULL_SCREEN
check("使用 PARTIAL_WAKE_LOCK(非 SCREEN_BRIGHT/FULL)",
      acq is not None and "PowerManager.PARTIAL_WAKE_LOCK" in acq
      and "SCREEN_BRIGHT_WAKE_LOCK" not in acq
      and "FULL_SCREEN_WAKE_LOCK" not in acq and "SCREEN_DIM_WAKE_LOCK" not in acq)
check("acquire 带超时(非无限持锁)",
      acq is not None and "acquire(WAKE_LOCK_TIMEOUT_MS)" in acq)
check("renew 仅在未持锁时续期", ren is not None and "isHeld" in ren)
check("release 幂等(判 isHeld 再释放)", rel is not None and "isHeld" in rel and "wakeLock = null" in rel)

# --- 四处调用点 ---
on_prog = body_of(svc, "onProgress")
check("onProgress 每秒续期 renewWakeLock",
      on_prog is not None and "renewWakeLock()" in on_prog)
check("录制开始处 acquireWakeLock",
      re.search(r"engine\.start\(engineConfig,\s*projection\)\s*\n\s*acquireWakeLock\(\)", svc) is not None)
check("cleanupAndStop 调 releaseWakeLock",
      "releaseWakeLock()" in body_of(svc, "cleanupAndStop"))
check("onDestroy 兜底 releaseWakeLock",
      "releaseWakeLock()" in body_of(svc, "onDestroy"))

# --- 关键:权限与豁免的区分(硬伤修复) ---
check("Manifest 无 REQUEST_IGNORE_BATTERY_OPTIMIZATIONS(未申请豁免)",
      "REQUEST_IGNORE_BATTERY_OPTIMIZATIONS" not in manifest)
# v6.7.182: WAKE_LOCK 必须声明,否则 acquire() 抛 SecurityException、锁形同虚设。
# 它是普通权限,安装自动授予,不等于电池优化豁免。
check("Manifest 声明 WAKE_LOCK 权限(持锁必需,否则静默失效)",
      'android.permission.WAKE_LOCK' in manifest)
check("Manifest 无 INTERNET 权限(硬约束)", "android.permission.INTERNET" not in manifest)

# --- 注释勘误:不得再声称 PARTIAL 无需权限 ---
check("已清除'纯 PARTIAL 无需 WAKE_LOCK 权限'错误注释",
      "纯 PARTIAL 无需 WAKE_LOCK 权限" not in svc
      and "PARTIAL 无需 WAKE_LOCK 权限" not in svc)
check("注释如实说明 WAKE_LOCK 为普通权限且非豁免",
      "android.permission.WAKE_LOCK" in svc and "普通权限" in svc)

# --- 补丁 C:持锁失败必须显式告警,不能静默吞掉 ---
check("acquireWakeLock 失败时写 DiagLog 告警",
      acq is not None and "DiagLog.logEvent(\"WAKE_LOCK\"" in acq and "FAILED" in acq)
check("acquireWakeLock 失败置 wakeLockAcquired=false",
      acq is not None and "wakeLockAcquired = false" in acq)
check("renewWakeLock 失败同样告警",
      ren is not None and "RENEW FAILED" in ren and "wakeLockAcquired = false" in ren)
check("acquire 成功置 wakeLockAcquired=true",
      acq is not None and "wakeLockAcquired = true" in acq)
check("状态位字段存在(@Volatile)",
      re.search(r"@Volatile\s+private\s+var\s+wakeLockAcquired\s*=\s*false", svc) is not None)
check("release 复位状态位",
      rel is not None and "wakeLockAcquired = false" in rel)

# --- N1: 停止时仍锁屏的时长补算 ---
check("RECORD_SUMMARY 前补算最后一段锁屏时长",
      re.search(r"if \(screenLockedAtMs >= 0\)\s*\{\s*screenLockedTotalMs \+= SystemClock\.elapsedRealtime\(\) - screenLockedAtMs", eng) is not None)
check("补算后复位 screenLockedAtMs", "screenLockedAtMs = -1" in eng)
check("screenLockedMs 仍写入报告", 'put("screenLockedMs", screenLockedTotalMs)' in eng)

# --- 与既有改动不冲突:锁屏仍只观测不停止 ---
rec = body_of(svc, "registerScreenStateReceiver")
check("屏幕接收器仍存在", rec is not None)
check("接收器内无 stopAsync", rec is not None and "stopAsync" not in rec)
check("接收器内无 handleStop", rec is not None and "handleStop" not in rec)
check("接收器内无 cleanupAndStop", rec is not None and "cleanupAndStop" not in rec)
check("屏幕接收器监听 SCREEN_OFF/ON",
      rec is not None and "ACTION_SCREEN_OFF" in rec and "ACTION_SCREEN_ON" in rec)

# --- 屏幕常亮仍在(与 WakeLock 是两件独立的事,两者叠加才等于锁屏连续录制) ---
check("RecordOverlay 仍有 FLAG_KEEP_SCREEN_ON",
      "FLAG_KEEP_SCREEN_ON" in read(os.path.join(B, "RecordOverlay.kt")))
check("MainActivity 仍有 FLAG_KEEP_SCREEN_ON 双保险",
      "FLAG_KEEP_SCREEN_ON" in read(os.path.join(B, "MainActivity.kt")))

# --- 暗色纯黑未被回退 ---
night = read(os.path.join(ROOT, "app/src/main/res/values-night/colors.xml"))
check("background 仍为纯黑", re.search(r'<color name="background">#000000</color>', night) is not None)

print(f"\n{passed} passed, {failed} failed")
sys.exit(1 if failed else 0)
