package com.monkeycode.screenrecorder

import android.content.Context
import android.net.Uri

class PreferencesManager(context: Context) {
    private val prefs = context.getSharedPreferences("recorder_prefs", Context.MODE_PRIVATE)

    fun loadConfig(): RecorderConfig {
        val audioModeOrdinal = prefs.getInt("audio_mode", AudioMode.SPEAKER_ONLY.ordinal)
        val audioMode = AudioMode.entries.getOrElse(audioModeOrdinal) { AudioMode.SPEAKER_ONLY }
        val pattern = prefs.getString("file_name_pattern", "ScreenRecord_%Y%m%d_%H%M%S") ?: "ScreenRecord_%Y%m%d_%H%M%S"
        val uriStr = prefs.getString("output_uri", null)
        val outputUri = if (uriStr != null) Uri.parse(uriStr) else null
        return RecorderConfig(audioMode, pattern, outputUri)
    }

    fun saveConfig(config: RecorderConfig) {
        prefs.edit()
            .putInt("audio_mode", config.audioMode.ordinal)
            .putString("file_name_pattern", config.fileNamePattern)
            .putString("output_uri", config.outputUri?.toString())
            .apply()
    }

    // v6.7.129 (A): 深色三态迁移。dark_mode 从 Boolean(0/1) 迁移为 Int 三态:
    // 0=跟随系统(默认) / 1=浅色 / 2=深色,由 AppCompatDelegate.setDefaultNightMode 驱动。
    // v6.7.166: 同名键类型冲突根治。老版以同名键 dark_mode 存 Boolean,升级后 getInt
    // 走平台 (Integer)map.get() 强转,存值为 Boolean 即抛 ClassCastException
    // (默认值仅在 key 缺失时生效,类型冲突不回退默认)。故不能"跳过迁移",
    // 否则老用户(曾开过深色)启动时 applySavedNightMode 即崩溃。
    // 修复: getInt 抛 CCE 时 catch 内用 getBoolean 读出老值,映射 老 true->2(深)/老 false->1(浅),
    // putInt 覆写为 Int 永久消除冲突,且保留用户原本的明暗选择(而非静默改成跟随系统)。
    // 新用户/已存 Int 的用户: getInt 直接成功,永不进 catch,零开销。
    fun darkMode(): Int {
        return try {
            prefs.getInt("dark_mode", 0)
        } catch (e: ClassCastException) {
            val oldDark = prefs.getBoolean("dark_mode", false)
            val migrated = if (oldDark) 2 else 1
            prefs.edit().putInt("dark_mode", migrated).apply()
            DiagLog.logEvent("CFG", "dark_mode migrated old=$oldDark -> $migrated")
            migrated
        }
    }
    fun setDarkMode(mode: Int) {
        prefs.edit().putInt("dark_mode", mode.coerceIn(0, 2)).apply()
    }

    // v6.7.107 (U1): 画质参数持久化。旧实现 currentQuality 只在 Activity 内存字段,
    // 旋转/暗色切换/进程回收重建后全部回落默认值,用户选好的分辨率/帧率/码率/方向
    // 静默丢失且无任何提示,下次录制直接按默认参数执行。
    fun loadQuality(): QualityParams {
        val w = prefs.getInt("q_width", 1920)
        val h = prefs.getInt("q_height", 1080)
        val fps = prefs.getInt("q_fps", 60)
        val vbr = prefs.getInt("q_vbitrate", 24_000_000)
        val abr = prefs.getInt("q_abitrate", 128_000)
        val dpi = prefs.getInt("q_dpi", 320)
        val hevc = prefs.getBoolean("q_prefer_hevc", true)
        val orient = prefs.getInt("q_orientation", 0)
        return QualityParams(w, h, fps, vbr, abr, dpi, hevc, orient)
    }

    fun saveQuality(q: QualityParams) {
        prefs.edit()
            .putInt("q_width", q.width)
            .putInt("q_height", q.height)
            .putInt("q_fps", q.frameRate)
            .putInt("q_vbitrate", q.videoBitRate)
            .putInt("q_abitrate", q.audioBitRate)
            .putInt("q_dpi", q.dpi)
            .putBoolean("q_prefer_hevc", q.preferHevc)
            .putInt("q_orientation", q.orientation)
            .apply()
    }

    fun selectedEncoder(): String? = prefs.getString("selected_encoder", null)
    fun setSelectedEncoder(name: String?) {
        prefs.edit().putString("selected_encoder", name).apply()
    }

    // v6.7.120 (被杀保护): 启动时重建 moov 分流的开关, 默认开启。
    fun isResumeProtectEnabled(): Boolean = prefs.getBoolean("resume_protect", true)
    fun setResumeProtectEnabled(enabled: Boolean) {
        prefs.edit().putBoolean("resume_protect", enabled).apply()
    }

    // v6.7.188h (改造2): 省电模式是否允许影响码率。默认 true = 保持既有行为,用户可关。
    // 省电模式在部分 ROM 常驻为真,关掉后可避免"降档后永不回弹"。
    fun isAllowPowerSaveDowngrade(): Boolean = prefs.getBoolean("allow_ps_downgrade", true)
    fun setAllowPowerSaveDowngrade(enabled: Boolean) {
        prefs.edit().putBoolean("allow_ps_downgrade", enabled).apply()
    }

    // v6.7.188 (【2】): 常驻悬浮球开关, 默认关闭。
    fun isShowOverlayEnabled(): Boolean = prefs.getBoolean("show_overlay", false)
    fun setShowOverlayEnabled(enabled: Boolean) {
        prefs.edit().putBoolean("show_overlay", enabled).apply()
    }

    var lastDiagPath: String
        get() = prefs.getString("last_diag_path", "") ?: ""
        set(value) {
            prefs.edit().putString("last_diag_path", value).apply()
        }

    // v6.7.144 (P0-1): 录制倒计时秒数。0=关闭(直接起录),1-10 有效。
    // 借鉴必剪 MediaConfig.countdownSwitch / 剪映 CountDownView:倒计时结束才真正起录。
    fun countdownSeconds(): Int = prefs.getInt("countdown_seconds", 0)
    fun setCountdownSeconds(s: Int) {
        prefs.edit().putInt("countdown_seconds", s.coerceIn(0, 10)).apply()
    }

    // v6.7.144 (P0-2): 录制时长上限(分钟)。0=不限,1/5/10/30/60 有效。
    // 借鉴必剪 MediaConfig.recordDuration:到点自动保存停止,防失控占盘。
    fun durationLimitMinutes(): Int = prefs.getInt("duration_limit_min", 0)
    fun setDurationLimitMinutes(m: Int) {
        prefs.edit().putInt("duration_limit_min", m.coerceIn(0, 60)).apply()
    }

    // v6.7.144 (P0-3): 摇一摇停止。500ms 内连续 2 次超 2.5g 判为摇动。
    // 借鉴必剪 MediaConfig.shakeToStopRecord;默认开(录制态才注册,误触已由双阈值防住)。
    fun isShakeToStopEnabled(): Boolean = prefs.getBoolean("shake_to_stop", true)
    fun setShakeToStopEnabled(e: Boolean) {
        prefs.edit().putBoolean("shake_to_stop", e).apply()
    }

    // v6.7.145 (P1-7): 悬浮球透明度百分比。40-100,默认 92 对齐原硬编码值。
    // 借鉴剪映 FloatWindowManager/BigFloatView/SmallFloatView 贴边低打扰形态。
    fun overlayAlphaPercent(): Int = prefs.getInt("overlay_alpha_percent", 92)
    fun setOverlayAlphaPercent(p: Int) {
        prefs.edit().putInt("overlay_alpha_percent", p.coerceIn(40, 100)).apply()
    }

    // v6.7.161 (压缩画质模式): 开启后完全自动(分辨率/帧率/码率均 Auto),
    // 按必剪压缩形态录制(短边 640 等比 + 30fps + AVC)。默认关,不牺牲常规录制的画质/帧率。
    fun isCompressQualityEnabled(): Boolean = prefs.getBoolean("compress_quality", false)
    fun setCompressQualityEnabled(e: Boolean) {
        prefs.edit().putBoolean("compress_quality", e).apply()
    }

    // v6.7.146 (P2-8): 首次启动引导标记。
    fun isGuideShown(): Boolean = prefs.getBoolean("guide_shown", false)
    fun setGuideShown() {
        prefs.edit().putBoolean("guide_shown", true).apply()
    }

    // v6.7.177 (增量A): 全局限额(引擎层,写路径检测,ms 级精度)。0=不限。
    // 与 durationLimitMinutes(分钟粒度,Service 定时器)互补:本组为写路径精确限额,
    // UI 开关另议,默认 0 关闭,不影响既有行为。
    fun recLimitBytes(): Long = prefs.getLong("rec_limit_bytes", 0L)
    fun recLimitDurationMs(): Long = prefs.getLong("rec_limit_duration_ms", 0L)

    // v6.7.178 (⑥): 设置页写入口。引擎侧 v6.7.177 已消费这两个 key,此处补 setter + UI。
    fun setRecLimitBytes(v: Long) {
        prefs.edit().putLong("rec_limit_bytes", v.coerceAtLeast(0L)).apply()
    }
    fun setRecLimitDurationMs(v: Long) {
        prefs.edit().putLong("rec_limit_duration_ms", v.coerceAtLeast(0L)).apply()
    }
}