package com.monkeycode.screenrecorder

import android.content.ContentValues
import android.content.Context
import android.content.Intent
import android.graphics.Bitmap
import android.graphics.PixelFormat
import android.hardware.display.DisplayManager
import android.hardware.display.VirtualDisplay
import android.media.Image
import android.media.ImageReader
import android.media.projection.MediaProjection
import android.media.projection.MediaProjectionManager
import android.net.Uri
import android.os.Build
import android.os.Environment
import android.os.Handler
import android.os.HandlerThread
import android.os.Looper
import android.provider.MediaStore
import android.util.Log
import java.io.File
import java.util.concurrent.atomic.AtomicBoolean

/** 超级截图核心：录制中截图 = 把已存在的录制 VirtualDisplay 的输出面**短暂切到
 *  ImageReader**，抓一帧后立刻切回，再在后台线程做转 Bitmap + 存盘。
 *
 *  为什么不能「复用 projection 再开一条 VirtualDisplay」：目标 Android 14（API 34）
 *  及以上的应用，对同一 MediaProjection 实例**第二次**调用 createVirtualDisplay 会抛
 *  SecurityException（单次捕获会话 = 单次 createVirtualDisplay，每个实例只能使用一次）。
 *  v6.7.152 在 sdk=37 真机上实测：新建第二条 VD → SecurityException → 系统 onStop 终止
 *  投影 → 录制被强制停止。切面法（setSurface）不受该限制，全程只有一条 VirtualDisplay，
 *  投影不终止，录制不被杀。本代码库 pause/resume 已在用 setSurface(null) /
 *  setSurface(inputSurface) 同款手法（RecorderEngine stopVirtualDisplayFeeding /
 *  resumeVirtualDisplayFeeding），模式一致、已验证。
 *
 *  两个必须遵守的顺序（v6.7.154 修的两个真高危）：
 *  1) 抓到帧**立刻** restore() 切回，重活（转 Bitmap + PNG 压缩 + 存盘）全部挪到后台
 *     线程。1280x2800 RGBA = 14.3MB，复制 + PNG 质量100 压缩在中端机上约 300ms~1s+，
 *     这段若排在 restore 之前，VD 一直指向 ImageReader，录制画面完全断流；更糟的是
 *     兜底超时 Runnable 若也 post 主线程，会被 PNG 压缩占满主线程而排不上执行，
 *     「绝不能让录制断流」的保护形同虚设。
 *  2) restore 的目标面必须尊重暂停态。暂停中 VD 已被 setSurface(null) 摘除投帧，
 *     截图抓完必须切回 null 而非 inputSurface——否则画面重新投给编码器但 isPaused
 *     仍为 true，录制在用户以为暂停时被静默续录，状态机矛盾。 */
object ScreenshotHelper {

    private const val TAG_SELF = "ScreenshotHelper"
    private const val ALBUM = "超级截图"
    private const val SHOT_THREAD = "shot"

    // v6.7.157: 截图编码从 PNG 切到无损 WebP(比 PNG 小 25~35% 且真无损)。
    // 屏幕内容=大片纯色+锐利边缘,正是无损 WebP 压缩率最好的场景;照片才会反之。
    // true  = 真无损 WEBP_LOSSLESS(API30+),画质数学无损
    // false = 视觉无损 WEBP_LOSSY 95,体积约无损 1/3~1/2,快 3~5 倍
    private const val USE_LOSSLESS = true
    // 无损模式的"编码努力",不是画质(无损只有一档画质)。100=最慢最小,0=最快最大。
    // 1280x2800 参考:100≈1~3s、90≈0.5~1.5s,体积差<5%。截图在 shotThread 压缩不阻塞录制,
    // 但影响 Toast 时机,取 90 平衡。
    private const val WEBP_LOSSLESS_EFFORT = 90
    // 有损模式的"视觉无损"档。
    private const val WEBP_LOSSY_VISUAL = 95

        // 兜底：切面首帧可能需重新触发合成,超时给足(1000ms)确保能抓到帧,绝不让录制断流。
        // v6.7.156 (修5) 曾 500→400ms 想缩短帧空洞,但切面后合成器未在窗口内投递 -> 恒超时 failed
        // (HONOR/HUAWEI 切面后首帧需重新触发)。v6.7.157 改回 1000ms 并在切面后强制重投一次。
        private const val GRAB_TIMEOUT_MS = 1000L

    /** v6.9.10 (AZ 一体四子球): 非录制态独立截图。
     *
     *  与 [captureDuringRecording] 的区别:没有可复用的录制 VD,必须自申请一条
     *  MediaProjection + 开一次性 VirtualDisplay 抓一帧。
     *
     *  为什么不复用录制中的 projection:API34+ 禁止同一 projection 二次
     *  createVirtualDisplay(SecurityException + 系统 onStop 杀掉录制)。独立截图
     *  走独立投影、独立生命周期,抓完立刻 release VD + mp.stop(),绝不泄漏。
     *
     *  [ctx] 必须是已拿到授权弹窗结果的 Activity(CaptureActivity),
     *  [resultCode]/[data] 来自 MediaProjectionManager.createScreenCaptureIntent() 的结果。
     *  [onResult] 在主线程回调。 */
    fun captureStandalone(
        ctx: Context,
        resultCode: Int,
        data: Intent,
        onResult: (Uri?) -> Unit
    ) {
        val mm = runCatching {
            ctx.getSystemService(Context.MEDIA_PROJECTION_SERVICE) as? MediaProjectionManager
        }.getOrNull()
        if (mm == null) {
            DiagLog.logEvent("SCREENSHOT", "screenshot_fail reason=mm_null")
            Handler(Looper.getMainLooper()).post { onResult(null) }
            return
        }
        val mp = runCatching { mm.getMediaProjection(resultCode, data) }.getOrNull()
        if (mp == null) {
            DiagLog.logEvent("SCREENSHOT", "screenshot_fail reason=projection_null")
            Handler(Looper.getMainLooper()).post { onResult(null) }
            return
        }
        // 屏幕尺寸:用真实分辨率(含状态栏/导航栏),与录制内容一致
        val dm = ctx.resources.displayMetrics
        val w = dm.widthPixels
        val h = dm.heightPixels
        if (w <= 0 || h <= 0) {
            DiagLog.logEvent("SCREENSHOT", "screenshot_fail reason=invalid_size ${w}x${h}")
            mp.stop()
            Handler(Looper.getMainLooper()).post { onResult(null) }
            return
        }

        val reader = ImageReader.newInstance(w, h, PixelFormat.RGBA_8888, 2)
        val done = AtomicBoolean(false)
        var vdCreated = false
        var vdRef: VirtualDisplay? = null
        // 抓完即放:关 reader + 释放 VD + stop projection,三重清理防泄漏
        val release = {
            try { reader.close() } catch (_: Exception) {}
            try { if (vdCreated) vdRef?.release() } catch (_: Exception) {}
            try { mp.stop() } catch (_: Exception) {}
        }

        val shotThread = HandlerThread(SHOT_THREAD).also { it.start() }
        val shotHandler = Handler(shotThread.looper)

        val vd: VirtualDisplay = try {
            mp.createVirtualDisplay(
                "standalone_shot", w, h, dm.densityDpi,
                DisplayManager.VIRTUAL_DISPLAY_FLAG_AUTO_MIRROR,
                reader.surface, null, null
            ).also {
                vdRef = it
                vdCreated = true
            } ?: throw IllegalStateException("createVirtualDisplay returned null")
        } catch (e: Exception) {
            DiagLog.logEvent("SCREENSHOT", "screenshot_fail reason=create_vd ${e.message}")
            Log.e(TAG_SELF, "standalone: createVirtualDisplay failed: ${e.message}", e)
            mp.stop()
            closeReader(reader)
            Handler(Looper.getMainLooper()).post { onResult(null) }
            return
        }

        reader.setOnImageAvailableListener({ r ->
            if (!done.compareAndSet(false, true)) return@setOnImageAvailableListener
            try { r.setOnImageAvailableListener(null, null) } catch (_: Exception) {}
            // v6.7.185 同款时序:先取 Image,拷完像素再关 reader,避免 "already closed"
            val img = try { r.acquireLatestImage() } catch (_: Exception) { null }
            if (img == null) {
                Log.w(TAG_SELF, "standalone: acquireLatestImage returned null")
                DiagLog.logEvent("SCREENSHOT", "screenshot_fail reason=acquire_null")
                release()
                Handler(Looper.getMainLooper()).post { onResult(null) }
                shotThread.quitSafely()
                return@setOnImageAvailableListener
            }
            shotHandler.post {
                var uri: Uri? = null
                try {
                    val bmp = imageToBitmap(img, w, h)
                    img.close()
                    uri = saveToGallery(ctx, bmp)
                    bmp.recycle()
                    Log.i(TAG_SELF, "standalone saved ${uri?.toString()}")
                } catch (e: Exception) {
                    Log.e(TAG_SELF, "standalone grab failed: ${e.message}", e)
                    DiagLog.logEvent("SCREENSHOT", "screenshot_fail reason=save_error ${e.message}")
                    try { img.close() } catch (_: Exception) {}
                } finally {
                    release()
                    Handler(Looper.getMainLooper()).post { onResult(uri) }
                    shotThread.quitSafely()
                }
            }
        }, shotHandler)

        // 静态画面强制一次合成(与 captureDuringRecording 同套 2x2 overlay 手法)
        val wm = runCatching {
            ctx.getSystemService(Context.WINDOW_SERVICE) as? android.view.WindowManager
        }.getOrNull()
        if (wm != null) {
            val trigger = android.view.View(ctx).apply { setBackgroundColor(0x01000001) }
            val tp = android.view.WindowManager.LayoutParams(
                2, 2,
                android.view.WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
                android.view.WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or
                    android.view.WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE,
                PixelFormat.TRANSLUCENT
            )
            if (runCatching { wm.addView(trigger, tp) }.isSuccess) {
                Handler(Looper.getMainLooper()).postDelayed({
                    try { wm.removeView(trigger) } catch (e: Exception) {
                        DiagLog.logEvent("SCREENSHOT", "screenshot_overlay_leak ${e.message}")
                    }
                }, 80L)
            } else {
                DiagLog.logEvent("SCREENSHOT", "screenshot_overlay_add_fail")
            }
        }

        // 兜底超时:抓不到帧也必须释放 projection,绝不泄漏
        shotHandler.postDelayed({
            if (done.compareAndSet(false, true)) {
                Log.w(TAG_SELF, "standalone grab timeout, releasing projection")
                DiagLog.logEvent("SCREENSHOT", "screenshot_fail reason=timeout")
                release()
                Handler(Looper.getMainLooper()).post { onResult(null) }
                shotThread.quitSafely()
            }
        }, GRAB_TIMEOUT_MS)
    }

    private fun closeReader(reader: ImageReader) {
        try { reader.close() } catch (_: Exception) {}
    }

    /** 录制中截图：切换已存在的录制 VD 输出面抓一帧，再切回 [restoreTarget]。
     *  [restoreTarget] 为 null 表示切回"不投帧"（录制已暂停时的正确目标）。
     *  绝不再新建 VirtualDisplay（API34+ 会 SecurityException + 系统 onStop 杀掉录制）。
     *  [onResult] 在主线程回调，成功返回 Uri、失败返回 null。 */
    fun captureDuringRecording(
        ctx: Context,
        vd: VirtualDisplay,
        restoreTarget: android.view.Surface?,
        width: Int,
        height: Int,
        onResult: (Uri?) -> Unit
    ) {
        if (width <= 0 || height <= 0) {
            Log.e(TAG_SELF, "capture: invalid size ${width}x${height}")
            // v6.7.156 (修5): 失败原因入 diag,此前只打 logcat,diag 无因无法排查。
            DiagLog.logEvent("SCREENSHOT", "screenshot_fail reason=invalid_size ${width}x${height}")
            Handler(Looper.getMainLooper()).post { onResult(null) }
            return
        }
        val reader = ImageReader.newInstance(width, height, PixelFormat.RGBA_8888, 2)
        val done = AtomicBoolean(false)
        // v6.7.185: 拆"恢复投帧"与"关 reader"。原 restore() 把两者绑在一起，
        // 在 acquireLatestImage 后的 finally 里同步 reader.close()，而 Image 的实际消费
        // （imageToBitmap 拷像素）被 post 到 shotHandler 后台线程——此刻 reader 早已关闭、
        // Image 已被回收，拷像素必然抛 "Image is already closed"。确定性 bug：只要成功
        // 取到图就一定在拷像素时失败，这正是"每次截屏都失败"的原因。
        // 修法：acquire 后立刻 resumeVd()（毫秒级恢复投帧，录制不空窗），reader 暂不关；
        // 后台把像素拷进 Bitmap 后，在 finally 末尾才 closeReader()。Image 全程有效。
        val resumeVd = {
            // setSurface(null) 合法，用于暂停态切回"不投帧"
            try { vd.setSurface(restoreTarget) } catch (_: Exception) {}
        }
        val closeReader = { try { reader.close() } catch (_: Exception) {} }

        // 重活（转 Bitmap + 存盘）专用后台线程：ImageReader 回调与超时都跑在这里，
        // 绝不跑主线程——否则 PNG 压缩占满主线程，超时兜底 Runnable 排不上执行。
        val shotThread = HandlerThread(SHOT_THREAD).also { it.start() }
        val shotHandler = Handler(shotThread.looper)

        reader.setOnImageAvailableListener({ r ->
            if (!done.compareAndSet(false, true)) return@setOnImageAvailableListener
            try { r.setOnImageAvailableListener(null, null) } catch (_: Exception) {}
            // 关键顺序：先恢复投帧（毫秒级），录制不空窗；reader/Image 暂不关
            resumeVd()
            val img = try { r.acquireLatestImage() } catch (_: Exception) { null }
            if (img == null) {
                Log.w(TAG_SELF, "grab: acquireLatestImage returned null")
                DiagLog.logEvent("SCREENSHOT", "screenshot_fail reason=acquire_null")
                closeReader()
                Handler(Looper.getMainLooper()).post { onResult(null) }
                shotThread.quitSafely()
                return@setOnImageAvailableListener
            }
            shotHandler.post {
                var uri: Uri? = null
                try {
                    // Image 仍有效（reader 未关）
                    val bmp = imageToBitmap(img, width, height)
                    img.close()
                    uri = saveToGallery(ctx, bmp)
                    bmp.recycle()
                    Log.i(TAG_SELF, "saved ${uri?.toString()}")
                } catch (e: Exception) {
                    Log.e(TAG_SELF, "grab failed: ${e.message}", e)
                    DiagLog.logEvent("SCREENSHOT", "screenshot_fail reason=save_error ${e.message}")
                    try { img.close() } catch (_: Exception) {}
                } finally {
                    // 最后才关 reader——保证 Image 全程有效
                    closeReader()
                    Handler(Looper.getMainLooper()).post { onResult(uri) }
                    shotThread.quitSafely()
                }
            }
        }, shotHandler)

        try {
            vd.setSurface(reader.surface)
        } catch (e: Exception) {
            Log.e(TAG_SELF, "setSurface failed: ${e.message}", e)
            DiagLog.logEvent("SCREENSHOT", "screenshot_fail reason=set_surface ${e.message}")
            done.set(true)
            resumeVd()
            closeReader()
            shotThread.quitSafely()
            Handler(Looper.getMainLooper()).post { onResult(null) }
            return
        }

        // v6.7.156 (修5): 强制一次屏幕合成。静态画面下 SurfaceFlinger 不合成新帧,
        // ImageReader 收不到图,500ms 超时必然失败并白挨 1s 录制断流。用一个 2x2 半透明
        // overlay add→remove 强制 SF 出两帧,保证切面后必有新帧落到 ImageReader。
        val wm = runCatching {
            ctx.getSystemService(Context.WINDOW_SERVICE) as? android.view.WindowManager
        }.getOrNull()
        if (wm != null) {
            val trigger = android.view.View(ctx).apply { setBackgroundColor(0x01000001) }
            val tp = android.view.WindowManager.LayoutParams(
                2, 2,
                android.view.WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
                android.view.WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or
                    android.view.WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE,
                PixelFormat.TRANSLUCENT
            )
            // v6.7.157 (BUG-4): add/removeView 都必须在 UI 线程。原实现 addView 在主线程,
            // removeView 却 postDelayed 到 shotHandler(后台线程)-> ViewRootImpl 线程检查抛异常,
            // 又套 runCatching 静默吞掉 -> overlay 永久泄漏(直到进程被杀)。改主线程定时移除。
            if (runCatching { wm.addView(trigger, tp) }.isSuccess) {
                Handler(Looper.getMainLooper()).postDelayed({
                    try { wm.removeView(trigger) }
                    catch (e: Exception) {
                        Log.w(TAG_SELF, "overlay remove failed: ${e.message}")
                        DiagLog.logEvent("SCREENSHOT", "screenshot_overlay_leak ${e.message}")
                    }
                }, 80L)
            } else {
                DiagLog.logEvent("SCREENSHOT", "screenshot_overlay_add_fail")
            }
        }

        // 兜底：超时没等到帧也必须切回，绝不能让录制断流
        shotHandler.postDelayed({
            if (done.compareAndSet(false, true)) {
                Log.w(TAG_SELF, "grab timeout, restore encoder surface")
                DiagLog.logEvent("SCREENSHOT", "screenshot_fail reason=timeout")
                resumeVd()
                closeReader()
                Handler(Looper.getMainLooper()).post { onResult(null) }
                shotThread.quitSafely()
            }
        }, GRAB_TIMEOUT_MS)
    }

    /** Image -> Bitmap。必须处理 rowStride/pixelStride 行填充，否则宽度不对会出斜条纹
     *  或色彩错位——这是这块最常见的坑。 */
    private fun imageToBitmap(image: Image, width: Int, height: Int): Bitmap {
        val plane = image.planes[0]
        val buffer = plane.buffer
        val pixelStride = plane.pixelStride
        val rowStride = plane.rowStride
        val rowPadding = rowStride - pixelStride * width
        val tmp = Bitmap.createBitmap(
            width + rowPadding / pixelStride, height, Bitmap.Config.ARGB_8888
        )
        tmp.copyPixelsFromBuffer(buffer)
        return if (rowPadding == 0) tmp
        else Bitmap.createBitmap(tmp, 0, 0, width, height).also { tmp.recycle() }
    }

    /** 存到 Pictures/超级截图。Android 10+ 走 MediaStore（无需存储权限），
     *  低于 10 走公有目录文件（需 WRITE_EXTERNAL_STORAGE，manifest 已申请）。
     *  v6.7.157: PNG → 无损 WebP。API30+ 走 WEBP_LOSSLESS(真无损,体积小 25~35%),
     *  API<30 无无损 WebP 的 Bitmap API,真无损回退 PNG。libwebp 无损编码需额外
     *  2~3 倍位图内存,低端机大图可能 OOM(Error 非 Exception),兜底回退有损 95。 */
    private fun saveToGallery(ctx: Context, bmp: Bitmap): Uri? {
        val useWebp = Build.VERSION.SDK_INT >= Build.VERSION_CODES.R
        val lossless = USE_LOSSLESS && useWebp
        val ext  = if (useWebp) "webp" else "png"
        val mime = if (useWebp) "image/webp" else "image/png"
        val name = "Screenshot_${System.currentTimeMillis()}.$ext"
        return if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
            val values = ContentValues().apply {
                put(MediaStore.Images.Media.DISPLAY_NAME, name)
                put(MediaStore.Images.Media.MIME_TYPE, mime)
                put(
                    MediaStore.Images.Media.RELATIVE_PATH,
                    Environment.DIRECTORY_PICTURES + File.separator + ALBUM
                )
                put(MediaStore.Images.Media.IS_PENDING, 1)
            }
            val uri = ctx.contentResolver.insert(
                MediaStore.Images.Media.EXTERNAL_CONTENT_URI, values
            ) ?: return null
            try {
                ctx.contentResolver.openOutputStream(uri)?.use { out ->
                    compressShot(bmp, lossless, out)
                }
                values.clear()
                values.put(MediaStore.Images.Media.IS_PENDING, 0)
                ctx.contentResolver.update(uri, values, null, null)
            } catch (e: OutOfMemoryError) {
                // OOM 是 Error 非 Exception,catch (Exception) 接不住。无损编码需 2~3 倍内存,
                // 1280x2800 约 30~50MB,低端机后台线程一样会炸。回退有损 95,宁可视觉无损不失败。
                Log.e(TAG_SELF, "save OOM, fallback lossy: ${e.message}")
                runCatching {
                    ctx.contentResolver.openOutputStream(uri)?.use { out ->
                        if (useWebp) bmp.compress(Bitmap.CompressFormat.WEBP_LOSSY, WEBP_LOSSY_VISUAL, out)
                        else bmp.compress(Bitmap.CompressFormat.PNG, 100, out)
                    }
                    values.clear()
                    values.put(MediaStore.Images.Media.IS_PENDING, 0)
                    ctx.contentResolver.update(uri, values, null, null)
                }.onFailure {
                    try { ctx.contentResolver.delete(uri, null, null) } catch (_: Exception) {}
                    return null
                }
            } catch (e: Exception) {
                Log.e(TAG_SELF, "save MediaStore failed: ${e.message}", e)
                try { ctx.contentResolver.delete(uri, null, null) } catch (_: Exception) {}
                return null
            }
            uri
        } else {
            @Suppress("DEPRECATION")
            val dir = File(
                Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_PICTURES),
                ALBUM
            )
            if (!dir.exists()) dir.mkdirs()
            val f = File(dir, name)
            try {
                f.outputStream().use { out -> compressShot(bmp, lossless, out) }
            } catch (e: Exception) {
                Log.e(TAG_SELF, "save file failed: ${e.message}", e)
                return null
            }
            Uri.fromFile(f)
        }
    }

    /** 统一压缩出口。[lossless] 为真走无损 WebP;否则 API30+ 走有损 95,API<30 走 PNG。 */
    private fun compressShot(bmp: Bitmap, lossless: Boolean, out: java.io.OutputStream) {
        when {
            lossless ->
                // 真无损:quality 只影响速度与体积,画质恒无损
                bmp.compress(Bitmap.CompressFormat.WEBP_LOSSLESS, WEBP_LOSSLESS_EFFORT, out)
            Build.VERSION.SDK_INT >= Build.VERSION_CODES.R ->
                // 视觉无损:体积约无损的 1/3~1/2,快 3~5 倍
                bmp.compress(Bitmap.CompressFormat.WEBP_LOSSY, WEBP_LOSSY_VISUAL, out)
            else ->
                // API<30 且要无损:只能 PNG(此分支 WEBP 恒有损,不能用)
                bmp.compress(Bitmap.CompressFormat.PNG, 100, out)
        }
    }
}
