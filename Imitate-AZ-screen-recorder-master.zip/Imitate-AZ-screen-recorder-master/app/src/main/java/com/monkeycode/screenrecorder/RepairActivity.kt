package com.monkeycode.screenrecorder

import android.os.Bundle
import android.view.View
import android.widget.*
import androidx.appcompat.app.AppCompatActivity
import java.io.File
import java.text.SimpleDateFormat
import java.util.Locale

// v6.7.188c: 手动修复面板——扫描(只读)与修复(Mp4Repairer)彻底解耦。
// 修复=一键全量跑既有 findStaleRecordings+restoreStale 流水线(幂等);
// 复选框仅提供"删除选中残留"(含分片目录形态)。全程后台线程,不卡 UI。
class RepairActivity : AppCompatActivity() {

    private val rows = ArrayList<Pair<RecorderEngine.OrphanInfo, CheckBox>>()
    private lateinit var list: LinearLayout
    private lateinit var btnRepair: Button
    private lateinit var btnDelete: Button
    private lateinit var prefsManager: PreferencesManager
    private lateinit var historyManager: RecordingHistoryManager
    private var busy = false

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        prefsManager = PreferencesManager(this)
        historyManager = RecordingHistoryManager.get(this)

        val root = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        root.addView(TextView(this).apply {
            text = "待修复的录制"; textSize = 18f; setPadding(48, 48, 48, 16)
        })
        list = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        root.addView(list)
        val btnRow = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
        btnRepair = Button(this).apply { text = "立即修复"; isEnabled = false }
        btnDelete = Button(this).apply { text = "删除选中"; isEnabled = false }
        btnRow.addView(btnRepair); btnRow.addView(btnDelete)
        root.addView(btnRow)
        setContentView(root)

        loadOrphans()
        btnRepair.setOnClickListener { repairAll() }
        btnDelete.setOnClickListener { deleteSelected() }
    }

    private fun loadOrphans() {
        Thread {
            val orphans = try { RecorderEngine.scanOrphans(this) } catch (e: Exception) { emptyList() }
            runOnUiThread {
                list.removeAllViews(); rows.clear()
                btnRepair.isEnabled = false; btnDelete.isEnabled = false
                if (orphans.isEmpty()) {
                    list.addView(TextView(this).apply {
                        text = "没有待修复的录制"; setPadding(48, 24, 48, 24)
                    }); return@runOnUiThread
                }
                val bps = try { prefsManager.loadQuality().videoBitRate } catch (e: Exception) { 24_000_000 }
                for (o in orphans) {
                    val cb = CheckBox(this)
                    val estSec = if (bps > 0) o.sizeBytes * 8 / bps else -1L
                    val info = StringBuilder(formatSize(o.sizeBytes))
                    if (estSec >= 0) info.append(" · 约 ${estSec}s")
                    if (o.isSegmentDir) info.append(" · 分片×${o.segCount}")
                    if (!o.isSegmentDir && o.hasIdx) info.append(" · 有索引")
                    val row = LinearLayout(this).apply {
                        orientation = LinearLayout.HORIZONTAL
                        setPadding(48, 24, 48, 24)
                    }
                    row.addView(cb)
                    row.addView(TextView(this).apply {
                        text = "${o.name}\n$info"
                        textSize = 13f
                    })
                    list.addView(row)
                    rows.add(Pair(o, cb))
                }
                btnRepair.isEnabled = true; btnDelete.isEnabled = true
            }
        }.start()
    }

    private fun repairAll() {
        if (busy) return; busy = true
        btnRepair.isEnabled = false; btnDelete.isEnabled = false; btnRepair.text = "修复中…"
        Thread {
            val restoredPaths = ArrayList<String>()
            var restored = 0; var kept = 0
            try {
                val stale = RecorderEngine.findStaleRecordings(this, true, skipActiveWindow = true)
                for (f in stale) {
                    val o = RecorderEngine.restoreStale(this, f)
                    val playable = o.playable
                    if (playable != null) {
                        val safUri = try { prefsManager.loadConfig().outputUri } catch (e: Exception) { null }
                        val finalPath = if (safUri != null) {
                            val docUri = try {
                                RecorderEngine.exportFileToSaf(this, playable, safUri, playable.name)
                            } catch (e: Exception) { null }
                            if (docUri != null) {
                                RecorderEngine.safExportedSet(this, add = playable.absolutePath)
                                SafeDeleteUtil.delete(playable, "manualRepair_saf_exported")
                                docUri.toString()
                            } else playable.absolutePath
                        } else playable.absolutePath
                        historyManager.add(RecordingEntry(
                            fileName = playable.name,
                            path = finalPath,
                            durationMs = o.durationMs,
                            sizeBytes = playable.length(),
                            width = o.width, height = o.height,
                            timestamp = parseRecordingTimestamp(f.name)
                                .let { if (it > 0L) it else f.lastModified() },
                            codecName = o.codecName))
                        // v6.7.188f: 逐条路径日志,方便用户在 diag 定位修复产物。
                        restoredPaths.add(playable.absolutePath)
                        android.util.Log.i("RepairActivity", "repaired -> ${playable.absolutePath} (${o.durationMs}ms ${o.width}x${o.height})")
                        restored++
                    } else kept++
                }
            } catch (e: Exception) { android.util.Log.w("RepairActivity", e.message, e) }
            val (r, k) = Pair(restored, kept)
            runOnUiThread {
                busy = false
                // v6.7.188f: Toast 带绝对路径,用户不再只看到计数。
                val msg = buildString {
                    append("已修复 $r 个")
                    if (k > 0) append("，$k 个保留为 _interrupted")
                    if (restoredPaths.isNotEmpty()) append("\n${restoredPaths.first()}")
                    if (restoredPaths.size > 1) append("\n…等 ${restoredPaths.size} 个，见历史")
                }
                Toast.makeText(this, msg, Toast.LENGTH_LONG).show()
                loadOrphans()
            }
        }.start()
    }

    private fun deleteSelected() {
        if (busy) return
        val sel = rows.filter { it.second.isChecked }.map { it.first }
        if (sel.isEmpty()) {
            Toast.makeText(this, "请先勾选要删除的条目", Toast.LENGTH_SHORT).show(); return
        }
        busy = true
        Thread {
            for (o in sel) {
                try {
                    if (o.isSegmentDir) {
                        File(o.path).listFiles()?.forEach { f ->
                            if (f.isFile && (f.name.matches(Regex("seg_\\d+\\.mp4(\\.tmp)?"))
                                    || f.name.endsWith(".idx") || f.name.contains("manifest"))) {
                                SafeDeleteUtil.delete(f, "manualRepair_seg_sweep")
                            }
                        }
                    } else {
                        val f = File(o.path)
                        SafeDeleteUtil.delete(f, "manualRepair_tmp")
                        SafeDeleteUtil.delete(File(f.parentFile, f.name + ".idx"), "manualRepair_idx")
                    }
                } catch (e: Exception) { android.util.Log.w("RepairActivity", e.message, e) }
            }
            runOnUiThread { busy = false; loadOrphans() }
        }.start()
    }

    private fun parseRecordingTimestamp(fileName: String): Long {
        val base = fileName.removeSuffix(".recording.tmp")
        val m = Regex("(?:_)?(\\d{8})_(\\d{6})").find(base) ?: return -1L
        return try {
            java.text.SimpleDateFormat("yyyyMMdd_HHmmss", java.util.Locale.US)
                .parse(m.groupValues[1] + "_" + m.groupValues[2])?.time ?: -1L
        } catch (_: Exception) { -1L }
    }

    private fun formatSize(b: Long): String = when {
        b >= 1024L * 1024 * 1024 -> String.format(Locale.US, "%.1f GB", b / 1073741824.0)
        b >= 1024L * 1024 -> "${b / (1024 * 1024)} MB"
        else -> "${b / 1024} KB"
    }
}
