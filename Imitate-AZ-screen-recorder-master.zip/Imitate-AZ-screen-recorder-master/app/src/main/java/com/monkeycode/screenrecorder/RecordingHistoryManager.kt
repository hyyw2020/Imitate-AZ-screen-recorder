package com.monkeycode.screenrecorder

import android.content.Context
import org.json.JSONArray
import org.json.JSONObject
import java.io.File
import java.util.UUID

data class RecordingEntry(
    val fileName: String,
    val path: String,
    val durationMs: Long,
    val sizeBytes: Long,
    val width: Int,
    val height: Int,
    val timestamp: Long,
    val codecName: String,
    // v6.7.128: 多分片录制的分片路径列表(单片为空)。播放用 setNextMediaPlayer 链式串联。
    val segmentPaths: List<String> = emptyList(),
    // v6.7.128: 降档元数据——本次是否降档、首次降档相对时刻(ms)、最低码率、是否锁死
    val downgradeActive: Boolean = false,
    val downgradeFirstAtMs: Long = 0L,
    val downgradeMinBitrate: Int = -1,
    val downgradeLatched: Boolean = false,
    // v6.7.145 (P1-5): 用户备注。借鉴必剪 ScreenCapDraftInfo 草稿语义,便于历史归类检索。
    // 向后兼容:老 JSON 无此字段,fromJson 回退空串(与 v6.7.128 分片列表兼容模式一致)。
    val note: String = "",
    // v6.7.145 (P1-6): 停止原因结构化字符串(MANUAL/DURATION_LIMIT/SHAKE/SYSTEM_KILL/ERROR)。
    // 借鉴必剪 RecordInfo4Report.StopReason。老 JSON 无此字段回退 "MANUAL"。
    val stopReason: String = "MANUAL",
    // v6.7.155: 产物可播放性。录制入库时用 MbRepairer 同款 moov 判定做轻量校验;
    // 若最终文件塌 moov/损坏(被杀瞬间仍可能产出不可播文件),置 false 并在历史列表
    // 显示"已损坏"角标、播放改成删除,避免给用户一个打不开的条目。向后兼容老 JSON 回退 true。
    val playable: Boolean = true
) {
    val formattedDuration: String
        get() {
            val totalSec = durationMs / 1000
            val h = totalSec / 3600
            val m = (totalSec % 3600) / 60
            val s = totalSec % 60
            return if (h > 0) "%d:%02d:%02d".format(h, m, s)
            else "%d:%02d".format(m, s)
        }

    val formattedSize: String
        get() {
            return when {
                sizeBytes >= 1_073_741_824 -> "%.1f GB".format(sizeBytes / 1_073_741_824.0)
                sizeBytes >= 1_048_576 -> "%.1f MB".format(sizeBytes / 1_048_576.0)
                sizeBytes >= 1024 -> "%.1f KB".format(sizeBytes / 1024.0)
                else -> "$sizeBytes B"
            }
        }

    val formattedResolution: String
        get() = "${width}x$height"

    fun toJson(): JSONObject = JSONObject().apply {
        put("fileName", fileName)
        put("path", path)
        put("durationMs", durationMs)
        put("sizeBytes", sizeBytes)
        put("width", width)
        put("height", height)
        put("timestamp", timestamp)
        put("codecName", codecName)
        // v6.7.128: 分片列表(向后兼容:老 JSON 无此字段,fromJson 回退空列表)
        // v6.7.160 (修BUG): 直接序列化数据类自身的 segmentPaths 属性。
        // 旧写法用 this.has("segmentPaths") 查 apply 块里正在构建的空 JSONObject——
        // apply 的 this 指向新建的 JSONObject(继承 HashMap,has 是其真实方法),
        // 此刻尚未 put 过该键,永远返回 false,导致 segs 恒为空、写盘 segmentPaths
        // 永远是 []、冷重启后多分片信息全部丢失。
        put("segmentPaths", JSONArray(segmentPaths))
        // v6.7.128: 降档元数据
        put("downgradeActive", downgradeActive)
        put("downgradeFirstAtMs", downgradeFirstAtMs)
        put("downgradeMinBitrate", downgradeMinBitrate)
        put("downgradeLatched", downgradeLatched)
        // v6.7.145: 备注与停止原因(空串也写,序列化字段恒定便于 diff)
        put("note", note)
        put("stopReason", stopReason)
        put("playable", playable)
    }

    companion object {
        @JvmStatic
        fun fromJson(json: JSONObject): RecordingEntry = RecordingEntry(
            fileName = json.getString("fileName"),
            path = json.getString("path"),
            durationMs = json.getLong("durationMs"),
            sizeBytes = json.getLong("sizeBytes"),
            width = json.getInt("width"),
            height = json.getInt("height"),
            timestamp = json.getLong("timestamp"),
            codecName = json.getString("codecName"),
            // v6.7.128: 向后兼容,老 JSON 无 segmentPaths
            segmentPaths = run {
                val arr = json.optJSONArray("segmentPaths")
                if (arr == null) emptyList()
                else {
                    val list = ArrayList<String>()
                    for (i in 0 until arr.length()) list.add(arr.getString(i))
                    list
                }
            },
            // v6.7.128: 降档元数据(向后兼容,老 JSON 无此字段默认 false/0/-1/false)
            downgradeActive = json.optBoolean("downgradeActive", false),
            downgradeFirstAtMs = json.optLong("downgradeFirstAtMs", 0L),
            downgradeMinBitrate = json.optInt("downgradeMinBitrate", -1),
            downgradeLatched = json.optBoolean("downgradeLatched", false),
            // v6.7.145: 备注与停止原因(向后兼容,老 JSON 无此字段回退默认值)
            note = json.optString("note", ""),
            stopReason = json.optString("stopReason", "MANUAL"),
            // v6.7.155: 可播放性(向后兼容,老 JSON 无此字段回退 true)
            playable = json.optBoolean("playable", true)
        )
    }
}

class RecordingHistoryManager(context: Context) {

    // v6.7.101 (B1/B3): 进程级单例 + 每次读写磁盘为准。
    // 旧实现 MainActivity 与 ScreenRecorderService 各自 new 一个实例,各自持
    // 独立 entryLock 与独立内存 entries,导致跨实例的 add/delete/clear 会互相
    // 用旧内存覆盖磁盘——用户"删除/清空"操作可能因 Service 侧残留内存被下一次
    // add 复活。改为 object 语义:整个进程共享一份内存快照与一把锁,并保留
    // constructor 接口以兼容既有调用点。
    // B3 tmp 名冲突:改用随机后缀避免同进程/不同线程 save 竞争写同一 tmp 文件。

    companion object {
        @Volatile private var INSTANCE: RecordingHistoryManager? = null

        @JvmStatic
        fun get(context: Context): RecordingHistoryManager {
            val inst = INSTANCE
            if (inst != null) return inst
            return synchronized(this) {
                INSTANCE ?: RecordingHistoryManager(context.applicationContext).also { INSTANCE = it }
            }
        }
    }

    private val jsonFile = File(context.filesDir, "recording_history.json")
    private val entryLock = Any()
    private val entries = mutableListOf<RecordingEntry>()
    private val maxEntries = 100

    init {
        load()
    }

    private fun load() {
        synchronized(entryLock) {
            entries.clear()
            try {
                if (!jsonFile.exists()) return
                val text = jsonFile.readText()
                val array = JSONArray(text)
                for (i in 0 until array.length()) {
                    // v6.7.50: 单条损坏时跳过该条继续加载,避免整段历史因一条脏数据丢失
                    try {
                        entries.add(RecordingEntry.fromJson(array.getJSONObject(i)))
                    } catch (e: Exception) {
                        android.util.Log.w("RecordingHistory", "skip corrupt entry at index $i", e)
                    }
                }
                entries.sortByDescending { it.timestamp }
            } catch (e: Exception) {
                android.util.Log.e("RecordingHistory", "failed to load history", e)
            }
        }
    }

    private fun snapshot(): List<RecordingEntry> = synchronized(entryLock) { entries.toList() }

    // 写盘统一从持锁的内存状态序列化,而非调用方快照,避免并发 add/delete/clear
    // v6.7.102 (B2): Linux/POSIX rename() 本身就是原子的、直接覆盖目标。
    // 之前先 delete 再 rename 存在数据丢失窗:delete 成功但 rename 因磁盘异常/并发失败,
    // jsonFile 短暂不存在,fallback 走 writeText 尚可,但 delete 若抛 IOException
    // 会被外层 catch 吞掉,tmpFile 已成孤儿、jsonFile 仍旧数据、内存 entries 已 mutate
    // → 下次重启读到旧数据,"删除后复活/新录制丢失"。改成直接 rename 覆盖。
    private fun save() {
        synchronized(entryLock) {
            try {
                // v6.7.101 (B3): tmp 名加 UUID,避免同进程不同线程或跨实例并发 save
                // 时共用固定 tmp 名互相覆盖(renameTo 前一个线程刚写的内容被后一个覆盖)。
                val tmpFile = File(jsonFile.parentFile, jsonFile.name + "." + UUID.randomUUID() + ".tmp")
                val array = JSONArray()
                entries.forEach { array.put(it.toJson()) }
                tmpFile.writeText(array.toString(2))
                if (!tmpFile.renameTo(jsonFile)) {
                    // rename 失败罕见(通常跨文件系统/权限异常);先落盘再清理 tmp,
                    // 避免"内存已 mutate 但磁盘仍旧"的一致性问题。
                    android.util.Log.w("RecordingHistory", "atomic rename failed, fallback copy")
                    jsonFile.writeText(array.toString(2))
                    try { tmpFile.delete() } catch (_: Exception) {}
                }
            } catch (e: Exception) {
                android.util.Log.e("RecordingHistory", "failed to save history", e)
            }
        }
    }

    // v6.7.101 (B1): 写操作前先 reload 从磁盘读入最新快照。
    // 单例化后跨实例竞争消除,但仍保留 reload 保证:即便未来再引入多写者路径,
    // 也不会用旧内存快照覆盖磁盘上其他写者刚写入的条目。
    private fun reloadForWrite() {
        synchronized(entryLock) {
            entries.clear()
            try {
                if (!jsonFile.exists()) return
                val text = jsonFile.readText()
                val array = JSONArray(text)
                for (i in 0 until array.length()) {
                    try {
                        entries.add(RecordingEntry.fromJson(array.getJSONObject(i)))
                    } catch (_: Exception) {
                        // skip corrupt entry,与 load() 一致
                    }
                }
                entries.sortByDescending { it.timestamp }
            } catch (e: Exception) {
                android.util.Log.e("RecordingHistory", "reloadForWrite failed", e)
            }
        }
    }

    fun add(entry: RecordingEntry) {
        synchronized(entryLock) {
            reloadForWrite()
            entries.add(0, entry)
            while (entries.size > maxEntries) {
                entries.removeAt(entries.lastIndex)
            }
            save()
        }
    }

    fun getAll(): List<RecordingEntry> = snapshot()

    fun getRecent(limit: Int = 5): List<RecordingEntry> {
        val snap = snapshot()
        return snap.take(limit.coerceIn(0, snap.size))
    }

    fun reload() {
        load()
    }

    fun delete(predicate: (RecordingEntry) -> Boolean) {
        synchronized(entryLock) {
            reloadForWrite()
            entries.removeAll(predicate)
            save()
        }
    }

    // v6.7.144 (P0-4) / v6.7.145 (P1-5): 通用原地更新。
    // 重命名(path/fileName)与备注(note)共用同一条写路径:先 reload 磁盘最新快照,
    // 定位后 copy 替换,再 save 原子落盘。与 add/delete 同一把锁,无并发覆盖。
    fun update(predicate: (RecordingEntry) -> Boolean, transform: (RecordingEntry) -> RecordingEntry) {
        synchronized(entryLock) {
            reloadForWrite()
            val idx = entries.indexOfFirst(predicate)
            if (idx >= 0) {
                entries[idx] = transform(entries[idx])
                save()
            }
        }
    }

    fun clear() {
        synchronized(entryLock) {
            reloadForWrite()
            entries.clear()
            save()
        }
    }

    fun size(): Int = synchronized(entryLock) { entries.size }
}