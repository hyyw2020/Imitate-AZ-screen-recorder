package com.monkeycode.screenrecorder

import android.animation.Animator
import android.animation.AnimatorListenerAdapter
import android.animation.AnimatorSet
import android.animation.ObjectAnimator
import android.animation.ValueAnimator
import android.content.Context
import android.content.SharedPreferences
import android.graphics.Canvas
import android.graphics.Paint
import android.graphics.PixelFormat
import android.graphics.RectF
import android.graphics.Outline
import android.graphics.RenderEffect
import android.os.Build
import android.os.Handler
import android.os.Looper
import android.provider.Settings
import android.view.GestureDetector
import android.view.Gravity
import android.view.MotionEvent
import android.view.View
import android.view.ViewGroup
import android.view.ViewOutlineProvider
import android.view.WindowInsets
import android.view.WindowManager
import android.view.accessibility.AccessibilityEvent
import android.view.animation.DecelerateInterpolator
import android.widget.FrameLayout
import android.widget.TextView
import androidx.core.content.ContextCompat
import java.util.Locale
import java.util.concurrent.atomic.AtomicBoolean

interface RecordOverlayListener {
    fun onStopClicked()
    fun onPauseClicked()
    fun onResumeClicked()
    // v6.9.10 (AZ 一体四子球): 子球①在非录制态改为"开始录制"红点,点击发起新录制
    fun onStartClicked()
    // v6.7.73: 返回设置页子球回调（启动 MainActivity，不停止录制）
    fun onSettingsClicked()
    // v6.7.152: 第四颗子球——超级截图（复用录制中的 projection 抓一帧）
    fun onScreenshotClicked()
    fun onOverlayFailed(reason: String)
    // P2-3: 悬浮窗挂载成功回调（区分 成功/权限缺失/addView 异常/挂载但不可见）
    fun onOverlayAttached()
}

class RecordOverlay(context: Context, private val listener: RecordOverlayListener) : FrameLayout(context) {

    // v6.7.79 (动态三球): 单个子浮球的登记信息。view 为实际 View,index 为其在 subBubbles
    // 中的序号(同时是 subAngles 下标与 lastSubClickElapsed 下标)。targetX/targetY 为展开
    // 目标位移(px),在 buildSubFanAnimator 计算后回填,供展开结束固定终值与收起动画启动值使用。
    private data class SubBubble(val view: View, val index: Int) {
        var targetX = 0f
        var targetY = 0f
    }

    companion object {
        private const val TAG = "RecordOverlay"
        // v6.7.71: 移除 EXPANDED_WIDTH_DP/EXPANDED_HEIGHT_DP/STROKE_WIDTH_DP 死常量,
        // 描边宽度走 R.dimen.float_stroke_width(FIX-5)。
        // v6.7.73 (三球): 移除胶囊展开宽高,子球展开走 float_expand_radius/float_sub_bubble_size。
        private const val COLLAPSE_TIMEOUT_MS = 8000L
        private const val PERSIST_PREFS = "overlay_position"
        private const val PERSIST_X = "overlay_x"
        private const val PERSIST_Y = "overlay_y"
        private const val INERTIA_DURATION_MS = 200L
        private const val INERTIA_DECAY = 0.85f
        private const val MIN_VELOCITY = 10f
        private const val MIN_VISIBLE_DP = 24
        private const val SNAP_DURATION_MS = 200L
        private const val PERSIST_DOCKED = "overlay_docked"
        private const val PERSIST_DOCK_SIDE = "overlay_dock_side"
        // 贴边方向(用于 PERSIST_DOCK_SIDE)
        private const val DOCK_LEFT = 0
        private const val DOCK_RIGHT = 1
        // v6.7.188e: 纯水平吸附后 snapToEdge 不再产出 DOCK_TOP/DOCK_BOTTOM,
        // 保留供 dockSide 域兼容(persistPosition/applyDocked 仍读写)。
        private const val DOCK_TOP = 2
        private const val DOCK_BOTTOM = 3
        // v6.7.73 (防御): 点击防抖阈值。主浮球点击与子浮球点击各自独立计时,但共享此常量。
        private const val CLICK_DEBOUNCE_MS = 300L
        // v6.7.77 魔法数字命名化(零逻辑改动):
        // 收起态 REC 徽标红点半径(dp)。仅用于 drawCollapsedBadge 一处,提起语义便于维护。
        private const val BADGE_DOT_RADIUS_DP = 3.5f
        // v6.7.79 (动态三球): 扇区子球数上限。子球数量可变(动态 180°/count 均分角度),
        // 展开半径=count*7dp+子球直径,窗口边长随之动态伸缩。此常量仅定义可容纳的子球个数上限。
        // v6.7.87 (P2 清理): 此值保留 6 仅为预留扩容位;实际只注册 MAX(3) 个子球,
        // 未使用的尾部下标一律由两处循环的 `if (i >= subBubbles.size) break` 守卫,
        // 永远不会被访问,不会越界。
        private const val MAX_SUB_BUBBLE_COUNT = 6
        // 子浮球阴影抬升高度(dp)。仅用于 createSubBubble 的 elevation 一处。
        private const val SUB_BUBBLE_ELEVATION_DP = 2f
    }

    private val windowManager: WindowManager =
        context.getSystemService(Context.WINDOW_SERVICE) as WindowManager

    private lateinit var layoutParams: WindowManager.LayoutParams
    private lateinit var prefs: SharedPreferences

    private var collapsedSizePx = 0
    // v6.7.73 (三球): 移除胶囊态的 expandedWidthPx/expandedHeightPx,改为子球展开半径与角度
    // v6.7.79 (动态三球): 移除固定 expandRadiusPx/fanWindowSizePx,改为按子球数动态计算的
    // dynamicExpandRadius()/fanWindowSize()。
    // v6.7.86: 删除死字段 cornerRadiusPx(真正生效的是 currentCornerRadius,见 L131)。
    private var subBubbleSizePx = 0

    // 吸附/贴边相关常量转 px
    private var minVisiblePx = 0

    private lateinit var timerText: TextView
    // v6.7.79 (动态三球): 子浮球统一登记在 ArrayList<SubBubble> 中,数量/角度/半径动态计算。
    // 每个 SubBubble 持有对应的 View(半透明纯色背景+图标)与目标图标/防抖下标。
    private val subBubbles = ArrayList<SubBubble>()
    private lateinit var subPauseButton: View
    private lateinit var subStopButton: View
    private lateinit var subSettingsButton: View
    // v6.7.152: 第四颗子球——超级截图
    private lateinit var subScreenshotButton: View
    // v6.7.85 (P0-视觉): 子球展开目标角度(度,以主球中心为原点,0° 正右,逆时针为正)。
    // 由 initSubBubbleAngles() 按 expandBaseAngle() 动态计算(180° 均分 count 子球+位置偏移)。
    private val subAngles = DoubleArray(MAX_SUB_BUBBLE_COUNT)
    // v6.7.70 (分层): glassLayer 承载半透明表面+描边,是唯一参与模糊的层;
    // 计时文字/图标/徽标在其上层,保持锐利。禁止对整容器模糊(会糊掉文字图标)。
    private lateinit var glassLayer: View
    private lateinit var badgeView: View

    private val bgPaint = Paint(Paint.ANTI_ALIAS_FLAG)
    private val strokePaint = Paint(Paint.ANTI_ALIAS_FLAG)
    // v6.7.89 (S-2): 徽标 Paint 提升为字段,避免每次 onDraw 新建对象 +
    // 重新 setShadowLayer(shadow layer 初始化会走 blur 通路)。收起态是球 99% 时间的状态。
    private val badgeDotPaint = Paint(Paint.ANTI_ALIAS_FLAG)
    private val bgRect = RectF()
    private var currentCornerRadius = 0f

    // v6.7.86 (重构): 扇区展开进度 0f..1f,驱动三叶连接臂的绘制长度。
    // 收起态恒为 0,armLayer.onDraw 直接 return,零开销。
    private var fanProgress = 0f
    // v6.7.86 (重构): 连接臂图层。位于 glassLayer 之下,不带 blur、不带背景、
    // 不参与无障碍,只画 max 3 条圆头粗线。
    // 放在 glassLayer 之下是有意的:臂的内端被主球盖住、外端被子球盖住,
    // 只在两者之间露出一段,形成"主球伸出三条短臂,末端各挂一个按钮"的观感。
    private lateinit var armLayer: View
    private val armPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        style = Paint.Style.STROKE
        // v6.7.87 (P1-7): 原 ROUND 端帽会在起点再往回延伸半个线宽(8.25dp),
        // 正好落进主球里,透过 80% 不透明的玻璃层透出"三叶螺旋桨"鬼影。改 BUTT。
        strokeCap = Paint.Cap.BUTT
    }
    // v6.7.87 (P1-8): 环形轨道画笔,把三颗子球串在一条连续的弧上
    private val trackPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        style = Paint.Style.STROKE
        strokeCap = Paint.Cap.ROUND
    }
    private val trackOval = RectF()
    // v6.7.86 (重构): 主球表盘内环画笔。只在 isExpanded 时画一笔,
    // 不参与每帧动画(glassLayer 带 RenderEffect blur,每帧 invalidate 会重算模糊)。
    private val dialPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        style = Paint.Style.STROKE
    }

    private var isExpanded = false
    // v6.7.188c-fix: 录制开始且当前展开时,延时自动收回(参照 AZ 收球习惯)。
    private val AUTO_RETRACT_MS = 3000L
    var isPaused = false
        private set
    // v6.9.10 (AZ 一体四子球): 子球①三态切换依据。false=实心红圆点(开始录制),
    // true 且未暂停=双竖条(暂停), true 且暂停=播放三角(继续)。
    var isRecording = false
        private set
    @Volatile
    private var isAttached = false

    // v6.7.79 (动态三球): 移除 subExpandFraction/subExpandAlpha 进度快照——ObjectAnimator
    // 驱动 translationX/translationY/alpha 属性,(受 View 布局重组影响的)快照摆位不再需要,
    // 也不再被 onLayout 每帧覆盖。收起态子球 GONE,展开态由属性动画实时定位。

    // v6.7.73 (防御): 主浮球与子浮球的点击防抖时间戳(各自独立,共享 CLICK_DEBOUNCE_MS)
    private var lastMainClickElapsed = 0L
    // v6.7.79 (动态三球): 子球防抖各自独立计时。长度=MAX_SUB_BUBBLE_COUNT,按下标
    // (RegistrationOrder 序号)索引,未使用的尾部下标由两处循环的
    // `if (i >= subBubbles.size) break` 守卫,不会被访问。
    private val lastSubClickElapsed = LongArray(MAX_SUB_BUBBLE_COUNT)
    // v6.7.188d: 子球①(开始/暂停/恢复)点击后的状态机切换锁时间戳。
    // 点击后锁 8s,等真实状态回读(updateRecordingState/updatePauseState 收到 Service
    // 推送)立即解锁;若用户取消授权框则 8s 兜底解锁。图标翻转走 invalidate() 单帧,
    // 无属性动画、无中间可点击态,切换即一帧,零性能损耗。
    private var subActionLockUntil = 0L

    // P2-1/P2-4: 挂载后可见性自检（挂载成功但被系统隐藏时上报并有限重试）
    private var visibilityCheckPosted = false
    private var visibilityRetryCount = 0
    private var visibilityReported = false
    private val visibilityCheckRunnable = Runnable { runVisibilityCheck() }

    private val isDragging = AtomicBoolean(false)
    // v6.7.101 (B5): 多指打断拖拽后,下一次 ACTION_UP 跳过点击分支。
    // 用户想拖主球但落第二指触发多指防护(isDragging=false),然后松第一指
    // UP 会走 tap 分支误触发 handleMainTap 的 expand/collapse。置此标志让
    // 下一次 UP 只复位标志、跳过点击;后续 UP 恢复正常。
    private val suppressNextTap = AtomicBoolean(false)
    private var initialX = 0
    private var initialY = 0
    private var initialTouchX = 0f
    private var initialTouchY = 0f

    private var inertiaAnimator: ValueAnimator? = null
    private var snapAnimator: ValueAnimator? = null
    // v6.7.79 (动态三球): 子球展开/收起动画改为 AnimatorSet+ObjectAnimator 组合(驱动
    // translationX/translationY/alpha/rotation 属性,不受 onLayout 影响)。
    private var subExpandAnimator: Animator? = null
    private var subCollapseAnimator: Animator? = null

    // 贴边停靠状态
    private var isDocked = false
    private var dockSide = DOCK_LEFT
    // v6.7.89 (L-5): 记录"展开前是否停靠"。dock-expand 会把 isDocked 清掉以便
    // 临时把球完全露出;收起动画结束后按这个值恢复停靠,避免停靠态被一次点击永久抹掉。
    private var pendingRedockSide = -1   // -1 = 展开前未停靠
    // v6.7.86: 删除死字段 dockedX/dockedY(停靠坐标现由 dockTargetX()/dockTargetY() 现算)。
    private var unlockDockThresholdPx = 0

    // 底部导航栏 inset
    private var navbarInsetPx = 0

    // v6.7.174 (异形屏 P1): 四边系统栏/刘海/挖孔安全边距。onApplyWindowInsets 用
    // displayCutout + navigationBars 组合取全边 inset,供 clampPosition 把悬浮球挡在
    // 可见安全区外——否则左上角挖孔/刘海机把球拖到顶部/左缘会盖进不可见区;
    // 横屏三键导航时导航条在侧边,bottom 帮不上。
    private var safeInsetLeft = 0
    private var safeInsetTop = 0
    private var safeInsetRight = 0

    private val mainHandler = Handler(Looper.getMainLooper())
    private val collapseRunnable = Runnable {
        // 延迟触发时再检查一次,避免聚集超时前已被手动折叠时仍执行折叠
        if (isExpanded) {
            collapse()
        }
    }
    private var touchSlop = 0

    // 最近三帧触摸位置,用于估算松手速度
    private var lastRawX = 0f
    private var lastRawY = 0f
    private var prevRawX = 0f
    private var prevRawY = 0f
    private var moveCountForLog = 0

    // 颜色缓存（当前生效值，recolor 时更新，不重建 View）
    private var colorSurface = 0
    private var colorStroke = 0
    private var colorTimer = 0
    private var colorStop = 0
    // v6.7.86: 删除死字段 colorPauseBg(三球改版后胶囊态遗留,无读取点)。
    private var colorBadge = 0
    private var colorBadgeShadow = 0
    // v6.7.88: 删除 colorRecText(去掉 REC 文字后无读取点,见 drawCollapsedBadge)
    private var colorShadow = 0
    // v6.7.73 (三球): 子浮球配色
    private var colorSubBg = 0
    private var colorSubStroke = 0
    private var colorSubIcon = 0

    private val gestureDetector = GestureDetector(context, object : GestureDetector.SimpleOnGestureListener() {
        override fun onSingleTapConfirmed(e: MotionEvent): Boolean {
            return handleMainTap()
        }
    })

        // v6.7.82 (P4/P5 修复): 主球点击处理,从 GestureDetector.onSingleTapConfirmed 中抽出。
    // 1) P4: 慢点也可靠触发——由 ACTION_UP 直接调用本方法,不再等 doubleTapTimeout
    //    (~300ms)才确认单击,响应更快,长按/慢点不再被吞。
    // 2) P5: 停靠态点击先 undockToEdge() 再 expand();v6.7.82 expand() 不再改窗口尺寸/坐标
    //    (常驻 fanWindowSize),故不再有"双写坐标跳动"。防抖由 shouldDebounceMainClick 统一把关,
    //    保证 ACTION_UP 与 onSingleTapConfirmed(延时触发)不会重复执行。
    private fun handleMainTap(): Boolean {
        if (!isAttached) return false
        if (isDragging.get()) return false
        // v6.7.73 (防御): 主浮球点击防抖,放一切业务逻辑之前
        if (shouldDebounceMainClick()) return true
        snapAnimator?.cancel()
        if (isDocked && !isExpanded) {
            // v6.7.83 (问题C): 不再"先 undockToEdge() 再立即 expand()"。expand() 会
            // snapAnimator?.cancel(),对刚启动、进度≈0 的 ValueAnimator,同步 cancel 触发
            // onAnimationEnd 于起始值,球被定在停靠/半隐藏位置,不滑出边界 → 展开动画
            // zero-frame、球卡在贴边。改为把展开动作挂到弹回动画的 onAnimationEnd 上,
            // 先完整滑出边界,再展开子球。
            undockAndThenExpand()
        } else if (isExpanded) {
            collapse()
        } else {
            expand()
        }
        return true
    }

    // v6.7.83 (问题C): 停靠态点击——先沿贴边方向完整弹回边界(lead 从停靠位滑到目标边),
    // 动画结束后再 expand() 展开子球。展开不再取消正在进行的弹回动画,消除 zero-frame 卡死。
    private fun undockAndThenExpand() {
        val screenWidth = screenWidthFromDisplay()
        val screenHeight = screenHeightFromDisplay()
        val toX = when (dockSide) {
            DOCK_LEFT -> 0
            DOCK_RIGHT -> screenWidth - leadW()
            else -> leadX()
        }
        val toY = when (dockSide) {
            DOCK_TOP -> 0
            DOCK_BOTTOM -> screenHeight - leadH()
            else -> leadY()
        }
        val fromX = leadX()
        val fromY = leadY()
        // v6.7.89 (L-5): 记录展开前停靠位,收起后恢复,避免停靠被一次点击永久抹掉
        pendingRedockSide = if (isDocked) dockSide else -1
        isDocked = false
        snapAnimator?.cancel()
        DiagLog.log("SNAP(dock-expand) start fromX=$fromX toX=$toX fromY=$fromY toY=$toY")
        snapAnimator = ValueAnimator.ofFloat(0f, 1f).apply {
            duration = SNAP_DURATION_MS
            interpolator = DecelerateInterpolator()
            addUpdateListener { anim ->
                if (!isAttached) { snapAnimator?.cancel(); return@addUpdateListener }
                if (isDragging.get()) { snapAnimator?.cancel(); return@addUpdateListener }
                val f = anim.animatedFraction
                // v6.7.94 (P2): 与 startSnapAnim 统一走 commitLeadNow —— 每帧一次
                // 同步提交、删掉逐帧 invalidate()。旧路径每帧 setLead + clampPosition
                // (内部再 setLead 一次) + safeUpdateViewLayout + invalidate,
                // 是 v6.7.87 (P0-3/P0-4) 在 startSnapAnim 里已删掉的老毛病。
                commitLeadNow((fromX + (toX - fromX) * f).toInt(),
                    (fromY + (toY - fromY) * f).toInt())
            }
            addListener(object : AnimatorListenerAdapter() {
                override fun onAnimationEnd(animation: Animator) {
                    clampPosition()
                    safeUpdateViewLayout()
                    persistPosition()
                    DiagLog.log("SNAP(dock-expand) end leadX=${leadX()} leadY=${leadY()}")
                    // 弹回完成后才展开子球
                    if (isAttached && !isDragging.get() && !isExpanded) {
                        expand()
                    }
                }
            })
            start()
        }
    }

    fun attach() {
        mainHandler.post { performAttach() }
    }

    private fun performAttach() {
        if (isAttached) return
        synchronized(this) {
            if (isAttached) return
            // P0-1: addView 前权限自检，缺失则上报失败、不再执行 addView
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M
                && !Settings.canDrawOverlays(context)) {
                isAttached = false
                listener.onOverlayFailed("no SYSTEM_ALERT_WINDOW permission")
                return
            }
            try {
                windowManager.addView(this, layoutParams)
                isAttached = true

                // v6.7.188 (【1】): 挂载成功、isAttached=true 后立即按唯一真相源
                // ScreenRecorderApp.recordState 回填三态,消除"setState 早于 performAttach"
                // 竞态导致①恒为红点的问题。
                val rs0 = ScreenRecorderApp.recordState
                isRecording = rs0 == RecordState.RECORDING || rs0 == RecordState.PAUSED
                isPaused = rs0 == RecordState.PAUSED
                subPauseButton.contentDescription = when {
                    isPaused -> context.getString(R.string.float_resume)
                    isRecording -> context.getString(R.string.float_pause)
                    else -> context.getString(R.string.float_start)
                }
                subPauseButton.invalidate()
                if (isRecording) {
                    timerText.visibility = View.VISIBLE
                    badgeView.visibility = if (isExpanded) View.GONE else View.VISIBLE
                } else {
                    timerText.visibility = View.INVISIBLE
                    badgeView.visibility = View.GONE
                }

                // v6.7.89 (L-1): 窗口真正落位后再实测坐标系偏移并据此钳制/同步 committedLead。
                // getLocationOnScreen 须等 addView 完成后才可靠；放在 post 保证在窗口布局后执行。
                post {
                    if (!isAttached) return@post
                    measureWindowOriginOffset()
                    clampPosition()
                    safeUpdateViewLayout()
                    committedLeadX = leadX()
                    committedLeadY = leadY()
                }
                android.util.Log.i(TAG, "attach success")
                // P2-3: 挂载成功写业务日志，便于 diag 区分"成功"与"挂载但不可见"
                listener.onOverlayAttached()
                // P3-2: 延迟 800ms 自检窗口是否真正上屏（系统层可能抑制渲染）
                scheduleVisibilityCheck()
                // v6.7.75-F2: 等 onApplyWindowInsets 回调出实测底部 inset 后,再把落在
                // 导航条区域内的球推回可点区。init 时刻 navbarInsetPx 只有 dimen 默认值。
                mainHandler.postDelayed({
                    if (isAttached) reClampOverNavbar()
                }, 200L)
            } catch (e: Exception) {
                isAttached = false
                android.util.Log.e(TAG, "addView failed", e)
                // P0-2: 异常路径上报到 Service，写入业务日志
                listener.onOverlayFailed("addView failed: ${e.message}")
            }
        }
    }

    // P3-2 (v6.7.66): 挂载后真实上屏自检。旧 P2-1 用 windowToken != null 判定是
    // 逻辑缺陷:addView 成功后 token 必然非空、visibility 默认 VISIBLE,
    // 自检永远 true,永远进不了报错分支。改判 view.isShown() + getGlobalVisibleRect,
    // 反映"是否真正被合成上屏",而非仅"是否已挂载"。
    private fun scheduleVisibilityCheck() {
        if (visibilityCheckPosted) return
        visibilityCheckPosted = true
        visibilityRetryCount = 0
        mainHandler.postDelayed(visibilityCheckRunnable, 800L)
    }

    private fun runVisibilityCheck() {
        visibilityCheckPosted = false
        if (!isAttached || !isActuallyVisible()) {
            // P2-4/P3-4: 有限重试(最多 2 次),updateViewLayout 触发重布局
            if (visibilityRetryCount < 2) {
                visibilityRetryCount++
                // [FIX-1] 统一走容错链
                safeUpdateViewLayout()
                mainHandler.postDelayed(visibilityCheckRunnable, 800L)
                return
            }
            android.util.Log.w(TAG, "overlay attached but not actually on screen")
            listener.onOverlayFailed("not actually on screen")
            return
        }
        android.util.Log.i(TAG, "overlay visible ok")
    }

    // P3-2: 真实上屏判定——isShown 且 getGlobalVisibleRect 非空(窗口内容真正进入
    // 合成可见区域)。windowToken/token 非空仅代表已挂载,不代表已上屏。
    fun isActuallyVisible(): Boolean {
        if (!isAttached || visibility != View.VISIBLE) return false
        return try {
            isShown && getGlobalVisibleRect(android.graphics.Rect())
        } catch (_: Exception) {
            false
        }
    }

    fun release() {
        mainHandler.post { performRelease() }
    }

    private fun performRelease() {
        synchronized(this) {
            if (!isAttached) {
                // 尚未 attach 或已释放:清除主线程所有待处理回调,避免
                // mainHandler 中残留引用本 View 的 runnable 造成内存泄漏
                // (collapseRunnable 等通过闭包间接持有 this)。
                mainHandler.removeCallbacksAndMessages(null)
                return
            }
            isAttached = false
            cancelCollapseTimeout()
            // 移除所有主线程回调,释放对本 View 及其内部 Paint/Drawable 的强引用
            mainHandler.removeCallbacksAndMessages(null)
            // v6.7.87 (P0-3): 清掉可能挂着的每帧提交回调,避免释放后仍操作窗口
            cancelPendingLead()
            subExpandAnimator?.cancel()
            subCollapseAnimator?.cancel()
            inertiaAnimator?.cancel()
            snapAnimator?.cancel()
            persistPosition()
            // v6.7.82 (P0 修复): 窗口常驻 fanWindowSize(),release 不再缩回尺寸(下次
            // attach 的 init 会按 lead 锚点重新定位),故删去旧"复位到 collapsedSizePx"块。
            // persistPosition() 已改存 lead(可见主球左上角)坐标,重启后位置还原准确。
            isExpanded = false
            try {
                windowManager.removeView(this)
                android.util.Log.i(TAG, "release success")
            } catch (e: Exception) {
                android.util.Log.e(TAG, "removeView failed", e)
            }
        }
    }

    // [FIX-1] P0: 三级容错链——updateViewLayout 失败(省电/内存压力下 token 被系统
    // 静默移除)时依次降级 addView 重挂、removeViewImmediate 清理,避免悬浮球变死球
    // 或 View 残留在 WindowManager 引发 native 崩溃。所有窗口位置更新统一走此方法。
    private fun safeUpdateViewLayout() {
        if (!isAttached) return
        try {
            windowManager.updateViewLayout(this@RecordOverlay, layoutParams)
        } catch (e: IllegalArgumentException) {
            // 二级:窗口已不在 WindowManager,重新挂载
            try {
                windowManager.addView(this@RecordOverlay, layoutParams)
                DiagLog.log("updateViewLayout failed, re-added view")
            } catch (e2: Exception) {
                // 三级:重挂失败,清理残留并上报失效
                try {
                    windowManager.removeViewImmediate(this@RecordOverlay)
                } catch (_: Exception) {}
                isAttached = false
                cancelCollapseTimeout()
                try { listener.onOverlayFailed("window lost: re-add failed") } catch (_: Exception) {}
                return
            }
        } catch (_: Exception) {
            return
        }
        // v6.7.88 (Ch3 D-4): 落地成功后同步 committedLead,供 commitPendingLead 跳过空转提交。
        committedLeadX = leadX()
        committedLeadY = leadY()
    }

    // P2-1: 系统层把窗口可见性压到 GONE/INVISIBLE（省电/后台管理抑制）时上报一次。
    // 仅当确实挂载中且非本应用主动折叠（根视图不参与折叠,见 collapse()）才视为被系统隐藏。
    override fun onWindowVisibilityChanged(visibility: Int) {
        super.onWindowVisibilityChanged(visibility)
        if (isAttached && visibility != View.VISIBLE && !visibilityReported) {
            visibilityReported = true
            android.util.Log.w(TAG, "overlay window hidden by system, visibility=$visibility")
            listener.onOverlayFailed("window hidden by system, visibility=$visibility")
        } else if (visibility == View.VISIBLE) {
            visibilityReported = false
        }
    }

    private fun loadColors() {
        val ctx = context
        val dark = isNight()
        // 显式按 App 手动 dark_mode 选择深浅色，匹配 MainActivity.setTheme 语义
        // v6.7.81 (代码质量): res.getColor() 已废弃,统一改 ContextCompat.getColor(ctx,res)
        // (API 安全,按主题解析,行为等价),消除 12 处 Deprecation 警告。
        colorSurface = ContextCompat.getColor(ctx, if (dark) R.color.float_surface_dark else R.color.float_surface_light)
        colorStroke = ContextCompat.getColor(ctx, if (dark) R.color.float_stroke_dark else R.color.float_stroke_light)
        colorTimer = ContextCompat.getColor(ctx, if (dark) R.color.float_timer_dark else R.color.float_timer_light)
        colorStop = ContextCompat.getColor(ctx, if (dark) R.color.float_stop_glass_dark else R.color.float_stop_glass_light)
        colorBadge = ContextCompat.getColor(ctx, if (dark) R.color.float_badge_dark else R.color.float_badge_light)
        colorBadgeShadow = ContextCompat.getColor(ctx, if (dark) R.color.float_badge_shadow_dark else R.color.float_badge_shadow_light)
        // v6.7.89 (S-2): 徽标 Paint 为字段,在 loadColors 同步颜色 + shadow layer(替代每次 onDraw 重建)。
        badgeDotPaint.color = colorBadge
        badgeDotPaint.setShadowLayer(ctx.resources.displayMetrics.density * 2, 0f, 0f, colorBadgeShadow)
        colorShadow = ContextCompat.getColor(ctx, if (dark) R.color.float_shadow_dark else R.color.float_shadow_light)
        // v6.7.73 (三球): 子浮球配色
        colorSubBg = ContextCompat.getColor(ctx, if (dark) R.color.float_sub_bg_dark else R.color.float_sub_bg_light)
        colorSubStroke = ContextCompat.getColor(ctx, if (dark) R.color.float_sub_stroke_dark else R.color.float_sub_stroke_light)
        colorSubIcon = ContextCompat.getColor(ctx, if (dark) R.color.float_sub_icon_dark else R.color.float_sub_icon_light)
    }

    // 深色判断:统一走 isNightNow()(AppCompatDelegate.getDefaultNightMode 三态)),
    // 与 MainActivity 同一数据源,杜绝"主界面暗色、悬浮球浅色"分裂。
    // v6.7.129 (A): 原实现读 prefs 的 dark_mode Boolean,现由系统 uiMode 驱动。
    private fun isNight(): Boolean {
        return isNightNow(context)
    }

    // v6.7.85 (P0-视觉): 扇区基准角——按主球中心落在屏幕哪一半决定朝哪展开,扇区中心永远
    // 指向屏幕内侧。
    //
    // 背景:原实现读 pref_float_position,但全仓库只有这一处读取、没有任何写入点(死代码),
    // 于是 floatPosition() 恒返回 "left",base 恒为 -90(扇区朝右)。而吸附逻辑(dockTargetX)
    // 允许停靠右边缘,主球中心 x = 屏宽,子球全部落在屏外,配 FLAG_LAYOUT_NO_LIMITS
    // 会静默画到屏外,表现为"点了球图标消失"。这里只做左右二选一:水平方向的出屏风险
    // 远大于垂直(球几乎总是贴左右边),且二选一不会引入"扇区朝向突变"的额外抖动。
    private fun expandBaseAngle(): Double {
        val cx = leadX() + leadW() / 2.0
        // 屏幕水平中线:主球中心在左半屏 -> 朝右展开;在右半屏 -> 朝左展开
        return if (cx < screenWidthFromDisplay() / 2.0) -90.0 else 90.0
    }

    // v6.7.85 (P0-视觉): 角度入参由 position 字符串改为扇区基准角 base(度)。
    // 角度约定与 subAngles 一致:0°=正右,90°=正下(y 轴向下),逆时针为负。
    // 第 i 个球角度 = base + (i+0.5)*(180/count),(i+0.5) 偏移使扇区关于基准方向对称。
    //   base=-90  -> 扇区中心   0°(朝右)
    //   base= 90  -> 扇区中心 180°(朝左)
    //   base=  0  -> 扇区中心  90°(朝下)
    //   base=180  -> 扇区中心 -90°(朝上)
    private fun calculateSubAngles(count: Int, base: Double): DoubleArray {
        val out = DoubleArray(count)
        val step = 180.0 / count
        for (i in 0 until count) {
            out[i] = base + (i + 0.5) * step
        }
        return out
    }

    private fun initSubBubbleAngles() {
        val base = expandBaseAngle()
        val angles = calculateSubAngles(subBubbles.size, base)
        for (i in angles.indices) {
            subAngles[i] = angles[i]
        }
    }

    // v6.7.83 (问题D): 展开半径回退到设计值 float_expand_radius(52dp),与 v6.7.78 及更早
    // AZ 对齐的固定几何一致。旧实现 (subBubbles.size * 7f * density + subBubbleSizePx) 在
    // PTP-AN70(density=3.5) 上算出 213px,而设计半径 52dp=182px,扇区被放大 31px/侧。
    // v6.7.88 (Ch3 D-2): subBubbles.size 在 registerSubBubbles() 后恒定,半径恒定,
    // 缓存为 expandRadiusPxCache;拖动热路径不再每帧重算 3 次 getDimension + Math.sin。
    private fun computeExpandRadius(): Int {
        val design = resources.getDimension(R.dimen.float_expand_radius)
        val count = subBubbles.size.coerceAtLeast(2)
        // v6.7.85 (P2-保险): 固定设计半径只在 count=3 时成立。
        // 相邻子球圆心距 = 2R·sin(90°/count),要求它 >= 子球直径 + 间隙才不压盖:
        //     count=3  圆心距 182.0px  间隙 +42.0px   正常
        //     count=4  圆心距 139.3px  间隙  -0.7px   开始压盖
        //     count=5  圆心距 112.5px  间隙 -27.5px
        //     count=6  圆心距  94.2px  间隙 -45.8px
        // 反解出"保证间隙 >= float_expand_gap"的最小半径,取与设计值的较大者。
        // 当前只有 3 个球,minR = (119+42)/(2*sin30°) = 161px = design,行为不变。
        val gap = resources.getDimension(R.dimen.float_expand_gap)
        val minR = (subBubbleSizePx + gap) / (2.0 * Math.sin(Math.PI / (2.0 * count)))
        return maxOf(design, minR.toFloat()).toInt()
    }

    private fun dynamicExpandRadius(): Int = expandRadiusPxCache

    // v6.7.79 (动态三球): 展开态窗口边长,需容纳整个动态扇区(子球中心最远不超过 expandRadius,
    // 再加一个子球半径即为最外缘)。随动态展开半径与子球数伸缩,取代原固定 fanWindowSizePx。
    // v6.7.84 (新增-6): 旧公式"窗口半边长 = radius + 子球半径 = 子球最外缘",安全边距结构性恒
    // 为 0,与 radius 取 213 还是 182 无关。加 8dp(float_expand_margin)内边距,子球才真正完整
    // 落在窗口内,给 HWUI 关闭越界绘制留出安全空白。验算(density=3.5): radius=182, margin=28,
    // fanWindowSize=(182+70+28)*2=560, 窗口半边=280, 子球最外缘=252, 边距=28px=8dp。
    private fun fanWindowSize(): Int {
        val margin = resources.getDimension(R.dimen.float_expand_margin)
        return ((dynamicExpandRadius() + subBubbleSizePx / 2f + margin) * 2).toInt()
    }

    // v6.7.82 (P0 修复): 常驻大窗口坐标锚点。窗口固定为 fanWindowSize() 正方形,可见主球
    // 画在窗口正中。lead = 可见主球左上角(用户感知的"球位置"),窗口左上角相对 lead
    // 固定偏移 fanShiftPx()。所有位置运算(拖拽/吸附/停靠/钳制/持久化)统一对 lead 操作,
    // 展开/收起不改变 lead,故球位置恒定、无漂移。
    // v6.7.87 (P2-10): fanWindowSize() 与 collapsedSizePx 在 init 之后恒定不变
    // (subBubbles.size 在 registerSubBubbles() 后固定为 3),故偏移是常量。
    // 原实现每次调用都要跑 fanWindowSize() -> dynamicExpandRadius()
    // = 3 次 getDimension + 1 次 Math.sin,而拖动热路径每帧调它 6~8 次。
    private var fanShiftPxCache = 0
    // v6.7.88 (Ch3 D-2/5.4): 缓存展开半径。dynamicExpandRadius() 在 registerSubBubbles()
    // 后恒定(subBubbles.size 固定),旧实现每次拖动帧调 6~8 次(每次 3 次 getDimension + Math.sin)。
    private var expandRadiusPxCache = 0
    // v6.7.88 (Ch3 D-4): 已落地到 WindowManager 的 lead 坐标。commitPendingLead 据此跳过
    // 无变化的 updateViewLayout(逐帧 Binder IPC),把拖动中的空转提交降到 0。
    private var committedLeadX = Int.MIN_VALUE
    private var committedLeadY = Int.MIN_VALUE
    // v6.7.89 (L-1): 窗口真实屏幕原点相对 layoutParams 的偏移。
    // SDK>=30 摘掉 FLAG_LAYOUT_IN_SCREEN 后，窗口被放进"内容区坐标系"，
    // layoutParams.y 的原点在状态栏下方，而 clamp/snap/安全区全部按全屏坐标系算，
    // 二者相差一个状态栏高度（本机实测 140px = 40dp）。这里实测一次并记下来，
    // 之后所有 lead 运算都补偿掉，不依赖任何硬编码。
    private var windowOriginOffsetX = 0
    private var windowOriginOffsetY = 0

    private fun measureWindowOriginOffset() {
        if (!isAttached) return
        val loc = IntArray(2)
        getLocationOnScreen(loc)
        windowOriginOffsetX = loc[0] - layoutParams.x
        windowOriginOffsetY = loc[1] - layoutParams.y
        DiagLog.log("window_origin layoutParams=${layoutParams.x},${layoutParams.y} " +
            "screen=${loc[0]},${loc[1]} offset=${windowOriginOffsetX},${windowOriginOffsetY}")
    }

    private fun fanShiftPx(): Int = fanShiftPxCache
    private fun leadX(): Int = layoutParams.x + windowOriginOffsetX + fanShiftPx()
    private fun leadY(): Int = layoutParams.y + windowOriginOffsetY + fanShiftPx()
    private fun setLead(x: Int, y: Int) {
        layoutParams.x = x - fanShiftPx() - windowOriginOffsetX
        layoutParams.y = y - fanShiftPx() - windowOriginOffsetY
    }
    private fun leadW(): Int = collapsedSizePx
    private fun leadH(): Int = collapsedSizePx

    // v6.7.79 (动态三球): 子球登记完成后调用——按当前子球数计算动态扇区角度,并把防抖
    // 数组裁剪到实际子球数(未登记的尾部下标永远不会被访问)。
    private fun registerSubBubbles() {
        initSubBubbleAngles()
    }

    init {
        val density = resources.displayMetrics.density
        touchSlop = android.view.ViewConfiguration.get(context).scaledTouchSlop
        collapsedSizePx = (resources.getDimension(R.dimen.float_bubble_size)).toInt()
        // v6.7.73 (三球): 子球展开半径与子球直径
        // v6.7.79 (动态三球): 展开半径改为 dynamicExpandRadius() 动态计算。
        // v6.7.83 (问题D): 半径回退到固定设计值 float_expand_radius(52dp),子球直径保留常量读取。
        subBubbleSizePx = (resources.getDimension(R.dimen.float_sub_bubble_size)).toInt()
        // v6.7.74: 展开态窗口需包住整个扇形展开(最远边缘 = center + expandRadius + subRadius)。
        // v6.7.83: dynamicExpandRadius() 固定为设计半径后,fanWindowSize() 回到设计尺寸。
        // v6.7.84 (新增-7): 前提是先给 fanWindowSize() 加 8dp 边距(见 fanWindowSize)。旧代码
        // 子球最外缘恰好等于窗口半边长,靠 clipChildren=false 才没被裁。现在越界部分只会落在
        // 8dp 安全空白区内,故关闭越界绘制:1) HWUI 少走一次裁剪判断;2) 万一动画未复位/半径算错,
        // 越界部分被安静裁掉,而不会画到窗口 surface 之外触发 libhwui.so/libskia.so native
        // SIGSEGV(Java 层 try-catch 抓不到)——即 v6.7.76"一点击就崩、视频损坏"的根因。
        clipChildren = true
        // v6.7.85: 展开角度不再读 pref_float_position(该偏好无写入点,恒为 "left"),
        // 改为按主球在屏幕上的象限动态决定(见 expandBaseAngle())。
        // initSubAngles() 调用移至 registerSubBubbles() 末尾,待子球数量确定后执行。
        currentCornerRadius = collapsedSizePx / 2f
        minVisiblePx = (MIN_VISIBLE_DP * density).toInt()
        unlockDockThresholdPx = (60 * density).toInt()
        navbarInsetPx = (resources.getDimension(R.dimen.float_navbar_inset)).toInt()

        loadColors()

        prefs = context.getSharedPreferences(PERSIST_PREFS, Context.MODE_PRIVATE)

        val windowType = when {
            // v6.7.67 (P1-5): Android 7~16 窗口类型标准降级路径。
            // API>=26 用 TYPE_APPLICATION_OVERLAY(2038);API==25 用 TYPE_PHONE(2002);
            // API<25 用 TYPE_SYSTEM_ERROR(2005,与 AZ 原版一致)。全版本无厂商特判。
            Build.VERSION.SDK_INT >= Build.VERSION_CODES.O ->
                WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY
            Build.VERSION.SDK_INT == Build.VERSION_CODES.N_MR1 -> {
                @Suppress("DEPRECATION")
                WindowManager.LayoutParams.TYPE_PHONE
            }
            else -> {
                @Suppress("DEPRECATION")
                WindowManager.LayoutParams.TYPE_SYSTEM_ERROR
            }
        }

        layoutParams = WindowManager.LayoutParams(
            collapsedSizePx,
            collapsedSizePx,
            windowType,
            buildWindowFlags(),
            PixelFormat.TRANSLUCENT
        ).apply {
            gravity = Gravity.TOP or Gravity.START
            // v6.7.188d: 每次开启常驻悬浮球都回到固定默认位——左贴边、水平露一半球体、
            // 球心落在屏高 45%。兼容所有分辨率(百分比换算,不写死像素),不再读旧持久化
            // 坐标,因此"每次打开位置都一样",不再杂乱。
            val sh = screenHeightFromDisplay()
            isDocked = true
            dockSide = DOCK_LEFT
            x = -(collapsedSizePx / 2)                 // leadX = -half,左缘露一半
            y = (sh * 0.45f).toInt() - collapsedSizePx / 2   // 球心在屏高 45%
        }

        bgPaint.setShadowLayer(
            density * 2,
            0f,
            density * 1f,
            colorShadow
        )

        strokePaint.style = Paint.Style.STROKE
        strokePaint.strokeWidth = resources.getDimension(R.dimen.float_stroke_width)
        strokePaint.color = colorStroke

        timerText = TextView(context).apply {
            text = "00:00"
            setTextColor(colorTimer)
            // FIX-1 (v6.7.71): setTextSize 语义是 sp,getDimension() 已返回 px,直接赋值会把设计
            // 10sp 放大 density 倍(如 GLA-AL00 density=3 → 实际 90px)。用 COMPLEX_UNIT_PX 显式
            // 以 px 为单位,使设计字号(px=getDimension(10sp))渲染为真实目标语义。
            setTextSize(android.util.TypedValue.COMPLEX_UNIT_PX,
                resources.getDimension(R.dimen.float_timer_text_size))
            setTypeface(null, android.graphics.Typeface.BOLD)
            gravity = Gravity.CENTER
            includeFontPadding = false
            // FIX-2 (v6.7.71): 强制单行,防止宽度不够时折行成两行糊一团。
            // setSingleLine 会开横向滚动,部分版本吃掉水平居中,故重新设置 gravity。
            setSingleLine(true)
            maxLines = 1
            gravity = Gravity.CENTER
            // v6.7.88 (P0-1): 计时框改成"主球外接正方形 + FrameLayout 居中重力"。
            // 原实现给 (实测宽度, WRAP_CONTENT) 的普通 LayoutParams,FrameLayout
            // 只会摆到 (0,0);随后 onLayout 又用 timerText.layout(0,0,w,h) 强行把帧撑到
            // 整窗 497x497 却不重新 measure,造成帧尺寸(497)与测量尺寸(168x40)永久不一致:
            //   水平 -> setText 走 TextView 定宽分支,按 View 宽度 497 重建 StaticLayout,
            //           ALIGN_CENTER 生效,文字水平居中(碰巧对了);
            //   垂直 -> getVerticalOffset/getBoxHeight 用 getMeasuredHeight(),仍是 40px,
            //           voffset=0,文字被画在帧顶边 —— 实测钉在窗口上沿 7.7px,球心上方 227px。
            // 现在框就是主球的外接正方形,由 FrameLayout 按 CENTER 正常摆放,两维都落球心;
            // 宽高都是定值,setText 不触发 requestLayout;脏区也从整窗 497x497 缩到 168x168。
            layoutParams = FrameLayout.LayoutParams(
                collapsedSizePx,
                collapsedSizePx,
                Gravity.CENTER
            )
            // 等宽数字，秒级刷新不抖动
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
                fontFeatureSettings = "tnum"
            }
            contentDescription = context.getString(R.string.float_timer)
            // v6.7.188 (【5】空闲常驻视觉): 创建即 INVISIBLE,开录前不显 00:00。
            // 开录时 updateRecordingState 才置 VISIBLE。
            visibility = View.INVISIBLE
        }

        // v6.7.73 (三球): 子浮球——半透明纯色背景(不画独立 blur),深色用 colorSurface 同源暗灰,
        // 浅色用白色半透明,加 1dp stroke + elevation 2dp。40dp 小面积上毛玻璃与半透明纯色
        // 视觉差异极低,AZ 子球亦为简单半透明背景。
        // v6.9.10 (AZ 一体四子球): 子球①三态。
        //   非录制态 -> 实心红圆点(开始录制)
        //   录制中未暂停 -> 双竖条(暂停)
        //   录制中已暂停 -> 播放三角(继续)
        subPauseButton = createSubBubble(
            draw = { canvas, cx, cy, size, iconPaint ->
                val iconW = size * 0.10f
                val iconH = size * 0.30f
                val gap = size * 0.06f
                if (!isRecording || isPaused) {
                    // v6.7.188d: 开始(IDLE)与恢复(PAUSED)统一播放三角,语义一致;
                    // 录制中未暂停为双竖条(暂停)。三角与暂停条共用 iconW/iconH/gap。
                    val path = android.graphics.Path().apply {
                        moveTo(cx + iconW * 0.7f, cy - iconH)
                        lineTo(cx + iconW * 0.7f, cy + iconH)
                        lineTo(cx - iconW * 1.4f, cy)
                        close()
                    }
                    canvas.drawPath(path, iconPaint)
                } else {
                    canvas.drawRect(cx - gap - iconW, cy - iconH, cx - gap, cy + iconH, iconPaint)
                    canvas.drawRect(cx + gap, cy - iconH, cx + gap + iconW, cy + iconH, iconPaint)
                }
            },
            contentDesc = {
                if (!isRecording) R.string.float_start
                else if (isPaused) R.string.float_resume
                else R.string.float_pause
            },
            onClick = {
                // v6.7.188c-fix: 贴边态禁操作子球①(用户需求:收回贴边期间不可操作)。
                if (isDocked) return@createSubBubble
                // 子浮球防抖(各自独立计时);0 下标=pause/start/resume
                if (shouldDebounceSubClick(0)) return@createSubBubble
                // v6.7.188d: 状态机切换锁。点击后锁 8s,覆盖"弹系统授权框(2~10s)"的等待;
                // 真实状态回读后由 updateRecordingState/updatePauseState 立即解锁,
                // 用户取消授权框则 8s 兜底解锁。杜绝快速连点导致状态机错乱。
                val now = android.os.SystemClock.elapsedRealtime()
                if (now < subActionLockUntil) return@createSubBubble
                subActionLockUntil = now + 8000L
                when {
                    !isRecording -> listener.onStartClicked()
                    isPaused -> listener.onResumeClicked()
                    else -> listener.onPauseClicked()
                }
            }
        )
        // v6.7.79 (动态三球): 登记到 subBubbles,index=0
        subBubbles.add(SubBubble(subPauseButton, subBubbles.size))

        subStopButton = createSubBubble(
            draw = { canvas, cx, cy, size, iconPaint ->
                // v6.7.85 (P1-视觉): 与暂停/设置两球统一——半透明底与描边由 createSubBubble
                // 统一绘制,这里只画一个"红色圆角方块"图标。原实现用 drawCircle(r = size/2 -
                // 1.5dp) 把整颗球铺成实心红饼,是三个子球里唯一的实心饼,和另外两个半透明
                // 玻璃球风格割裂。
                val sq = size * 0.20f
                val corner = sq * 0.28f
                val sp = Paint(Paint.ANTI_ALIAS_FLAG).apply {
                    color = colorStop
                    style = Paint.Style.FILL
                }
                canvas.drawRoundRect(
                    RectF(cx - sq, cy - sq, cx + sq, cy + sq),
                    corner, corner, sp
                )
            },
            contentDesc = { R.string.float_stop },
            onClick = {
                if (shouldDebounceSubClick(1)) return@createSubBubble
                listener.onStopClicked()
            }
        )
        // v6.7.79 (动态三球): 登记到 subBubbles,index=1
        subBubbles.add(SubBubble(subStopButton, subBubbles.size))

        subSettingsButton = createSubBubble(
            draw = { canvas, cx, cy, size, iconPaint ->
                // 返回设置图标:房子轮廓
                val stroke = Paint(Paint.ANTI_ALIAS_FLAG).apply {
                    color = colorSubIcon
                    style = Paint.Style.STROKE
                    strokeWidth = resources.displayMetrics.density * 2f
                }
                val w = size * 0.32f
                val h = size * 0.26f
                val roof = Paint(Paint.ANTI_ALIAS_FLAG).apply {
                    color = colorSubIcon
                    style = Paint.Style.STROKE
                    strokeWidth = resources.displayMetrics.density * 2f
                }
                // 屋顶
                val roofPath = android.graphics.Path().apply {
                    moveTo(cx - w, cy - h * 0.3f)
                    lineTo(cx, cy - h * 0.9f)
                    lineTo(cx + w, cy - h * 0.3f)
                }
                canvas.drawPath(roofPath, roof)
                // 屋体
                canvas.drawRect(cx - w, cy - h * 0.3f, cx + w, cy + h * 0.5f, stroke)
                // 门
                canvas.drawRect(cx - w * 0.12f, cy, cx + w * 0.12f, cy + h * 0.5f, stroke)
            },
            contentDesc = { R.string.float_sub_settings },
            onClick = {
                if (shouldDebounceSubClick(2)) return@createSubBubble
                listener.onSettingsClicked()
            }
        )
        // v6.7.79 (动态三球): 登记到 subBubbles,index=2
        subBubbles.add(SubBubble(subSettingsButton, subBubbles.size))

        // v6.7.152: 第四颗——超级截图。图标=相机造型(机身圆角矩形+顶部取景凸块+镜头圆),
        // 与前三个子球的 colorSubIcon + STROKE 2dp 风格一致。
        subScreenshotButton = createSubBubble(
            draw = { canvas, cx, cy, size, iconPaint ->
                val stroke = Paint(Paint.ANTI_ALIAS_FLAG).apply {
                    color = colorSubIcon
                    style = Paint.Style.STROKE
                    strokeWidth = resources.displayMetrics.density * 2f
                }
                val w = size * 0.34f
                val h = size * 0.26f
                // 机身
                canvas.drawRoundRect(
                    android.graphics.RectF(cx - w, cy - h * 0.55f, cx + w, cy + h),
                    size * 0.05f, size * 0.05f, stroke
                )
                // 顶部取景凸块
                canvas.drawLine(cx - w * 0.35f, cy - h * 0.55f, cx - w * 0.20f, cy - h * 1.05f, stroke)
                canvas.drawLine(cx - w * 0.20f, cy - h * 1.05f, cx + w * 0.20f, cy - h * 1.05f, stroke)
                canvas.drawLine(cx + w * 0.20f, cy - h * 1.05f, cx + w * 0.35f, cy - h * 0.55f, stroke)
                // 镜头
                canvas.drawCircle(cx, cy + h * 0.15f, size * 0.075f, stroke)
            },
            contentDesc = { R.string.float_sub_screenshot },
            onClick = {
                if (shouldDebounceSubClick(3)) return@createSubBubble
                listener.onScreenshotClicked()
            }
        )
        // v6.7.152: 登记到 subBubbles,index=3
        subBubbles.add(SubBubble(subScreenshotButton, subBubbles.size))

        // v6.7.73 (三球): 三个子球初始位置=主球中心、alpha=0,展开时由动画驱动位移
        // v6.7.79 (动态三球): 收起态一律 GONE(未附加窗口前也无需显示)。
        subBubbles.forEach { it.view.visibility = View.GONE }

        // v6.7.86 (重构): 三叶连接臂。
        // 问题背景:主球(48dp)与三个子球都是圆,缩小子球会撞到触摸目标下限,
        // 纯靠"大小差"建立不了主次;四球在扇形里彼此孤立,视觉上就是四个散球,
        // 中间那个写着计时的主球被读成"第四个扇形成员"。
        // 解法:在主球中心与每个子球中心之间各画一条圆头粗线(线宽 = 子球直径 x 0.55,
        // 与子球同材质同色),四者因此在视觉上连成一个控件,主球成为花心/表盘。
        armLayer = object : View(context) {
            override fun onDraw(canvas: Canvas) {
                if (fanProgress <= 0f) return
                val w = width.toFloat()
                val h = height.toFloat()
                if (w <= 0f || h <= 0f) return
                val cx = w / 2f
                val cy = h / 2f
                val d = resources.displayMetrics.density
                val subR = subBubbleSizePx / 2f
                val rMain = collapsedSizePx / 2f
                val rFull = dynamicExpandRadius().toFloat()

                // v6.7.87 (P1-7): 起点压在主球边缘内侧 1dp。
                // v6.7.86 从圆心(cx,cy)起笔 + ROUND 端帽,主球内部被三条 16.5dp 宽的
                // 楔形覆盖;主球玻璃层只有 80% 不透明(float_surface = #CC...),压不住,
                // 于是透出"三叶螺旋桨"鬼影。从主球外缘起笔后,球内一条臂的像素都没有。
                // 内缩 1dp 是为了不留抗锯齿缝隙(80% 不透明下这 1dp 的渗漏仅约 3%)。
                val r0 = rMain - d
                val r1 = rFull * fanProgress
                armPaint.color = colorSubBg
                armPaint.strokeWidth = subBubbleSizePx * 0.55f
                if (r1 > r0) {
                    for (i in 0 until subBubbles.size) {
                        if (i >= subAngles.size) break
                        val rad = Math.toRadians(subAngles[i])
                        val cos = Math.cos(rad).toFloat()
                        val sin = Math.sin(rad).toFloat()
                        canvas.drawLine(
                            cx + r0 * cos, cy + r0 * sin,
                            cx + r1 * cos, cy + r1 * sin,
                            armPaint
                        )
                    }
                }

                // v6.7.87 (P1-8): 环形轨道。把三个子球串在一条连续的弧上,主球成为弧心。
                // 这是"一个控件"观感的主要来源——三条独立直线只能读作"四个散球之间连了
                // 三条线",一条弧才能读作"一条表带上串着三颗珠子"。drawArc 的角度约定
                // (0°=三点钟、顺时针为正)与 subAngles 完全一致,可直接用,无需换算。
                val capDeg = Math.toDegrees(Math.asin((subR / rFull).toDouble())).toFloat()
                val stepDeg = 180f / subBubbles.size
                val startDeg = subAngles[0].toFloat() - capDeg
                val sweepDeg = 2f * capDeg + (subBubbles.size - 1) * stepDeg
                trackOval.set(cx - rFull, cy - rFull, cx + rFull, cy + rFull)
                trackPaint.color = colorSubBg
                trackPaint.strokeWidth = subBubbleSizePx * 0.55f
                trackPaint.alpha = (255 * 0.6f * fanProgress).toInt().coerceIn(0, 255)
                canvas.drawArc(trackOval, startDeg, sweepDeg, false, trackPaint)
            }
        }.apply {
            layoutParams = ViewGroup.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT,
                ViewGroup.LayoutParams.MATCH_PARENT
            )
            // 纯装饰层:不参与无障碍遍历;不设 clickable,不消费触摸,
            // 触摸仍由 RecordOverlay.dispatchTouchEvent 的命中测试决定去向。
            importantForAccessibility = View.IMPORTANT_FOR_ACCESSIBILITY_NO
        }

        // v6.7.70 (分层): glassLayer 承载玻璃表面与描边,铺满容器,唯一参与模糊。
        // 背景必须在代码里画(用 isNight() 手动选择的 _light/_dark 色),而非 uiMode
        // 解析的 drawable,以匹配 App 手动深色模式。
        glassLayer = object : View(context) {
            override fun onDraw(canvas: Canvas) {
                val w = width.toFloat()
                val h = height.toFloat()
                if (w <= 0 || h <= 0) return
                // v6.7.74: 主玻璃球始终为 48dp 正圆且居中。展开态窗口虽被拉大以容纳
                // 子球扇区,但玻璃球本体保持 collapsedSizePx,不铺满整窗(避免变增大面板)。
                val b = collapsedSizePx.toFloat()
                val left = (w - b) / 2f
                val top = (h - b) / 2f
                bgRect.set(left, top, left + b, top + b)
                val r = currentCornerRadius
                bgPaint.color = colorSurface
                canvas.drawRoundRect(bgRect, r, r, bgPaint)
                canvas.drawRoundRect(bgRect, r, r, strokePaint)
                // v6.7.86 (重构): 展开态给主球加一圈表盘内环,给主球一个"表盘"的
                // 语义标记,让它从"第四个圆"变成"扇形的心"。
                // 用 isExpanded 布尔驱动而非 fanProgress:glassLayer 带 RenderEffect blur,
                // 每帧 invalidate 会重算模糊;环只在 expand()/collapse() 各 invalidate 一次。
                // v6.7.87 (P1-9): 表盘内环加强到 1.5dp/alpha110(原 0.75dp/alpha60 基本不可见),
                // 并加 12 点刻度,给"表盘"一个方向锚——让人一眼读出"这是计时器"而非第四个圆按钮。
                // 仍由 isExpanded 布尔驱动,只在 expand()/收起动画结束各 invalidate 一次,
                // 不参与每帧动画:glassLayer 在非华为/荣耀且 API>=31 上带 RenderEffect blur,
                // 每帧 invalidate 会重算模糊。
                if (isExpanded) {
                    val d = resources.displayMetrics.density
                    val rDial = b / 2f - d * 4.5f
                    dialPaint.color = colorTimer
                    dialPaint.strokeWidth = d * 1.5f
                    dialPaint.alpha = 110
                    canvas.drawCircle(w / 2f, h / 2f, rDial, dialPaint)
                    // v6.7.89 (任务1/L1): 删除 12 点刻度线。它是唯一真正"调试线"性质的绘制
                    // —— 5dp 竖线贴在计时文字上方,观感是残留;时长文本本身就是方向,不损失信息。
                }
            }
        }.apply {
            layoutParams = ViewGroup.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT,
                ViewGroup.LayoutParams.MATCH_PARENT
            )
            // STEP4: 纯装饰层,不参与无障碍遍历,避免干扰计时/按钮的播报顺序
            importantForAccessibility = View.IMPORTANT_FOR_ACCESSIBILITY_NO
        }

        // v6.7.70 (分层): badgeView 绘制收起态 REC 徽标,位于 glassLayer 之上、不参与模糊。
        badgeView = object : View(context) {
            override fun onDraw(canvas: Canvas) {
                drawCollapsedBadge(canvas)
            }
        }.apply {
            layoutParams = ViewGroup.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT,
                ViewGroup.LayoutParams.MATCH_PARENT
            )
            visibility = View.VISIBLE
            // STEP4: 纯装饰层,不参与无障碍遍历
            importantForAccessibility = View.IMPORTANT_FOR_ACCESSIBILITY_NO
        }

        // v6.7.86 (重构): armLayer 置于最底层,被主球(glassLayer)与子球自然遮住两端,
        // 只在主球外缘与子球之间露出一段。
        addView(armLayer)
        addView(glassLayer)
        addView(badgeView)
        addView(timerText)
        // v6.7.73 (三球): 子球在主球内部 addView,不开独立窗口。
        // 父 View 的 RenderEffect blur 作用于自身背景,不影响子 View 的独立半透明背景色。
        // v6.7.79 (动态三球): 遍历 subBubbles 统一挂载,支持任意数量子球。
        subBubbles.forEach { addView(it.view) }

        // v6.7.79 (动态三球): 子球登记完成后计算动态扇区参数(角度分配、防抖数组裁剪)。
        registerSubBubbles()

        // v6.7.88 (Ch3 D-2): 半径恒定后缓存,供 fanWindowSize() 与 expand()/collapse() 复用。
        expandRadiusPxCache = computeExpandRadius()

        // v6.7.82 (P0 修复): 常驻大窗口。子球登记完毕(此时 subBubbles.size 为最终值,
        // fanWindowSize() 恒定不变),把窗口一次性撑到 fanWindowSize(),此后展开/收起都
        // 不再改 layoutParams 尺寸。旧实现展开时才 updateViewLayout 改尺寸,触发
        // 录制中(HONOR sdk37) VirtualDisplay 合成管线重协商,造成 1.5~6.2s 捕获冻结。
        // 坐标统一走 lead 锚点(可见主球左上角),窗口左上角相对 lead 固定偏移 fanShiftPx(),
        // 展开/收起不改变球在屏幕上的位置。此处在 addView 前完成,无 freeze 风险。
        if (layoutParams.width != fanWindowSize() || layoutParams.height != fanWindowSize()) {
            val leadX = layoutParams.x + layoutParams.width / 2 - collapsedSizePx / 2
            val leadY = layoutParams.y + layoutParams.height / 2 - collapsedSizePx / 2
            layoutParams.width = fanWindowSize()
            layoutParams.height = fanWindowSize()
            setLead(leadX, leadY)
        }
        // v6.7.87 (P2-10): 窗口尺寸定型后缓存偏移,把每次 MOVE 的 18~24 次 getDimension 降到 0
        fanShiftPxCache = (fanWindowSize() - collapsedSizePx) / 2

        // 毛玻璃：API 31+ 对 glassLayer 施加 RenderEffect blur(仅玻璃层,文字图标在上层不受糊)，
        // 低版本半透明降级。
        // v6.7.66 (P3-1): 华为/荣耀 ROM 跳过 blur。RenderEffect blur 在华为 EMUI/
        // 部分驱动上渲染整窗时可能静默失败(不抛异常但整窗不上屏)，且本机 sdk=31
        // 正好命中此分支，与"挂载成功但不可见"高度吻合。跳过后用表面色半透明纯色
        // 背景代替，其余品牌设备保留 blur 视觉。此逻辑不变，仅作用对象从整容器改为 glassLayer。
        val hwRom = Build.MANUFACTURER?.lowercase(Locale.ROOT) in setOf("huawei", "honor")
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S && !hwRom) {
            try {
                // createBlurEffect 单位是像素。getDimension() 对 dp 资源已直接换算为 px,
                // 因此这里不再乘 density,clamp ≤25px 避免过大拖垮性能(施工提示词错误4)。
                val blurPx = resources.getDimension(R.dimen.float_blur_radius)
                    .toInt().coerceIn(0, 25)
                glassLayer.setRenderEffect(RenderEffect.createBlurEffect(
                    blurPx.toFloat(),
                    blurPx.toFloat(),
                    android.graphics.Shader.TileMode.CLAMP
                ))
            } catch (e: Exception) {
                android.util.Log.w(TAG, "blur effect unavailable, fallback translucent", e)
            }
        } else if (hwRom) {
            android.util.Log.i(TAG, "renderEffect blur disabled on huawei/honor ROM (avoid silent offscreen)")
        } else {
            // API 30 及以下降级:半透明 + elevation,不黑屏不闪烁(施工提示词第四节)
            // v6.7.145 (P1-7): alpha 从硬编码 0.92 改为读用户配置(40-100%,默认 92)。
            glassLayer.alpha = PreferencesManager(context).overlayAlphaPercent() / 100f
            glassLayer.elevation = resources.getDimension(R.dimen.float_elevation)
        }
    }

    // v6.7.73 (防御): SDK 版本分水岭 flags 精确化。
    // SDK < 30: FLAG_NOT_FOCUSABLE | FLAG_NOT_TOUCH_MODAL | FLAG_LAYOUT_NO_LIMITS | FLAG_LAYOUT_IN_SCREEN
    // SDK >= 30: 去掉 FLAG_LAYOUT_IN_SCREEN。
    // Android 11+ 对窗口边界限制更严格,保留 LAYOUT_IN_SCREEN 在某些 ROM 上会导致悬浮窗
    // 位置计算异常,故按分水岭分支处理。NOT_FOCUSABLE 与 NOT_TOUCH_MODAL 保持不变。
    // v6.7.180: 加 FLAG_KEEP_SCREEN_ON——纯窗口标志、零权限、零电池豁免,球在屏上即屏幕
    // 不因超时变暗,覆盖"用户切到别的 App 仍在录制"的场景;球移除后标志随之消失。
    private fun buildWindowFlags(): Int {
        val base = WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or
            WindowManager.LayoutParams.FLAG_NOT_TOUCH_MODAL or
            WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS or
            WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON
        return if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.R) {
            base
        } else {
            base or WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN
        }
    }

    // v6.7.73 (三球): 创建子浮球——半透明纯色背景 + 1dp stroke + elevation,图标由 draw 绘制。
    // 子球不画独立 blur(40dp 小面积上与纯色差异极低,且避免 5 窗口触发厂商检测)。
    private fun createSubBubble(
        draw: (Canvas, Float, Float, Float, Paint) -> Unit,
        contentDesc: () -> Int,
        onClick: () -> Unit
    ): View {
        val density = resources.displayMetrics.density
        val sizePx = subBubbleSizePx
        val bgColor = colorSubBg
        val strokeColor = colorSubStroke
        return object : View(context) {
            private val subBgPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
                color = bgColor
            }
            private val subStrokePaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
                color = strokeColor
                style = Paint.Style.STROKE
                strokeWidth = resources.getDimension(R.dimen.float_stroke_width)
            }
            private val iconPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
                color = colorSubIcon
                // v6.7.188d: 穿透性 Material 图标 —— 透明度 40%(即不透明度 60%),
                // alpha = 255*0.6 ≈ 153。onDraw 重设 color 不动 alpha,故持续生效。
                alpha = 153
            }
            private val bgRect = RectF()

            override fun onDraw(canvas: Canvas) {
                val cx = width / 2f
                val cy = height / 2f
                // v6.7.73: 每次绘制重读当前配色,使 recolor() 深色/浅色切换即时生效
                subBgPaint.color = colorSubBg
                subStrokePaint.color = colorSubStroke
                iconPaint.color = colorSubIcon
                bgRect.set(0f, 0f, width.toFloat(), height.toFloat())
                val r = width / 2f
                canvas.drawRoundRect(bgRect, r, r, subBgPaint)
                canvas.drawRoundRect(bgRect, r, r, subStrokePaint)
                draw(canvas, cx, cy, width.toFloat(), iconPaint)
            }
        }.apply {
            layoutParams = ViewGroup.LayoutParams(sizePx, sizePx)
            elevation = density * SUB_BUBBLE_ELEVATION_DP
            // v6.7.85 (P1-视觉): 这个 View 没有 background,圆是 onDraw 里手画的,默认
            // OutlineProvider.BACKGROUND 取不到轮廓,elevation 不会产生任何阴影,三个子球
            // 看起来"贴"在主球平面上。这里手动提供圆形轮廓,阴影立刻生效;clipToOutline
            // 把绘制裁成圆(与 onDraw 的 drawRoundRect 一致)。
            outlineProvider = object : ViewOutlineProvider() {
                override fun getOutline(view: View, outline: Outline) {
                    outline.setRoundRect(0, 0, view.width, view.height, view.width / 2f)
                }
            }
            clipToOutline = true
            importantForAccessibility = View.IMPORTANT_FOR_ACCESSIBILITY_YES
            contentDescription = context.getString(contentDesc())
            setOnClickListener { onClick() }
        }
    }

    // 主题变更即时换色：仅刷新颜色并重绘，不重建 View、不做动画
    fun recolor() {
        if (Looper.myLooper() != Looper.getMainLooper()) {
            mainHandler.post { recolor() }
            return
        }
        if (!isAttached) return
        loadColors()
        // v6.7.147 (修复3 P1-7): 透明度仅在 API≤30 降级分支设 alpha,与 buildView 分支对齐。
        // 原实现无条件写 alpha 会把 API31+ 的 RenderEffect blur 层与 hwRom 不透明层一起调透,
        // 与初值(API31+ 恒 1.0,透明度由 blur 视觉承载)不一致。仅 API≤30 生效。
        if (Build.VERSION.SDK_INT <= Build.VERSION_CODES.R) {
            glassLayer.alpha = PreferencesManager(context).overlayAlphaPercent() / 100f
        }
        bgPaint.color = colorSurface
        bgPaint.setShadowLayer(
            resources.displayMetrics.density * 2,
            0f,
            resources.displayMetrics.density * 1f,
            colorShadow
        )
        strokePaint.color = colorStroke
        timerText.setTextColor(colorTimer)
        // v6.7.73 (三球): 刷新子浮球(替换原 stopButton/pauseResumeButton 胶囊按钮)
        // v6.7.79 (动态三球): 遍历 subBubbles 统一刷新
        subBubbles.forEach { it.view.invalidate() }
        glassLayer.invalidate()
        badgeView.invalidate()
        invalidate()
        android.util.Log.i(TAG, "recolor dark=${isNight()}")
    }

    override fun onDraw(canvas: Canvas) {
        // v6.7.70 (分层): 玻璃表面与徽标已移到 glassLayer / badgeView 子视图绘制,
        // 容器本身透明,不再绘制背景(避免模糊糊到文字)。此处保留空实现。
        super.onDraw(canvas)
    }

    private fun drawCollapsedBadge(canvas: Canvas) {
        val density = resources.displayMetrics.density
        val cx = width / 2f
        val cy = height / 2f
        val dotR = density * BADGE_DOT_RADIUS_DP
        // v6.7.88 (P0-1-B): 展开态不画红点。展开态主球中心是"表盘 + 时长",
        // 再叠红点会互相干扰;展开态的录制状态由 pause 子球图标承担。
        // v6.7.89 (S-3): 不再在绘制路径里判 isExpanded——onLayout 已用
        // badgeView.visibility(展开态 GONE)门控该 View 的 onDraw,这里重复守卫属冗余,
        // 删掉,消除"两处同步维护 isExpanded 状态"的负担。
        // v6.7.89 (S-2): 用字段 badgeDotPaint(loadColors 已同步颜色与 shadow)。
        badgeDotPaint.color = colorBadge
        // v6.7.88 (P0-1-B): 红点上移到球心上方 13dp,中心让给时长文本。
        // 旧实现红点在左侧 + "REC" 文字,现去掉 REC(时长本身已说明状态),
        // 红点仅作"正在录"指示,与居中时长不打架。
        canvas.drawCircle(cx, cy - density * 13f, dotR, badgeDotPaint)
    }

    private fun expand() {
        if (isDragging.get()) return
        if (isExpanded) return
        isExpanded = true
        cancelCollapseTimeout()

        subCollapseAnimator?.cancel()
        inertiaAnimator?.cancel()
        snapAnimator?.cancel()
        // v6.7.85 (P0-视觉): 每次展开都按主球当前实际位置重算扇区朝向。
        // init 时算的那次只能覆盖初始位置,球被拖到另一侧后就失效了。
        initSubBubbleAngles()
        val fRad = dynamicExpandRadius()
        val fWin = fanWindowSize()
        DiagLog.log("expand start sub bubbles count=${subBubbles.size} radius=$fRad win=$fWin base=${expandBaseAngle()}")
        // v6.7.82 (P0 修复): 窗口在 init 已固定为 fanWindowSize(),展开不再改尺寸,消除
        // 录制期间 updateViewLayout 改尺寸导致的合成管线冻结。旧 v6.7.76 的撑窗反向补偿
        // (x/y 减 dx)已随之删除——窗口尺寸恒定,lead 锚点恒定,球位置天然不漂移。
        // 子球从主球中心向外扇形展开:translation 由 0 → 目标偏移,alpha 0→1。
        // v6.7.85 (P0-视觉): 移除 rotation 0→90° 动画。原实现在展开结束后把 rotation
        // 停在 90f(收尾只固定 translationX/Y,没有复位 rotation),导致三个子球图标全部
        // 侧躺:房子图标躺倒、暂停的两根竖条变成横条。
        // v6.7.79-FIX: 时长是整数毫秒,自无单位 dimen 迁移至 integer(getInteger)。
        val animDuration = resources.getInteger(R.integer.float_expand_anim_duration).toLong()
        // 确保子球可见并参与布局(onLayout 会按主球中心作为基线摆放)
        badgeView.visibility = View.GONE
        // v6.7.188d: 空闲(IDLE)展开不显示假 00:00,仅录制中显示计时。
        timerText.visibility = if (isRecording) View.VISIBLE else View.INVISIBLE
        subBubbles.forEach { it.view.visibility = View.VISIBLE }
        // v6.7.86: 主球表盘环出现。只 invalidate 一次(blur 层不做每帧重绘)。
        glassLayer.invalidate()
        requestLayout()

        subExpandAnimator?.cancel()
        subExpandAnimator = buildSubFanAnimator(isExpand = true, radius = fRad, duration = animDuration)
        if (isAttached) {
            subExpandAnimator!!.start()
        }
    }

    private fun collapse() {
        if (isDragging.get()) return
        if (!isExpanded) return
        isExpanded = false
        cancelCollapseTimeout()

        subExpandAnimator?.cancel()
        inertiaAnimator?.cancel()
        snapAnimator?.cancel()
        DiagLog.log("collapse start sub bubbles")
        // v6.7.79-FIX: 时长是整数毫秒,自无单位 dimen 迁移至 integer(getInteger)。
        val animDuration = resources.getInteger(R.integer.float_expand_anim_duration).toLong()
        subCollapseAnimator?.cancel()
        subCollapseAnimator = buildSubFanAnimator(isExpand = false, radius = dynamicExpandRadius(), duration = animDuration)
        if (isAttached) {
            subCollapseAnimator!!.start()
        }
    }

    // v6.7.79 (动态三球): 为一个子球构建 ObjectAnimator 属性动画(translationX/Y、alpha),
    // 目标位置由子球展开角度与展开半径计算。属性动画不受 onLayout 每帧重排影响(基线在主球中心
    // onLayout 中固定),彻底取代 updateSubBubbles() 的进度快照摆位。
    private fun buildSubFanAnimator(isExpand: Boolean, radius: Int, duration: Long): AnimatorSet {
        val set = AnimatorSet()
        val animations = ArrayList<Animator>()
        for (sub in subBubbles) {
            val i = sub.index
            if (i >= subBubbles.size) break
            val rad = Math.toRadians(subAngles[i])
            val tx = radius * Math.cos(rad).toFloat()
            val ty = radius * Math.sin(rad).toFloat()
            sub.view.pivotX = sub.view.width / 2f
            sub.view.pivotY = sub.view.height / 2f
            // 回填展开目标位移:供展开结束固定终值、收起动画启动时读取
            sub.targetX = tx
            sub.targetY = ty
            if (isExpand) {
                // 收起基线已归零;直接驱动到目标
                animations += ObjectAnimator.ofFloat(sub.view, "translationX", 0f, tx)
                animations += ObjectAnimator.ofFloat(sub.view, "translationY", 0f, ty)
                animations += ObjectAnimator.ofFloat(sub.view, "alpha", 0f, 1f)
            } else {
                // 收起:从当前展开位回到基线(0,0)
                animations += ObjectAnimator.ofFloat(sub.view, "translationX", sub.view.translationX, 0f)
                animations += ObjectAnimator.ofFloat(sub.view, "translationY", sub.view.translationY, 0f)
                // v6.7.101 (B8): alpha 从当前值出发而非硬编码 1f。展开动画中途被
                // cancel 后 subExpandAnimator 保留当前 alpha(如 0.5),紧接着 collapse
                // 若第一帧硬设为 1f 会造成视觉"闪一下"再淡出到 0。与 translationX/Y
                // rotation 的 from-arg 用 sub.view.xxx 写法保持一致。
                animations += ObjectAnimator.ofFloat(sub.view, "alpha", sub.view.alpha, 0f)
                animations += ObjectAnimator.ofFloat(sub.view, "rotation", sub.view.rotation, 0f)
            }
        }
        // v6.7.86 (重构): 连接臂进度动画。用 ValueAnimator 而非 ObjectAnimator,
        // 因此不会被下面的错峰循环 filterIsInstance<ObjectAnimator>() 命中,
        // 臂始终与第一个子球同步伸出,末端三球再各自错峰到位。
        animations += ValueAnimator.ofFloat(if (isExpand) 0f else 1f, if (isExpand) 1f else 0f).apply {
            addUpdateListener {
                fanProgress = it.animatedValue as Float
                armLayer.invalidate()
            }
            interpolator = DecelerateInterpolator()
            this.duration = duration
        }
        set.playTogether(animations)
        set.interpolator = DecelerateInterpolator()
        set.duration = duration
        // v6.7.85 (P2-视觉): 错峰出场。展开时按 index 依次延迟 35ms,收起时反序(后出的先回),
        // 避免三球同时位移时中途叠成一团。
        for (sub in subBubbles) {
            if (sub.index >= subBubbles.size) break
            val order = if (isExpand) sub.index else (subBubbles.size - 1 - sub.index)
            animations
                .filterIsInstance<ObjectAnimator>()
                .filter { it.target === sub.view }
                .forEach { it.startDelay = order * 35L }
        }
        set.addListener(object : AnimatorListenerAdapter() {
            override fun onAnimationEnd(animation: Animator) {
                if (!isAttached) return
                if (isExpand) {
                    // 到位后固定最终值,防止布局抖动;计时器超时折叠
                    subBubbles.forEach { it.view.translationX = it.targetX; it.view.translationY = it.targetY }
                    // v6.7.86: 臂完全伸出
                    fanProgress = 1f
                    armLayer.invalidate()
                    scheduleCollapseTimeout()
                } else {
                    // 收起结束:子球回到中心并隐藏
                    subBubbles.forEach {
                        it.view.translationX = 0f
                        it.view.translationY = 0f
                        it.view.rotation = 0f
                        it.view.visibility = View.GONE
                    }
                    // v6.7.86: 臂收回,主球表盘环消失(glassLayer 只在这里 invalidate 一次,
                    // 避免带 blur 的图层被每帧重绘)
                    fanProgress = 0f
                    armLayer.invalidate()
                    glassLayer.invalidate()
                    badgeView.visibility = View.VISIBLE
                    // v6.7.88 (P0-1-B): 收起态计时文本保持可见(红点上移、时长居中)。
                    // 旧逻辑这里 GONE 掉计时文本,导致收起态只有 REC 徽标,看不到时长。
                    timerText.visibility = View.VISIBLE
                    // v6.7.89 (L-5): 收起后若展开前处于停靠态,恢复停靠(先吸附再弹回停靠位)。
                    // 否则 dock-expand 把 isDocked 清掉后,停靠态会被一次点击永久抹掉。
                    if (pendingRedockSide >= 0) {
                        applyDocked(pendingRedockSide)
                        // v6.7.92 (P0): 形参顺序是 (fromX, toX, fromY, toY)。
                        // 旧调用把第 2、3 个实参传反:toX 填成 leadY(),fromY 填成 dockTargetX(-28),
                        // 表现是收起时球先纵向上窜到屏幕顶端外(y=-28)再滑下,横向被自己的纵坐标
                        // 决定最终 X,被 clampPosition 截到 1196。用具名实参,编译期就会暴露错位。
                        startSnapAnim(
                            fromX = leadX(),
                            toX = dockTargetX(pendingRedockSide),
                            fromY = leadY(),
                            toY = dockTargetY(pendingRedockSide)
                        )
                        pendingRedockSide = -1
                    }
                    requestLayout()
                }
            }
        })
        return set
    }

    // v6.7.82 (P1 修复): 命中测试放行透明区。v6.7.82 窗口常驻 fanWindowSize()(如 566px),
    // 可见主球只占窗口中心一小块,其余是透明不可见区域。若无条件消费触摸,展开态圆形
    // 大窗会整块吞掉其下方 App 的点击(变成"触摸黑洞")。这里只消费落在主球或任一可见
    // 子球命中圆内的触摸,圆外直接 return false 放行给底层窗口。窗口 FLAG_NOT_TOUCH_MODAL
    // 保证外部触摸可穿透。主球始终在窗口中心;子球现位于 cx+translationX, cy+translationY。
    override fun dispatchTouchEvent(event: MotionEvent): Boolean {
        // v6.7.88 (Ch3 D-3/5.6): 拖拽进行中直接 super.dispatchTouchEvent(event) 派发到
        // onTouchEvent,由 onTouchEvent 的 rawX/rawY 处理跟手。
        // 注意:不能改成 return true——那样只是声明"消费事件"但没有真正派发,
        // onTouchEvent 收不到 MOVE/UP,悬浮球就跟着手指不动。
        if (isDragging.get()) return super.dispatchTouchEvent(event)
        val w = width.toFloat()
        val h = height.toFloat()
        if (w <= 0f || h <= 0f) return super.dispatchTouchEvent(event)
        val cx = w / 2f
        val cy = h / 2f
        val x = event.x
        val y = event.y
        val density = resources.displayMetrics.density
        // v6.7.87 (P1-6): 展开态先判子球,再判主球,两者容差都拿满 8dp。
        // v6.7.86 的做法是"主球容差从 8dp 收到 2dp"来避免热区重叠,
        // 结果主球可抓面积从 112px 掉到 91px(缩 34%),手指一偏就抓空。
        // 换顺序是更优解:子球是按钮,命中精度优先,拿满 8dp 容差;
        // 主球是拖动把手,丢掉朝向子球那一侧的月牙不影响跟手,也拿满 8dp。
        if (isExpanded) {
            for (sub in subBubbles) {
                if (sub.view.visibility != View.VISIBLE) continue
                val sx = cx + sub.view.translationX
                val sy = cy + sub.view.translationY
                val sr = subBubbleSizePx / 2f + 8f * density
                if (distance(x, y, sx, sy) <= sr) {
                    return super.dispatchTouchEvent(event)
                }
            }
        }
        val mainR = collapsedSizePx / 2f + 8f * density
        if (distance(x, y, cx, cy) <= mainR) {
            return super.dispatchTouchEvent(event)
        }
        // 不在任一球内:不消费,放行给底层 App
        if (event.action == MotionEvent.ACTION_DOWN) {
            DiagLog.log("HIT miss x=$x y=$y (transparent) pass-through")
        }
        return false
    }

    private fun distance(x1: Float, y1: Float, x2: Float, y2: Float): Double {
        val dx = x1 - x2
        val dy = y1 - y2
        return Math.sqrt((dx * dx + dy * dy).toDouble())
    }

    override fun onTouchEvent(event: MotionEvent): Boolean {
        // [FIX-2] P1: View 已被释放时不再消费触摸,避免 removeView 后仍对已移除
        // 窗口做 updateViewLayout/窗口操作,防止 WindowManager 状态不一致引发 native 崩溃。
        if (!isAttached) return false
        gestureDetector.onTouchEvent(event)

        when (event.action) {
            MotionEvent.ACTION_DOWN -> {
                DiagLog.resetMoveGap()          // v6.7.189 (P2-13): 手势起点复位
                isDragging.set(false)
                // v6.7.82 (P0 修复): 拖拽以 lead(可见主球左上角)为基准。
                initialX = leadX()
                initialY = leadY()
                // v6.7.87 (P0-3): 新一轮触摸开始时清掉上一轮可能残留的待提交位置
                cancelPendingLead()
                initialTouchX = event.rawX
                initialTouchY = event.rawY
                lastRawX = event.rawX
                lastRawY = event.rawY
                prevRawX = event.rawX
                prevRawY = event.rawY
                snapAnimator?.cancel()
                cancelCollapseTimeout()
                // v6.7.82 (P2 修复): 不再无条件 cancel 子球展开/收起动画。Animator.cancel()
                // 会回调 onAnimationEnd 执行收尾分支:展开播到一半被 cancel,会把子球 translation
                // 固定到完全展开位再收起,视觉"猛甩出去再缩回"。让动画自然播完或由后续动作接管。
                // subExpandAnimator?.cancel()
                // subCollapseAnimator?.cancel()
                inertiaAnimator?.cancel()
                DiagLog.log("DOWN rawX=${event.rawX} rawY=${event.rawY} " +
                    "leadX=${leadX()} leadY=${leadY()} winX=${layoutParams.x} winY=${layoutParams.y} " +
                    "off=${windowOriginOffsetX},${windowOriginOffsetY} isExpanded=$isExpanded isDocked=$isDocked")
            }
            MotionEvent.ACTION_MOVE -> {
                // v6.7.81 (健壮性): 多指防护——第二根手指落下(event.pointerCount>1,
                // 原始坐标 rawX/rawY 会以最后一根手指为基准,导致坐标瞬变、球被拽飞)。
                // 检测到多指时立即取消本次拖拽,避免球体位置被第二根手指带偏后失控。
                if (event.pointerCount > 1) {
                    if (isDragging.get()) {
                        isDragging.set(false)
                        // v6.7.101 (B5): 多指打断"已在进行的拖拽"后,后续第一指
                        // ACTION_UP 会走 tap 分支(handleMainTap),误触发主球 expand/collapse。
                        // 置 suppressNextTap 让下一次 UP 跳过点击逻辑,只走拖拽收尾
                        // (snapToEdge 等),消除用户"拖一半加指→松手误点击"的 UI 缺陷。
                        suppressNextTap.set(true)
                        DiagLog.log("MOVE multi-finger cancel drag pointerCount=${event.pointerCount} suppressNextTap=true")
                    }
                    // v6.7.102 (B7): 未进入拖拽(isDragging=false)时落下第二指,
                    // 说明第一指仍在 DOWN 阶段(未过 touchSlop),此时不存在"拖拽被打断"
                    // 的语义——用户只是双指按住主球,后续 UP 时若第一指抬起、第二指
                    // 仍在按住,那是一次新的 DOWN 序列的开始,不应被 suppressNextTap 吞掉。
                    // 旧逻辑无条件置 true 会导致"合法多指手势下一次 UP 的点击被吃掉"。
                    // 只在 isDragging 分支置位,精确对应"多指真的打断了拖拽"。
                    return true
                }
                val dx = (event.rawX - initialTouchX).toInt()
                val dy = (event.rawY - initialTouchY).toInt()
                // v6.7.87 (P1-5): 去掉 !isExpanded 门控——展开态同样可以拖动。
                // 三个子球是 RecordOverlay 的子 View,窗口整体平移时它们的
                // translationX/Y 相对主球中心不变,扇形跟着走;UP 会重新吸附。
                if (Math.abs(dx) > touchSlop || Math.abs(dy) > touchSlop) {
                    isDragging.set(true)
                    prevRawX = lastRawX
                    prevRawY = lastRawY
                    lastRawX = event.rawX
                    lastRawY = event.rawY

                    if (isDocked) {
                        // v6.7.94 (P1 衔接): 位置始终 1:1 跟手,阈值只决定"是否解除停靠"。
                        // 旧实现未过阈值时把沿边轴钉死在停靠位、一过阈值就整段跳到
                        // initialX+dx —— 本机 4 次 unlock 的 dx=-264/-214/-259/+221,
                        // 即球在跨过 210px 的那一帧瞬移 214~264px,无衔接动画;且小幅
                        // 拖拽松手时 leadX()==toX,snapToEdge 直接 return,连回弹都没有。
                        // 改成位置连续跟手后:未过阈值 -> 松手从当前位置回弹到停靠位
                        // (有动画);过阈值 -> 正常吸边。两条路径都连续。
                        requestLead(initialX + dx, initialY + dy)
                        val unlockDelta =
                            if (dockSide == DOCK_TOP || dockSide == DOCK_BOTTOM) dy else dx
                        if (Math.abs(unlockDelta) > unlockDockThresholdPx) {
                            isDocked = false
                            pendingRedockSide = -1
                            DiagLog.log("dock unlock drag d=$unlockDelta")
                        }
                    } else {
                        // v6.7.90 (A-3): 用户已经把球拖到了新位置,收起后不该再吸回
                        // 展开前的停靠位,否则这次拖动被静默丢弃。
                        pendingRedockSide = -1
                        requestLead(initialX + dx, initialY + dy)
                    }

                    DiagLog.recordMoveGap()
                    // v6.7.87 (P0-3): 日志从"每 5 个事件"降到"每 30 个事件",
                    // 且不再调用 leadX()/leadY()(每次 3 次 getDimension + 1 次 Math.sin)
                    moveCountForLog++
                    if (moveCountForLog % 30 == 0) {
                        DiagLog.log("MOVE rawX=${event.rawX} rawY=${event.rawY} " +
                            "dx=$dx dy=$dy isDocked=$isDocked isExpanded=$isExpanded")
                    }
                }
            }
            MotionEvent.ACTION_UP -> {
                val dragging = isDragging.get()
                if (dragging) {
                    isDragging.set(false)
                    cancelPendingLead()
                    val vx = lastRawX - prevRawX
                    val vy = lastRawY - prevRawY
                    val speed = Math.sqrt((vx * vx + vy * vy).toDouble())
                    DiagLog.log("UP dragging=true vx=$vx vy=$vy speed=${"%.1f".format(speed)} " +
                        "leadX=${leadX()} leadY=${leadY()} winX=${layoutParams.x} winY=${layoutParams.y} isExpanded=$isExpanded")
                    if (isDocked) {
                        snapToEdge(respectDocked = true)
                    } else if (speed > MIN_VELOCITY) {
                        launchInertia(vx * 2f, vy * 2f)
                    } else {
                        snapToEdge(respectDocked = false)
                    }
                } else {
                    // v6.7.82 (P4 修复): 慢点收不起主球——原仅依赖 GestureDetector 的
                    // onSingleTapConfirmed,需等 doubleTapTimeout 才确认,慢点/长按被吞。
                    // 现在直接在此处触发 toggle(含防抖),gestureDetector 的延时回调
                    // 会被同一防抖窗口抑制,不会重复。
                    // v6.7.101 (B5): 多指打断后的下一次 UP 跳过点击,只复位标志。
                    val suppressed = suppressNextTap.getAndSet(false)
                    if (suppressed) {
                        DiagLog.log("UP tap suppressed by prior multi-finger cancel")
                    } else {
                        DiagLog.log("UP tap (not dragging) isExpanded=$isExpanded")
                        performClick()
                        handleMainTap()
                    }
                }
                scheduleCollapseTimeout()
            }
            // v6.7.81 (健壮性): 系统级触摸取消(手势区抢占、来电、其他窗口拦截 touch)
            // 必须复位拖拽状态。此前缺失 ACTION_CANCEL,一旦取消时正在拖拽,
            // isDragging 会永久停在 true,导致主球后续永远无法再展开(expand() 首行
            // 即 return isDragging)。复位同时取消惯性/吸附动画,确认球不被卡死。
            MotionEvent.ACTION_CANCEL -> {
                isDragging.set(false)
                // v6.7.104 (B3): CANCEL 时同步复位 suppressNextTap。
                // 多指打拖拽后系统派发 CANCEL(而非 UP),CANCEL 分支旧逻辑只复位
                // isDragging,若前一步 v6.7.102 B7 逻辑已置位 suppressNextTap,
                // 该标志会残留到下一次正常 tap,把用户的合法点击吃掉,
                // 表现为"点两次才展开扇形"。CANCEL 意味着本次手势被系统吞掉,
                // 本次序列的"下一次 UP"承诺不再成立,抑制不应跨越手势序列延续。
                suppressNextTap.set(false)
                cancelPendingLead()
                DiagLog.log("CANCEL reset dragging & suppressNextTap isExpanded=$isExpanded isDocked=$isDocked")
                inertiaAnimator?.cancel()
                snapAnimator?.cancel()
                scheduleCollapseTimeout()
            }
        }
        return true
    }

    // v6.7.87 (P0 拖动流畅度): 窗口位置提交与触摸采样解耦。
    // 触摸 120~240Hz、屏幕 60~120Hz，逐事件提交 = 每帧排 2~4 次同步 Binder
    // 事务(Session.relayout)，其中只有最后一次有意义，其余纯阻塞主线程。
    // 改成:MOVE 只登记目标位置，由 Choreographer 每帧提交一次最新值。
    private var pendingLeadX = 0
    private var pendingLeadY = 0
    private var hasPendingLead = false
    private var leadCommitPosted = false
    private val leadCommitCallback = android.view.Choreographer.FrameCallback { commitPendingLead() }

    /** 登记目标位置，不立刻碰 WindowManager。 */
    private fun requestLead(x: Int, y: Int) {
        pendingLeadX = x
        pendingLeadY = y
        hasPendingLead = true
        if (!leadCommitPosted) {
            leadCommitPosted = true
            android.view.Choreographer.getInstance().postFrameCallback(leadCommitCallback)
        }
    }

    /** 每帧最多一次 updateViewLayout。 */
    private fun commitPendingLead() {
        leadCommitPosted = false
        if (!hasPendingLead) return
        hasPendingLead = false
        setLead(pendingLeadX, pendingLeadY)
        clampPosition()
        // v6.7.88 (Ch3 D-4): 与已落地位置相同则跳过 Binder IPC。拖动沿吸附边/停靠线
        // 滑动时,clamp 后 lead 不变,逐帧空转 updateViewLayout 纯阻塞主线程。
        val lx = leadX()
        val ly = leadY()
        if (lx == committedLeadX && ly == committedLeadY) return
        val t0 = android.os.SystemClock.uptimeMillis()
        safeUpdateViewLayout()
        // 埋点挪到这里:按帧统计而不是按触摸事件统计
        DiagLog.recordUpdateViewLayoutMs(android.os.SystemClock.uptimeMillis() - t0)
    }

    /** 松手/吸附/停靠等必须同帧生效的场景走这里。 */
    private fun commitLeadNow(x: Int, y: Int) {
        if (leadCommitPosted) {
            android.view.Choreographer.getInstance().removeFrameCallback(leadCommitCallback)
            leadCommitPosted = false
        }
        hasPendingLead = false
        setLead(x, y)
        clampPosition()
        safeUpdateViewLayout()
    }

    private fun cancelPendingLead() {
        if (leadCommitPosted) {
            android.view.Choreographer.getInstance().removeFrameCallback(leadCommitCallback)
            leadCommitPosted = false
        }
        hasPendingLead = false
        // v6.7.88 (Ch3 D-4): 取消挂起提交后,把 committedLead 对齐当前实际窗口位置,
        // 避免后续首次真实位移被误判为"无变化"而跳过。
        committedLeadX = leadX()
        committedLeadY = leadY()
    }

    private fun launchInertia(vx: Float, vy: Float) {
        DiagLog.log("inertia launch vx=$vx vy=$vy")
        // v6.7.82 (P0 修复): 惯性以 lead 坐标为基准。
        var startX = leadX().toFloat()
        var startY = leadY().toFloat()
        var currentVx = vx
        var currentVy = vy

        inertiaAnimator = ValueAnimator.ofFloat(0f, 1f).apply {
            duration = INERTIA_DURATION_MS
            addUpdateListener { anim ->
                // [FIX-3] 释放后取消,避免对已移除 View 继续操作
                if (!isAttached) {
                    inertiaAnimator?.cancel()
                    return@addUpdateListener
                }
                if (isDragging.get()) {
                    inertiaAnimator?.cancel()
                    return@addUpdateListener
                }
                // v6.7.87 (P0-3): 惯性动画同帧提交,走 commitLeadNow 而非逐帧 setLead+relayout
                commitLeadNow((startX + currentVx).toInt(), (startY + currentVy).toInt())
                currentVx *= INERTIA_DECAY
                currentVy *= INERTIA_DECAY
                startX = leadX().toFloat()
                startY = leadY().toFloat()
            }
            addListener(object : AnimatorListenerAdapter() {
                override fun onAnimationEnd(animation: Animator) {
                    if (isDragging.get()) return
                    snapToEdge(respectDocked = false)
                }
            })
            start()
        }
    }

    private fun startSnapAnim(fromX: Int, toX: Int, fromY: Int, toY: Int) {
        snapAnimator?.cancel()
        DiagLog.log("SNAP start fromX=$fromX toX=$toX fromY=$fromY toY=$toY")
        snapAnimator = ValueAnimator.ofFloat(0f, 1f).apply {
            duration = SNAP_DURATION_MS
            interpolator = DecelerateInterpolator()
            addUpdateListener { anim ->
                // [FIX-3] 释放后取消,避免对已移除 View 继续操作
                if (!isAttached) {
                    snapAnimator?.cancel()
                    return@addUpdateListener
                }
                if (isDragging.get()) {
                    snapAnimator?.cancel()
                    return@addUpdateListener
                }
                val f = anim.animatedFraction
                // v6.7.87 (P0-3/P0-4): 同帧提交;删掉 invalidate()——移动窗口不需重绘内容,
                // 原来的 invalidate() 让 497x497 的树每帧重走绘制并产出新帧缓冲,与 relayout 叠加。
                commitLeadNow((fromX + (toX - fromX) * f).toInt(), (fromY + (toY - fromY) * f).toInt())
            }
            addListener(object : AnimatorListenerAdapter() {
                override fun onAnimationEnd(animation: Animator) {
                    clampPosition()
                    // [FIX-1] 统一走容错链
                    safeUpdateViewLayout()
                    persistPosition()
                    DiagLog.log("SNAP end leadX=${leadX()} leadY=${leadY()} isDocked=$isDocked dockSide=$dockSide")
                }
            })
            start()
        }
    }

    private fun snapToEdge(respectDocked: Boolean) {
        val screenWidth = screenWidthFromDisplay()
        val screenHeight = screenHeightFromDisplay()
        // v6.7.188e: 纯水平吸附(A/B 方案)。Y 轴只表示高度,不参与左右判断。
        // 以屏幕中心为原点:dx = 球心X - W/2。
        //   A 方案 |dx| > ε:dx<0 吸左,dx>0 吸右。
        //   B 方案 |dx| <= ε:中心线无法判左右,随机左/右(各 50%)。
        // 停靠目标 Y 统一回到屏幕垂直中心 H/2。
        val lx = leadX()
        val ly = leadY()
        val ballCx = lx + leadW() / 2.0
        val dx = ballCx - screenWidth / 2.0
        val epsPx = 1.0
        val targetSide: Int
        if (respectDocked && isDocked) {
            targetSide = dockSide
        } else {
            val isCenterLine = Math.abs(dx) <= epsPx
            val goLeft = if (isCenterLine) {
                // B 方案:中心线无法判左右,随机选侧(约 50% 各)
                Math.random() < 0.5
            } else {
                // A 方案:按 dx 符号判定左右
                dx < 0
            }
            targetSide = if (goLeft) DOCK_LEFT else DOCK_RIGHT
        }
        val toX = dockTargetX(targetSide)
        val toY = dockTargetY(targetSide)
        // v6.7.90 (A-3): 拖到新边缘吸附后,停靠意图已被用户改变,
        // 收起时不应再吸回展开前的旧停靠位。
        if (!(respectDocked && isDocked)) {
            pendingRedockSide = -1
        }
        applyDocked(targetSide)
        if (leadX() == toX && leadY() == toY) {
            return
        }
        startSnapAnim(fromX = leadX(), toX = toX, fromY = leadY(), toY = toY)
    }

    private fun dockTargetX(dockSide: Int): Int {
        return when (dockSide) {
            // v6.7.188d: 始终露一半球体 → 停靠目标 = 屏幕边缘 +/- 半径(leadW/2)
            DOCK_LEFT -> -(leadW() / 2)
            DOCK_RIGHT -> screenWidthFromDisplay() - leadW() / 2
            else -> leadX()
        }
    }

    private fun dockTargetY(dockSide: Int): Int {
        // v6.7.188e: 纯水平吸附,停靠 Y 统一回到屏幕垂直中心,
        // 球心 = H/2 → lead 左上角 = H/2 - leadH()/2。
        return when (dockSide) {
            DOCK_LEFT, DOCK_RIGHT -> screenHeightFromDisplay() / 2 - leadH() / 2
            else -> leadY()
        }
    }

    private fun screenWidthFromDisplay(): Int = resources.displayMetrics.widthPixels
    private fun screenHeightFromDisplay(): Int = resources.displayMetrics.heightPixels

    // v6.7.75-F1: 计算滚动条底部安全边距。init 时 onApplyWindowInsets 尚未回调,
    // navbarInsetPx 仍是 float_navbar_inset(12dp) 的默认值,远小于 HONOR PTP-AN70
    // 这类三段式底部手势导航条的实测高度(约 96px)。
    // v6.7.89 (S-6): 兜底从 48dp 降到 28dp。48dp 是在 density=2 机器上定的(96px),
    // 本机 density=3.5 算成 168px,比实测导航条(约 96px)高出 72px,把球凭空顶高;
    // 28dp @3.5 = 98px 才贴合实测。实测值到位后仍以实测为准(maxOf)。
    private fun safeBottomInsetPx(): Int {
        val floorPx = (resources.displayMetrics.density * 28).toInt()
        return maxOf(navbarInsetPx, floorPx)
    }

    private fun applyDocked(dockSide: Int) {
        this.dockSide = dockSide
        isDocked = true
    }

    // v6.7.75-F3: 屏幕方向变化时重置底部 inset 并重新钳制,防止横竖屏切换后
    // 沿用旧方向坐标系里的坐标越界/被导航条盖住。由 Service.onConfigurationChanged
    // 转发调用(Service 级声明了 configChanges,不会重建,必须手动转发)。
    fun onScreenOrientationChanged() {
        // v6.7.89 (L-1): 横竖屏切换后状态栏/内容区原点会变,重新实测坐标系偏移
        measureWindowOriginOffset()
        // 方向一变,旧导航条 inset 失效,置 0 等待 onApplyWindowInsets 重新实测
        navbarInsetPx = 0
        clampPosition()
        if (!isDocked && !isDragging.get()) {
            // 未停靠且未拖拽:回到默认位置(贴边 + 底部安全边距),避免沿用旧方向坐标
            setLead(
                (resources.getDimension(R.dimen.float_margin_edge)).toInt(),
                screenHeightFromDisplay() - collapsedSizePx - safeBottomInsetPx()
            )
            clampPosition()
        }
        // [FIX-1] 统一走容错链
        safeUpdateViewLayout()
    }

    private fun clampPosition() {
        val screenWidth = screenWidthFromDisplay()
        val screenHeight = screenHeightFromDisplay()
        // v6.7.82 (P0 修复): 全部按 lead(可见主球左上角)运算,窗口左上角 = lead - fanShift。
        var lx = leadX()
        var ly = leadY()
        // v6.7.174 (异形屏 P1): 非 docked 时用四边系统栏/刘海/挖孔安全边距钳制,
        // 把球挡在可见安全区外(左上挖孔/横屏侧边导航条不再盖球)。docked 状态吸附
        // 边缘露小舌是刻意行为,不受 safe inset 约束,防止破坏停靠交互。
        // v6.7.188d: dock 态露一半 → 球可合法越过屏幕边半个身位,钳制下限=半个球,
        // 上限=屏幕尺寸-半个球,保证永远露一半、不整球飞出屏。
        val dockInsetX = leadW() / 2
        val dockInsetY = leadH() / 2
        val minLeft = if (isDocked) dockInsetX else maxOf(minVisiblePx, safeInsetLeft)
        val minRight = if (isDocked) dockInsetX else maxOf(minVisiblePx, safeInsetRight)
        val minTop = if (isDocked) dockInsetY else maxOf(minVisiblePx, safeInsetTop)
        if (lx + minRight > screenWidth) {
            lx = screenWidth - minRight
        }
        if (lx + leadW() < minLeft) {
            lx = minLeft - leadW()
        }
        if (ly + minVisiblePx > screenHeight) {
            ly = screenHeight - minVisiblePx
        }
        if (ly + leadH() < minTop) {
            ly = minTop - leadH()
        }
        setLead(lx, ly)
    }

    // v6.7.75-F2: 当底部导航栏实测 inset 到位(onApplyWindowInsets)后,若球仍落在
    // 真实导航条区域内(非 dock、非拖拽、非展开),把它向上推到导航条上方,避免
    // 屏幕可点区域被手势区/导航条盖住的初始坐标一直残留在不可点区。
    private fun reClampOverNavbar() {
        if (isDocked) return
        if (isDragging.get()) return
        if (isExpanded) return
        if (navbarInsetPx <= 0) return
        val screenHeight = screenHeightFromDisplay()
        val overNavbar = leadY() + leadH() >= screenHeight - navbarInsetPx
        if (!overNavbar) return
        setLead(leadX(), screenHeight - collapsedSizePx - safeBottomInsetPx())
        // [FIX-1] 统一走容错链
        safeUpdateViewLayout()
    }

    private fun persistPosition() {
        prefs.edit().apply {
            // v6.7.82 (P0 修复): 持久化 lead 坐标(可见主球左上角),不含窗口偏移,
            // 重启 restore 时按 lead 还原位置准确。
            putInt(PERSIST_X, leadX())
            putInt(PERSIST_Y, leadY())
            putBoolean(PERSIST_DOCKED, isDocked)
            putInt(PERSIST_DOCK_SIDE, dockSide)
            apply()
        }
    }

    // v6.7.88 (P0-1/Ch6.1): 删除 measureTimerWidth()——计时框改为主球外接正方形
    // (collapsedSizePx, FrameLayout.CENTER) 后,实测宽度不再需要,相关 dimen
    // float_timer_width/_max/_slack 一并删除。

    override fun onLayout(changed: Boolean, left: Int, top: Int, right: Int, bottom: Int) {
        super.onLayout(changed, left, top, right, bottom)

        // v6.7.79 (动态三球): 移除 subExpandFraction/subExpandAlpha 进度快照 hack。
        // 子球始终以主球中心为基线居中布局(layoutParams 无 gravity 会被 re-layout 到左上角,
        // 故必须在 super 之后统一摆回中心),展开离中心、收起回中心全部由 translationX/Y 属性
        // 动画驱动——translation 相对基线生效,onLayout 每帧重排基线并不会覆盖动画位移,
        // 彻底摆脱"每帧按快照重摆扇形"的竞态。收起结束子球 GONE,不参与可见布局。
        val s = subBubbleSizePx
        val cx = width / 2f
        val cy = height / 2f
        for (sub in subBubbles) {
            if (sub.view.visibility == View.GONE) continue
            sub.view.layout(
                (cx - s / 2f).toInt(),
                (cy - s / 2f).toInt(),
                (cx + s / 2f).toInt(),
                (cy + s / 2f).toInt()
            )
        }

        // v6.7.70 (分层): glassLayer 与 badgeView 铺满容器(MATCH_PARENT,
        // FrameLayout 会摆到完全相同位置,手工 layout 是冗余的,行为逐像素一致)。
        // v6.7.88 (Ch6.2): 删掉 glassLayer.layout / badgeView.layout。
        // 收起态显示徽标,展开态隐藏。
        // v6.7.188 (【5】空闲常驻视觉): 非录制态 badgeView 也隐藏,只留红点①。
        badgeView.visibility = if (isExpanded || !isRecording) View.GONE else View.VISIBLE

        // v6.7.88 (P0-1): 删除 timerText.layout(0, 0, width, height) —— 它是
        // "计时器飘在球外"的直接原因(见 init 的 layoutParams 注释)。timerText 现在
        // 是 collapsedSizePx 见方 + Gravity.CENTER,由 super.onLayout()(FrameLayout)
        // 摆到窗口正中即主球正中,两个维度都落在球心。
        // v6.7.88 (P0-1-B): 计时文本录制期间始终可见。旧逻辑"仅展开态可见"导致收起态
        // 主球里只有 REC 徽标,用户想看时长必须先展开——而收起态才是球 99% 时间的状态。
        // v6.7.89 (S-4): 可见性由 expand()/collapse()/初始化管理,onLayout 热路径不再覆盖。
    }

    // 底部导航栏 inset：应用 +12dp 抬高，避免悬浮球被手势区遮挡
    // v6.7.174 (异形屏 P1): 从"只读 bottom"扩展到"四边 + displayCutout"。刘海/挖孔
    // insets.top>0(左上挖孔)或 insets.left>0(左缘),导航栏在横屏可能落右侧而非底部。
    // 用 displayCutout|navigationBars|statusBars 组合取全边,供 clampPosition 挡球。
    override fun onApplyWindowInsets(insets: WindowInsets): WindowInsets {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.R) {
            val b = insets.getInsets(
                WindowInsets.Type.displayCutout() or WindowInsets.Type.navigationBars()
            )
            safeInsetLeft = b.left
            safeInsetTop = b.top
            safeInsetRight = b.right
            if (b.bottom > 0) {
                navbarInsetPx = b.bottom + (resources.getDimension(R.dimen.float_navbar_inset)).toInt()
                reClampOverNavbar()
            } else {
                // v6.7.183 的 else 只置零 + reClampOverNavbar,但后者在 navbarInsetPx<=0
                // 时 early return,结果是"记账对了、球没动"。v6.7.184 改为真的落球:
                // 球停在旧导航条上沿时,主动设到新底部安全区。
                val oldInset = navbarInsetPx
                navbarInsetPx = 0
                if (oldInset > 0 && !isDocked && !isDragging.get() && !isExpanded) {
                    val sh = screenHeightFromDisplay()
                    if (leadY() + leadH() >= sh - oldInset) {
                        setLead(leadX(), sh - collapsedSizePx - safeBottomInsetPx())
                        safeUpdateViewLayout()
                    }
                }
            }
        } else {
            @Suppress("DEPRECATION")
            safeInsetLeft = insets.systemWindowInsetLeft
            @Suppress("DEPRECATION")
            safeInsetTop = insets.systemWindowInsetTop
            @Suppress("DEPRECATION")
            safeInsetRight = insets.systemWindowInsetRight
            // v6.7.178 (①拦发版): <R 分支原先只置左/上/右,bottom 完全没接。minSdk=24,
            // Android 7-11 全部走本分支,旋转后悬浮球仍压进导航条(176→177 字节零差异即因此)。
            // 与 @R 分支同构:bottom>0 才抬高 navbarInsetPx 并重钳(底部钳位走 clampPosition 的
            // minVisiblePx 与 reClampOverNavbar,不设单独 safeInsetBottom 字段,避免未使用变量)。
            @Suppress("DEPRECATION")
            val bottomInset = insets.systemWindowInsetBottom
            if (bottomInset > 0) {
                navbarInsetPx = bottomInset +
                    (resources.getDimension(R.dimen.float_navbar_inset)).toInt()
                reClampOverNavbar()
            } else {
                // v6.7.184: 同 @R 分支,记账复位后必须真的落球,不能只调 reClampOverNavbar
                // (navbarInsetPx<=0 时它 early return,球不会动)。
                val oldInset = navbarInsetPx
                navbarInsetPx = 0
                if (oldInset > 0 && !isDocked && !isDragging.get() && !isExpanded) {
                    val sh = screenHeightFromDisplay()
                    if (leadY() + leadH() >= sh - oldInset) {
                        setLead(leadX(), sh - collapsedSizePx - safeBottomInsetPx())
                        safeUpdateViewLayout()
                    }
                }
            }
        }
        return insets
    }

    fun updatePauseState(paused: Boolean) {
        if (!isAttached) return
        mainHandler.post {
            val prev = isPaused
            isPaused = paused
            subActionLockUntil = 0L   // 真实状态已回读,解除切换锁
            // v6.7.73 (三球): 暂停/继续状态反映到子浮球图标与描述
            subPauseButton.contentDescription = context.getString(
                if (paused) R.string.float_resume else R.string.float_pause
            )
            // 可访问性：录制状态变化发事件
            sendAccessibilityEvent(AccessibilityEvent.TYPE_WINDOW_CONTENT_CHANGED)
            if (prev != isPaused) {
                subPauseButton.invalidate()
            }
        }
    }

    // v6.9.10 (AZ 一体四子球): 子球①录制态三态刷新,镜像 updatePauseState。
    // recording=false 时复位 isPaused,避免退出录制后残留"继续"三角。
    // v6.7.188 (【5】): 空闲常驻时不显 00:00 与 REC 徽标。
    fun updateRecordingState(recording: Boolean) {
        if (!isAttached) return
        mainHandler.post {
            val prev = isRecording
            isRecording = recording
            subActionLockUntil = 0L   // 真实状态已回读,解除切换锁(即使未变化也解,无害)
            if (!recording) isPaused = false
            subPauseButton.contentDescription = context.getString(
                if (!recording) R.string.float_start
                else if (isPaused) R.string.float_resume
                else R.string.float_pause
            )
            sendAccessibilityEvent(AccessibilityEvent.TYPE_WINDOW_CONTENT_CHANGED)
            if (prev != isRecording || !recording) {
                subPauseButton.invalidate()
            }
            // v6.7.188 (【5】空闲常驻视觉): 非录制态隐藏计时与 REC 徽标,只露红点①。
            if (!recording) {
                timerText.visibility = View.INVISIBLE
                badgeView.visibility = View.GONE
            } else {
                timerText.visibility = View.VISIBLE
                badgeView.visibility = if (isExpanded) View.GONE else View.VISIBLE
            }
            // v6.7.188c-fix: 录制开始且用户正展开操作 → 延时收球回贴边。
            if (recording && isExpanded) {
                mainHandler.postDelayed(collapseRunnable, AUTO_RETRACT_MS)
            }
        }
    }

    // v6.7.73/74 (计时刷新 + 窗口尺寸): 引擎 onProgress 事件驱动 + Handler 载体,非协程。
    // 计时文本始终居中。窗口尺寸:展开态固定为容纳三子球扇区的正方形 fanWindowSizePx
    // (计时与子球都在其中,无需再逐秒撑宽);收起态恢复 48dp 正圆。故计时刷新只更新文本,
    // 不再动态改窗口宽度(避免与扇区窗口相互覆盖)。保留引擎 durationMs 为计时值来源。
    // v6.7.89 (S-1): 上次 setTextSize 用到的字号资源。setTextSize 内部 requestLayout()+invalidate(),
    // 无条件调用等于每秒对计时框走一次完整 measure/layout/draw,而字号只会在 mm:ss -> h:mm:ss 时变一次。
    private var currentTimerSizeRes = 0

    fun updateTimer(text: String) {
        if (!isAttached) return
        // v6.7.88 (Ch2.4-3): 时长 ≥6 字符(hh:mm:ss)切到 long 9sp,避免长串撑破主球外接正方形。
        val sizeRes = if (text.length >= 6) R.dimen.float_timer_text_size_long else R.dimen.float_timer_text_size
        mainHandler.post {
            if (timerText.text != text) {
                timerText.text = text
            }
            // v6.7.89 (S-1): 只在字号真正切换时 setTextSize,避免每秒一次 requestLayout。
            if (currentTimerSizeRes != sizeRes) {
                currentTimerSizeRes = sizeRes
                // COMPLEX_UNIT_PX: getDimension 已返回 px,避免 sp→px 二次放大(见 init FIX-1)
                timerText.setTextSize(
                    android.util.TypedValue.COMPLEX_UNIT_PX,
                    resources.getDimension(sizeRes)
                )
            }
        }
    }

    private fun scheduleCollapseTimeout() {
        if (isExpanded) {
            mainHandler.removeCallbacks(collapseRunnable)
            mainHandler.postDelayed(collapseRunnable, COLLAPSE_TIMEOUT_MS)
        }
    }

    private fun cancelCollapseTimeout() {
        mainHandler.removeCallbacks(collapseRunnable)
    }

    // v6.7.73 (防御): 主浮球点击防抖——300ms 内的重复点击直接忽略,放一切业务逻辑之前。
    private fun shouldDebounceMainClick(): Boolean {
        val now = android.os.SystemClock.elapsedRealtime()
        if (now - lastMainClickElapsed < CLICK_DEBOUNCE_MS) {
            return true
        }
        lastMainClickElapsed = now
        return false
    }

    // v6.7.73 (防御): 子浮球点击防抖——v6.7.76-FIX3 改为按下标各自计时(index 0/1/2),
    // 避免三个子球共用一个时间戳导致连点时后者被吞。
    private fun shouldDebounceSubClick(index: Int): Boolean {
        val now = android.os.SystemClock.elapsedRealtime()
        if (now - lastSubClickElapsed[index] < CLICK_DEBOUNCE_MS) {
            return true
        }
        lastSubClickElapsed[index] = now
        return false
    }
}
