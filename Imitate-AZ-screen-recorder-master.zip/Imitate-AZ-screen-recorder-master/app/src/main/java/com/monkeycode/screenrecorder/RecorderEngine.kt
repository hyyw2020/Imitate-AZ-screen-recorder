package com.monkeycode.screenrecorder

import android.content.ContentResolver
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.hardware.display.DisplayManager
import android.hardware.display.VirtualDisplay
import android.app.ActivityManager
import android.os.PowerManager
import android.media.AudioAttributes
import android.media.AudioFormat
import android.media.AudioManager
import android.media.AudioPlaybackCaptureConfiguration
import android.media.AudioRecord
import android.media.MediaCodec
import android.media.MediaCodecInfo
import android.media.MediaCodecList
import android.media.MediaFormat
import android.media.MediaMuxer
import android.media.MediaRecorder
import android.media.projection.MediaProjection
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.os.Environment
import android.os.StatFs
import android.os.Handler
import android.os.HandlerThread
import android.os.Process
import android.os.SystemClock
import android.os.BatteryManager
import android.os.ParcelFileDescriptor
import android.provider.DocumentsContract
import android.util.Log
import android.view.Surface
import java.io.File
import java.io.FileInputStream
import java.io.IOException
import java.nio.ByteBuffer
import java.util.concurrent.LinkedBlockingQueue
import java.util.concurrent.atomic.AtomicBoolean
import java.util.concurrent.atomic.AtomicLong
import android.util.SparseLongArray

interface RecorderEngineCallback {
    fun onStarted()
    fun onStopped(durationMs: Long, fileSize: Long, outputPath: String)
    fun onError(exception: Exception)
    fun onEncoderChanged(codec: String)
    fun onProgress(durationMs: Long, fileSize: Long)
    // v6.7.48: 非致命运行期预警(纯观测、不动作),供上层记录/排查瓶颈。
    fun onWarning(warning: String) {}
    // v6.7.128: 分片清单回调(多分片录制结束时给出所有已封口分片路径)。单片录制为空。
    fun onSegments(segments: List<String>) {}
}

// v6.7.128: 单个已封口分片的信息(manifest 一行 + 恢复/历史用)。
data class SegmentInfo(
    val seq: Int,
    val path: String,
    val durationMs: Long,
    val bytes: Long,
    val width: Int,
    val height: Int,
)

class RecorderEngine(private val context: Context) {

    // v6.7.188c: 直接嵌套类（companion 外，跨文件限定名 RecorderEngine.OrphanInfo 无歧义）。
    data class OrphanInfo(
        val name: String,          // tmp 文件名 或 分片目录名
        val path: String,          // 绝对路径
        val sizeBytes: Long,       // tmp 大小 或 目录内分片总大小
        val hasIdx: Boolean,       // 伴生 .idx 是否存在(有则修复更快更准)
        val isSegmentDir: Boolean, // true=分片目录形态,false=旧式单 tmp
        val segCount: Int,         // 目录内 seg_*.mp4(.tmp) 数;tmp 形态为 0
        val lastModified: Long
    )

    companion object {
        private const val TAG = "RecorderEngine"

        // v6.7.157 (P0-1): 原"删已编码 P 帧"的降档丢帧节奏已移除——花屏根治见 handleVideoOutput。
        // 帧率控制改在编码前(启动期历史封顶/分片边界重建编码器),降档只降码率不删帧。
        // 降档锁:回升后此时间内再次触发降档 → 锁死档位不再回弹
        const val RUN_LATCH_MS = 30_000L
        // 回升稳定观察期:温度<46 且电量>30 持续此时间才回弹
        const val RECOVER_STABLE_MS = 10_000L
        // v6.7.156 (修3): 过热触发阈值与回弹线。本机(HONOR PTP-AN70)空闲即 49-53C,
        // 45C 触发/40C 回弹导致"开录 3 秒即降、永不回弹";改 50C 触发、46C 回弹。
        const val THERMAL_DOWNGRADE_C = 50
        const val THERMAL_RECOVER_C = 46
        // v6.7.157 (修B2): 相对基线降档——首 N 次健康读数中位数作基线;过热 = 超基线 +6℃,
        // 回弹 = 回落至基线 +2℃ 内。让"热"=这台机异常升温,而非一刀切绝对阈值。
        const val THERMAL_BASELINE_SAMPLES = 5
        const val THERMAL_OVER_BASELINE = 6
        const val THERMAL_RECOVER_OVER_BASE = 2
        // v6.7.156 (修3): 单次录制最多降档步数,防 46 秒 ×0.8 一路砸到 floor。
        const val MAX_DOWNGRADE_STEPS = 4
        // v6.7.156 (修3): 降档乘数 0.9(原 0.8),单步更温和。
        const val DOWNGRADE_MUL_NUM = 9
        const val DOWNGRADE_MUL_DEN = 10
        // 降档最低档位(固定下限,与 userBitrate/4 取高)
        const val MIN_DOWNGRADE_BITRATE = 4_000_000
        // v6.7.188h (改造5): 基线物理上限。超过此值视为传感器标定异常,回退常量。
        const val BASELINE_PHYSICAL_MAX_C = 65
        /** v6.7.189 (P1-5): 温度中位数窗口与尖峰抑制阈值。 */
        const val THERMAL_MEDIAN_N = 5
        const val THERMAL_SPIKE_C = 15
        // v6.7.188h (改造5): 异常基线时的回退常量。取常见机型空闲温度区间上沿。
        const val BASELINE_FALLBACK_C = 45
        // v6.7.188h (改造5): 基线自适应单次最小间隔,防抖动。
        const val BASELINE_ADAPT_INTERVAL_MS = 30_000L
        // v6.7.188h (改造5): 基线相对回退常量的允许漂移幅度(℃)。
        const val BASELINE_ADAPT_RANGE_C = 8
        // v6.7.188h (改造2): 省电模式浅降,每档 -10%(比硬压 -10% 实际同为 9/10,语义独立便于调参)。
        const val SOFT_DOWNGRADE_NUM = 9
        const val SOFT_DOWNGRADE_DEN = 10
        // v6.7.188h (改造2): 省电模式最多浅降 1 档,避免"系统省电"被当成"设备过热"。
        const val SOFT_MAX_DOWNGRADE_STEPS = 1
        // v6.7.188h (改造1): boost 重估周期(ms),与 5s health 周期同源调用。
        const val BOOST_EVAL_INTERVAL_MS = 5_000L
        /** v6.7.189 (P0-3): boost 上限从 2.5 收到 1.5,只补回被摊薄的每帧比特。 */
        const val BOOST_FACTOR_MAX = 1.5
        // v6.7.188h (改造1): 滞后区间。系数相对变化小于此值不调整,防抖。
        const val BOOST_HYSTERESIS = 0.15
        // v6.7.188h (改造1): 用户码率硬上限,防 4K 高档 boost 后越过 4GiB 安全水线。
        const val USER_BITRATE_HARD_CAP = 80_000_000

        const val PIXEL_THROUGHPUT_CAP = 180_000_000L
        const val MIME_VIDEO = "video/avc"
        const val MIME_HEVC = "video/hevc"

        private const val DEFAULT_FPS = 30
        private const val DEFAULT_BITRATE = 10_000_000
        // v6.7.127 (S3): 启动期按分辨率硬 clamp 码率已废弃(azBitrateCapForHeight 删除),
        // 上限交给 clampToCapabilities 的 hardware bitrateRange.upper。历史背景(早期 16M
        // 一刀切在真机触发编码器热节流退化 ~21fps)由 runtime 三级降档接管,而非静态压码率。
        private const val KEY_PROFILE = "profile"
        private const val KEY_BIT_RATE = "bitrate"
        private const val KEY_FRAME_RATE = "frame-rate"
        private const val KEY_I_FRAME_INTERVAL = "i-frame-interval"
        private const val KEY_COLOR_FORMAT = "color-format"
        // v6.7.95: 移除未引用常量 KEY_MAX_BITRATE(仅声明处出现)。

        // v6.7.91 (5.5): MP4 视频轨标准 timescale=90000(90kHz),
        // 1 个 timescale 单位 = 1_000_000 / 90000 ≈ 11µs。
        // 旧 +1µs 在 90kHz 下取整为 0, 两帧 PTS 可能相同(非严格单调)。
        private const val VIDEO_TRACK_TIMESCALE = 90_000L
        private val VIDEO_PTS_MIN_TICK_US = 1_000_000L / VIDEO_TRACK_TIMESCALE // = 11

        // v6.7.46: 对齐 AZ 6.9.10 Lnh/f0->y() 反编译实证的码率-分辨率分档。
        // 该档位即 AZ 主录制在对应分辨率的固定码率,用于我方 clamp 上限,
        // 确保 1080p/2K 运动场景码率足额(不再被 8M 一刀切压低)。
        // v6.7.127 (S3): azBitrateCapForHeight 已删除,码率上限由 clampToCapabilities 的
        // hardware bitrateRange.upper 兜底(见 azBitrateCapForHeight caller 注释)。
        private const val KEY_BITRATE_MODE = "bitrate-mode"
        // v6.7.95: 移除未引用常量 KEY_DURATION / KEY_IS_BITRATE_MODE_SUPPORTED /
        // KEY_QUALITY / KEY_SAMPLE_RATE(均仅声明处出现)。
        private const val KEY_CHANNEL_COUNT = "channel-count"
        private const val KEY_AAC_PROFILE = "aac-profile"
        private const val KEY_MAX_INPUT_SIZE = "max-input-size"

        // v6.7.48: 连续低帧率预警阈值(秒)。actualFps < 0.8*target 持续该秒数触发 onWarning。
        private const val LOW_FPS_WARNING_SECONDS = 5

        // v6.7.127 (S6): FRAMERATE_DOWNGRADE_STEPS / PROBE_SAFETY_FACTOR 已随启动期
        // 探针/历史降档链一并移除(见 applyHistoricalFpsCap 删除处)。

        // v6.7.45(层级四 超越AZ点): 磁盘满提前至 500MB 触发安全收尾,而不是等到写满报错。
        // 触发后经 onError -> cleanupAndStop -> engine.stop 走完整 finalize,不损坏已有文件。
        // 高于 AZ(其无任何磁盘满自愈,写满时 muxer writeSampleData 直接失败)。
        private const val MIN_FREE_SPACE_BYTES = 500L * 1024 * 1024  // 500MB

        // v6.7.105: 4GiB 单文件边界防护。
        // MP4 (MediaMuxer MUXER_OUTPUT_MPEG_4) 内部用 32-bit 偏移寻址,单文件超过
        // 4GiB 后 mdat 内 64-bit 原子尚可继续写,但 moov 索引(mvor)对 chunk/样本偏移
        // 的 32-bit 编码会溢出,最终产物 moov 损坏、无法 seek 甚至完全打不开。
        // 本项目无分段器,默认 10Mbps 约 57 分钟、16Mbps 约 36 分钟、20Mbps 约 29 分钟
        // 就会撞线;旧代码在超限后才靠写失败 onError 兜底,且 stop() 无条件
        // renameToFinal() 把损坏的 .recording.tmp 改名为 .mp4 并写进历史——用户看到
        // "录完了"却打不开。这里预留一个安全水线(取 4GiB - 64MiB 余量),逐帧在写入前
        // 检查 videoBytesWritten,到水线即触发 onError 走完整收尾,产出可播放文件
        // (内容截止在水线前,而非 4GiB 撞毁)。
        // 抖动由 Bitrate→字节率估算:高速率档仍留不少于几十 MB 缓冲,确保最后几帧
        // 安全落入 muxer 而不越过 4GiB。
        private const val MUXER_4G_SAFE_LIMIT_BYTES = (4L * 1024 * 1024 * 1024) - (64L * 1024 * 1024)  // 4GiB - 64MiB
        private const val MUXER_4G_SAFE_LIMIT_MB = (MUXER_4G_SAFE_LIMIT_BYTES + 512L) / (1024L * 1024L)   // 4032MiB

        // v6.7.128: 多分片 MP4 + manifest。MediaMuxer 仅输出普通 MP4(无 fMP4),
        // 用「多个普通 MP4 分片 + 清单」实现剪映式分段:每片独立 moov、独立可播、moov
        // 32-bit 索引绝对安全,且 API24~37 全版本原生可用。4GiB 水线保留为最后保险。
        const val SEGMENT_DURATION_MS = 60_000L   // 分段主阈值:60s 到点切
        const val SEGMENT_MAX_BYTES = 1L * 1024 * 1024 * 1024  // 分段兜底阈值:单片 1GiB
        /** v6.7.189 (P1-9): 分片到期前预请求 IDR / 切段后等 IDR 的墙钟上限。 */
        const val SEG_IDR_PRE_REQUEST_MS = 800L
        const val SEG_IDR_WAIT_MS = 500L
        /** v6.7.189 (P1-10): AV 半步重锚——连续 N 窗口同向且超阈值才对音频 PTS 补偿一半。 */
        const val AV_REANCHOR_US = 250_000L     // 250ms 才启动重锚
        const val AV_REANCHOR_WINDOWS = 3       // v6.7.190 (P0-6): 近 3 个窗口累积(不再要求同号)
        /** v6.7.189 (P1-11): capture_stall 窗口告警阈值(60s 内 >=5 次停顿)。 */
        const val STALL_WINDOW_MAX = 5
        /** v6.7.189 (P2-12): 运行时静音告警阈值(8s 无非零音频字节增量)。 */
        const val AUDIO_SILENT_WARN_MS = 8_000L
        // v6.7.159 (NEW-BUG-1): 等首帧 IDR 的有界丢弃上限。requestKeyFrame 用 setParameters("request-sync")
        // 是软提示,硬件编码器可合法忽略(hybrid 编码路径/个别 OEM 驱动在时机不当时忽略)。一旦本次切换后
        // 编码器始终不发 IDR,pendingSegIdr 会永远为 true -> 该分片从切换点到录制结束/下次切换前的所有视频帧
        // 都被丢弃,变成 0 视频样本的分片(中段绿屏整片缺失;末段 0 样本可致 mergeSegments 抛异常或产出损坏 mp4)。
        // 有界丢弃:正常设备只丢 1~2 帧;异常设备最多丢 30 帧(≈0.5s @60fps,足够多数设备吐 IDR)后放弃等待、
        // 写 P 帧(新片开头至多一个 GOP 短暂参考缺失 = 花屏,比整片全空/损坏可接受得多)。
        const val SEG_IDR_DROP_MAX = 30
        const val MANIFEST_NAME = "manifest.txt"
        private const val MANIFEST_HEADER = "# ImitateAZ manifest v1"
        const val SEG_PREFIX = "seg_"

        // v6.7.133: 移除 "hevc" 黑名单项。旧实现把含 hevc 的编码器(OMX.qcom.video.encoder.hevc /
        // c2.qti.hevc.encoder 等)一并过滤,导致 listAllCodecCandidates 的候选池里根本没有 HEVC 编码器,
        // selectBestVideoEncoder(preferHevc=true) 的 +200 加分与 HEVC_PREFERRED_BITRATE_CAP=80M 全部
        // 落空,preferHevc 永远选不上 HEVC,只能选 AVC(现象:useHevc=true 但日志输出 mime=video/avc)。
        // 移除后 HEVC 编码器进入候选池,preferHevc 生效;无 HEVC 硬编的设备走 configureEncoderWithRetry
        // 自动回退 AVC,不崩溃。
        // v6.7.137: 同步移除 "omx.exynos." 项。旧实现既把三星 Exynos 全部 AVC/HEVC 硬编
        // (OMX.Exynos.avc.enc / OMX.Exynos.hevc.enc)过滤出候选池,又在 selectBestVideoEncoder 给含
        // exynos 的候选 +30 分——加分永远落空,自相矛盾,导致 Exynos 机型(三星欧版 S 系)退到 Google 软编,
        // 帧率/功耗劣化。删除黑名单项后 Exynos 硬编可进候选池并被优先,与 exynos +30 加分一致。
        private val BLACKLIST_PATTERNS = listOf(
            "vp9", "secure", "decoder", "omx.google."
        )

        // v6.7.132: HEVC 偏好码率上限抬到 UI 上限 80M。让 2K/4K/高码率档全部优先 HEVC
        // (码率 max 取向:HEVC 与 AVC 同码率、画质更足)。HEVC 实际不可用(编码器缺失/
        // configure 失败/资源不足)由 selectBestVideoEncoder 的 sorted.firstOrNull 与
        // configureEncoderWithRetry 自动回退 AVC,不依赖此 cap 兜底。
        private val HEVC_PREFERRED_BITRATE_CAP = 80_000_000

        // v6.7.132: 144fps 档是否用 AVCProfileHigh。true=画质 MAX(144 档也 High);
        // false=回退 144 档 Baseline(规避 v6.3.15 已修的 surface 消费不稳风险)。
        const val ALLOW_HIGH_AT_HIGH_FPS = true

        // 录制状态持久化:进程重启后自动恢复录制
        private const val PREFS_NAME = "recorder_state"
        private const val KEY_RECORDING_ACTIVE = "recording_active"
        private const val KEY_OUTPUT_PATH = "recording_output_path"
        private const val KEY_SAF_URI = "recording_saf_uri"
        private const val KEY_SAF_FILE_NAME = "recording_saf_file_name"
        private const val KEY_CONFIG_WIDTH = "recording_config_width"
        private const val KEY_CONFIG_HEIGHT = "recording_config_height"
        private const val KEY_CONFIG_FPS = "recording_config_fps"
        private const val KEY_CONFIG_BITRATE = "recording_config_bitrate"
        private const val KEY_CONFIG_USE_AUDIO = "recording_config_use_audio"
        private const val KEY_CONFIG_USE_INTERNAL = "recording_config_use_internal"
        private const val KEY_CONFIG_USE_MIC = "recording_config_use_mic"
        private const val KEY_CONFIG_USE_HEVC = "recording_config_use_hevc"
        private const val KEY_VIDEO_FRAME_SEQ = "recording_video_frame_seq"
        private const val KEY_AUDIO_STREAM_BYTES = "recording_audio_stream_bytes"
        private const val KEY_AUDIO_OUTPUT_FRAME_COUNT = "recording_audio_output_frame_count"
        private const val KEY_LAST_AUDIO_PTS_US = "recording_last_audio_pts_us"
        // v6.7.95: 移除未引用常量 KEY_VIDEO_START_ANCHOR_US(仅声明处出现)。
        private const val KEY_FIRST_AUDIO_FRAME_TIME_US = "recording_first_audio_frame_time_us"
        private const val KEY_FIRST_VIDEO_FRAME_TIME_US = "recording_first_video_frame_time_us"
        private const val KEY_LAST_VIDEO_FRAME_TIME_US = "recording_last_video_frame_time_us"
        private const val KEY_CURRENT_FPS = "recording_current_fps"
        private const val KEY_CURRENT_BITRATE = "recording_current_bitrate"
        private const val KEY_VIDEO_BYTES_WRITTEN = "recording_video_bytes_written"
        private const val KEY_AUDIO_BYTES_WRITTEN = "recording_audio_bytes_written"
        private const val KEY_AUDIO_START_REALTIME_US = "recording_audio_start_realtime_us"
        private const val KEY_ADAPTIVE_LEVEL = "recording_adaptive_level"

        fun saveRecordingState(context: Context, engine: RecorderEngine) {
            val prefs = context.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE)
            val cfg = engine.config ?: return
            prefs.edit()
                .putBoolean(KEY_RECORDING_ACTIVE, true)
                .putString(KEY_OUTPUT_PATH, engine.outputFilePath)
                .putString(KEY_SAF_URI, engine.safOutputUri?.toString())
                .putString(KEY_SAF_FILE_NAME, engine.safTargetFileName)
                .putInt(KEY_CONFIG_WIDTH, cfg.width)
                .putInt(KEY_CONFIG_HEIGHT, cfg.height)
                .putInt(KEY_CONFIG_FPS, cfg.fps)
                .putInt(KEY_CONFIG_BITRATE, cfg.bitrate)
                .putBoolean(KEY_CONFIG_USE_AUDIO, cfg.useAudio)
                .putBoolean(KEY_CONFIG_USE_INTERNAL, cfg.useInternalAudio)
                .putBoolean(KEY_CONFIG_USE_MIC, cfg.useMicAudio)
                .putBoolean(KEY_CONFIG_USE_HEVC, cfg.useHevc)
                .putLong(KEY_VIDEO_FRAME_SEQ, engine.videoFrameSeq)
                .putLong(KEY_AUDIO_STREAM_BYTES, engine.audioStreamBytes)
                .putLong(KEY_AUDIO_OUTPUT_FRAME_COUNT, engine.audioOutputFrameCount)
                .putLong(KEY_LAST_AUDIO_PTS_US, engine.lastAudioPtsOutUs)
                .putLong(KEY_FIRST_AUDIO_FRAME_TIME_US, engine.firstAudioFrameTimeUs.get())
                .putLong(KEY_FIRST_VIDEO_FRAME_TIME_US, engine.firstVideoFrameTimeUs)
                .putLong(KEY_LAST_VIDEO_FRAME_TIME_US, engine.lastVideoFrameTimeUs)
                .putInt(KEY_CURRENT_FPS, engine.currentFps)
                .putInt(KEY_CURRENT_BITRATE, engine.currentBitrate)
                .putLong(KEY_VIDEO_BYTES_WRITTEN, engine.videoBytesWritten)
                .putLong(KEY_AUDIO_BYTES_WRITTEN, engine.audioBytesWritten)
                .putLong(KEY_AUDIO_START_REALTIME_US, engine.audioStartRealtimeUs)
                .putInt(KEY_ADAPTIVE_LEVEL, 0) // 恢复后使用默认自适应等级
                .apply()
        }

        fun clearRecordingState(context: Context) {
            context.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE)
                .edit().clear().apply()
        }

        fun isRecordingActive(context: Context): Boolean {
            return context.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE)
                .getBoolean(KEY_RECORDING_ACTIVE, false)
        }

        // —— 自学习状态持久化 ——
        // 跨录制保持 adaptiveLevel、fps 历史、编码器性能记录，
        // 使每次录制从上次学习到的参数开始，而非从默认值重新适配。
        private const val LEARN_PREFS_NAME = "learn_state"
        private const val KEY_LEARN_ADAPTIVE_LEVEL = "adaptive_level"
        private const val KEY_LEARN_AVG_FPS = "avg_fps"
        private const val KEY_LEARN_AVG_BITRATE = "avg_bitrate"
        private const val KEY_LEARN_TOTAL_RECORDINGS = "total_recordings"
        private const val KEY_LEARN_ENCODER_PREF = "encoder_preference"
        // v6.7.138 (改进1 缺陷修复): 记录 encoder_preference 的来源原因。
        // 取值枚举 "device_cap"(设备能力/配置失败被迫 AVC) 或 "manual"(用户显式开/关)。
        // 供 start() 回灌条件: 仅 reason==device_cap 且 learned=="avc" 时压制 useHevc,
        // 避免用户显式打开 HEVC 开关被学习态永久压制(原 v6.7.137 缺陷:无原因字段,
        // learned=="avc" && useHevc 直接覆盖,混淆 device_cap/manual 两种场景)。
        // 旧数据无此 key 视为 null,统一按 manual 处理(宁可少回灌也不压制用户显式选择)。
        private const val KEY_LEARN_REASON = "encoder_pref_reason"
        private const val KEY_LEARN_RESOLUTION_DOWNGRADE = "resolution_downgrade"
        // v6.7.127 (P1-5): learn_state 完整性校验。写用 commit() 同步落盘 + 尾部 crc32，
        // 读时校验失败回退默认；老版本数据(无该 key)视为合法保留，避免升级清空历史学习状态。
        private const val KEY_LEARN_CRC32 = "learn_state_crc32"

        // 稳定序列化指纹输入：固定分隔符拼接，与字段顺序无关，防止歧义。
        private fun learnStateFingerprint(
            adaptiveLevel: Int, avgFps: Int, avgBitrate: Int,
            totalRecordings: Int, encoderPreference: String?, resolutionDowngraded: Boolean
        ): String = "_${adaptiveLevel}_${avgFps}_${avgBitrate}_${totalRecordings}_${encoderPreference}_${resolutionDowngraded}_"

        private fun crc32Of(s: String): Long =
            java.util.zip.CRC32().apply { update(s.toByteArray(Charsets.UTF_8)) }.value

        fun loadLearnState(context: Context): LearnState {
            // v6.7.113 (健壮性): 某些 ROM 或异常关机/杀进程后 SharedPreferences 底层
            // XML 可能损坏,getInt/getString 会抛 XmlPullParserException。若不捕获,
            // loadLearnState 在 applyHistoricalFpsCap(启动)里抛异常会让整个 start() 失败,
            // 用户无法录制。捕获后回退默认值,最坏影响=本次从用户设定帧率起录(第1档),
            // 仍能正常录音/录像,只是暂失历史参数。比崩溃强得多。
            return try {
                val prefs = context.getSharedPreferences(LEARN_PREFS_NAME, Context.MODE_PRIVATE)
                val state = LearnState(
                    adaptiveLevel = prefs.getInt(KEY_LEARN_ADAPTIVE_LEVEL, 1),
                    avgFps = prefs.getInt(KEY_LEARN_AVG_FPS, 0),
                    avgBitrate = prefs.getInt(KEY_LEARN_AVG_BITRATE, 0),
                    totalRecordings = prefs.getInt(KEY_LEARN_TOTAL_RECORDINGS, 0),
                    encoderPreference = prefs.getString(KEY_LEARN_ENCODER_PREF, null),
                    resolutionDowngraded = prefs.getBoolean(KEY_LEARN_RESOLUTION_DOWNGRADE, false)
                )
                // v6.7.127 (P1-5): crc32 完整性命中才采用；缺失(老版本)保留=兼容迁移，
                // 存在但不匹配=数据被篡改/损坏，回退默认并丢弃，避免脏数据污染自学习均值。
                val storedCrc = prefs.getLong(KEY_LEARN_CRC32, -1L)
                if (storedCrc >= 0L && crc32Of(
                        learnStateFingerprint(
                            state.adaptiveLevel, state.avgFps, state.avgBitrate,
                            state.totalRecordings, state.encoderPreference, state.resolutionDowngraded)) != storedCrc) {
                    Log.e(TAG, "learn_state crc32 mismatch (stored=$storedCrc); corrupted, falling back to defaults")
                    return LearnState(1, 0, 0, 0, null, false)
                }
                state
            } catch (e: Throwable) {
                Log.e(TAG, "loadLearnState failed, state may be corrupted; falling back to defaults: ${e.message}")
                LearnState(1, 0, 0, 0, null, false)
            }
        }

        // v6.7.157 (修A): 历史实测帧率封顶的纯决策函数,返回生效帧率(0 = 不封顶)。
        // 必剪"按素材实际帧率决定导出帧率"——编码器 KEY_FRAME_RATE 定死后 PTS 跟着铺,
        // 请求 60 实测 25 时产物是 1/4 速慢放,不如开机即按实测封顶。
        // 生效条件:样本数 >=2 且 avgFps >=10;省电模式强制封顶;非省电需请求值明显高于
        // 实测(avgFps 的 15/8 ≈ 1.875 倍)才封顶,避免对已达标的机器过度降帧。
        // 下限 15fps。返回 0 表示保持请求帧率不变。
        // v6.7.188h (改造3): 用"最近 N 次的中位数 + 最低样本数门槛"替代单一点 avgFps,
        // 避免一次异常录制(后台限频/热降频)把长期上限固化。
        // 生效条件:样本数 >=MIN_LEARN_SAMPLES 且中位数 >=10;省电模式强制封顶;
        // 非省电需请求值明显高于中位数(15/8 ≈ 1.875 倍)才封顶。下限 15fps。返回 0 = 不封顶。
        fun capFpsByLearn(recentFps: List<Int>, requestedFps: Int, powerSave: Boolean, totalRecordings: Int): Int {
            if (requestedFps <= 0 || totalRecordings < MIN_LEARN_SAMPLES || recentFps.size < MIN_LEARN_SAMPLES) return 0
            val valid = recentFps.filter { it >= 10 }.sorted()
            if (valid.size < MIN_LEARN_SAMPLES) return 0
            val median = valid[valid.size / 2]                   // 中位数,抗单次异常
            // v6.7.189 (P1-8): 下限从 15 提到 30。本仓 minSdk=24 时代的机型普遍能稳跑 30fps;
            // 低于 30fps 的卡顿是硬伤,远大于省下的电。省电模式宁可降码率也不降帧率。
            val cap = median.coerceAtLeast(FPS_CAP_FLOOR)
            if (requestedFps <= cap) return 0
            // 省电模式不再"无条件"封顶:仅在用户允许省电影响码率/帧率时才封顶
            if (powerSave || requestedFps > cap * 15 / 8) return cap
            return 0
        }

        // v6.7.189 (P1-8): 帧率学习封顶下限 30fps(省电模式优先降码率、不降帧率)。
        const val FPS_CAP_FLOOR = 30

        // v6.7.188h (改造3): 学习态生效所需的最低样本数。
        const val MIN_LEARN_SAMPLES = 3

        /** v6.7.188h (改造3): 用官方 VideoCapabilities 探测本机在给定分辨率下编码器能稳跑的帧率。
         *  借鉴 C 的"先探测再设参"方法论,全部走官方 API,无任何厂商私有接口。
         *  @return 探测上限(保守取整到 5fps 档并留 1 档余量);探测失败返回 0 = 不限制,沿用静态表。 */
        @JvmStatic
        fun probeMaxFpsForConfig(mime: String, width: Int, height: Int): Int {
            return try {
                var caps: MediaCodecInfo.CodecCapabilities? = null
                val codecList = MediaCodecList(MediaCodecList.ALL_CODECS)
                for (codecInfo in codecList.codecInfos) {
                    if (!codecInfo.isEncoder) continue
                    if (!codecInfo.supportedTypes.contains(mime)) continue
                    try {
                        caps = codecInfo.getCapabilitiesForType(mime)
                        if (caps != null) break
                    } catch (_: Exception) {}
                }
                val videoCaps = caps?.videoCapabilities ?: return 0
                // 1) 先确认该尺寸本身是否受支持(不支持则交给 clampToCapabilities 处理尺寸)
                val sizeOk = try { videoCaps.isSizeSupported(width, height) } catch (_: Throwable) { true }
                if (!sizeOk) return 0
                // 2) 官方 API 直接给该尺寸下的帧率区间,比任何经验表都准
                val range = try { videoCaps.getSupportedFrameRatesFor(width, height) }
                    catch (_: Throwable) { null } ?: return 0
                val upper = range.upper.toInt()
                if (upper <= 0) return 0
                // 3) 保守化:取整到 5fps 档并留 1 档余量,避免贴边跑导致背压掉帧
                val stepped = (upper / 5) * 5
                val safe = if (stepped >= 5) stepped - 5 else stepped
                safe.coerceAtLeast(15)
            } catch (_: Throwable) {
                0
            }
        }

        // v6.7.188 (【3】): 已删除内联自校验死代码,零调用者。

        // v6.7.140 (方案1): 纯标准 API 设备分级，返回 0=低/1=中/2=高。
        // 仅作上限钳制：低档机在 Auto 档封顶 fps=30/bitrate=24M，用户显式选过的值一律尊重。
        private fun deviceTier(context: Context): Int {
            val am = context.getSystemService(Context.ACTIVITY_SERVICE)
                    as? android.app.ActivityManager
            val lowRam = try { am?.isLowRamDevice == true } catch (_: Throwable) { false }
            val cores = Runtime.getRuntime().availableProcessors()
            val memMb = try {
                val mi = android.app.ActivityManager.MemoryInfo()
                am?.getMemoryInfo(mi)
                mi.totalMem / (1024 * 1024)
            } catch (_: Throwable) { 0L }
            return when {
                lowRam || cores <= 4 || (memMb in 1 until 3 * 1024) -> 0
                cores <= 6 || (memMb in 1 until 6 * 1024) -> 1
                else -> 2
            }
        }

        fun clearLearnState(context: Context) {
            context.getSharedPreferences(LEARN_PREFS_NAME, Context.MODE_PRIVATE)
                .edit().clear().apply()
        }

        data class LearnState(
            val adaptiveLevel: Int,
            val avgFps: Int,
            val avgBitrate: Int,
            val totalRecordings: Int,
            val encoderPreference: String?,
            val resolutionDowngraded: Boolean
        )

        private const val AUDIO_SAMPLE_RATE = 44100
        // v6.7.43: GLA-AL00 复测 AudioRecord 实际 ch=1 mono,编码器 KEY_CHANNEL_COUNT=2 stereo
        // 导致 PCM 帧长/声道数错位 → 编码异常/静音。改为:AudioRecord 请求 stereo(CHANNEL_IN_STEREO),
        // 构建成功后读 record.channelCount;若设备降级为 mono,以实际声道数驱动编码器 MediaFormat
        // 与所有 PCM 字节换算;编码器已创建时不重建,采集线程对 mono 样本做 mono→stereo 双声道复制
        // (每 sample 左右声道相同),编码器统一按 stereo 消费。AUDIO_CHANNEL_COUNT 表示期望的 stereo,
        // 实际字节换算一律用 actualAudioChannelCount 成员(=1 或 2),不再写死。
        private const val AUDIO_CHANNEL_COUNT = 2
        private const val AUDIO_BIT_RATE = 128_000
        private const val AUDIO_BUFFER_SIZE_MULTIPLIER = 4
        // v6.7.142(优化5·退避): 双录 DEAD_OBJECT 重建失败后的退避间隔。
        // 5s 一次重试,兼顾"路由恢复可自愈"与"避免每 tick 重建(最坏阻塞采集线程)"。
        private const val DUAL_AUDIO_REBUILD_RETRY_MS = 5000L
        private const val AUDIO_PCM_FORMAT = AudioFormat.ENCODING_PCM_16BIT
        // 内录 AudioPlaybackCapture 的 usage 集合。
        // 华为/部分厂商系统对 addMatchingUsage 的 AudioPolicy 注册数量有限制,
        // usage 越全越易触发 "could not register audio policy" 抛异常导致内录静音。
        // 提供从全量到最少量的降级阶梯,保证至少能录到 MEDIA 的系统音频。
        private val USAGE_SET_MEDIA_GAME_UNKNOWN: List<Int> =
            listOf(
                AudioAttributes.USAGE_MEDIA,
                AudioAttributes.USAGE_GAME,
                AudioAttributes.USAGE_UNKNOWN
            )
        private val USAGE_SET_MEDIA_GAME: List<Int> =
            listOf(
                AudioAttributes.USAGE_MEDIA,
                AudioAttributes.USAGE_GAME
            )
        private val USAGE_SET_MEDIA: List<Int> =
            listOf(AudioAttributes.USAGE_MEDIA)
        // 音频采集看门狗：无有效 PCM 数据超过该时长即注入静音帧,强制产出音频轨
        private const val AUDIO_SILENCE_TIMEOUT_MS = 500
        // 静音帧字节量:见实例字段 silenceFrameBytes(定义在实例字段区,依赖 actualAudioChannelCount)。
        // v6.7.44: sleep 时长由实例字段 silenceFrameSleepMs 动态计算,按 silenceFrameBytes 精确对齐
        // 1024 采样 @44.1kHz(23.2199ms),消除"sleep 23ms vs 实际 23.22ms"造成的 93s 累计 200ms+
        // PTS 漂移。原常量 23L 已删除,避免写死导致 sleep 偏快 PTS 慢于墙钟。
        // 注:PTS 已改用墙钟映射(calculateAudioPts),sleep 精度对 PTS 不再直接作用,但仍保留动态计算
        // 以保证字节吞吐 = 44100Hz * 声道数 * 2 的实时速率,避免采集端过慢导致真实数据到达时爆队列。

        // 自适应音频捕获策略:多级 retry 退避 + 动态调整
        // 策略等级:0=禁用(使用旧路径),1=保守(2+21ms),2=平衡(2+10+11ms),3=激进(2+10+10+1ms)
        private const val ADAPTIVE_STRATEGY_LEVEL = 3
        // 各等级对应的 retry 等待时间(ms),逐级累加至总时长不超过 silenceFrameSleepMs
        private val ADAPTIVE_RETRY_WAIT_MS = mapOf(
            1 to longArrayOf(2, 21),
            2 to longArrayOf(2, 10, 11),
            3 to longArrayOf(2, 10, 10, 1)
        )
        // 每次 retry 后 read(NON_BLOCKING),若任一级成功立即使用; 全部失败才走旧路径
        // 健康窗口计数:连续 N 个 healthy 窗口后降低 retry 等级; 连续 N 个 low-realtime 窗口后升高
        private const val ADAPTIVE_WINDOW_LOOKBACK = 6

        // v6.7.95: 移除未引用常量 MUXER_TIMEOUT_US / MAX_MUXER_RETRIES——源注释声称的
        // "muxer 重试循环"在当前代码里已不存在(混流失败走 muxerFailed 置位 + onError 快速收尾,
        // 无任何重试消费者)。
        private const val DEQUEUE_TIMEOUT_US = 10_000L
        private const val PENDING_FLUSH_WAIT_MS = 3000
        private const val EMERGENCY_DIR_NAME = "emergency_recordings"
        // 一个 AAC 音频帧的时长(微秒):1024 采样 @44.1kHz
        private const val AUDIO_FRAME_US = 1024L * 1_000_000L / AUDIO_SAMPLE_RATE

        fun listAllVideoEncoders(): List<String> {
            val encoders = mutableListOf<String>()
            val codecList = MediaCodecList(MediaCodecList.ALL_CODECS)
            for (codecInfo in codecList.codecInfos) {
                if (!codecInfo.isEncoder) continue
                val supportedTypes = codecInfo.supportedTypes
                if (supportedTypes.any { it.startsWith("video/") }) {
                    encoders.add(codecInfo.name)
                }
            }
            return encoders.distinct()
        }

        // —— 被杀死中断录制的发现与恢复 (v6.7.118~121) ——
        // v6.7.121: 检测前移到 MainActivity 横幅([继续]/[丢弃] 驱动),不再在 Service 自动处理。
        // [findStaleRecordings] 只"发现并列出"待处理的残留,修复/删除动作由用户显式选择,
        // 让"生成的视频要能播放"且用户可见(P0 修复由 Mp4Repairer 重建 moov 达成)。
        // P1-3: 递归扫描整个应用专属目录, 不再只扫 MOVIES 顶层, 覆盖自定义输出路径。
        // P1-1: 保留上限 KEEP_STALE, 更旧的连 .idx 删除; 目标已存在时先删再改, 免静默覆盖。
        // P1-2: 每步失败都写日志, 不再 catch 全咽(避免残留反复弹出提示)。
        // P1-4: performSafCopy 成功拷贝后写"已导出"标记, 命中标记的残留是被杀窗口里的
        //       SAF 已成功副本, 直接删除, 不在应用目录再留一份、也不误报未完成。
        // P2-1: 检测前按"最近 30s 内修改的 tmp"判活跃(替代旧 isRecordingActive 短路,
        //       后者在进程被杀后因 KEY_RECORDING_ACTIVE 残留 true 永远短路, 见 v6.7.133 注释)。
        private const val KEEP_STALE = 3
        // v6.7.133: 判定"正在写入"的 tmp 时间窗。最近 30s 内修改过的 .recording.tmp 视为活跃, 扫描跳过。
        private const val STALE_ACTIVE_WINDOW_MS = 30_000L
        private const val SAF_EXPORTED_KEY = "saf_exported_tmp_paths"

        // v6.7.140-补(必修3): 放开可见性,供 MainActivity 导出成功后打标记,
        // findStaleRecordings 的 exported .mp4 分支据此兜底清理本地副本。
        fun safExportedSet(context: Context, add: String? = null, remove: String? = null): MutableSet<String> {
            val prefs = context.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE)
            val cur = prefs.getStringSet(SAF_EXPORTED_KEY, emptySet())?.toMutableSet() ?: mutableSetOf()
            if (add != null) cur.add(add)
            if (remove != null) cur.remove(remove)
            prefs.edit().putStringSet(SAF_EXPORTED_KEY, cur).apply()
            return cur
        }

        /** v6.7.148 (FIX-2): 可播放探针——MediaExtractor 真正打开修复产物,确认
         * 视频轨 mime 与时长 >0 才判"可播放"。防止重建出结构合法但解码器不认的坏文件
         * 仍以 _restored 状态进历史(打不开)。返回 (playable, mime, durationUs)。
         */
        private fun probeRepairedMp4(f: File): Triple<Boolean, String, Long> {
            return try {
                val ex = android.media.MediaExtractor()
                ex.setDataSource(f.absolutePath)
                var mime = ""; var durUs = 0L; var hasVideo = false
                for (i in 0 until ex.trackCount) {
                    val fmt = ex.getTrackFormat(i)
                    val m = fmt.getString(android.media.MediaFormat.KEY_MIME) ?: ""
                    if (m.startsWith("video/")) {
                        mime = m; hasVideo = true
                        durUs = try { fmt.getLong(android.media.MediaFormat.KEY_DURATION) } catch (_: Exception) { 0L }
                        ex.selectTrack(i); break
                    }
                }
                ex.release()
                // v6.7.188f: 可播放 = 能解析且含 video 轨;时长0(个别设备/极短片段回读0)不再误杀。
                // 旧 `durUs > 0L` 会把合法短视频判不可播→产物被删→历史缺失。
                val ok = hasVideo
                if (!ok) android.util.Log.w(TAG, "probeRepairedMp4: no video track in ${f.name} mime=$mime")
                else if (durUs <= 0L) android.util.Log.i(TAG, "probeRepairedMp4: accept ${f.name} with durUs=0 (device quirk)")
                Triple(ok, mime, durUs)
            } catch (e: Exception) {
                android.util.Log.w(TAG, "probeRepairedMp4: parse failed ${f.name}: ${e.message}")
                Triple(false, "", 0L)
            }
        }

        /** v6.7.140 (BUG-F): 用标准 API 探测修复后文件的真实编码类型。 */
        private fun detectCodecName(f: File): String {
            return try {
                val ret = android.media.MediaMetadataRetriever()
                ret.setDataSource(f.absolutePath)
                val mime = ret.extractMetadata(
                    android.media.MediaMetadataRetriever.METADATA_KEY_MIMETYPE)
                ret.release()
                if (mime?.contains("hevc", true) == true ||
                    mime?.contains("h265", true) == true) "HEVC" else "AVC"
            } catch (_: Exception) { "AVC" }
        }

        // v6.7.188c: 纯只读孤儿清单——不合并、不修复、不删除、不改名。
        // 供主页徽标与 RepairActivity 列表使用；修复由用户手动触发。
        @JvmStatic
        fun scanOrphans(context: Context): List<OrphanInfo> {
            val out = ArrayList<OrphanInfo>()
            try {
                val base = context.getExternalFilesDir(null) ?: return out
                val exported = safExportedSet(context)
                val now = System.currentTimeMillis()
                // 30s 内仍在写的 tmp 视为活跃会话,不上报(与 findStale 同一判据)。
                base.walkTopDown().forEach { f ->
                    if (!f.isFile) return@forEach
                    if (f.name.endsWith(".recording.tmp") &&
                        f.absolutePath !in exported &&
                        (now - f.lastModified()) >= STALE_ACTIVE_WINDOW_MS) {
                        out.add(OrphanInfo(f.name, f.absolutePath, f.length(),
                            File(f.parentFile, f.name + ".idx").exists(),
                            false, 0, f.lastModified()))
                    }
                }
                // 分片目录形态:子目录里有 seg_*.mp4 或 seg_*.mp4.tmp 即上报,不合并。
                base.listFiles()?.filter { it.isDirectory }?.forEach { d ->
                    val segs = d.listFiles()?.filter {
                        it.isFile && it.name.matches(Regex("seg_\\d+\\.mp4(\\.tmp)?$"))
                    } ?: emptyList()
                    if (segs.isNotEmpty()) {
                        out.add(OrphanInfo(d.name, d.absolutePath,
                            segs.sumOf { it.length() }, false, true, segs.size,
                            segs.maxOf { it.lastModified() }))
                    }
                }
            } catch (_: Exception) {}
            out.sortByDescending { it.lastModified }
            return out.take(16)
        }

        /** v6.7.121: 发现待处理的中断残留(.recording.tmp)。开关关闭时静默删除全部并返回空。
         * v6.7.133: 修复前置短路缺陷——旧实现 `if (isRecordingActive) return emptyList()` 在进程被杀后
         * 因 KEY_RECORDING_ACTIVE 残留 true 而永远返回空(被杀后重启提示隔次才出现的根因)。
         * 现改为:仅当存在"最近 STALE_ACTIVE_WINDOW_MS 内修改的 .recording.tmp"(正在写入)才跳过,
         * 否则必须正常扫描。
         * v6.7.140 (必修2): 新增 skipActiveWindow 参数,冷启动/onResume 恢复路径传 true 跳过 30s
         * 窗口检查(此时 recordState==IDLE 且录制服务未运行,磁盘上不可能存在"正在写入的 tmp")。
         */
        @JvmStatic
        fun findStaleRecordings(context: Context, enabled: Boolean, skipActiveWindow: Boolean = false): List<File> {
            val exported = safExportedSet(context)
            // P1-4: 清理"已导出"标记中文件已不存在的条目(干净导出或已处理), 防集合膨胀。
            try {
                for (p in exported.filter { path -> !File(path).exists() }) safExportedSet(context, remove = p)
            } catch (_: Exception) {}
            val found = mutableListOf<File>()
            try {
                val base = context.getExternalFilesDir(null) ?: return found
                // v6.7.128: 先处理分片 manifest(多分片录制残留), 再处理旧式单文件残留。
                // v6.7.160 (修BUG-2): 接收合并产物并入恢复列表,供上层导出 SAF + 历史登记。
                found.addAll(recoverSegmentManifests(context, base, exported))
                // v6.7.133/v6.7.140: 先找"正在写入"的 tmp(30s 内修改), 有则跳过扫描, 避免把活跃 tmp 改名/删除。
                // skipActiveWindow=true 时跳过此检查,避免冷启动把残件误判为活跃 tmp。
                if (!skipActiveWindow) {
                    val activeTmp = base.walkTopDown().asSequence().firstOrNull { f ->
                        f.isFile && f.name.endsWith(".recording.tmp") &&
                            (System.currentTimeMillis() - f.lastModified()) < STALE_ACTIVE_WINDOW_MS
                    }
                    if (activeTmp != null) return found
                }
                base.walkTopDown().forEach { f ->
                    if (f.isFile && f.name.endsWith(".recording.tmp")) {
                        if (f.absolutePath in exported) {
                            // P1-4: SAF 已导出成功, 本地副本重复, 直接删(v6.7.134: 统一收口 safeDelete)。
                            if (!SafeDeleteUtil.delete(f, "findStale_exported_tmp")) {
                                android.util.Log.w(TAG, "findStale: delete failed for exported $f")
                            }
                            safExportedSet(context, remove = f.absolutePath)
                        } else {
                            found.add(f)
                        }
                    }
                }
                // v6.7.121+fix: 扫描 SAF 导出的 .mp4 文件并删除本地副本
                for (p in exported.filter { it.endsWith(".mp4") }) {
                    val mp4File = File(p)
                    if (mp4File.exists() && !SafeDeleteUtil.delete(mp4File, "findStale_exported_mp4")) {
                        android.util.Log.w(TAG, "findStale: delete failed for exported mp4 $p")
                    } else {
                        safExportedSet(context, remove = p)
                    }
                }
            } catch (e: Exception) {
                android.util.Log.w(TAG, "findStale scan error: ${e.message}", e)
            }
            found.sortByDescending { it.lastModified() }
            // P1-1: 只留最近 KEEP_STALE 个, 更旧的连 .idx 一起删。
            for (f in found.drop(KEEP_STALE)) deleteStale(f)
            val keep = found.take(KEEP_STALE).toMutableList()
            if (keep.isEmpty()) return keep
            if (!enabled) {
                // 开关关闭: 静默删除全部残留, 不打扰。若删除失败则保留以免数据丢失。
                val toDelete = mutableListOf<File>()
                for (f in keep) {
                    val idx = File(f.parentFile, f.name + ".idx")
                    val deleted = SafeDeleteUtil.delete(f, "findStale_disabled") &&
                        (if (idx.exists()) SafeDeleteUtil.delete(idx, "findStale_disabled_idx") else true)
                    if (deleted) {
                        toDelete.add(f)
                    } else {
                        android.util.Log.w(TAG, "findStale: failed to delete stale while disabled: $f")
                    }
                }
                android.util.Log.i(TAG, "findStale: resumeProtect off, deleted ${toDelete.size}/${keep.size} stale")
                keep.removeAll(toDelete)
                return keep
            }
            android.util.Log.i(TAG, "findStale: found ${keep.size} interrupted recording(s)")
            return keep
        }

        /** v6.7.128: 分片录制残留恢复。
         *  已封口分片(seg_N.mp4)保留磁盘(独立可播);当前 .tmp 片走 restoreStale 修复;
         *  manifest 处理后删除。不自动写历史(崩溃场景无 onStopped,由用户从文件浏览访问)。 */
        /** v6.7.128: 分片录制残留恢复。
         *  v6.7.160 (修BUG-2): 原实现只修复最后一个未封口分片、从不合并,
         *  单分片被杀(头 60s 内)时 manifest 未写出、findStaleRecordings 主循环只认 *.recording.tmp
         *  而伴生索引叫 seg_1.mp4.tmp.idx 文件名不匹配 -> restoreStale 找不到 .idx -> 残留 .idx 垃圾、
         *  拿不到合并产物。现与正常停止路径 mergeSegmentsToFinal 对齐:合并 + probe + 清理;
         *  合并失败降级为逐片改名可播 + 删 .idx。返回合并产物供上层导出/历史登记。 */
        private fun recoverSegmentManifests(context: Context, base: File, exported: MutableSet<String>): List<File> {
            val produced = mutableListOf<File>()
            try {
                val dirs = base.walkTopDown().filter { it.isDirectory }.toList()
                for (dir in dirs) {
                    val mf = manifestFileAt(dir.absolutePath)
                    val hasManifest = mf.exists()
                    val rec = if (hasManifest) parseManifest(dir) else ManifestRecord(emptyList(), false)
                    // 当前未封口片:seg_<n+1>.mp4.tmp(manifest 存在时)。
                    // v6.7.186 (fix): 原 orphanTmp 在无 manifest 时只回退找 seg_1.mp4.tmp,
                    // 封口分片已改名 seg_N.mp4(无 .tmp) -> pairs 为空 -> 跳过整目录 -> 残留 .idx。
                    // 已删除该回退,改由下方扫目录统一发现,不再需要此变量。
                    val currentTmp = segFileAt(dir.absolutePath, rec.segments.size + 1)
                    // 收集 (mp4, idx) 对:已封口分片 + 未封口 .tmp 片。
                    // v6.7.161 (修BUG-B): 按绝对路径去重,避免同一片被拼两次(样本翻倍)。
                    val pairMap = LinkedHashMap<String, Pair<File, File>>()
                    val addPair = { mp4: File ->
                        if (mp4.exists()) pairMap[mp4.absolutePath] = Pair(mp4, File(mp4.absolutePath + ".idx"))
                    }
                    for (seg in rec.segments) addPair(File(seg.path))
                    addPair(currentTmp)
                    if (!hasManifest && rec.segments.isEmpty()) {
                        // v6.7.186 (fix): manifest 丢失时扫目录补回所有 seg_*.mp4 / seg_*.mp4.tmp,
                        // 覆盖封口分片(无 .tmp)与未封口片两种形态,取代旧 orphanTmp 单点回退。
                        dir.listFiles()?.filter { f ->
                            f.isFile && f.name.matches(Regex("seg_\\d+\\.mp4(\\.tmp)?$"))
                        }?.sortedBy { it.name }?.forEach { addPair(it) }
                    }
                    val pairs = pairMap.values.toList().sortedBy { it.first.name } // mergeSegments 要求按 seq 升序
                    // v6.7.189 (P0-4): 恢复流程此前完全静默,崩溃录制丢了什么都无从查起。
                    // 各分支累加计数,收尾打 restore_stale_summary(成功/降级各一次)。
                    var mergedOk = 0
                    val keptList = mutableListOf<String>()
                    val droppedList = mutableListOf<String>()
                    var keptBytes = 0L
                    var droppedBytes = 0L
                    if (pairs.isEmpty()) {
                        // v6.7.186 (fix): 即便无分片可合并,也清掉本目录残留 .idx。
                        // .idx 是分段索引边车,绝不可播放;孤儿 idx(mp4 早被旧恢复误删)在此一并清扫。
                        dir.listFiles()?.filter { it.name.endsWith(".idx") }?.forEach {
                            SafeDeleteUtil.delete(it, "seg_recover_idx_sweep")
                        }
                        continue
                    }
                    // 最终产物名:沿用同目录 .recording.tmp 占位文件名;无占位则用目录时间戳。
                    val finalName = run {
                        val recTmp = dir.listFiles()?.firstOrNull { it.name.endsWith(".recording.tmp") }
                        val stem = recTmp?.name?.removeSuffix(".recording.tmp")
                            ?: "ScreenRecord_" + java.text.SimpleDateFormat("yyyyMMdd_HHmmss", java.util.Locale.US).format(java.util.Date(dir.lastModified()))
                        "$stem.mp4"
                    }
                    // v6.7.161 (修BUG-A/BUG-C): 单片且是未封口 .tmp 时走 restoreStale,不绕 mergeSegments。
                    // restoreStale 是久经验证的单文件修复路径(.idx 损坏时还有 NAL 扫描兜底),
                    // mergeSegments 适合多片合并;单片走它最稳,且避免合并失败进降级分支产出不可播 _interrupted。
                    if (pairs.size == 1 && pairs[0].first.name.endsWith(".tmp")) {
                        val out = try { restoreStale(context, pairs[0].first).playable } catch (_: Exception) { null }
                        if (out != null) {
                            val dst = File(dir.absolutePath, finalName)
                            SafeDeleteUtil.delete(dst, "seg_recover_single_dst", force = true)
                            produced.add(if (out.renameTo(dst)) dst else out)
                            SafeDeleteUtil.delete(mf, "seg_recover_manifest", force = true)
                            deleteRecordingTmpPlaceholder(dir)
                            android.util.Log.i(TAG, "segment recovery single -> ${dst.name}")
                            mergedOk = 1
                            keptBytes += File(dst.parentFile, dst.name).length()
                            DiagLog.log("restore_stale_summary " +
                                "dir=${dir.name} candidates=${pairs.size} merged=$mergedOk " +
                                    "kept=${keptList.size} dropped=${droppedList.size} " +
                                    "keptBytes=$keptBytes droppedBytes=$droppedBytes")
                            continue
                        }
                    }
                    val finalFile = File(dir.absolutePath, finalName)
                    SafeDeleteUtil.delete(finalFile, "seg_recover_dst_conflict", force = true)
                    val merged = try {
                        Mp4Repairer.mergeSegments(pairs.map { Pair(it.second, it.first) }, finalFile.absolutePath)
                    } catch (_: Exception) { null }
                    if (merged == null) {
                        // v6.7.161: mergeSegments 失败原无任何日志(catch 全咽 + return null),下次盲查。
                        android.util.Log.w(TAG, "segment mergeSegments returned null, pairs=${pairs.size} " +
                            pairs.joinToString { it.first.name })
                    }
                    val ok = merged != null && probeRepairedMp4(merged).first
                    if (ok && merged != null) {
                        // 合并成功且可播:删所有分片/.idx/manifest/占位,产物进入恢复列表。
                        for ((mp4, idx) in pairs) {
                            droppedBytes += mp4.length()
                            SafeDeleteUtil.delete(mp4, "seg_recover_mp4")
                            SafeDeleteUtil.delete(idx, "seg_recover_idx")
                        }
                        SafeDeleteUtil.delete(mf, "seg_recover_manifest", force = true)
                        deleteRecordingTmpPlaceholder(dir)
                        produced.add(finalFile)
                        mergedOk = 1
                        keptBytes = finalFile.length()
                        android.util.Log.i(TAG, "segment recovery merged ${pairs.size} arcs -> ${finalFile.name}")
                        DiagLog.log("restore_stale_summary " +
                            "dir=${dir.name} candidates=${pairs.size} merged=$mergedOk " +
                                "kept=${keptList.size} dropped=${droppedList.size} " +
                                "keptBytes=$keptBytes droppedBytes=$droppedBytes")
                    } else {
                        // 降级:逐片改名可播 + 删 .idx,绝不残留 .idx 垃圾。
                        // v6.7.161 (修BUG-A): 未封口片必须先调 restoreStale(它依赖 .idx 重建 moov,
                        // 内部会自行删除 .idx),绝不可提前删 idx,否则必然退化为不可播的 _interrupted.mp4。
                        // 已封口片 muxer 已 stop,本就独立可播:删 idx + 改干净名。
                        for ((mp4, idx) in pairs) {
                            if (mp4.name.endsWith(".tmp")) {
                                try { restoreStale(context, mp4) } catch (_: Exception) {}
                                SafeDeleteUtil.delete(idx, "seg_recover_fb_idx_leftover")  // 兜底:restoreStale 没清干净
                                // restoreStale 成功改名 .mp4 / 失败保留 _interrupted,均算 kept
                                keptList.add(mp4.name)
                            } else {
                                SafeDeleteUtil.delete(idx, "seg_recover_fb_idx")
                                val clean = File(mp4.parentFile, finalName.removeSuffix(".mp4") + "_seg${mp4.name}.mp4")
                                if (mp4.renameTo(clean)) {
                                    android.util.Log.i(TAG, "segment kept as ${clean.name}")
                                    keptList.add(clean.name)
                                    keptBytes += clean.length()
                                } else {
                                    droppedList.add(mp4.name)
                                    droppedBytes += mp4.length()
                                }
                            }
                        }
                        SafeDeleteUtil.delete(mf, "seg_recover_manifest_fb", force = true)
                        deleteRecordingTmpPlaceholder(dir)
                        android.util.Log.w(TAG, "segment recovery merge failed, kept fragments dir=${dir.absolutePath}")
                        DiagLog.log("restore_stale_summary " +
                            "dir=${dir.name} candidates=${pairs.size} merged=$mergedOk " +
                                "kept=${keptList.size} dropped=${droppedList.size} " +
                                "keptBytes=$keptBytes droppedBytes=$droppedBytes")
                    }
                    // v6.7.186 (fix): 合并/降级块统一收尾清扫。上方两分支只删"本次 pairs 配对到的 .idx",
                    // 目录内其它孤儿 .idx(非本次配对、或合并异常未遍历到)会残留。.idx 绝不可播放,
                    // 任何残留都是垃圾;此处覆盖 合并异常/部分失败/孤儿 idx 三种漏清路径。
                    dir.listFiles()?.filter { it.name.endsWith(".idx") }?.forEach {
                        SafeDeleteUtil.delete(it, "seg_recover_idx_sweep")
                    }
                }
            } catch (e: Exception) {
                android.util.Log.w(TAG, "segment manifest recovery error: ${e.message}")
            }
            return produced
        }

        // v6.7.160 (修BUG-2): 删除分片目录内的 .recording.tmp 占位。
        // 分段模式下该文件只是占位(无真实数据、无 .idx),删之让 findStaleRecordings 主循环
        // 不再把它误判成待恢复文件。非分段模式(只有一个 .recording.tmp 带真实 .idx)不被此函数触碰。
        private fun deleteRecordingTmpPlaceholder(dir: File) {
            try {
                dir.listFiles()?.filter { it.name.endsWith(".recording.tmp") }?.forEach {
                    SafeDeleteUtil.delete(it, "seg_recover_rectmp", force = true)
                }
            } catch (_: Exception) {}
        }

        /** v6.7.121: [继续]——用伴生 .idx 重建 moov 为可播放 mp4; 失败改名 *_interrupted.mp4 保留。 */
        data class RestoreOutcome(
            val playable: File?, val durationMs: Long, val width: Int, val height: Int,
            val codecName: String = "AVC"
        )

        @JvmStatic
        fun restoreStale(context: Context, f: File): RestoreOutcome {
            val idxFile = File(f.parentFile, f.name + ".idx")
            val base = f.name.removeSuffix(".recording.tmp")
            val repaired = File(f.absolutePath + ".repaired")
            var dur = 0L; var w = 0; var h = 0
            if (idxFile.exists()) {
                // 路径一: .idx 完整(含样本)→ 依索引重建。
                try {
                    val r = Mp4Repairer.repair(f.absolutePath, idxFile)
                    if (r.ok && r.repaired && repaired.exists()) {
                        try {
                            val spec = Mp4Repairer.readIndex(idxFile)
                            dur = spec.samples.lastOrNull()?.ptsUs?.div(1000L) ?: 0L
                            w = spec.width; h = spec.height
                        } catch (_: Exception) {}
                    } else {
                        // v6.7.122: .idx 因杀进程未落盘样本/损坏而不可用 → 用它头部参数 NAL 扫描重建。
                        SafeDeleteUtil.delete(repaired, "restoreStale_repaired_retry")
                        val s = Mp4Repairer.repairByScan(f.absolutePath, idxFile)
                        if (s.ok && s.repaired && repaired.exists()) {
                            android.util.Log.i(TAG, "restoreStale: NAL-scan repaired ${f.name}")
                        }
                    }
                } catch (e: Exception) {
                    android.util.Log.w(TAG, "restoreStale idx repair failed: ${e.message}", e)
                }
                if (repaired.exists()) {
                    // v6.7.148 (FIX-2): 可播放探针通过才收为 _restored; 否则(结构合法但解码不认/
                    // 损坏)删掉 repaired, 落回下方 _interrupted 保留分支, 历史不出现打不开的条目。
                    val (playable2, mime2, durUs2) = probeRepairedMp4(repaired)
                    if (playable2) {
                        try {
                            val spec = Mp4Repairer.readIndexHeader(idxFile)
                            w = spec.width; h = spec.height
                            // 时长探针读取优先(真实值), 若无 fallback 到样本近似。
                            dur = if (durUs2 > 0L) durUs2 / 1000L
                                  else {
                                      try {
                                          val s2 = Mp4Repairer.readIndex(idxFile)
                                          s2.samples.lastOrNull()?.ptsUs?.div(1000L) ?: 0L
                                      } catch (_: Exception) { 0L }
                                  }
                            if (dur <= 0L) {
                                val n = Mp4Repairer.lastScanSampleCount
                                if (n >= 0) dur = n * 1_000L / spec.fps.coerceAtLeast(1)
                            }
                        } catch (_: Exception) {}
                        val newName = "$base" + "_restored.mp4"
                        val dest = File(f.parentFile, newName)
                        // P1-1: 目标已存在则先删, 免静默覆盖旧恢复产物。dest 是 _restored.mp4(保护项),
                        // 此处为恢复流程内部的产物替换,业务已确认可删,显式 force。
                        SafeDeleteUtil.delete(dest, "restoreStale_dest_conflict", force = true)
                        if (repaired.renameTo(dest)) {
                            SafeDeleteUtil.delete(f, "restoreStale_tmp")
                            SafeDeleteUtil.delete(idxFile, "restoreStale_idx")
                            android.util.Log.i(TAG, "restoreStale: repaired -> $newName (${dur}ms ${w}x$h)")
                            val codec = if (mime2.contains("hevc", true)) "HEVC"
                                        else if (mime2.contains("avc", true)) "AVC"
                                        else detectCodecName(dest)
                            return RestoreOutcome(dest, dur, w, h, codec)
                        } else {
                            android.util.Log.w(TAG, "restoreStale: rename $repaired -> $dest failed")
                        }
                    } else {
                        // v6.7.188f: 探针失败不再静默删除用户数据。改名 _interrupted.mp4 保留,
                        // 用户至少能用系统播放器试播;scanOrphans/findStaleRecordings 只认
                        // .recording.tmp/分片目录,不会重复扫描误删。
                        val interrupted = File(f.parentFile, base + "_interrupted.mp4")
                        SafeDeleteUtil.delete(interrupted, "restoreStale_interrupted_conflict", force = true)
                        val kept = if (repaired.renameTo(interrupted)) interrupted else repaired
                        android.util.Log.w(TAG,
                            "restoreStale: probe failed, kept as ${kept.name} (old moov strip may be needed) ${f.name}")
                    }
                }
            } else {
                // v6.7.160 (修BUG-2): 文件已是 .mp4 且无 .idx——这是 recoverSegmentManifests
                // 合并产出的最终 mp4(已含合法 moov,可直接播放),不是待修复的 .tmp。
                // 直接 probe 当可播产物返回,不重命名 _interrupted,避免误把可播合并产物标损坏丢历史。
                if (f.name.endsWith(".mp4")) {
                    val (playable, mime, durUs) = probeRepairedMp4(f)
                    if (playable) {
                        // v6.7.160: 宽高从视频轨 MediaFormat 取(METADATA_KEY_WIDTH 在部分版本不可用)。
                        val wh = run {
                            var w = 0; var h = 0
                            try {
                                val ex = android.media.MediaExtractor()
                                ex.setDataSource(f.absolutePath)
                                for (i in 0 until ex.trackCount) {
                                    val fmt = ex.getTrackFormat(i)
                                    val m = fmt.getString(android.media.MediaFormat.KEY_MIME) ?: ""
                                    if (m.startsWith("video/")) {
                                        w = try { fmt.getInteger(android.media.MediaFormat.KEY_WIDTH) } catch (_: Exception) { 0 }
                                        h = try { fmt.getInteger(android.media.MediaFormat.KEY_HEIGHT) } catch (_: Exception) { 0 }
                                        break
                                    }
                                }
                                ex.release()
                            } catch (_: Exception) {}
                            Pair(w, h)
                        }
                        android.util.Log.i(TAG, "restoreStale: merged mp4 ready ${f.name} dur=${durUs/1000L}ms ${wh.first}x${wh.second}")
                        val codec = if (mime.contains("hevc", true)) "HEVC"
                                    else if (mime.contains("avc", true)) "AVC"
                                    else detectCodecName(f)
                        return RestoreOutcome(f, durUs / 1000L, wh.first, wh.second, codec)
                    }
                    android.util.Log.w(TAG, "restoreStale: merged mp4 probe failed for ${f.name}, keep as is")
                } else {
                    android.util.Log.w(TAG, "restoreStale: no .idx for ${f.name}, cannot rebuild moov")
                }
            }
            // 修复失败: 保留为 *_interrupted.mp4(可修复入口), 并写日志供排查。
            try {
                val newName = "$base" + "_interrupted.mp4"
                val dest = File(f.parentFile, newName)
                SafeDeleteUtil.delete(dest, "restoreStale_interrupted_conflict", force = true)
                if (f.renameTo(dest)) {
                    // v6.7.189 (P0-4): 绝不删除 .idx。它是唯一能重建 moov 的数据,
                    // 删掉 = 永久放弃这段录制。改名跟随 mp4,保证 RepairActivity 能按
                    // "<同名>.idx" 找到配对,用户后续可再点「修复」。
                    var idxKept = false
                    if (idxFile.exists()) {
                        val idxDest = File(dest.parentFile, dest.name + ".idx")
                        SafeDeleteUtil.delete(idxDest, "restoreStale_idx_dest_conflict", force = true)
                        idxKept = idxFile.renameTo(idxDest)
                    }
                    android.util.Log.w(TAG,
                        "restoreStale: keep as $newName (unrepairable now) idxKept=$idxKept")
                    DiagLog.log("restore_stale_keep " +
                        "name=$newName bytes=${dest.length()} idxKept=$idxKept")
                } else {
                    android.util.Log.w(TAG, "restoreStale: failed to rename ${f.name}")
                }
            } catch (e: Exception) {
                android.util.Log.w(TAG, "restoreStale preserve error: ${e.message}", e)
            }
            return RestoreOutcome(null, 0, 0, 0)
        }

        /** v6.7.121: [丢弃]——删除残留及其伴生 .idx。 */
        @JvmStatic
        fun discardStale(f: File) {
            if (!SafeDeleteUtil.delete(f, "discardStale")) {
                android.util.Log.w(TAG, "discardStale: failed to delete ${f.absolutePath}")
            }
            try {
                val idxFile = File(f.parentFile, f.name + ".idx")
                if (idxFile.exists() && !SafeDeleteUtil.delete(idxFile, "discardStale_idx"))
                    android.util.Log.w(TAG, "discardStale: failed to delete $idxFile")
            } catch (_: Exception) {}
        }

        private fun deleteStale(f: File) {
            try {
                if (f.exists() && !SafeDeleteUtil.delete(f, "deleteStale"))
                    android.util.Log.w(TAG, "deleteStale: failed ${f.absolutePath}")
            } catch (e: Exception) { android.util.Log.w(TAG, "deleteStale: ${e.message}", e) }
            try {
                val idx = File(f.parentFile, f.name + ".idx")
                if (idx.exists() && !SafeDeleteUtil.delete(idx, "deleteStale_idx"))
                    android.util.Log.w(TAG, "deleteStale: failed idx $idx")
            } catch (_: Exception) {}
        }

        /** v6.7.121: 清理超龄 emergency 日志(>3 个)。由 Service 启动时后台执行。 */
        @JvmStatic
        fun cleanEmergencyLogs(context: Context) {
            try {
                val baseDir = recBaseDir(context) ?: return
                val emergencyDir = File(baseDir, EMERGENCY_DIR_NAME)
                if (!emergencyDir.exists()) return
                val files = emergencyDir.listFiles { _, n -> n.endsWith(".log") } ?: return
                if (files.size > 3) {
                    files.sortedByDescending { it.lastModified() }.drop(3).forEach {
                        try { it.delete() } catch (_: Exception) {}
                    }
                }
            } catch (e: Exception) {
                android.util.Log.w(TAG, "cleanEmergencyLogs: ${e.message}", e)
            }
        }

        private fun recBaseDir(context: Context): File? {
            return try {
                context.getExternalFilesDir(Environment.DIRECTORY_MOVIES)?.parentFile
                    ?: context.getExternalFilesDir(null)
            } catch (_: Exception) { null }
        }

        // —— v6.7.128: manifest 读写(静态工具,不动录制热路径) ——
        // 分片文件命名:seg_<seq>.mp4.tmp(写入) -> seg_<seq>.mp4(封口)。伴生 .idx 与分片同名。
        fun segFileName(seq: Int): String = "${SEG_PREFIX}$seq.mp4.tmp"
        fun segFinalName(seq: Int): String = "${SEG_PREFIX}$seq.mp4"
        fun segFileAt(baseDir: String, seq: Int): File = File(baseDir, segFileName(seq))
        fun segFinalFileAt(baseDir: String, seq: Int): File = File(baseDir, segFinalName(seq))
        fun manifestFileAt(baseDir: String): File = File(baseDir, MANIFEST_NAME)

        // 写一行分片记录并 fsync(复用 126 周期 fsync 经验,确保被杀不丢已封口分片)。
        fun appendManifestLine(dir: File, seq: Int, durationMs: Long, bytes: Long, width: Int, height: Int) {
            try {
                val f = manifestFileAt(dir.absolutePath)
                val out = java.io.FileOutputStream(f, true)
                try {
                    if (!f.exists() || f.length() == 0L) {
                        out.write(MANIFEST_HEADER.toByteArray(Charsets.UTF_8))
                        out.write(0x0A)
                    }
                    val line = "${segFinalName(seq)} $durationMs $bytes $width $height\n"
                    out.write(line.toByteArray(Charsets.UTF_8))
                    out.flush()
                    out.fd.sync()
                } finally {
                    out.close()
                }
            } catch (e: Exception) {
                android.util.Log.w(TAG, "manifest append failed: ${e.message}")
            }
        }

        // 正常收尾写 FINAL 标记行(fsync)。有 FINAL 表示本次录制已完整收尾。
        fun writeManifestFinal(dir: File) {
            try {
                val f = manifestFileAt(dir.absolutePath)
                val out = java.io.FileOutputStream(f, true)
                try {
                    out.write("FINAL\n".toByteArray(Charsets.UTF_8))
                    out.flush()
                    out.fd.sync()
                } finally {
                    out.close()
                }
            } catch (e: Exception) {
                android.util.Log.w(TAG, "manifest FINAL write failed: ${e.message}")
            }
        }

        // 解析 manifest:返回 (分片清单, 是否有 FINAL 标记)。供恢复逻辑使用。
        data class ManifestRecord(val segments: List<SegmentInfo>, val finalized: Boolean)

        fun parseManifest(dir: File): ManifestRecord {
            val f = manifestFileAt(dir.absolutePath)
            if (!f.exists()) return ManifestRecord(emptyList(), false)
            val segs = mutableListOf<SegmentInfo>()
            var finalFlag = false
            try {
                f.forEachLine { line ->
                    val t = line.trim()
                    if (t.isEmpty() || t.startsWith("#")) return@forEachLine
                    if (t == "FINAL") { finalFlag = true; return@forEachLine }
                    // seg_1.mp4 60000 131072000 1920 1080
                    val parts = t.split(" ")
                    if (parts.size == 5 && parts[0].startsWith(SEG_PREFIX)) {
                        try {
                            segs.add(SegmentInfo(
                                seq = parts[0].removePrefix(SEG_PREFIX).removeSuffix(".mp4").toInt(),
                                path = File(dir.absolutePath, parts[0]).absolutePath,
                                durationMs = parts[1].toLong(),
                                bytes = parts[2].toLong(),
                                width = parts[3].toInt(),
                                height = parts[4].toInt(),
                            ))
                        } catch (_: Exception) {}
                    }
                }
            } catch (e: Exception) {
                android.util.Log.w(TAG, "manifest parse failed: ${e.message}")
            }
            return ManifestRecord(segs, finalFlag)
        }

        // v6.7.140: 静态 SAF 导出入口,供 restoreStale 路径复用。
        // 独立于实例的 safCopyToTree(后者依赖 this.context),此处入参 context/resolver 解耦。
        // 拷贝成功返回 document URI,失败返回 null;调用方可据此决定是否保留本地副本。
        @JvmStatic
        fun exportFileToSaf(context: Context, src: File, treeUri: Uri, fileName: String): Uri? {
            val resolver = context.contentResolver
            val srcLen = try { src.length() } catch (_: Exception) { -1L }
            if (srcLen <= 0L) {
                android.util.Log.w(TAG, "exportFileToSaf: source empty or stat failed src=${src.absolutePath}")
                return null
            }
            val treeDocUri = try {
                DocumentsContract.buildDocumentUriUsingTree(treeUri, DocumentsContract.getTreeDocumentId(treeUri))
            } catch (e: Exception) {
                android.util.Log.w(TAG, "exportFileToSaf: invalid treeUri $treeUri err=${e.message}")
                return null
            }
            return try {
                val createdUri = DocumentsContract.createDocument(resolver, treeDocUri, "video/mp4", fileName)
                    ?: run { android.util.Log.w(TAG, "exportFileToSaf: createDocument returned null for $fileName"); null }
                    ?: return null
                val out = resolver.openOutputStream(createdUri, "w")
                    ?: run { android.util.Log.w(TAG, "exportFileToSaf: openOutputStream null for $createdUri"); null }
                    ?: return null
                val copied = out.use { o -> FileInputStream(src).use { input -> input.copyTo(o, 1 shl 20) } }
                if (copied != srcLen) {
                    try { DocumentsContract.deleteDocument(resolver, createdUri) } catch (_: Exception) {}
                    android.util.Log.w(TAG, "exportFileToSaf: size mismatch copied=$copied src=$srcLen")
                    null
                } else {
                    android.util.Log.i(TAG, "exportFileToSaf: success -> $createdUri bytes=$copied")
                    createdUri
                }
            } catch (e: Exception) {
                android.util.Log.w(TAG, "exportFileToSaf: error=${e.message}", e)
                null
            }
        }
    }

    // 静音帧字节量:一个 AAC 帧的 PCM 量(1024 采样 @44.1kHz),字节随实际声道数伸缩,
    // 不再写死 1 或 2。内部音频无流时按实时速率注入,保证音频轨持续推进,不与视频 PTS 脱节。
    // 作为实例字段直接依赖 actualAudioChannelCount,保证编译期即绑定到实例声道配置。
    private val silenceFrameBytes: Int
        get() = 1024 * actualAudioChannelCount * 2

    // v6.7.44: 静音帧 sleep 时长精确到整数毫秒下取,避免 23ms vs 23.2199ms 累计漂移。
    // 44100Hz * 1024 采样 = 每块 23.2199ms,向下取 23ms 会每块慢 0.22ms,93s 累计 ~880ms。
    // 修正:按 1024/44100 精确换算,并用 (sleep * blockRate) 累计补偿剩余。这里简化为
    // "sleep 24ms 但注入量减为 1031 采样" 的补偿方案实现复杂,直接采用 23ms 但同步将
    // PTS 改用墙钟(见 PTS 修改),彻底切断 sleep 精度对 PTS 的影响。保留字段供诊断日志。
    val silenceFrameSleepMs: Long
        get() = (1024L * 1000L / AUDIO_SAMPLE_RATE.toLong())

    @Volatile
    var logSink: ((String) -> Unit)? = null

    @Volatile
    var callback: RecorderEngineCallback? = null

    data class RecorderConfig(
        val width: Int = 0,
        val height: Int = 0,
        val fps: Int = DEFAULT_FPS,
        val bitrate: Int = DEFAULT_BITRATE,
        val useAudio: Boolean = true,
        val useInternalAudio: Boolean = true,
        val useMicAudio: Boolean = false,
        val useHevc: Boolean = false,
        val outputFilePath: String = "",
        val densityDpi: Int = 320,
        val orientation: Int = 0,
        val recLimitBytes: Long = 0L,          // v6.7.177: 全局字节限额,0=不限
        val recLimitDurationMs: Long = 0L      // v6.7.177: 全局时长限额,0=不限
    )

    data class EncoderCandidate(
        val codecInfo: MediaCodecInfo,
        val name: String,
        val isHardware: Boolean,
        val isVendor: Boolean,
        val isHevc: Boolean,
        val score: Int
    )

    // v6.7.43: AudioRecord 构建成功后由 setupInternalAudioCapture / setupMicAudioCapture 写入,
    // 等于 record.channelCount 实际值(1 mono 或 2 stereo);编码器与所有 PCM 字节换算一律取该值。
    @Volatile
    private var actualAudioChannelCount = 2
    private var config: RecorderConfig? = null
    private var mediaProjection: MediaProjection? = null
    private var virtualDisplay: VirtualDisplay? = null
    // v6.7.177 (增量A): 全局限额收尾。autoStopReason 由写路径(限额/VD断开)置位,
    // stopAsync 在幂等守卫后取它作为最终停止原因;limitCheckLastMs 1s 节流,
    // autoStopScheduled 保证回退 post 只调度一次。
    @Volatile private var autoStopReason: String? = null
    private var limitCheckLastMs = 0L
    private val autoStopScheduled = java.util.concurrent.atomic.AtomicBoolean(false)
    private var videoEncoder: MediaCodec? = null
    private var audioEncoder: MediaCodec? = null
    private var audioRecord: AudioRecord? = null
    @Volatile
    private var micAudioRecord: AudioRecord? = null
    private var micFallbackAttempted = false
    // v6.7.50: 内录 AudioRecordingCallback 的执行器,需要保存引用并在释放时 shutdown,
    // 否则每次录制新建单线程 executor 从不关闭,长期录制会持续累积线程泄漏。
    private var internalAudioExecutor: java.util.concurrent.ExecutorService? = null
    var foregroundMicCallback: (() -> Unit)? = null
    private var mediaMuxer: MediaMuxer? = null
    private var inputSurface: Surface? = null

    private val isRunning = AtomicBoolean(false)
    private val isPaused = AtomicBoolean(false)
    private val forceStop = AtomicBoolean(false)
    private val encoderReady = AtomicBoolean(false)
    private val muxerStarted = AtomicBoolean(false)
    // MediaMuxer 非线程安全,视频回调线程与音频 drain 线程并发写会破坏 MP4 时间轴。
    // 所有 start/writeSampleData/addTrack/stop/release 访问统一加锁串行化。
    private val muxerLock = Any()

    private var videoDrainDone = java.util.concurrent.CountDownLatch(1)
    private var audioDrainDone = java.util.concurrent.CountDownLatch(1)
    private var audioTrackWaitStartNs = 0L
    private val AUDIO_TRACK_TIMEOUT_NS = 8_000_000_000L
    private val stopCompleted = AtomicBoolean(false)

    @Volatile
    private var videoTrackIndex = -1
    @Volatile
    private var audioTrackIndex = -1
    @Volatile
    private var audioTrackFailed = false
    private var videoEncoderName = ""
    private var audioEncoderName = ""

    private var encodeThread: HandlerThread? = null
    private var encodeHandler: Handler? = null
    private var audioThread: HandlerThread? = null
    private var audioCaptureHandler: Handler? = null
    private var audioEncodeThread: HandlerThread? = null
    private var audioEncodeHandler: Handler? = null
    private var audioDrainThread: Thread? = null
    @Volatile private var audioDrainRunning = false

    private var outputFile: File? = null
    private var outputFilePath = ""
    private var safOutputUri: Uri? = null
    private var safTargetFileName = ""
    // v6.7.97 (改进1): 录制结束后 renameToFinal 成功时的最终 URI(仅 SAF 路径有效)。
    // 用于 stop/forceStop/stopAsync 回调 onStopped 时把历史指向真实 .mp4 document URI,
    // 而非录制中的 .recording.tmp URI。null 表示未走 SAF 或改名失败。
    private var finalSafUri: Uri? = null
    // v6.7.106 (修复): performSafCopy 创建出的目的文件 document URI。safOutputUri 存的是
    // tree(目录) URI,DocumentsContract.renameDocument 只接受 document URI,传给 tree URI 会抛
    // "Invalid URI" 导致 rename_final 保留 .recording.tmp、历史恒指向 tmp 产物("录制历史显示异常")。
    // 本字段记录 createDocument 返回的真实 document URI,renameToFinal 据此改名。
    private var safDocumentUri: Uri? = null
    private var lastFreeBytes = -1L

    @Volatile
    private var startTimeNs = 0L
    // v6.7.95: 移除未引用字段 videoStartTimeUs / audioStartTimeUs(仅声明处出现)。
    @Volatile
    private var firstVideoFrameTimeUs = -1L
    // 差异A: 视频 PTS 首帧归零基准(信任编码器输出时间戳)
    private var videoFirstPtsUs = -1L
    private val firstAudioFrameTimeUs = AtomicLong(-1L)
    // v6.7.124 (Bug1 修复): encoder-input 侧音频 PTS 归零基准。须与 drain-output 侧共用字段
    // firstAudioFrameTimeUs 分离——input 侧写的是带 avDiff 的采样锚定绝对值,drain 侧写的是
    // 0 基锚定值,坐标系不同,共用时两线程竞争谁先 set,致 duration_calc 音视频时长错乱。
    // 本字段只在 encoder-input 侧读写(主音频 encode、backlog/final flush),不影响 muxer PTS。
    private val firstInputAudioPtsUs = AtomicLong(-1L)
    @Volatile
    private var lastVideoFrameTimeUs = 0L
    @Volatile
    private var lastAudioFrameTimeUs = 0L

    // 对齐 AZ 6.9.10 m0(): 写 muxer 的音频 PTS 单调钳制。
    // 记录上一次实际写入 muxer 的音频 PTS,每条写入前 pts = max(lastMuxAudioPtsUs + 1000, curPts),
    // 令 muxer 音频时间轴严格单调且相邻帧最小间隔 1ms,消除写入序列中的 PTS 回退/过近帧。
    private var lastMuxAudioPtsUs = -1L

    // v6.7.171 (P0): 录制起点单调时钟。音视频 PTS 全部引用同一个 recordingT0Us,
    // 不再各自维护 anchor,从根上消除两套时钟发散。约束6:只用 SystemClock.elapsedRealtime()
    // (单调,不跳变),严禁 System.currentTimeMillis()(墙钟会跳变)算任何 PTS。
    // 约束1:不丢帧——v6.7.157 已证明删 P 帧破坏参考链致花屏,统一时钟是正解。
    // 原 v6.7.170 audioDrainAnchorWallNs 仅锚定音频、未管视频,且用 System.nanoTime 而非
    // elapsedRealtime;120Hz 屏上音视频仍发散到成片 208ms 超阈。改为起点统一锚定。
    private var recordingT0Us: Long = -1L

    // v6.7.169 (P1 方案B): 有效采集帧率=显示刷新率。AZ 架构下 Surface 按设备刷新率投帧,
    // 编码器照单全收(本机 60Hz 即 ~60fps),配置 fps 仅作码率 hint 不限流。
    // 码率预算与 learn 基数改用此值而非配置帧率,使码率与真实帧数匹配。
    private var effectiveCaptureFps: Float = 0f

    // v6.7.62: 写 muxer 的视频 PTS 单调钳制(同音频)。见 handleVideoOutput 4347-4377。
    // 每条写入前 pts = max(lastMuxVideoPtsUs + VIDEO_PTS_MIN_TICK_US, curPts),
    // 保证视频轨 PTS 严格单调递增(MediaMuxer 要求),消除编码器输出时间戳回退/相等导致的抖动。
    private var lastMuxVideoPtsUs = -1L

    // 视频 PTS 采用"信任编码器输出渲染时间戳 + 首帧归零 + 单调钳制"(见 handleVideoOutput,
    // 对齐 AZ Lfg/h$a)。此处注释已过时:不再完全自算视频 PTS。videoFrameSeq 现仅用于
    // 帧率/诊断统计,不再作为视频 PTS 来源。audioPtsAccumulatorUs 供诊断。
    @Volatile private var videoFrameSeq = 0L

    private var framePtsCounter = 0L
    private var ptsIntervalSum = 0L
    private var ptsIntervalMin = Long.MAX_VALUE
    private var ptsIntervalMax = Long.MIN_VALUE
    private var ptsCount = 0L
    private val healthWindowSumUs = AtomicLong(0L)
    private val healthWindowCount = AtomicLong(0L)
    // 帧率健康诊断(仅打日志,不降级):checkFrameRateHealth 中重置稳定计数


    @Volatile private var currentFps = DEFAULT_FPS
    @Volatile private var currentBitrate = DEFAULT_BITRATE
    @Volatile private var targetFps = DEFAULT_FPS
    @Volatile private var targetBitrate = DEFAULT_BITRATE
// 降档一二(runtime 热降档):电量<20% 或 温度>45°C 进入降档态。
    // 一级降码率每 5s 渐进一档 20%,回弹渐升;二级丢帧见 FRAME_DROPPED_MAP。
    @Volatile private var downgradeActive = false
    private var lastBitrateStepMs = 0L
    private var lastDowngradeCheckMs = 0L
    // v6.7.140 (方案2): 最近窗口实测帧率，供 maybeStepDowngrade 判断掉帧触发降档。
    private var runtimeDropWindowFps = 0
    // v6.7.190 (P0-3): 连续可信掉帧窗口计数。单窗口 <70% 目标不再直接定罪,
    // 必须连续 3 个 >=800ms 的可信窗口都低于 70% 才判定为性能掉帧(见 frameDrop)。
    private var frameDropWindowStreak = 0
    // v6.7.140-补(方案2): 滑动窗口采样点(上一次 reportProgress 的帧序与墙钟)。
    private var lastDropWindowSeq = 0L
    private var lastDropWindowWallMs = 0L
    // v6.7.142(优化5·退避): 双录两轨各自的 DEAD_OBJECT 退避截止时刻(elapsedRealtime)。
    // 重建失败时记此时刻,退避期内跳过 read(该轨静音,健康轨继续);到期再重试,路由恢复后可自愈。
    private var internalTrackRetryAfterMs = 0L
    private var micTrackRetryAfterMs = 0L
    // v6.7.140 (方案3): 录制停止原因，供结构化报告使用。
    private var finalStopReason: String = "normal"
    // 用户设定码率快照(启动时锁定,降档 floor 与回弹目标都以它为基准,防静默吞用户配置)
    private var userBitrate = DEFAULT_BITRATE
    // 失败锁死:回弹后 30s 内再次触发降档 → 本次录制锁死降档档位、不再回弹(防震荡最终兜底)
    private var downgradeLatched = false
    private var lastRampUpAtMs = 0L
    // 回升稳定观察期:温度<40 且电量>30 须持续 10s 才回弹(防阈值边缘抖动反复横跳)
    private var recoverCandidateStartMs = 0L
    // v6.7.157 (P0-1): 删帧逻辑已移除,count 仅作 AV 漂移容忍日志计数。
    private var avSyncDropCount = 0
    // v6.7.149 (FIX-C): AV 漂移修正——视频轨 PTS 大幅领先音频(av_pts_delta 恒正且超阈值)时置位,
    // 由视频写入路径丢帧,让已写视频时间轴放慢、把领先拉回音频 master。音频领先(负漂移)不处理
    // (音频为生成/静音填充,负漂移本来就是等音频的视频落后,无害)。带滞回避免阈值边缘抖抖。
    // v6.7.157 (P0-1): 已不再删帧,avSyncDropActive 仅作容忍日志开关(留置位/复位,见 5866+)。
    @Volatile private var avSyncDropActive = false
    // v6.7.128: 降档元数据(历史条目用)——首次降档时刻/最终档位/是否锁死
    @Volatile private var downgradeFirstAtMs = 0L  // 首次触发降档的录制相对时刻(ms)
    @Volatile private var downgradeMinBitrate = 0L  // 本次降档达到的最低码率
    private var downgradeSteps = 0  // v6.7.156 (修3): 本次录制已降档步数,上限 MAX_DOWNGRADE_STEPS
    @Volatile private var softDowngradeSteps = 0  // v6.7.188h (改造2): 省电浅降步数,上限 SOFT_MAX_DOWNGRADE_STEPS
    // v6.7.188h (改造1): boost 的目标基准与当前系数,供周期重估。
    @Volatile private var boostBaseBitrate = 0          // 用户设定(boost 前)码率,恒定
    @Volatile private var currentBoostFactor = 1.0      // 当前生效系数
    private var lastBoostEvalMs = 0L
    private val thermalRing = java.util.ArrayDeque<Int>()  // v6.7.189 (P1-5): 采样环形缓冲(N=5)
    private var thermalSpikeRejected = 0                   // v6.7.189 (P1-5): 尖峰丢弃计数
    // v6.7.157 (修B2): 相对温度基线。绝对阈值(原 45→50℃)在常态 50-53℃ 的机上永远命中,
    // 一开录就降到 floor 且永不回升(HUAWEI GLA-AL00/HONOR 均实测)。"热"应解释为"比这台机
    // 日常运行温度异常升高",而非"超过一个对所有机型一刀切的数"。用前 N 次读数中位数拟合基线。
    private var thermalBaselineC = 0
    private val thermalBaselineSamples = ArrayList<Int>()  // 汇总首基线用的健康读数
    private var useHevc = false
    private var tryAgainCounter = 0
    // v6.7.120 (被杀保护): 伴生 .idx + moov 重建索引跟踪。trailer 在磁盘上,
    // 进程被杀后仍在,由 findStaleRecordings/restoreStale 依此重建 moov。
    private var indexTracker: Mp4Repairer.Tracker? = null
    private var indexOut: java.io.OutputStream? = null
    private var videoTrackFormat: MediaFormat? = null
    private var audioTrackFormat: MediaFormat? = null
    @Volatile private var frameCount = 0
    @Volatile private var audioBytesWritten = 0L
    @Volatile private var audioStreamBytes = 0L
    @Volatile private var videoBytesWritten = 0L

    // —— v6.7.128 多分片 MP4 + manifest ——
    // 分片状态:切段全程在 muxerLock 内串行(视频/音频 drain 天然串行),编码器不重启,
    // 用已 start 的 track format(含 csd)重新 addTrack 到新建 MediaMuxer。
    @Volatile private var segmentationEnabled = false  // SAF/自定义路径不支持分片,退化为单片
    @Volatile private var segmentSeq = 0          // 已封口分片数(下一个分片号 = segmentSeq + 1)
    @Volatile private var segmentStartMs = 0L     // 当前分片起始实时时刻(elapsedRealtime)
    @Volatile private var segmentStartPtsUs = 0L  // 当前分片起点的全局 PTS(分片内 PTS 重基锚)
    @Volatile private var segmentBytesWritten = 0L  // 当前分片已写视频字节(切段阈值判定)
    @Volatile private var segmentVideoFirstPtsUs = -1L  // 当前分片首个写入 PTS(时长统计)
    @Volatile private var segmentStartAudioPtsUs = 0L   // 当前分片音频起点 PTS(惰性锚定)
    @Volatile private var segmentAudioFirst = true      // 分片内首个音频帧标志(惰性锚定起点)
    private var manifestOut: java.io.OutputStream? = null
    // v6.7.180: 锁屏打点——只统计不阻断。screenLockedAtMs>0 表示当前处于锁屏/息屏态,
    // 此时 MediaProjection 捕获的是锁屏/黑帧(Android 机制上限)。不丢帧、不停止、不改码率,
    // 仅在 RECORD_SUMMARY 汇报锁屏累计时长,供诊断与后续产品决策。
    @Volatile private var screenLockedAtMs = -1L
    @Volatile private var screenLockedTotalMs = 0L

    // v6.7.183: 持锁状态快照,由 ScreenRecorderService 每次续期/持锁时同步过来。
    // 报告里出这条,真机排障不用翻 logcat: false = 锁屏段 CPU 可能已被 Doze 挂起。
    @Volatile var wakeLockHeld = false
        private set
    fun setWakeLockHeld(held: Boolean) {
        wakeLockHeld = held
    }

    // v6.7.184: 中段锁丢失计数。wakeLockHeld 是"结尾快照",若锁被系统审计中途撤销
    // 又被续期恢复,结尾快照仍是 true,空洞不可见。此计数把语义升级为全程:
    // >0 说明录制期间出现过 CPU 挂起窗口(即使结尾已恢复)。
    @Volatile var wakeLockLostCount = 0
        private set
    fun onWakeLockLost() {
        wakeLockLostCount++
        setWakeLockHeld(false)
    }
    private var segmentFile: File? = null
    private val segments = mutableListOf<SegmentInfo>()  // 本次录制的分片清单
    @Volatile private var segmentSwitchFailed = false     // 切段失败置位,停止录制兜底
    // v6.7.157 (BUG-3): 分片切换后等首帧 IDR。新片 muxer 建好后置 true,
    // 丢弃新片开头到达的非关键帧,直到第一个 BUFFER_FLAG_KEY_FRAME 才写入。
    // 这是安全的:此时新片还没写入任何帧,丢的是新片自身开头几帧,不破坏已写入帧的参考链。
    // (与 BUG-2 删已编码帧有本质区别——那是在已写入若干帧后删中间帧,才致命。)
    @Volatile private var pendingSegIdr = false
    // v6.7.159 (NEW-BUG-1): 等首帧 IDR 期间的丢弃帧计数,到 SEG_IDR_DROP_MAX 即放弃等待(有界丢弃)。
    private var segIdrDropCount = 0
    // v6.7.189 (P1-9): 预请求 IDR 标记 + 等待起始墙钟。分片到期前 SEG_IDR_PRE_REQUEST_MS
    // 就先要关键帧,切段时 IDR 已在路上,把"等 IDR"从阻塞路径变成零等待;
    // 等待上限改按墙钟 SEG_IDR_WAIT_MS(原按帧数,25fps 下 3 帧仅 40ms,必然放弃)。
    private var segIdrPreRequested = false
    private var segIdrWaitStartMs = 0L
    // v6.7.149 (FIX-A): 本次录制最终产物名(不含 .tmp),收尾合并单文件时用作输出文件名。
    private var recordingFinalBasePath = ""
    @Volatile private var audioPendingPcm = ByteArray(0)
    @Volatile private var audioPendingLen = 0
    // v6.7.167: audioPending* 的跨线程闸门。生产(3183/3224)与消费(3246)同在
    // AudioCaptureThread,彼此天然串行;但 flushAudioBacklog()(forceStop/
    // stopAsync 路径)在别的线程读写并清零,必须与之互斥。
    private val audioPendingLock = Any()
    @Volatile private var audioOutputFrameCount = 0L
    @Volatile private var lastAudioPtsOutUs = 0L

    // —— 日志强化(低开销计数聚合) ——
    // B层:零读/reset 微观统计(原子累加,5s 聚合,不逐次打点)
    private val statZeroReads = AtomicLong(0)
    private val statResets = AtomicLong(0)
    private val statGiveUp = AtomicLong(0)
    // v6.7.56: 内录真故障(read<0 错误码/异常)计数,供 audio_cap_stat 判定硬件故障
    private val audioReadErrorCount = AtomicLong(0)
    // v6.7.57: 部分读取(单次 read 未填满 buffer)计数,供跨机型对照 PTP-AN70(4096) vs GLA(满buffer)
    private val partialReadCount = AtomicLong(0)
    // v6.7.57: 真实非零采样字节统计(供 PTP-AN70 区分"捕获不到"与"捕获到但被误判")
    private val capStatNonZeroBytes = AtomicLong(0)
    // v6.7.94 (P2): "读成功但全零"的块计数,与 silentChunks(read 失败)区分
    private val capStatZeroChunks = AtomicLong(0)
    // v6.7.95 (改进3): 静音自检——双路四计数器,对齐 AZ 6.9.10 eg/d.java 架构。
    // internal: 内录系统音 / output: 麦克风,各维护总数与静音数。
    // 判定:总数>=100 且 静音数>=总数*0.98 -> 全程静音。
    // 每次录制结束时打一条日志,供排查"没录上声音"类问题。
    private val audioSilenceInternalTotal = AtomicLong(0)
    private val audioSilenceInternalSilent = AtomicLong(0)
    private val audioSilenceOutputTotal = AtomicLong(0)
    private val audioSilenceOutputSilent = AtomicLong(0)
    // 部分读取节流打点时间戳(仅采集线程写)
    private var lastPartialLogNs = 0L
    // B层:av_pts_delta 漂移率监控 —— 记录上次 health 快照的 delta,供增量计算
    private var lastAvDeltaUs = 0L
    private var lastHealthWallMs = 0L
    // v6.7.178 (⑤-d): av_pts_delta 1Hz 环形采样,封顶 7200 条(2h)。
    // ConcurrentLinkedDeque:health 采样线程写,RECORD_SUMMARY 读(主线程),无锁。
    private val avDeltaRing = java.util.concurrent.ConcurrentLinkedDeque<Long>()
    // v6.7.178 (⑤-e): PTS 步长直方图分桶计数。仅 drain 写线程访问,无需同步。
    private var ptsStepBurst = 0L
    private var ptsStepLt20 = 0L
    private var ptsStep30 = 0L
    private var ptsStepHi = 0L
    private var ptsStepGt80 = 0L
    private var ptsStepMaxUs = 0L
    private var lastPtsForHist = -1L
    // v6.7.191 (P0-2): 真正写入 muxer 的视频 PTS(墙钟坐标系,与 audioTrimEndUs 同源)。
    // 容器时长的真值必须来自这对字段,而不是 lastVideoFrameTimeUs —— 后者在裁尾判断之前
    // 就被更新,忠实记录的是"编码器交回的最后一帧",会把 av_trim_align 裁掉的时长又加回去。
    @Volatile private var lastMuxedVideoPtsUs = 0L
    @Volatile private var videoFirstMuxedPtsUs = -1L
    // v6.7.191 (P0-5): PTS 单调钳制熔断计数(钳制位移超 3 帧间隔即视为时间戳不可信)。
    private var ptsClockFuseCount = 0
    // v6.7.90 (A-6): 累积漂移告警一次门(单会话内 abs(avDelta)>200ms 只打一次,避免刷屏)
    private var avCumulativeWarned = false
    // v6.7.189 (P1-10) / v6.7.191 (P0-1): AV 半步重锚状态。avDeltaUs = video - audio,
    // 正值 = 视频超前 = 音频滞后。补偿方向 audioPtsOffsetUs += avDeltaUs/2,把滞后的音频
    // PTS 推大以追上视频(闭环收敛)。注意本文件 computeAvDiffUs 的 avDiffUs = audio - video,
    // 与本量符号相反,其"为正=滞后需加回"的语义不能照搬到 avDeltaUs —— 取反号就是反向放大。
    @Volatile private var audioPtsOffsetUs = 0L
    private var avDriftAccumUs = 0L    // v6.7.190 (P0-6): 带符号累积漂移,不要求同号
    private var avDriftWindowCount = 0 // v6.7.190 (P0-6): 累积器窗口计数
    private var reanchorCount = 0   // av_reanchor 打点计数(见 health 监控块)
    // v6.7.189 (P1-11): capture_stall 计数/累计/窗口基线。
    private var stallCount = 0
    private var stallTotalUs = 0L
    // v6.7.191 (P0-4): PTS 维度停顿总时长与估算缺帧数(与 frame_accounting 交叉验证)。
    private var stallPtsTotalUs = 0L
    private var stallMissingFrames = 0L
    private var stallMaxUs = 0L
    private var stallWindowBase = 0
    // v6.7.189 (P2-12): 运行时静音告警状态。
    private var lastNonZeroAudioBytes = 0L
    private var lastNonZeroAudioMs = 0L
    private var silentWarned = false
    // v6.7.189 (P2-15b): 丢帧归因计数。采集侧与编码侧的差额帧此前完全无日志,
    // 在写入 muxer 前的每一处 return 打点分类计数,停止时一次汇总。
    // v6.7.190 (P0-2): 旧 captured/written 都在同一条成功路径自增,恒等式永远成立,
    // 没有任何诊断价值。现改为三级口径:
    //   dequeued   = 编码器 dequeueOutputBuffer 交回的帧总数(含后续被丢弃的)
    //   captured   = 编码器交回且未被任何"已归因"分支丢弃(即将写 muxer)
    //   written    = 真正写入 muxer 成功
    //   attributed = 五个已命名丢弃分支之和
    //   unattributed = dequeued - written - attributed,必须恒为 0;非 0 说明还有未归因丢帧路径。
    private var framesDequeued = 0
    private var framesDroppedElse = 0   // 未归因丢弃(EOS/4GiB 水线/未就绪 return 等)
    private var capturedFrames = 0
    private var writtenFrames = 0
    private var dropPaused = 0
    private var dropNonMonotonic = 0
    private var dropTooDense = 0
    private var dropWaitIdr = 0
    private var dropTailTrim = 0
    private var dropEosOrIdle = 0   // v6.7.190 (P0-2): EOS/零字节帧与未就绪(muxer 未启动)帧
    private var drop4GLimit = 0     // v6.7.190 (P0-2): 4GiB 安全水线截断
    private var dropSwitchFailed = 0// v6.7.190 (P0-2): 切段失败丢弃
    // C层:热/CPU 周期采样节流(独立于帧循环,约1s一次)
    private var lastThermalSampleMs = 0L
    private val thermalSampledCurMs = AtomicLong(0)
    private val thermalSampledMaxMs = AtomicLong(0)
    private val thermalSampleCount = AtomicLong(0)
    // A层: 内录已放弃标志(成员,供焦点回调等跨线程读取)
    @Volatile private var audioGiveUp = false
    // v6.7.44: 休眠探测模式下最近一次探测的墙钟时间(ns),控制 1s 一次读采样。
    @Volatile private var audioProbeLastNs = 0L

    // v6.7.44: 音频流状态(AudioRecordingCallback 回调驱动),供休眠探测判断"是否有媒体流"。
    // 值域:STATE_RECORDING(2)=有采集/有媒体流,STATE_STOPPED(1)=已停,STATE_ERROR(3)=出错。
    // 初始 -1 表示未注册回调(API<29 或非内录路径),探测时按 STATE_STOPPED 处理。
    @Volatile private var audioStreamState = -1
    // v6.7.44: AudioRecord.AudioRecordingCallback 实例,注册到 internal AudioRecord 上。
    // 实际类是 android.media.AudioManager.AudioRecordingCallback(不是 AudioRecord 的子类),
    // onRecordingConfigChanged 每次系统音频流集合变化时被调用,可间接反映"是否有媒体流"。
    // 空列表 = 无流;非空 = 有流。API 29+,与 AudioPlaybackCapture 同代。
    private var internalAudioRecordingCallback: android.media.AudioManager.AudioRecordingCallback? = null

    // v6.7.91 (A-1): 把 (PCM, PTS) 打包成不可变数据类一起入队,
    // 一次性原子完成"传数据 + 传 PTS",消除旧实现"先 offer 数据再 put PTS"的竞态窗口
    // (编码线程在两步之间被抢占时 audioPtsMap.get(idx) 返回 -1 -> 整 chunk 被 continue 丢弃)。
    private data class AudioChunk(val bytes: ByteArray, val ptsUs: Long)

    // 采集与编码解耦双缓冲队列:
    // encoderQueue (LinkedBlockingQueue): 编码线程消费的待编码 PCM+PTS 数据块,
    // 有界(64)提供自然背压,采集线程 offer 失败即表示编码跟不上,
    // 避免采集端无限堆积导致内存膨胀与音频实时性告警失真。
    private val encoderQueue = LinkedBlockingQueue<AudioChunk>(64)
    // 采集累计块数(只增计数):用于诊断"采集总量",不代表实时积压。
    // 实时积压由 encoderQueue.size 反映(有界),其余参见 accumulate 统计。
    private val audioCaptureTotalChunks = AtomicLong(0)

    // AZ 6.9.9 风格: AtomicLong 时间戳/计数器,
    // 替代 @Volatile 字段,保证跨线程可见性与原子性
    private val audioCaptureCount = AtomicLong(0)
    private val audioEncodeCount = AtomicLong(0)
    private val audioFramePts = AtomicLong(0)
    private val audioLastCaptureNs = AtomicLong(0)

    // 音频编码独立线程(双 HandlerThread 架构):
    // audioCaptureHandler -> 采集线程,负责读 AudioRecord + 混音
    // audioEncodeHandler  -> 编码线程,负责从 encoderQueue 取数据送入编码器

    private var lastPauseRealtimeNs = 0L
    private var audioStartRealtimeUs = -1L
    // v6.7.97 (改进3): 音频首块真实数据到达的墙钟时间(ns),用于与视频首帧墙钟做差,
    // 消除音画启动阶段的固定偏差。-1 表示尚未采集到任何数据。
    private val audioFirstCaptureRealtimeNs = AtomicLong(-1L)

    // v6.7.59: AZ 朴素路径以采样计数推进音频 PTS,
    // 用"累计编码采样数 vs 墙钟流逝"自校正(见 calibrateAudioSampleRate)补偿时钟漂移。
    // 未取得可靠测量前回退标称 44100。采集线程写、drain 线程读(不同线程),
    // 必须 @Volatile 保证 drain 能看到校准更新,否则 JIT 可能把循环内读提升为
    // 陈旧值,导致漂移校正不收敛(残留线性 av_pts_delta)。
    @Volatile private var realAudioSampleRate = AUDIO_SAMPLE_RATE
    // v6.7.59: 诊断——最近一次实测采样率估算值(未平滑)与对应墙钟流逝毫秒,
    // 供 audio_cap_stat 复测确认漂移是否消除、采样率是否收敛到实测值。
    @Volatile private var lastMeasuredSampleRate = 0
    @Volatile private var lastCalibElapsedMs = 0L
    // v6.7.90 (A-1): 差分估计的上一采样点。累积平均式会把"启动偏移"当成
    // 速率误差(实测: 稳态 44100Hz, 但累积式在 t=5s 读出 45969),
    // 改用"上次校准以来的增量"做估计,常量启动偏移自动消掉。
    @Volatile private var calibLastSamples = 0L
    @Volatile private var calibLastWallUs = -1L
    // v6.7.90 (A-2): 音频输出时间轴累加器(us, Double 避免逐帧截断累积)。
    // 旧写法用"累积帧号 x 当前速率"重算整条时间轴,速率一变就把已发出的
    // 时间戳追溯性改写;改为纯增量累加后,每帧只前进固定步长,不再被速率抖动回溯。
    @Volatile private var audioPtsAccumulatorUs = 0.0
    // v6.7.95 (改进1): 墙钟锚点制音频 PTS——对齐 AZ 6.9.10 fg/d.java E() 方法。
    // 双层次结构:理论层由采样数累加保证长期速率严格等于采样率;
    // 锚点层用墙钟校准避免暂停期间的音频积存导致漂移。
    // pause() 不做任何时间戳动作(只摘 surface);resume() 重置锚点为 -1,
    // 强制下一次 calculateAudioPts() 重新锚定,从音频时间轴上剪掉暂停时长。
    @Volatile private var audioPtsAnchorUs = -1L
    @Volatile private var audioSampleCount = 0L

    // —— 音视频时钟锚定 ——
    // 差异A/C: 视频 PTS 信任编码器首帧归零,音频 PTS 纯墙钟首帧归零,
    // 二者均独立单调递增,不再互相锚定,消除 av_pts_delta 缓增。
    // 视频末帧 PTS。视频 EOS 接收后锁定,音频样本平移后 PTS 超过
    // videoTrimEndUs + 一个音频帧即丢弃,裁剪掉视频结束后的音频超长尾。
    @Volatile
    private var videoTrimEndUs = 0L
    // v6.7.172 (P0-A): 音频末端裁剪上界。停止排空后取 commonEndUs = min(视频末PTS, 音频末PTS),
    // 把较长的一路裁到 commonEndUs,消除成片"最后 113ms 没声音"(音频轨比视频轨短)。
    // 符号无关:无论音频先结束还是后结束都正确,与 videoTrimEndUs 对称。
    @Volatile
    private var audioTrimEndUs = 0L
    // v6.7.48: 连续低帧率预警计数(秒)。actualFps < 0.8*target 持续 N 秒触发 onWarning,
    // 纯观测不动作,用于区分编码器吞吐瓶颈与 SF 投帧瓶颈。
    private var lowFpsWarningCount = 0
    // reportProgress 墙钟节流:距上次回调 < 1000ms 跳过,避免帧计数停滞时过频回调
    private var lastProgressReportMs = 0L
    // 自学习自适应等级：跨录制持久化，供下次录制恢复
    @Volatile
    private var adaptiveLevel = ADAPTIVE_STRATEGY_LEVEL

    private var hevcConfigureFailed = false
    // v6.7.139 (修复隔次循环): 本次录制是否因学习态回灌而压制 HEVC 使用 AVC。
    // 落盘 reason 需据此保持 device_cap 连续，避免 cfg.useHevc 被回灌覆盖后误写 manual。
    private var hevcSuppressedByLearn = false
    private var finalDurationMs = 0L
    private var finalFileSize = 0L

    @Volatile
    private var muxerVideoDone = false
    // v6.7.105: 4GiB 边界收尾已触发一次标志,onMuxer4GLimitReached 内部 CAS 幂等,
    // 防止多线程同时命中水线时重复 onError。
    private val muxer4gTriggered = java.util.concurrent.atomic.AtomicBoolean(false)
    @Volatile
    private var muxerAudioDone = false
    // 存储/写入异常标记:若 writeSampleData 失败,损坏的 muxer 无法正常 stop,
    // 跳过 muxer.stop() 仅释放避免 IllegalStateException
    @Volatile
    private var muxerFailed = false

    // v6.7.95: 移除未引用字段 videoBufferInfo(仅声明处出现,视频侧用局部 BufferInfo)。


    @Volatile
    private var pendingAudioFormat: MediaFormat? = null

    // 音频看门狗:若音频采集在超时时间内未产出任何有效数据,则注入静音帧以
    // 保证音频编码器能产出输出格式、音频轨能被添加,避免最终无声视频。
    private var lastAudioDataNs = 0L
    private var audioSilenceInjected = false
    private var audioSilenceBytes = 0L

    // 双路混音独立音量系数(浮点增益,0.0f~2.0f,默认 1.0f)
    var internalVolume = 1.0f
    var micVolume = 1.0f

    fun setSafOutput(uri: Uri, fileName: String) {
        safOutputUri = uri
        safTargetFileName = fileName
        safDocumentUri = null
    }

    fun start(config: RecorderConfig, projection: MediaProjection) {
        if (isRunning.get()) {
            logDetail("start", "already running, ignoring")
            return
        }
        // v6.7.169 (P1 方案B): 取显示刷新率作为有效采集帧率。AZ 架构下 Surface 按设备刷新率
        // 投帧、编码器照单全收,配置 fps 仅作码率 hint。码率预算与 learn 基数用此值而非配置帧率,
        // 使码率与真实帧数匹配——60Hz 屏选 30fps 时按 ~60fps 进 autoBitrate 模型拿对应系数,
        // 每帧比特不再被摊薄;learn avgFps 不被真实采集帧率污染基数。
        // v6.7.190 (P0-4): 取"当前显示模式"刷新率,不再取 supportedModes 的**最高模式**。
        // 旧实现 supportedModes.maxOfOrNull{refreshRate} 在本机得到 120(面板支持 1280x2800@120),
        // 而 Display.refreshRate 返回的是**当前模式**(省电/系统设定时常为 60),实际投帧跟随
        // 当前模式。120 这个假值已被 188h P0-3 降为冷启动兜底,但从未消灭:ls.avgFps<=1
        // (首次安装/清数据首录)时仍会污染 boost 基数与 learn 报告。现按当前模式取,
        // 并把两个候选值全部打进 capture_fps_probe,消除 120 vs 60 的口径矛盾。
        effectiveCaptureFps = try {
            val dm = context.getSystemService(Context.DISPLAY_SERVICE) as android.hardware.display.DisplayManager
            val disp = dm.getDisplay(android.view.Display.DEFAULT_DISPLAY)
            val currentHz = disp?.refreshRate ?: 60f
            val maxModeHz = disp?.supportedModes?.maxOfOrNull { it.refreshRate } ?: currentHz
            logDetail("capture_fps_probe",
                "currentHz=$currentHz maxModeHz=$maxModeHz modes=${
                    disp?.supportedModes?.joinToString { "${it.physicalWidth}x${it.physicalHeight}@${it.refreshRate}" }
                }")
            currentHz.coerceAtLeast(30f)
        } catch (_: Throwable) { 60f }
        // v6.7.189 (P2-15a): 保留 2 位小数,消除 120.00001 这类 float 脏值。
        // 该值会参与学习与码率计算,脏值会顺着传播。
        effectiveCaptureFps = kotlin.math.round(effectiveCaptureFps * 100f) / 100f
        logDetail("capture_fps",
            "effectiveCaptureFps=$effectiveCaptureFps configFps=${config.fps} " +
                "targetFps=$targetFps (capture rate is NOT encode rate; never use it for bitrate math)")
        // v6.7.171 (P0): 录制起点单调时钟,仅取一次。音视频 PTS 全部引用此基准,
        // 不再各自维护 anchor。约束6:用 SystemClock.elapsedRealtime()(单调不跳变),
        // 严禁 System.currentTimeMillis()(墙钟会跳变)算任何 PTS。
        recordingT0Us = SystemClock.elapsedRealtime()
        logDetail("recording_t0", "recordingT0Us=$recordingT0Us (monotonic, single anchor for A/V)")
        this.config = config
        this.mediaProjection = projection
        // v6.7.46: 码率按分辨率分档钳制,对齐 AZ 6.9.10 Lnh/f0->y() 的反编译实证分档:
        //   height>=1440 -> 12M   >=1080 -> 10M   >=720 -> 8M   >=640 -> 6.5M
        //   >=540 -> 5M  >=480 -> 4M  其余 -> 1.5M
        // 历史原因:早期 16M 一刀切在真机曾触发编码器热节流退化到 ~21fps(见 L63 注释),
        // 故不再简单解除 clamp,而是按分辨率给足运动清晰度所需码率,同时保留上限防热节流。
        // 用户设置的码率若高于对应档位则降到档位;若低于档位则尊重用户设置(不拔高)。
        // v6.7.127 (S3): 废弃启动期按高度硬 clamp 码率。旧逻辑 azBitrateCapForHeight
        // 把 2K/4K 钉死在 12M/10M,与 defaultBitrateForHeight 同表,等于"上限=默认",
        // 用户选择高于默认的码率被静默压回,所有高档选择都是无效输入(见 v6.7.89 L-7)。
        // 上限改为由 clampToCapabilities 的 hardware bitrateRange.upper 兜底(编码器自身
        // 会节流,比人为分档更贴合硬件),低于该上限的用户值一律尊重。
        // v6.7.137 (改进1): 编码器学习态回灌。saveRecordingLearnState 每次录制结束把上次实际
        // 编码器偏好写入 KEY_LEARN_ENCODER_PREF("hevc"/"avc"),但 start() 从未读回,学习态"只存不用"。
        // v6.7.138 (改进1 缺陷修复): 增加 reason 字段区分 device_cap / manual。
        // 仅 reason==device_cap 时才回灌压制 useHevc,否则保持用户当前配置:
        //   - device_cap: 设备真的跑不动 HEVC,默认关闭避免弱机每次都重试又失败;
        //   - manual/null: 用户显式选择或老数据兼容,不开启覆盖。
        // 显式手动选择的意图不受影响(用户显式关闭时 useHevc 本为 false;录制一次后 learnState 更新,
        // reason 写 "manual",下次不再压制)。
        // v6.7.139: 每次 start() 复位 hevcSuppressedByLearn=false，避免上次录制状态污染本次。
        hevcSuppressedByLearn = false
        val learnedEncoder = learnedEncoderPref()
        val learnedReasonVal = learnedReason()
        var effConfig = if (learnedEncoder == "avc" && learnedReasonVal == "device_cap" && config.useHevc) {
            logDetail("learn_encoder_reuse", "learned=avc reason=device_cap -> useHevc=false")
            // v6.7.139: 记录"本次 AVC 源于学习态回灌"，供 saveRecordingLearnState 落盘保持 device_cap。
            hevcSuppressedByLearn = true
            config.copy(useHevc = false)
        } else config
        // v6.7.140 (方案1): 低端机 Auto 档上限钳制。用户显式选过的值一律尊重。
        val tier = deviceTier(context)
        if (tier == 0) {
            if (effConfig.fps == 0) {
                effConfig = effConfig.copy(fps = 30)
                logDetail("device_tier", "low-end fps Auto -> 30")
            }
        }
        // v6.7.151 (缺陷E): bitrate==0 兜底从仅 tier==0 扩展到所有 tier。此前非低端机若收到
        // bitrate==0 会原样传给 MediaCodec,用其极差默认值。当前上游(Service:673)已用 autoBitrate
        // 兜底不会传 0,但引擎侧补防御,避免后续调用方误传 0。
        if (effConfig.bitrate == 0) {
            effConfig = effConfig.copy(bitrate = 10_000_000)
            logDetail("device_tier", "bitrate 0 -> 10M (tier=$tier)")
        }
        this.config = effConfig
        this.currentFps = effConfig.fps
        this.currentBitrate = effConfig.bitrate
        this.targetFps = effConfig.fps
        this.targetBitrate = effConfig.bitrate
        // v6.7.188h (改造1): 基准码率在 try 外先落,防 learn/boost 段异常时 userBitrate 取到 0。
        this.boostBaseBitrate = effConfig.bitrate
        this.currentBoostFactor = 1.0
        this.lastBoostEvalMs = 0L
        // v6.7.157 (修A): 历史实测帧率封顶。必剪策略"按素材实际帧率决定导出帧率"(oh0.c())——
        // 编码器 KEY_FRAME_RATE 是 configure 时定死的,本机只能真产 25fps 却按 60fps 铺 PTS,
        // 产物就是 1/4 速慢放(HUAWEI GLA-AL00 实测 targetFps=60 actualFps=24.8,
        // ptsGap=670015us = 16666us×4)。开机即按 learnState.avgFps 封顶,PTS 与实际帧对齐,
        // 省电模式强制封顶(限频是本机常态,60fps 数学可行但实测不可达)。
        // 仅在历史样本充足(n>=2)且明显低于请求值时生效;下限 15fps 防过度降帧。
        try {
            val ls = loadLearnState(context)
            val osPowerSave = try {
                (context.getSystemService(Context.POWER_SERVICE) as? PowerManager)?.isPowerSaveMode == true
            } catch (_: Exception) { false }
            val capped = capFpsByLearn(List(RecorderEngine.MIN_LEARN_SAMPLES) { ls.avgFps }, effConfig.fps, osPowerSave, ls.totalRecordings)
            if (capped > 0 && capped < effConfig.fps) {
                val requestedFps = effConfig.fps
                val requestedBitrate = effConfig.bitrate
                val scaledBitrate = (requestedBitrate.toLong() * capped / requestedFps)
                    .coerceAtLeast(1_000_000L).toInt()
                val cappedConfig = effConfig.copy(fps = capped, bitrate = scaledBitrate)
                this.config = cappedConfig
                this.currentFps = capped
                this.targetFps = capped
                this.currentBitrate = scaledBitrate
                this.targetBitrate = scaledBitrate
                logDetail("learn_fps_cap",
                    "requested=$requestedFps capped=$capped (learnAvgFps=${ls.avgFps} n=${ls.totalRecordings} powerSave=$osPowerSave) bitrate $requestedBitrate -> $scaledBitrate")
            }
            // v6.7.171 (P1): 码率按真实采集帧率放大。AZ 架构下 Surface 按显示刷新率投帧、
            // 编码器照单全收,配置 fps 仅作码率 hint。若按配置 fps 预算码率,真实 ~60fps 下
            // 每帧比特被摊薄一半,高动态画质下降。仅当 realFps > cfg.fps 时放大,使每帧码率回到
            // 配置意图;不要反过来限帧(约束1:不丢帧)。learn 封顶下调已发生时不再放大,避免双改。
            // v6.7.172 (P1): 放大基数改用 learn 均值(上次实测帧率)而非 effectiveCaptureFps
            // (屏幕刷新率)。本机 120Hz 屏 effectiveCaptureFps=120 但实测只采到 60fps,
            // 按 120 放大会无脑 4 倍(4166400->16665601)。倍数硬上限 2.5,120Hz 屏实际 60fps
            // 时 boostFactor≈2,不再浪费码率(约束 C9)。
            val measuredFps = if (ls.avgFps > 1) ls.avgFps.toDouble()
                else effectiveCaptureFps.toDouble()
            // v6.7.178 (⑦): 定基收敛。裸 measuredFps 会把 120Hz 屏顶到 2.5 上限,
            // 给要 30fps 的用户按 53fps 花码、每帧偏薄。收敛到 min(实测, 目标*1.5):
            // 用户要的画质 + 适度余量,而非裸刷新率。上限 2.5 保留(learn 异常时仍有垫)。
            val measuredBasis = kotlin.math.min(measuredFps, effConfig.fps * 1.5)
            val boostFactor = (measuredBasis / effConfig.fps.toDouble()).coerceAtMost(2.5)
            // v6.7.188h (改造1): 只记录基准码率与初始系数,实际应用交给 applyBoost/applyBoostPeriodic。
            // 启动瞬间的实测帧率不代表全程,boost 改为 5s 周期重估(见 applyBoostPeriodic)。
            this.boostBaseBitrate = effConfig.bitrate
            this.currentBoostFactor = if (boostFactor > 1.0 + 1e-3 && effConfig.bitrate > 0 &&
                currentFps == effConfig.fps) boostFactor else 1.0
            this.lastBoostEvalMs = 0L
            if (this.currentBoostFactor > 1.0) {
                applyBoost(this.currentBoostFactor, "startup")
                this.config = effConfig.copy(bitrate = targetBitrate)
            }
        } catch (e: Exception) {
            logDetail("learn_fps_cap_error", "${e.message}")
        }
        // v6.7.130: 用户设定码率快照。降档 floor 与回弹目标都以它为准(userBitrate/4, 最低 4M),
        // 避免 4K/用户高档录制过热降档后回弹到全局默认,静默吞掉用户配置。
        // v6.7.157 (修A): 取封顶后的值,保证降档 floor 与回弹目标与最终生效码率一致。
        // v6.7.188h (改造1): userBitrate 恒取用户设定(boost 前),不含 boost。
        // boost 只是"当前目标"的上下浮动;floor/回弹目标都基于用户真实意图,
        // 不再被启动瞬间的虚高帧率抬高。
        this.userBitrate = boostBaseBitrate
        this.downgradeActive = false
        this.downgradeLatched = false
        this.lastRampUpAtMs = 0L
        this.recoverCandidateStartMs = 0L
        this.downgradeFirstAtMs = 0L
        this.downgradeMinBitrate = 0L
        this.downgradeSteps = 0
        this.softDowngradeSteps = 0
        this.useHevc = effConfig.useHevc
        this.tryAgainCounter = 0
        // 每次重新录制都允许重新尝试 mic fallback,避免上次硬件故障后
        // 本次录制(同一进程)永久跳过麦克风回退。
        this.micFallbackAttempted = false
        this.frameCount = 0
        this.audioBytesWritten = 0L
        this.audioStreamBytes = 0L
        this.audioPendingLen = 0
        this.audioOutputFrameCount = 0L
        this.lastAudioPtsOutUs = 0L
        this.audioStartRealtimeUs = -1L
        this.audioFirstCaptureRealtimeNs.set(-1L)
        this.realAudioSampleRate = AUDIO_SAMPLE_RATE
        this.lastMeasuredSampleRate = 0
        this.lastCalibElapsedMs = 0L
        // v6.7.90 (A-1/A-2): 差分估计点与增量时间轴累加器复位,新会话重新锚定。
        this.audioPtsAccumulatorUs = 0.0
        // v6.7.95 (改进1): 重置墙钟锚点与采样计数,确保新会话音频 PTS 从零开始。
        this.audioPtsAnchorUs = -1L
        this.audioSampleCount = 0L
        this.calibLastSamples = 0L
        this.calibLastWallUs = -1L

        this.videoTrimEndUs = 0L
        this.audioTrimEndUs = 0L
        this.videoBytesWritten = 0L
        this.firstVideoFrameTimeUs = -1L
        this.firstAudioFrameTimeUs.set(-1L)
        this.lastVideoFrameTimeUs = 0L
        this.lastAudioFrameTimeUs = 0L
        // v6.7.171 (P0): 重置起点锚,每次录制重新取 recordingT0Us
        this.recordingT0Us = -1L
        this.lowFpsWarningCount = 0
        this.videoFrameSeq = 0L
        // v6.7.142(优化3): 滑动窗口字段一并归零,避免跨录制首窗用上一段旧 seq 计算产生跳变帧率。
        // 窗口计算在 lastDropWindowWallMs > 0 时才生效,置 0 后新录制首窗自然跳过。
        this.runtimeDropWindowFps = 0
        this.lastDropWindowSeq = 0L
        this.lastDropWindowWallMs = 0L
        this.lastMuxedVideoPtsUs = 0L      // v6.7.191 (P0-2): 写入末端计时点复位
        this.videoFirstMuxedPtsUs = -1L
        this.videoFirstPtsUs = -1L         // v6.7.191 (P0-2): 首帧锚点一并复位(此前只置位不复位)
        this.ptsClockFuseCount = 0
        this.stallCount = 0               // v6.7.191 (P0-4): 停顿统计跨录制归零
        this.stallTotalUs = 0L
        this.stallPtsTotalUs = 0L
        this.stallMissingFrames = 0L
        this.stallMaxUs = 0L
        this.stallWindowBase = 0
        this.frameDropWindowStreak = 0
        // v6.7.142(优化5·退避): 新录制重新尝试双录两轨重建,清除上一段残留退避。
        this.internalTrackRetryAfterMs = 0L
        this.micTrackRetryAfterMs = 0L
        this.videoFirstFrameRealtimeNs.set(-1L)
        this.lastWrittenPtsUs = -1L
        this.lastMuxAudioPtsUs = -1L
        this.finalSafUri = null
        this.safDocumentUri = null
        this.lastMuxVideoPtsUs = -1L
        this.prevWriteWallNs = 0L
        this.prevWritePtsUs = 0L
        this.resetTearingDiag()
        this.diagFrameCount = 0L
        this.framePtsCounter = 0L
        this.ptsIntervalSum = 0L
        this.ptsIntervalMin = Long.MAX_VALUE
        this.ptsIntervalMax = Long.MIN_VALUE
        this.ptsCount = 0L
        this.statZeroReads.set(0L)
        this.statResets.set(0L)
        this.statGiveUp.set(0L)
        this.audioReadErrorCount.set(0L)
        this.partialReadCount.set(0L)
        this.capStatNonZeroBytes.set(0L)
        this.capStatZeroChunks.set(0L)
        this.lastPartialLogNs = 0L
        this.audioGiveUp = false
        this.audioStreamState = -1
        this.internalAudioRecordingCallback = null
        this.audioProbeLastNs = 0L
        this.lastLeakSampleMs = 0L
        this.lastAvDeltaUs = 0L
        this.lastHealthWallMs = 0L
        this.avCumulativeWarned = false
        this.lastThermalSampleMs = 0L
        this.muxerVideoDone = false
        this.muxerAudioDone = false
        this.muxerFailed = false
        this.muxer4gTriggered.set(false)
        this.videoTrackIndex = -1
        this.audioTrackIndex = -1
        this.audioTrackFailed = false
        this.pendingAudioFormat = null
        this.finalDurationMs = 0L
        this.finalFileSize = 0L
        // v6.7.95 (改进3): 静音自检计数器复位
        this.audioSilenceInternalTotal.set(0L)
        this.audioSilenceInternalSilent.set(0L)
        this.audioSilenceOutputTotal.set(0L)
        this.audioSilenceOutputSilent.set(0L)
        forceStop.set(false)
        isPaused.set(false)
        encoderReady.set(false)
        muxerStarted.set(false)
        stopCompleted.set(false)
        // v6.7.120 (被杀保护): 重置索引跟踪状态
        indexTracker = null
        indexOut = null
        videoTrackFormat = null
        audioTrackFormat = null

        logSection("Recording Start")
        logDetail("config", "size=${config.width}x${config.height} fps=${config.fps} bitrate=${config.bitrate} audio=${config.useAudio} hevc=${config.useHevc}")
        logEnvironmentSnapshot()

        outputFilePath = config.outputFilePath.ifEmpty {
            val dir = context.getExternalFilesDir(Environment.DIRECTORY_MOVIES)
            // v6.7.95 (改进4): 本地路径也加 .recording.tmp 后缀,保证未完成的录制文件
            // 对系统媒体扫描器不可见。正常收尾后调用 renameToFinal 去掉后缀;
            // 若进程崩溃中断,残留 .tmp 文件不影响历史列表(历史存的是最终名)。
            File(dir, "recording_${System.currentTimeMillis()}.recording.tmp").absolutePath
        }
        outputFile = File(outputFilePath)
        // v6.7.128: 分片模式下 outputFilePath 指向首片(.tmp),manifest 与分片同目录。
        // v6.7.149 (FIX-A): 原判定 `!outputFilePath.isEmpty() && config.outputFilePath.isEmpty() &&
        //   safOutputUri == null` 恒为假——Service 的 resolveOutputUri 无论是否 SAF 都回私有目录
        //   tmp 路径,config.outputFilePath 永不空,导致分片自引入起从未生效(死代码)。现改为
        //   全场景启用分片(SAF/自定义/本地一致):分片写盘仍走私有 getExternalFilesDir 目录,
        //   SAF 只影响收尾导出(合并后单文件再 copy),不阻断分片。
        segmentationEnabled = outputFilePath.isNotEmpty()
        // v6.7.149 (FIX-A): 记住本次录制"最终文件名"(不含 .tmp),供收尾合并产物命名,与
        //   非分片 mode 的 renameToFinal 输出一致(同一 base + .mp4)。
        recordingFinalBasePath = if (outputFilePath.endsWith(".recording.tmp"))
            outputFilePath.dropLast(".recording.tmp".length) + ".mp4"
        else outputFilePath
        if (segmentationEnabled) {
            val baseDir = outputFile?.parentFile?.absolutePath ?: return
            segmentSeq = 0
            segmentBytesWritten = 0L
            segmentVideoFirstPtsUs = -1L
            segmentStartPtsUs = 0L
            segments.clear()
            segmentSwitchFailed = false
            manifestOut = null
            segmentFile = outputFile
            logDetail("segment", "enabled, baseDir=$baseDir durMs=$SEGMENT_DURATION_MS maxBytes=$SEGMENT_MAX_BYTES")
        } else {
            logDetail("segment", "disabled (SAF or custom path)")
        }
        logDetail("output_path", outputFilePath)
        // v6.7.178 (⑤-c): 容量基准。estimateRemainingTime 是相对估算,这里落绝对值,
        // 满盘事故可事后归因。
        try {
            val sf = android.os.StatFs(java.io.File(outputFilePath).parentFile!!.absolutePath)
            logDetail("disk", "free=${sf.availableBytes / (1024L * 1024)}MB total=${sf.totalBytes / (1024L * 1024)}MB")
        } catch (_: Exception) {}

        performPixelThroughputCheck()

        tryAgainCounter = 0
        // v6.7.127 (S6): 废弃启动期强制降档(applyHistoricalFpsCap)。旧逻辑用上次 avgFps*0.62-1
        // 落到 [120..30] 阶梯,用户选 144 也被历史压到 30 且恶性循环升不回来;与已授权的 runtime
        // 三级降档(降码率→丢帧→分片边界降分辨率)职责重叠且方向相反。用户 144 就从 144 起录,
        // 扛不住由 runtime 降档接管(runtime 降档已定案,随后续批次落地)。
        // 历史学习数据仍落盘( saveRecordingLearnState ),仅作诊断记录不再反过来压启动帧率。
        try {
            isRunning.set(true)
            startTimeNs = System.nanoTime()
            videoDrainDone = java.util.concurrent.CountDownLatch(1)
            audioDrainDone = java.util.concurrent.CountDownLatch(1)
            audioTrackWaitStartNs = 0L
            setupVideoEncoder()
            setupAudioCapture()
            setupMuxer()
            setupVirtualDisplay()
            startEncodeLoop()
            callback?.onStarted()
            logDetail("start", "engine started successfully")
        } catch (e: Throwable) {
            isRunning.set(false)
            forceStop.set(false)
            logDetail("start_failed", Log.getStackTraceString(e))
            writeEmergencyLog("start_failed: ${e.message ?: e.javaClass.name}", e)
            // v6.7.140-补(方案3): 启动/编码失败路径必须落 error 报告。
            // 该路径不经过 stop()/forceStop(),不会触发 saveRecordingLearnState 落盘,
            // 故在此直接落一条结构化失败报告,stopReason=error,满足三态全覆盖。
            finalStopReason = "error"
            runCatching {
                val cfg = config
                val report = org.json.JSONObject().apply {
                    put("durationMs", 0)
                    put("frameCount", 0)
                    put("avgSeqFps", 0)
                    put("targetFps", cfg?.fps ?: 0)
                    // v6.7.142(优化4): 宽高用真实值——已建轨时取实际分辨率,未建轨返回 -1("未知")比 0 更诚实。
                    put("width", getActualWidth())
                    put("height", getActualHeight())
                    put("bitrate", currentBitrate)
                    put("encoder", if (cfg?.useHevc == true) "hevc" else "avc")
                    put("powerSave", false)
                    put("stopReason", "error")
                    put("segmentCount", 0)
                    put("error", e.message ?: e.javaClass.name)
                }
                context.getSharedPreferences(LEARN_PREFS_NAME, Context.MODE_PRIVATE)
                    .edit().putString("record_report_latest", report.toString()).apply()
            }
            DiagLog.logEvent("RECORD_SUMMARY", "start failed report written, stopReason=error")
            callback?.onError(
                if (e is Exception) e else RuntimeException("start failed: ${e.message}", e)
            )
            videoDrainDone.countDown()
            audioDrainDone.countDown()
            releaseResources()
        }
    }

    private fun performPixelThroughputCheck() {
        val cfg = config ?: return
        val px = cfg.width.toLong() * cfg.height.toLong()
        if (px <= 0) return
        // v6.7.153: 让 cap 变成硬约束——启动前预降帧。此前的"仅打日志不降级"注释写的是
        // "对齐 AZ",但 AZ 在别的机型/别的负载下不降,不代表 1280x2800@60(215M px/s,
        // 超 cap 19%)这台机可以不降——实测结果是 actual_fps=45.8 / 丢 95 帧 / 91C。
        // 关键认知:降码率对像素吞吐几乎没用(码率 34.27M→21.9M,帧率还是 45.8),因为
        // 编码器负载主要由「分辨率 x 帧率」决定。要降温稳帧只能动帧率或分辨率。
        // 调用时序在 createVideoFormat 之前(1613 行),targetFps 改动会进编码器。
        if (cfg.fps <= 0) return   // v6.7.154 (BUG-7): Auto 未解析的 0 直接跳过,不进入 coerceIn
        val fitByCap = (PIXEL_THROUGHPUT_CAP / px).toInt()
        // v6.7.161 (能力锚定): 与编码器真实可持续帧率取小。PIXEL_THROUGHPUT_CAP 保留作兜底上界,
        // 不再是唯一依据——强机真实能力高于魔法数时不被人为天花板压住,弱机真实能力低于魔法数时别硬撑。
        val fitByCaps = achievableFps(cfg.width, cfg.height, findCodecCapabilities(if (cfg.useHevc) MIME_HEVC else MIME_VIDEO))
        val fit = if (fitByCaps > 0) minOf(fitByCap, fitByCaps) else fitByCap
        val upper = cfg.fps.coerceAtLeast(15)   // v6.7.154 (BUG-7): 避免 min>max 抛 IllegalArgumentException
        val capped = fit.coerceIn(15, upper)
        if (capped < targetFps) {
            targetFps = capped
            // v6.7.154 (BUG-6): 同步 config.fps 与 currentFps。此前只改 targetFps,
            // getCurrentFps() 仍返回 60、日志 cfg.fps 记 60、学习态按 60 上限收敛,
            // 而真实落盘是 50——UI/日志与真值不符,排查时被假数据误导。
            config = cfg.copy(fps = capped)
            currentFps = capped
            // v6.7.154 (BUG-5): 码率跟着新帧率走。
            // v6.7.156 (修2): 只在 Auto 码率(cfg.bitrate<=0)时重算;显式档位按帧率比例
            // 折算,不再用 Auto 公式越权覆盖用户值——此前用户选 16Mbps 被算成 24Mbps(+50%)。
            if (cfg.bitrate <= 0) {
                val recomputed = QualityParams.bitrateScheduler()
                    .autoBitrate(cfg.width, cfg.height, capped, cfg.useHevc, false)
                if (recomputed > 0 && recomputed != targetBitrate) {
                    logDetail("pixel_throughput", "bitrate recomputed(Auto) for fps=$capped -> $recomputed")
                    targetBitrate = recomputed
                    currentBitrate = recomputed
                }
            } else {
                val srcFps = cfg.fps.coerceAtLeast(1)
                val scaled = (cfg.bitrate.toLong() * capped / srcFps)
                    .coerceAtLeast(1_000_000L).toInt()
                if (scaled != targetBitrate) {
                    logDetail("pixel_throughput", "bitrate scaled(explicit) for fps=$capped -> $scaled")
                    targetBitrate = scaled
                    currentBitrate = scaled
                }
            }
            logDetail("pixel_throughput",
                "${px * cfg.fps} (cap=$PIXEL_THROUGHPUT_CAP fit=$fitByCap caps=$fitByCaps) -> fps ${cfg.fps} -> $capped")
        } else {
            logDetail("pixel_throughput", "${px * cfg.fps} (cap=$PIXEL_THROUGHPUT_CAP fit=$fitByCap caps=$fitByCaps) -> ok")
        }
    }

    // v6.7.127 (S6): 启动期历史/探针降档链已整段移除(applyHistoricalFpsCap /
    // calibrateSustainedFps / measureEncoderThroughput / putYuv420SystemBytes 及
    // FRAMERATE_DOWNGRADE_STEPS / PROBE_SAFETY_FACTOR / probeCache / 探针缓冲数组)。
    // 用户选择的目标帧率从原值起录,抗不住由 runtime 三级降档接管。

    private fun setupVideoEncoder() {
        val cfg = config ?: throw IllegalStateException("config is null")
        // v6.7.43: 默认录制尺寸取设备真实 DisplayMetrics,与真实屏幕 1:1 匹配,避免 VirtualDisplay
        // 因宽高比例不一致导致 scale/letterbox,增加 SF 合成开销(GLA-AL00 默认 1080x1920 vs 真实
        // 1080x2400 级,原逻辑每帧合成都要额外插值)。密度 520 保留,flags 保持 AUTO_MIRROR。
        val realMetrics = context.resources.displayMetrics
        val rawWidth = if (cfg.width > 0) cfg.width else realMetrics.widthPixels
        val rawHeight = if (cfg.height > 0) cfg.height else realMetrics.heightPixels
        val finalConfig = if (rawWidth != cfg.width || rawHeight != cfg.height) {
            cfg.copy(width = rawWidth, height = rawHeight)
        } else {
            cfg
        }
        config = finalConfig
        val adjustedWidth = alignToEven(finalConfig.width)
        val adjustedHeight = alignToEven(finalConfig.height)

        var selectedCodec = selectBestVideoEncoder(useHevc)
        if (selectedCodec == null && useHevc && !hevcConfigureFailed) {
            logDetail("video_encoder", "HEVC encoder not found, falling back to AVC")
            selectedCodec = selectBestVideoEncoder(false)
        }
        if (selectedCodec == null) {
            selectedCodec = selectBestVideoEncoder(false)
        }
        val codecInfo = selectedCodec?.codecInfo
            ?: throw IllegalStateException("No suitable video encoder found")

        val mime = getMimeForCodec(codecInfo.name)
        videoEncoderName = codecInfo.name
        logDetail("video_encoder", "selected: ${codecInfo.name} mime=$mime")

        configureEncoderWithRetry(codecInfo, mime, adjustedWidth, adjustedHeight)

        useHevc = mime == MIME_HEVC
        val newConfig = finalConfig.copy(width = adjustedWidth, height = adjustedHeight)
        config = newConfig
        callback?.onEncoderChanged(videoEncoderName)
    }

    private fun configureEncoderWithRetry(codecInfo: MediaCodecInfo, mime: String, width: Int, height: Int) {
        val cfg = config ?: return
        var currentMime = mime

        val bitrateModes = listOf(
            MediaCodecInfo.EncoderCapabilities.BITRATE_MODE_CBR to "CBR",
            MediaCodecInfo.EncoderCapabilities.BITRATE_MODE_VBR to "VBR_CQ",
            MediaCodecInfo.EncoderCapabilities.BITRATE_MODE_VBR to "VBR"
        )

        var lastError: Exception? = null
        var success = false

        for ((bitrateMode, modeName) in bitrateModes) {
            if (success) break
            var candidate: MediaCodec? = null
            try {
                val format = createVideoFormat(currentMime, width, height, targetFps, targetBitrate, bitrateMode)
                val encoder = MediaCodec.createByCodecName(codecInfo.name)
                candidate = encoder
                encoder.configure(format, null, null, MediaCodec.CONFIGURE_FLAG_ENCODE)
                inputSurface = encoder.createInputSurface()
                // 不设 frame-rate / FIXED_SOURCE：对齐 AZ 架构，让 SurfaceFlinger 按设备
                // 物理刷新率投帧，编码器跟不上时靠 BufferQueue 背压自然降速。
                // 帧完整、无跳变。FIXED_SOURCE 强制按目标 fps 投帧，编码器跟不上时
                // SF 会丢弃帧，造成视觉上水平错位感（误判为撕裂）。
                // 编码器输出改为显式轮询模式(dequeueOutputBuffer)而非异步回调。
                // 对齐 AZ 6.9.9 架构:回调模式在低帧率/资源受限时(如省电模式导致
                // SF 投帧不足)可能因回调线程调度延迟丢帧,轮询在 EncodeLoopThread 中
                // 主动取输出,时序更确定,能及时处理可用输出。仅保留 formatChanged 在
                // 启动后显式调用一次 + 轮询到 INFO_OUTPUT_FORMAT_CHANGED 时处理。
                encoder.start()
                // v6.7.46: 对齐 AZ 6.9.10 启动一次性 request-sync(Lfg/u->n),
                // 强制编码器立即输出首帧关键帧,启动瞬间即恢复完整细节。
                requestKeyFrame(encoder)
                // 启动后立即读取一次输出格式以注册视频轨道并入 muxer
                handleOutputFormatChanged()
                videoEncoder = encoder
                encoderReady.set(true)
                success = true
                logDetail("encoder_configure", "success with mime=$currentMime mode=$modeName")
            } catch (e: Exception) {
                candidate?.release()
                lastError = e
                logDetail("encoder_configure_fail", "mime=$currentMime mode=$modeName error=${e.message}")

                if (currentMime == MIME_HEVC && !hevcConfigureFailed) {
                    hevcConfigureFailed = true
                    logDetail("hevc_fail", "caching HEVC configure failure")
                    writeEmergencyLog("HEVC configure failed: ${e.message ?: e.javaClass.name}", e)
                }

                if (e is MediaCodec.CodecException &&
                    e.errorCode == MediaCodec.CodecException.ERROR_INSUFFICIENT_RESOURCE &&
                    currentMime == MIME_HEVC
                ) {
                    logDetail("encoder_retry", "HEVC insufficient resource, retrying with AVC")
                    currentMime = MIME_VIDEO
                    val avcCodec = selectBestVideoEncoder(false)
                    if (avcCodec != null) {
                        var avcCandidate: MediaCodec? = null
                        try {
                            val newFormat = createVideoFormat(
                                currentMime, width, height, targetFps, targetBitrate,
                                MediaCodecInfo.EncoderCapabilities.BITRATE_MODE_CBR
                            )
                            val encoder = MediaCodec.createByCodecName(avcCodec.codecInfo.name)
                            avcCandidate = encoder
                            encoder.configure(newFormat, null, null, MediaCodec.CONFIGURE_FLAG_ENCODE)
                            inputSurface = encoder.createInputSurface()
                            // 同上,编码器输出使用显式轮询模式,对齐 AZ 架构
                                encoder.start()
                                // v6.7.46: 启动一次性 request-sync,对齐 AZ Lfg/u->n
                                requestKeyFrame(encoder)
                                // 启动后立即读取一次输出格式以注册视频轨道
                                handleOutputFormatChanged()
                                videoEncoder = encoder
                                videoEncoderName = avcCodec.codecInfo.name
                                encoderReady.set(true)
                            success = true
                            logDetail("encoder_retry", "switched to AVC successfully")
                        } catch (e2: Exception) {
                            avcCandidate?.release()
                            lastError = e2
                            logDetail("encoder_retry_fail", "AVC retry error=${e2.message}")
                        }
                    }
                }
            }
        }

        if (!success) {
            videoEncoder?.release()
            videoEncoder = null
            inputSurface = null
            throw lastError ?: IllegalStateException("Failed to configure encoder")
        }
    }

    // v6.7.180: 锁屏状态打点入口,由 ScreenRecorderService 的屏幕状态接收器调用。
    // 只记录时刻、不改变任何编码/写入行为;累计时长在 RECORD_SUMMARY 汇报。
    fun markScreenLocked() {
        if (screenLockedAtMs < 0) {
            screenLockedAtMs = SystemClock.elapsedRealtime()
        }
    }

    fun markScreenUnlocked() {
        if (screenLockedAtMs >= 0) {
            screenLockedTotalMs += SystemClock.elapsedRealtime() - screenLockedAtMs
            screenLockedAtMs = -1
        }
    }

    private fun createVideoFormat(mime: String, width: Int, height: Int, fps: Int, bitrate: Int, bitrateMode: Int): MediaFormat {
        val format = MediaFormat.createVideoFormat(mime, width, height)
        format.setInteger(KEY_BIT_RATE, bitrate)
        format.setInteger(KEY_FRAME_RATE, fps)
        // v6.7.132: GOP 可配置(默认 120 帧,剪映 Hw.gop=120)。KEY_I_FRAME_INTERVAL 单位秒,
        // 按 GOP 帧数 / 帧率换算;fps<=0(Auto) 回退 1 秒。
        val gopSec = if (fps > 0) maxOf(1, QualityParams.bitrateScheduler().gopFrames / fps) else 1
        format.setInteger(KEY_I_FRAME_INTERVAL, gopSec)
        format.setInteger(KEY_COLOR_FORMAT, MediaCodecInfo.CodecCapabilities.COLOR_FormatSurface)
        format.setInteger(KEY_BITRATE_MODE, bitrateMode)
        // v6.7.163 (BUG-2): 设 KEY_MAX_FPS_TO_ENCODER=fps(仅 fps>0 非 Auto 时)。
        // 编码器在**编码前**丢弃快于 1/fps 的输入帧,引用链完好,不会花屏——与
        // repeat-previous-frame-after 的"按需拉取+补帧"是两种机制,后者 v6.7.13x 实测
        // 产生 dedup/drop 已移除,**仍然不设**;operating-rate 也继续不设。
        // v6.7.162 压缩模式实测(不设此键):目标 30fps,编码器照单全收 SF 投帧
        // 57~60fps(tearing_diag wall_avg≈17ms),全程 42fps,多编 40% 的帧=白发热,
        // 51°C 触发 runtime_frame_drop 降档——用户选 30fps 就该得 30fps。
        // 厂商 ROM 若忽略此键,行为=现状,无害。
        if (fps > 0) {
            try {
                format.setInteger(MediaFormat.KEY_MAX_FPS_TO_ENCODER, fps)
            } catch (_: Exception) {}
        }
        // v6.7.177 (增量C, 防御收口): 显式钉死 B帧=0。v6.7.62 PTS 单调钳制与 .idx(仅 pts+sync、
        // 重建 moov 无 ctts)均以「解码序=显示序」为不变量;个别厂商驱动默认插 B 时,单调钳制会
        // 静默抬高 B帧 pts 改坏时间轴、被杀修复文件播放序错乱。显式置 0 把前提钉死在配置,不赌
        // 驱动默认。B帧整体启用需同时满足 .idx v2(ctts) + 钳制改 DTS 单调 + kill-9 回归,当前冻结。
        try { format.setInteger(MediaFormat.KEY_MAX_B_FRAMES, 0) } catch (_: Exception) {}
        if (mime == MIME_VIDEO) {
            // v6.7.132: 画质 MAX——所有帧率档(含 144)统一 AVCProfileHigh(CABAC/8x8,
            // 同码率画质+10~20%)。v6.3.15 曾修 High 在 144 高负载下 surface 输入消费不稳
            // (旧注释),该风险由 ALLOW_HIGH_AT_HIGH_FPS 开关释放;发热由 runtime 降档兜底。
            // 若需回退 144 档 Baseline,置 ALLOW_HIGH_AT_HIGH_FPS=false。
            try {
                val profile = if (fps <= 60 || ALLOW_HIGH_AT_HIGH_FPS)
                    MediaCodecInfo.CodecProfileLevel.AVCProfileHigh
                else
                    MediaCodecInfo.CodecProfileLevel.AVCProfileBaseline
                format.setInteger(KEY_PROFILE, profile)
            } catch (_: Exception) {}
            // 报告"改动5"安全子集:写入色彩元数据 colr box(AVC/HEVC 均适用)。
            // MediaMuxer(API 24+)据此在文件写入 BT.709 色彩信息,纯元数据、
            // 不影响编码器输入 surface 消费,播放器颜色更正确。不设则播放器
            // 可能误判为 BT.601 导致偏色。只是声明,不强制转换,零回归风险。
            try {
                format.setInteger(MediaFormat.KEY_COLOR_STANDARD, MediaFormat.COLOR_STANDARD_BT709)
            } catch (_: Exception) {}
            try {
                format.setInteger(MediaFormat.KEY_COLOR_TRANSFER, MediaFormat.COLOR_TRANSFER_SDR_VIDEO)
            } catch (_: Exception) {}
            // v6.7.130: 色彩范围 full——屏幕内容源为 full range(0-255),声明 limited
            // 会让播放器按 16-235 解码导致发灰,full 与内容一致。
            try {
                format.setInteger(MediaFormat.KEY_COLOR_RANGE, MediaFormat.COLOR_RANGE_FULL)
            } catch (_: Exception) {}
        }

        // v6.7.130: HEVC 分支显式 Main profile(兼容性最好的 HEVC 档)。
        // 此前不设,依赖编码器默认,设备间档位漂移不可控。
        if (mime == MIME_HEVC) {
            try {
                format.setInteger(KEY_PROFILE, MediaCodecInfo.CodecProfileLevel.HEVCProfileMain)
            } catch (_: Exception) {}
        }

        val caps = findCodecCapabilities(mime)
        if (caps != null) {
            clampToCapabilities(format, caps, width, height, fps, bitrate)
        }

        return format
    }

    // v6.7.95: 主动请求关键帧,对齐 AZ 6.9.10 Lfg/u->n() 的
    // MediaCodec.setParameters("request-sync"=0)。AZ 在录制启动与恢复时均调用,
    // 用于强制编码器立即输出关键帧,启动瞬间即恢复完整细节。
    // 与 i-frame-interval=1 叠加保证关键帧基础密度,不重复叠加周期请求开销。
    private fun requestKeyFrame(encoder: MediaCodec?) {
        try {
            if (encoder != null) {
                val bundle = android.os.Bundle()
                bundle.putInt("request-sync", 0)
                encoder.setParameters(bundle)
                logDetail("request_sync", "requested keyframe at start")
            }
        } catch (e: Throwable) {
            logDetail("request_sync", "failed: ${e.message}")
        }
    }

    // v6.7.161 (能力锚定): 问编码器"你能跑多少帧",而不是用跨机型魔法数拍脑袋。
    // 对齐必剪/剪映:能力锚定——getAchievableFrameRatesFor 拿该分辨率下真实可持续帧率上界。
    // 强机(编码器真能跑 60/120)返回真实上界,移除人工 50 天花板;弱机(本机实测 1280x2800 只 37~43)
    // 返回真实上界,目标设 ~43 而非追 50 只跑 37——更顺(不再持续掉帧)且更凉(不触发降档)。
    // 返回 0 表示查不到,调用方回退到纯魔法数上限。
    private fun achievableFps(width: Int, height: Int, caps: MediaCodecInfo.CodecCapabilities?): Int {
        val vc = caps?.videoCapabilities ?: return 0
        return try {
            vc.getAchievableFrameRatesFor(width, height)?.upper?.toInt()?.coerceAtLeast(0) ?: 0
        } catch (_: Exception) { 0 }
    }

    private fun findCodecCapabilities(mime: String): MediaCodecInfo.CodecCapabilities? {
        return try {
            val codecList = MediaCodecList(MediaCodecList.ALL_CODECS)
            for (codecInfo in codecList.codecInfos) {
                if (!codecInfo.isEncoder) continue
                if (!codecInfo.supportedTypes.contains(mime)) continue
                try {
                    val capabilities = codecInfo.getCapabilitiesForType(mime)
                    if (capabilities != null) return capabilities
                } catch (e: Exception) {
                    logDetail("codec_caps_skip", "codec=${codecInfo.name} mime=$mime err=${e.message}")
                }
            }
            null
        } catch (e: Throwable) {
            logDetail("codec_caps_error", "mime=$mime err=${e.message}")
            writeEmergencyLog("findCodecCapabilities failed: ${e.message ?: e.javaClass.name}", e)
            null
        }
    }

    private fun clampToCapabilities(format: MediaFormat, caps: MediaCodecInfo.CodecCapabilities, width: Int, height: Int, fps: Int, bitrate: Int) {
        val videoCaps = caps.videoCapabilities
        if (videoCaps == null) {
            logDetail("clamp", "no VideoCapabilities available")
            return
        }

        val supportedWidths = videoCaps.supportedWidths
        val supportedHeights = videoCaps.supportedHeights
        // v6.7.88 (Ch5.5): 等比缩放——宽高同因子,保持纵横比,再 alignDownTo 对齐。
        // 旧实现独立 clamp 宽高,会把 1920x1080 压成 1280x1080 之类的非 16:9 形变,
        // 编码后画面被横向拉伸。现按"两维都需落入支持区间"的最小公缩放因子同缩。
        if (supportedWidths != null && supportedHeights != null &&
            (!supportedWidths.contains(width) || !supportedHeights.contains(height))) {
            val minW = supportedWidths.lower
            val maxW = supportedWidths.upper
            val minH = supportedHeights.lower
            val maxH = supportedHeights.upper
            val scaleX = when {
                width > maxW -> maxW.toFloat() / width
                width < minW -> minW.toFloat() / width
                else -> 1f
            }
            val scaleY = when {
                height > maxH -> maxH.toFloat() / height
                height < minH -> minH.toFloat() / height
                else -> 1f
            }
            val scale = minOf(scaleX, scaleY)
            var cw = alignDownTo((width * scale).toInt(), 2)
            var ch = alignDownTo((height * scale).toInt(), 2)
            // 对齐后若跌破下限(缩放因子把值压到下限附近再向下取整),提到下限
            if (cw < minW) cw = minW
            if (ch < minH) ch = minH
            if (cw != width || ch != height) {
                logDetail("clamp_size", "$width x $height -> $cw x $ch (scale=$scale)")
                format.setInteger(MediaFormat.KEY_WIDTH, cw)
                format.setInteger(MediaFormat.KEY_HEIGHT, ch)
            }
        }

        val maxFrameRate = videoCaps.supportedFrameRates.upper
        if (fps > maxFrameRate) {
            logDetail("clamp_fps", "$fps -> $maxFrameRate")
            // 仅 clamp frame-rate。不再同步设置 max-fps-to-encoder / operating-rate,
            // 与 createVideoFormat 对齐 AZ(两键均不设)。
            format.setInteger(KEY_FRAME_RATE, maxFrameRate.toInt())
        }

        val maxBitrate = videoCaps.bitrateRange.upper
        if (bitrate > maxBitrate) {
            logDetail("clamp_bitrate", "$bitrate -> $maxBitrate")
            format.setInteger(KEY_BIT_RATE, maxBitrate.toInt())
        }

        logDetail("clamp_result", "width=${format.getInteger(MediaFormat.KEY_WIDTH)} " +
            "height=${format.getInteger(MediaFormat.KEY_HEIGHT)} " +
            "fps=${format.getInteger(KEY_FRAME_RATE)} " +
            "bitrate=${format.getInteger(KEY_BIT_RATE)}")
    }

    // v6.7.88 (Ch5.5): 向下对齐到 alignment 的整数倍(编解码器要求宽高偶数/16 倍)。
    private fun alignDownTo(value: Int, alignment: Int): Int {
        val remainder = value % alignment
        return if (remainder == 0) value else value - remainder
    }

    private fun selectBestVideoEncoder(preferHevc: Boolean): EncoderCandidate? {
        val candidates = listAllCodecCandidates()
        val scored = candidates.map { candidate ->
            val isHevc = candidate.contains("hevc", ignoreCase = true)
            val isHw = isHardwareEncoder(candidate)
            val isVendor = candidate.contains("vendor", ignoreCase = true) ||
                candidate.contains("omx.", ignoreCase = true) ||
                candidate.contains("c2.", ignoreCase = true)

            var score = 0
            if (isHw) score += 100
            if (isVendor) score += 50
            // v6.7.135: HEVC 加分仅当 preferHevc=true 生效;preferHevc=false 时反向压 -50,
            // 确保用户关闭 HEVC 开关时 AVC 明确胜出。旧逻辑 preferHevc=false 仍给 HEVC +50,
            // 高通硬编 HEVC=230 > AVC=180 恒胜出,useHevc 开关失效。压分后 HEVC=130 < AVC=180。
            if (isHevc) score += if (preferHevc) 200 else -50
            if (candidate.contains("qcom", ignoreCase = true)) score += 30
            if (candidate.contains("exynos", ignoreCase = true)) score += 30
            if (candidate.contains("mediatek", ignoreCase = true)) score += 30
            if (candidate.contains("google", ignoreCase = true)) score += 10

            val codecInfo = findCodecInfoByName(candidate)
            if (codecInfo != null) {
                EncoderCandidate(codecInfo, candidate, isHw, isVendor, isHevc, score)
            } else null
        }.filterNotNull()

        val sorted = scored.sortedByDescending { it.score }

        if (preferHevc) {
            val bitrate = config?.bitrate ?: DEFAULT_BITRATE
            if (bitrate > HEVC_PREFERRED_BITRATE_CAP) {
                logDetail("select_encoder", "bitrate $bitrate > ${HEVC_PREFERRED_BITRATE_CAP}, prefer AVC over HEVC")
                val avcCandidate = sorted.firstOrNull { !it.isHevc }
                if (avcCandidate != null) return avcCandidate
            }
        }

        return sorted.firstOrNull()
    }

    private fun isHardwareEncoder(name: String): Boolean {
        return !name.contains("omx.google.", ignoreCase = true) &&
            !name.contains("ffmpeg", ignoreCase = true) &&
            !name.contains("sw.", ignoreCase = true) &&
            !name.contains("software", ignoreCase = true)
    }

    private fun findCodecInfoByName(name: String): MediaCodecInfo? {
        return try {
            val codecList = MediaCodecList(MediaCodecList.ALL_CODECS)
            for (codecInfo in codecList.codecInfos) {
                if (codecInfo.name == name) return codecInfo
            }
            null
        } catch (e: Throwable) {
            logDetail("codec_info_error", "name=$name err=${e.message}")
            null
        }
    }

    private fun listAllCodecCandidates(): List<String> {
        val candidates = mutableListOf<String>()
        try {
            val codecList = MediaCodecList(MediaCodecList.ALL_CODECS)
            for (codecInfo in codecList.codecInfos) {
                if (!codecInfo.isEncoder) continue
                val name = codecInfo.name
                if (BLACKLIST_PATTERNS.any { name.contains(it, ignoreCase = true) }) continue
                val supportedTypes = codecInfo.supportedTypes
                if (supportedTypes.any { it.startsWith("video/") }) {
                    candidates.add(name)
                }
            }
        } catch (e: Throwable) {
            logDetail("codec_list_error", "${e.message}")
        }
        return candidates.distinct()
    }

    private fun getMimeForCodec(codecName: String): String {
        return if (codecName.contains("hevc", ignoreCase = true)) MIME_HEVC else MIME_VIDEO
    }

    private fun setupAudioCapture() {
        val cfg = config ?: return
        if (!cfg.useAudio) {
            logDetail("audio_setup", "audio disabled by config")
            return
        }

        // 主路径对齐 AZ 6.9.10:纯内录单轨。AZ 主录音路径全程无 mic,
        // mic 仅在 MediaRecorder 传统路径。internal 捕获成功即单轨;
        // 内录失败输出静音轨,不 fallback mic、不双路。MIXED 为独立增值开关,
        // 显式开启时走双路混音(internal + mic 均按 mono 采集,逐采样相加)。
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q && cfg.useInternalAudio) {
            val mixed = cfg.useInternalAudio && cfg.useMicAudio
            setupInternalAudioCapture(alsoMic = mixed, monoChannel = mixed)
            if (mixed) {
                logDetail("audio_setup", "MIXED mode: internal + mic dual-track mono mixdown")
            }
        } else if (cfg.useInternalAudio) {
            // Android 7/8/9 (API<29) 无 AudioPlaybackCapture,无法内录系统音频。
            // 按 AZ 主路径纯度:输出静音轨,提示用户,不混入环境音。
            logDetail("audio_setup",
                "internal audio requires API 29+, sdk=${Build.VERSION.SDK_INT}; audio muted (no system audio available)")
        } else {
            setupMicAudioCapture()
        }
    }

    private fun setupInternalAudioCapture(alsoMic: Boolean = false, monoChannel: Boolean = false) {
        if (Build.VERSION.SDK_INT < Build.VERSION_CODES.Q) {
            logDetail("internal_audio", "requires API 29+, not capturing internal audio")
            return
        }

        val projection = mediaProjection
            ?: throw IllegalStateException("MediaProjection required for internal audio")

        // v6.7.110 (MIXED): MIXED 混音为逐采样相加(见采集循环 2044-2055),两路声道数必须一致。
        // mic 侧固定 CHANNEL_IN_MONO,故 MIXED 时 internal 也按 mono 构建,保证混音不错位;
        // 非 MIXED 保持原 STEREO 请求。
        val internalChannelMask = if (monoChannel) AudioFormat.CHANNEL_IN_MONO else AudioFormat.CHANNEL_IN_STEREO
        val audioFormat = AudioFormat.Builder()
            .setEncoding(AUDIO_PCM_FORMAT)
            .setSampleRate(AUDIO_SAMPLE_RATE)
            .setChannelMask(internalChannelMask)
            .build()

        val minBufferSize = AudioRecord.getMinBufferSize(
            AUDIO_SAMPLE_RATE,
            internalChannelMask,
            AUDIO_PCM_FORMAT
        ) * AUDIO_BUFFER_SIZE_MULTIPLIER

        // 华为 GLA-AL00 等设备 addMatchingUsage 含 VOICE_COMMUNICATION/UNKNOWN 时,
        // AudioRecord.build() 注册 AudioPolicy 会抛 RuntimeException("could not register audio policy"),
        // 导致整个内录静音。这里做链式降级:优先全量 usage,失败逐级去掉 usage 重试,
        // 至少保住 MEDIA/GAME 的系统内录;全部失败才走 mic 回退/静音。
        audioRecord = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
            buildPlaybackAudioRecord(
                projection, audioFormat, minBufferSize,
                // AZ 6.9.10 实证 usage = 1/0/14 (MEDIA=1, UNKNOWN=0, GAME=14)。
                // 去 VOICE_COMMUNICATION 档:其在部分设备触发 register audio policy 失败。
                // 主路径以 AZ 的 MEDIA_GAME_UNKNOWN 为首选。
                listOf(
                    USAGE_SET_MEDIA_GAME_UNKNOWN,
                    USAGE_SET_MEDIA_GAME,
                    USAGE_SET_MEDIA
                )
            )
        } else {
            null
        }

        if (audioRecord == null) {
            // AZ 主路径纯内录:创建失败输出静音轨,不 fallback mic、不双路。
            // mic 回退仅存在于独立 mic 场景,不在此处混入。
            logDetail("internal_audio", "AudioRecord creation failed, audio muted (AZ pure-internal, no mic fallback)")
            return
        }

        audioRecord?.startRecording()
        logDetail("internal_audio", "started internal audio capture")

        // v6.7.44: 注册 AudioManager.AudioRecordingCallback,让系统告知音频流集合变化
        // (流新增/移除),供休眠探测判断"是否有媒体流"。AZ(Leg/Lfg/d->E) 亦在 PlaybackCapture
        // 建后挂回调,流恢复时立刻重采。API 29+,失败仅记日志不阻断主流程;探测路径以
        // audioStreamState 为参考。
        // 注意:实际回调类是 AudioManager.AudioRecordingCallback(不是 AudioRecord 的子类),
        // registerAudioRecordingCallback(Executor, AudioManager.AudioRecordingCallback) 用
        // HandlerExecutor 把回调投递到 audioCaptureHandler 线程,避免跨线程竞争。
        try {
            val cb = internalAudioRecordingCallback ?: object : android.media.AudioManager.AudioRecordingCallback() {
                override fun onRecordingConfigChanged(configs: List<android.media.AudioRecordingConfiguration>?) {
                    val hasStream = configs != null && configs.size > 0
                    val newState = if (hasStream) 2 else 1
                    if (newState != audioStreamState) {
                        audioStreamState = newState
                        logDetail("audio_stream_state",
                            "onRecordingConfigChanged size=${configs?.size} -> hasStream=$hasStream " +
                            "(state=2 有流/1 无流)")
                        // 流从"无"到"有"时,若处于休眠探测模式,主动触发一次探测(下一 tick 会读)
                        if (hasStream && audioGiveUp) {
                            audioProbeLastNs = 0L
                            logDetail("audio_stream_state", "stream resumed, probing immediately")
                        }
                    }
                }
            }.also { internalAudioRecordingCallback = it }
            val executor = java.util.concurrent.Executors.newSingleThreadExecutor().also {
                // 用 ExecutorService 把回调投到独立线程,避免阻塞主采集线程
                // (registerAudioRecordingCallback 需 Executor,不能直接传 Handler)
            }
            internalAudioExecutor?.shutdown()
            internalAudioExecutor = executor
            audioRecord?.registerAudioRecordingCallback(executor, cb)
            logDetail("internal_audio", "AudioRecordingCallback registered (via Executor)")
        } catch (e: Exception) {
            logDetail("internal_audio", "registerAudioRecordingCallback failed: ${e.message}")
        }

        // v6.7.43: AudioRecord 构建成功后读取 record.channelCount,记录实际声道数(1 mono 或 2 stereo)。
        // 华为 GLA-AL00 上虽请求 STEREO,但部分厂商 AudioPolicy 注册时可能强制降级为 mono(ch=1),
        // 此时编码器和所有 PCM 字节换算一律以 actualAudioChannelCount=1 为准;同时采集线程对 mono
        // 样本做 mono→stereo 复制,供编码器(可能已按 stereo 或按实际按 1 配置)消费。
        try {
            val ch = audioRecord?.channelCount ?: 2
            actualAudioChannelCount = ch.coerceAtLeast(1).coerceAtMost(2)
            logDetail("internal_audio",
                "record.channelCount=$ch -> actualAudioChannelCount=$actualAudioChannelCount (requested=STEREO)")
        } catch (_: Exception) {
            logDetail("internal_audio", "could not read record.channelCount, using actualAudioChannelCount=2")
        }

        // AudioPlaybackCapture 管道建立需要时间:给 200ms 预热让系统音频路由就绪,
        // 减少启动阶段连续零读导致 AUDIO_ONLY_SILENCE 的概率。
        // 该预热仅对首次 setup 有效,rebuild 时不阻塞采集线程。
        try {
            Thread.sleep(200)
        } catch (e: InterruptedException) {
            Thread.currentThread().interrupt()
        }

        // v6.7.110 (MIXED): 内录建好后、编码器配置与采集线程启动前补建 mic。
        // setupMicAudioCapture 内 audioRecord 已非 null,走其"只存 micAudioRecord 不分派线程"
        // 分支;此时 actualAudioChannelCount 已被 mic(CHANNEL_IN_MONO)统一为 1,
        // 与 internal(monoChannel=true)声道一致,采集循环 isDualMix 时逐采样相加不错位。
        if (alsoMic) {
            setupMicAudioCapture()
        }

        ensureAudioEncoder()
        startAudioCaptureThread()
    }

    /**
     * 用给定的 usage 集合尝试构建内部录音 AudioRecord。
     * @return 构建成功且已初始化的 AudioRecord;全部用法集合均失败返回 null(交由上层决定静音或 mic 回退)。
     */
    private fun buildPlaybackAudioRecord(
        projection: android.media.projection.MediaProjection,
        audioFormat: AudioFormat,
        minBufferSize: Int,
        usageSets: List<List<Int>>
    ): AudioRecord? {
        for (usageSet in usageSets) {
            try {
                val playbackConfig = AudioPlaybackCaptureConfiguration.Builder(projection)
                    .also { b -> usageSet.forEach { u -> b.addMatchingUsage(u) } }
                    .build()
                return AudioRecord.Builder()
                    .setAudioFormat(audioFormat)
                    .setBufferSizeInBytes(minBufferSize)
                    .setAudioPlaybackCaptureConfig(playbackConfig)
                    .build().also { r ->
                        // 日志强化A层: 内录构建参数一次性 dump(与 AZ 的 44100/STEREO 比对)
                        logDetail("internal_audio",
                            "built sr=${AUDIO_SAMPLE_RATE} requested=STEREO(16bit) " +
                            "buf=${r.bufferSizeInFrames}frames usage=$usageSet " +
                            "actual_ch=${r.channelCount}")
                    }
            } catch (e: Throwable) {
                logDetail(
                    "internal_audio",
                    "build failed (usage=$usageSet) : ${e.javaClass.simpleName}: ${e.message}"
                )
                // 短暂让出,避免瞬时系统音频策略争用时连续注册反而更容易失败
                try {
                    Thread.sleep(50)
                } catch (ie: InterruptedException) {
                    Thread.currentThread().interrupt()
                }
            }
        }
        return null
    }

    private fun setupMicAudioCapture() {
        val minBufferSize = AudioRecord.getMinBufferSize(
            AUDIO_SAMPLE_RATE,
            AudioFormat.CHANNEL_IN_MONO,
            AUDIO_PCM_FORMAT
        ) * AUDIO_BUFFER_SIZE_MULTIPLIER

        val micRecord = AudioRecord(
            MediaRecorder.AudioSource.MIC,
            AUDIO_SAMPLE_RATE,
            AudioFormat.CHANNEL_IN_MONO,
            AUDIO_PCM_FORMAT,
            minBufferSize
        )

        if (micRecord.state != AudioRecord.STATE_INITIALIZED) {
            logDetail("mic_audio", "AudioRecord initialization failed")
            micRecord.release()
            return
        }

        micRecord.startRecording()
        logDetail("mic_audio", "started mic audio capture")
        try {
            val ch = micRecord.channelCount
            actualAudioChannelCount = ch.coerceAtLeast(1).coerceAtMost(2)
            logDetail("mic_audio", "mic channelCount=$ch -> actualAudioChannelCount=$actualAudioChannelCount")
        } catch (_: Exception) {
            actualAudioChannelCount = 1
        }

        // 如果已有 internal AudioRecord（MIXED 模式），只存 micAudioRecord 不分派线程
        if (audioRecord != null) {
            micAudioRecord = micRecord
            return
        }

        // 单路 mic-only：接管 audioRecord + 创建编码器 + 启动线程
        audioRecord = micRecord
        ensureAudioEncoder()
        startAudioCaptureThread()
    }

    /**
     * 运行中懒创建 mic AudioRecord，用于内部音频长期失效时的实时 fallback。
     * 仅在 mic 尚未存在且未尝试过时创建，避免每次零读循环都重复尝试。
     * 返回创建成功的 record，失败或无权限返回 null（保持静音，不混入环境音）。
     */
    private fun lazyCreateMicRecord(): AudioRecord? {
        if (micAudioRecord != null) return micAudioRecord
        if (micFallbackAttempted) return null
        micFallbackAttempted = true
        val granted = try {
            context.checkSelfPermission(android.Manifest.permission.RECORD_AUDIO) ==
                android.content.pm.PackageManager.PERMISSION_GRANTED
        } catch (e: Throwable) {
            false
        }
        if (!granted) {
            logDetail("mic_audio", "mic fallback skipped: RECORD_AUDIO not granted")
            return null
        }
        val minBufferSize = AudioRecord.getMinBufferSize(
            AUDIO_SAMPLE_RATE,
            AudioFormat.CHANNEL_IN_MONO,
            AUDIO_PCM_FORMAT
        ) * AUDIO_BUFFER_SIZE_MULTIPLIER
        val micRecord = try {
            AudioRecord(
                MediaRecorder.AudioSource.MIC,
                AUDIO_SAMPLE_RATE,
                AudioFormat.CHANNEL_IN_MONO,
                AUDIO_PCM_FORMAT,
                minBufferSize
            )
        } catch (e: Throwable) {
            logDetail("mic_audio", "mic fallback creation failed: ${e.message}")
            null
        }
        if (micRecord == null || micRecord.state != AudioRecord.STATE_INITIALIZED) {
            logDetail("mic_audio", "mic fallback initialization failed")
            micRecord?.release()
            return null
        }
        try {
            micRecord.startRecording()
        } catch (e: Throwable) {
            logDetail("mic_audio", "mic fallback start failed: ${e.message}")
            micRecord.release()
            return null
        }
        micAudioRecord = micRecord
        logDetail("mic_audio", "lazily created mic AudioRecord for internal fallback")
        return micRecord
    }

    private fun ensureAudioEncoder() {
        if (audioEncoder != null) return
        val encoderMime = MediaFormat.MIMETYPE_AUDIO_AAC
        val encoder = MediaCodec.createEncoderByType(encoderMime)
        // v6.7.43: 编码器 KEY_CHANNEL_COUNT 取 AudioRecord 实际声道数,而非写死 stereo。
        // 保证编码器和采集端声道一致,消除 PCM 帧长/声道错位导致静音。
        val channels = actualAudioChannelCount
        val audioFormat = MediaFormat.createAudioFormat(encoderMime, AUDIO_SAMPLE_RATE, channels)
        audioFormat.setInteger(KEY_BIT_RATE, AUDIO_BIT_RATE)
        audioFormat.setInteger(KEY_AAC_PROFILE, MediaCodecInfo.CodecProfileLevel.AACObjectLC)
        audioFormat.setInteger(KEY_MAX_INPUT_SIZE, 8192)
        encoder.configure(audioFormat, null, null, MediaCodec.CONFIGURE_FLAG_ENCODE)
        encoder.start()
        this.audioEncoder = encoder
        audioEncoderName = encoder.name
        logDetail("audio_encoder", "created encoder=${encoder.name} channels=$channels")
    }

    private fun startAudioCaptureThread() {
        // 采集线程:读 AudioRecord + 混音,写入 captureQueue
        audioThread = HandlerThread("AudioCaptureThread", Process.THREAD_PRIORITY_URGENT_AUDIO)
        audioThread?.start()
        if (audioThread == null || audioThread!!.looper == null) {
            throw IllegalStateException("AudioCaptureThread start failed")
        }
        audioCaptureHandler = Handler(audioThread!!.looper)

        audioEncodeThread = HandlerThread("AudioEncodeThread", Process.THREAD_PRIORITY_MORE_FAVORABLE)
        audioEncodeThread?.start()
        if (audioEncodeThread == null || audioEncodeThread!!.looper == null) {
            throw IllegalStateException("AudioEncodeThread start failed")
        }
        audioEncodeHandler = Handler(audioEncodeThread!!.looper)

        // drain 线程:读音频编码器输出,写入 muxer
        audioDrainRunning = true
        audioDrainThread = Thread {
            while (audioDrainRunning && !forceStop.get()) {
                try {
                    drainAudioEncoder(false)
                } catch (e: Throwable) {
                    if (isRunning.get()) {
                        logDetail("audio_drain_thread_error", "${e.message}")
                    }
                }
                Thread.sleep(2)
            }
        }.also { it.name = "AudioDrainThread"; it.start() }

        // 启动编码线程:从 encoderQueue 消费 PCM 数据,送入 AAC 编码器
        audioEncodeHandler?.post {
            val encoder = audioEncoder ?: return@post
            val inputBuffers = encoder.inputBuffers
            val encoderQueueLocal = encoderQueue

            while (isRunning.get() && !forceStop.get()) {
                try {
                    if (isPaused.get()) {
                        Thread.sleep(10)
                        continue
                    }
                    // v6.7.91 (A-1): 从 encoderQueue 取 AudioChunk(PCM+PTS 打包),
                    // ptsUs 一定有效,无需判 -1(旧实现的"先数据后 PTS"竞态窗口已消除)。
                    val item = encoderQueueLocal.poll(50, java.util.concurrent.TimeUnit.MILLISECONDS)
                    if (item == null) continue
                    val data = item.bytes
                    val ptsUs = item.ptsUs

                    val adjustedPts = if (firstInputAudioPtsUs.get() < 0) {
                        firstInputAudioPtsUs.getAndSet(ptsUs)
                        logDetail("audio_anchor", "firstAudioFrameTimeUs=$ptsUs (encode thread)")
                        0L
                    } else {
                        (ptsUs - firstInputAudioPtsUs.get()).coerceAtLeast(0L)
                    }

                    // 尽力把数据送入编码器
                    var pendingOffset = 0
                    var waitMs = 0
                    val PENDING_WAIT_MS = 50
                    while (pendingOffset < data.size) {
                        val inputBufferIndex = encoder.dequeueInputBuffer(0L)
                        if (inputBufferIndex < 0) {
                            if (waitMs >= PENDING_WAIT_MS) break
                            Thread.sleep(1)
                            waitMs++
                            continue
                        }
                        val inputBuffer = inputBuffers[inputBufferIndex]
                        inputBuffer.clear()
                        val size = minOf(data.size - pendingOffset, inputBuffer.capacity())
                        inputBuffer.put(data, pendingOffset, size)
                        inputBuffer.flip()

                        encoder.queueInputBuffer(inputBufferIndex, 0, size, adjustedPts + pendingOffset * 1_000_000L / (actualAudioChannelCount * 2 * AUDIO_SAMPLE_RATE), 0)
                        audioBytesWritten += size
                        pendingOffset += size
                        waitMs = 0
                        audioEncodeCount.incrementAndGet()
                    }
                } catch (e: Throwable) {
                    if (isRunning.get()) {
                        logDetail("audio_encode_error", "${e.message}")
                    }
                }
            }
        }

        val isDualMix = audioRecord != null && micAudioRecord != null && audioRecord !== micAudioRecord

        audioCaptureHandler?.post {
            val encoder = audioEncoder ?: return@post
            val bufferSize = (audioRecord ?: micAudioRecord)
                ?.let { it.bufferSizeInFrames * actualAudioChannelCount * 2 }
                ?.coerceAtLeast(4096) ?: 4096
            val pcmBuffer = ByteArray(bufferSize)

            // 双路混音:改用 ShortArray 直接读入,消除 byte 拆装(每采样 4 次位运算 -> 0 次)
            val internalShortBuf = if (isDualMix) ShortArray(bufferSize / 2) else null
            val micShortBuf = if (isDualMix) ShortArray(bufferSize / 2) else null

            val shortBuf = ShortArray(bufferSize / 2)

            // 单路内部音频连续 read 返回 0 的计数;超过阈值自动 fallback 到麦克风,
            // 避免内部音频无流时录音完全无声。
            var consecutiveZeroReads = 0
            val CONSECUTIVE_ZERO_READS_FAILOVER = 20
            var switchedToMic = false
            // 零读/零填充日志节流:至少间隔 5 秒打一条,避免无流时每秒几十条刷屏
            var lastZeroReadLogNs = 0L
            // reset 次数上限:连续零读时 stop+startRecording 只做有限次,仍无效则
            // 不再重建/重试,直接放弃内部音频:切 mic 或纯静音,避免 rebuild 空转死循环
            // (华为该设备 register policy 反复失败,重试无意义,只拖垮主线程)。上限 2。
            var zeroReadResets = 0
            val MAX_ZERO_READ_RESETS = 2
            // 内部音频已放弃标志:true 后不再 reset/rebuild,走 mic 或纯静音。
            var zeroReadGaveUp = false

            // 自适应策略运行时状态（adaptiveLevel 从实例字段恢复，实现跨录制持久化）
            // adaptiveHealthHistory 等运行时状态保留局部变量（不需持久化）
            val adaptiveHealthHistory = IntArray(ADAPTIVE_WINDOW_LOOKBACK) { 0 }
            var adaptiveHealthIdx = 0
            var adaptiveTotalWindows = 0
            // 自适应 retry 辅助函数:按当前等级逐级等待+read,返回读到的字节数或 -1
            fun adaptiveRetryRead(singleRecord: android.media.AudioRecord?, pcmBuffer: ByteArray): Int {
                val waits = ADAPTIVE_RETRY_WAIT_MS[adaptiveLevel] ?: longArrayOf(2, 21)
                for (waitMs in waits) {
                    Thread.sleep(waitMs)
                    val ret = try {
                        singleRecord?.read(pcmBuffer, 0, pcmBuffer.size, AudioRecord.READ_NON_BLOCKING) ?: -1
                    } catch (e: Throwable) { -1 }
                    if (ret > 0) return ret
                }
                return -1
            }

            // 单路模式下的实际 AudioRecord 引用:主路径纯内录单轨。
            // fallbackToMic 门控:主路径(useInternalAudio=true)恒为 false,
            // 对齐 AZ 纯内录——内录持续零读/零填充只注入静音,不切 mic、不双路。
            // mic 仅用于独立的纯 mic 场景(useInternalAudio=false)。
            val fallbackToMic = !(config?.useInternalAudio == true) && (config?.useMicAudio == true)
            val initialSingleRecord: android.media.AudioRecord? =
                if (!isDualMix) (audioRecord ?: micAudioRecord) else null
            var singleRecord = initialSingleRecord

            // 音频时钟速率诊断:统计静音注入/真实数据字节 vs 墙钟流逝,
            // 周期上报音频时钟实际推进速率,用于定位音画内容错位
            // (若速率显著 >1 则静音注入让音频时钟超墙钟,声音被撑长/拉长)。
            var capStatStartNs = System.nanoTime()
            var capStatStartBytes = audioStreamBytes
            var capStatStartFrame = audioOutputFrameCount
            var capStatRealBytes = 0L
            var capStatRealChunks = 0L
            var capStatSilentChunks = 0L
            var capStatZeroChunks = 0L
            var capStatDroppedChunks = 0L

            while (isRunning.get() && !forceStop.get()) {
                try {
                    if (isPaused.get()) {
                        Thread.sleep(10)
                        continue
                    }

                    // v6.7.44: 休眠探测分支。进入 give_up 状态(zeroReadGaveUp=true)后不再永久放弃,
                    // 而是每 1s 用 singleRecord 做一次 non-blocking read,仅探测不编码;
                    // 若探测读到非零 PCM,立即 startRecording 恢复高频采集,清 give_up 标志。
                    // AudioStreamState 由 registerAudioRecordingCallback 回调驱动,
                    // 若为 STATE_RECORDING(2) 且媒体流恢复,优先走真实采集。
                    if (zeroReadGaveUp && singleRecord != null) {
                        val probeNowNs = System.nanoTime()
                        val sinceLastProbeMs = (probeNowNs - audioProbeLastNs) / 1_000_000L
                        if (sinceLastProbeMs >= 1000L || audioProbeLastNs == 0L) {
                            audioProbeLastNs = probeNowNs
                            // 探测前置:尝试用 AudioRecord.startRecording 重新激活(AZ 语义:流恢复即重建)
                            // 若 AudioRecord 因焦点丢失被 stop(),此处拉回 RECORDING 状态。
                            try {
                                if (singleRecord.recordingState != AudioRecord.RECORDSTATE_RECORDING) {
                                    singleRecord.startRecording()
                                }
                            } catch (_: Exception) {}
                            // 探测读:non-blocking,只读一小段,不消费真实数据
                            val probeBuf = ByteArray(4096)
                            val probeRead = try {
                                singleRecord.read(probeBuf, 0, probeBuf.size, AudioRecord.READ_NON_BLOCKING)
                            } catch (_: Throwable) { -1 }
                            val probeHasNonZero = probeRead > 0 && probeBuf.any { it != 0.toByte() }
                            val probeBytesToEncode = if (probeHasNonZero) {
                                0
                            } else {
                                val maybeSilence = maybeInjectSilence(pcmBuffer, silenceFrameBytes)
                                if (maybeSilence) silenceFrameBytes else 0
                            }
                            if (probeHasNonZero) {
                                // 探测命中:视为媒体流恢复,立即切换回高频采集模式
                                consecutiveZeroReads = 0
                                zeroReadGaveUp = false
                                audioGiveUp = false
                                statGiveUp.incrementAndGet()
                                logDetail("audio_record_probe_resume",
                                    "probe detected non-zero PCM after ${sinceLastProbeMs}ms, " +
                                    "resuming capture streamState=$audioStreamState " +
                                    "probeBytes=$probeRead")
                                lastAudioDataNs = System.nanoTime()
                                // 让下一轮走正常采集路径(isDualMix/singleRecord 判断)
                                continue
                            }
                            // 探测未命中:媒体流仍空,注入静音推进 PTS
                            if (probeBytesToEncode > 0) {
                                val ptsUs = calculateAudioPts().coerceAtLeast(lastAudioPtsOutUs)
                                // v6.7.91 (A-1): PCM+PTS 打包原子入队,消除竞态窗口。
                                val enqueued = encoderQueue.offer(
                                    AudioChunk(pcmBuffer.copyOf(probeBytesToEncode), ptsUs))
                                audioCaptureTotalChunks.incrementAndGet()
                                audioFramePts.set(ptsUs)
                                audioCaptureCount.incrementAndGet()
                                capStatSilentChunks++
                                audioStreamBytes += probeBytesToEncode.toLong()
                                // v6.7.95 (改进1): 静音注入也累加采样数,保持理论层连续性。
                                audioSampleCount += probeBytesToEncode.toLong() / (actualAudioChannelCount * 2L)
                            }
                            // 休眠到下一 tick
                            Thread.sleep(silenceFrameSleepMs)
                            continue
                        } else {
                            // 未到 1s,快速 sleep 避免空转
                            Thread.sleep(50)
                            continue
                        }
                    }
                    // v6.7.47: 移除"焦点 gain 触发重建"分支——音频焦点抢占机制已整体删除
                    // (见 registerAudioFocus 移除说明),audioRecord 的恢复由下方探测自愈
                    // (检测非零 PCM 自动 resume)与 AudioRecordingCallback 驱动,不再依赖焦点信号。

                    // v6.7.142(优化5): 改 var,允许 DEAD_OBJECT 重建后刷新局部引用。
                    var internalRecord = if (isDualMix) audioRecord else null
                    var micRecord = if (isDualMix) micAudioRecord else null

                    var realDataRead = false
                    var bytesToEncode = 0

                    if (isDualMix && internalRecord != null && micRecord != null) {
                        // 双路混音:ShortArray 直接读入 + 直接操作,消除 byte 拆装
                        // v6.7.142(优化5·退避): 引用永不置空,失败只记退避时刻。
                        // 双录入口条件要求两轨都非空;置空任一轨会让整段落到"无采集源"分支,
                        // 连带掐掉健康轨。改为"退避期内跳过 read(该轨静音),到期重试"。
                        var internalShorts = 0
                        val internalRetryDue = internalTrackRetryAfterMs == 0L
                            || android.os.SystemClock.elapsedRealtime() >= internalTrackRetryAfterMs
                        if (internalRetryDue) {
                            internalShorts = try {
                                internalRecord.read(internalShortBuf!!, 0, internalShortBuf.size, AudioRecord.READ_NON_BLOCKING)
                            } catch (e: Throwable) { -1 }
                            if (internalShorts == android.media.AudioRecord.ERROR_DEAD_OBJECT) {
                                logDetail("dual_audio_dead_object", "internal track dead, rebuilding")
                                val rebuilt = runCatching { rebuildInternalAudioRecord() }.getOrNull()
                                if (rebuilt != null) {
                                    audioRecord = rebuilt
                                    internalRecord = rebuilt
                                    internalTrackRetryAfterMs = 0L
                                    logDetail("dual_audio_dead_object", "internal rebuilt ok")
                                } else {
                                    internalTrackRetryAfterMs =
                                        android.os.SystemClock.elapsedRealtime() + DUAL_AUDIO_REBUILD_RETRY_MS
                                    logDetail("dual_audio_dead_object", "internal rebuild failed, back off ${DUAL_AUDIO_REBUILD_RETRY_MS}ms")
                                }
                                internalShorts = 0
                            } else if (internalShorts < 0) {
                                internalShorts = 0
                            }
                        }
                        var micShorts = 0
                        val micRetryDue = micTrackRetryAfterMs == 0L
                            || android.os.SystemClock.elapsedRealtime() >= micTrackRetryAfterMs
                        if (micRetryDue) {
                            micShorts = try {
                                micRecord.read(micShortBuf!!, 0, micShortBuf.size, AudioRecord.READ_NON_BLOCKING)
                            } catch (e: Throwable) { -1 }
                            if (micShorts == android.media.AudioRecord.ERROR_DEAD_OBJECT) {
                                logDetail("dual_audio_dead_object", "mic track dead, rebuilding")
                                val rebuilt = runCatching { rebuildMicAudioRecord() }.getOrNull()
                                if (rebuilt != null) {
                                    micAudioRecord = rebuilt
                                    micRecord = rebuilt
                                    micTrackRetryAfterMs = 0L
                                    logDetail("dual_audio_dead_object", "mic rebuilt ok")
                                } else {
                                    micTrackRetryAfterMs =
                                        android.os.SystemClock.elapsedRealtime() + DUAL_AUDIO_REBUILD_RETRY_MS
                                    logDetail("dual_audio_dead_object", "mic rebuild failed, back off ${DUAL_AUDIO_REBUILD_RETRY_MS}ms")
                                }
                                micShorts = 0
                            } else if (micShorts < 0) {
                                micShorts = 0
                            }
                        }

                        // v6.7.95 (改进3): 静音自检——双路路径分别统计 internal/output 总数与静音数
                        audioSilenceInternalTotal.incrementAndGet()
                        if (internalShorts <= 0) {
                            audioSilenceInternalSilent.incrementAndGet()
                        }
                        audioSilenceOutputTotal.incrementAndGet()
                        if (micShorts <= 0) {
                            audioSilenceOutputSilent.incrementAndGet()
                        }

                        if (internalShorts > 0) realDataRead = true
                        if (micShorts > 0) realDataRead = true
                        if (internalShorts <= 0 && micShorts <= 0) {
                            // v6.7.57: 双路均无数据时如实跳过,不注入静音覆盖真实采样
                            bytesToEncode = 0
                            Thread.sleep(2)
                        } else {
                            val mixShorts = when {
                                internalShorts > 0 && micShorts > 0 -> minOf(internalShorts, micShorts)
                                internalShorts > 0 -> internalShorts
                                else -> micShorts
                            }
                            val hasInternal = internalShorts > 0
                            val hasMic = micShorts > 0
                            // AZ 6.9.9 风格:ShortArray 逐采样直接相加(非平均,保留响度),
                            // 单路存在则只用一路,结果 clamp 到 [-32768, 32767] 防削波。
                            // 相较于浮点增益 + 0.5 平均,直接相加保留更多动态范围,
                            // 适合内录+麦克风场景下两路声音叠加的自然响度。
                            for (i in 0 until mixShorts) {
                                val s1 = if (hasInternal) internalShortBuf!![i] else 0
                                val s2 = if (hasMic) micShortBuf!![i] else 0
                                val mixed = if (hasInternal && hasMic) {
                                    (s1.toInt() + s2.toInt()).coerceIn(Short.MIN_VALUE.toInt(), Short.MAX_VALUE.toInt()).toShort()
                                } else if (hasInternal) {
                                    (s1.toFloat() * internalVolume).toInt().coerceIn(Short.MIN_VALUE.toInt(), Short.MAX_VALUE.toInt()).toShort()
                                } else {
                                    (s2.toFloat() * micVolume).toInt().coerceIn(Short.MIN_VALUE.toInt(), Short.MAX_VALUE.toInt()).toShort()
                                }
                                shortBuf[i] = mixed
                            }
                            // 批量将 ShortArray 转成 ByteArray 写入 pcmBuffer
                            var writePos = 0
                            for (i in 0 until mixShorts) {
                                val v = shortBuf[i].toInt()
                                pcmBuffer[writePos++] = (v and 0xFF).toByte()
                                pcmBuffer[writePos++] = ((v shr 8) and 0xFF).toByte()
                            }
                            bytesToEncode = mixShorts * 2
                        }
                    } else if (singleRecord != null) {
                        // v6.7.57: 单录路径回归 AZ 朴素策略 + 部分读取续读。
                        // AudioRecord 读到什么(含全零静音帧)直接入队编码,PTS 按实际读取字节数
                        // (采样计数)推进,严禁零填充冒充数据。read() 返回值不足请求帧数时
                        // 在有限时间预算内循环续读直至填满(或无更多数据),避免部分读取被漏采,
                        // 也不因零填充虚增 PTS 帧数。
                        // v6.7.83 (问题A 根治丢采样): 旧实现 3ms 预算 + READ_NON_BLOCKING,
                        // 遇空(内部 buffer 暂空)read 立即返回 0 就 break。PTP-AN70 上每块
                        // pcmBuffer=12288B=3072 帧=69.7ms,但预算仅 3ms(差 23 倍),实测每次
                        // 恒定只读 4096B(请求量 1/3),partialReads 2581/2585(99.85%),累计
                        // 丢采样 3.25%,末尾被迫补 370489B(2.10 秒)静音,音画持续漂移+2455ms。
                        // 改 READ_BLOCKING:阻塞到读满/被 stop 打断,采集节奏跟随音频真实速率,
                        // 不漏采。预算放大到"这块音频自身时长×1.5+20ms"作安全网,防畸形卡死。
                        // 停止时 audioRecord.stop() 会打断阻塞读,故不会挂死采集线程。
                        // v6.7.140-补(方案4): rec 是本 tick 的本地非空句柄,DEAD_OBJECT 重建后
                        // 同步刷新 rec 与 singleRecord,保证下一次 read 不再指向已 release 的旧对象。
                        var rec: android.media.AudioRecord = singleRecord
                        val readStartNs = System.nanoTime()
                        var totalRead = 0
                        var readErr = false
                        var iterCount = 0
                        val blockMs = bufferSize * 1000L / (2 * 2 * AUDIO_SAMPLE_RATE)
                        val readDeadlineNs = readStartNs + (blockMs * 3 / 2 + 20L) * 1_000_000L
                        while (totalRead < pcmBuffer.size && System.nanoTime() < readDeadlineNs) {
                            val ret = try {
                                rec.read(
                                    pcmBuffer, totalRead, pcmBuffer.size - totalRead,
                                    AudioRecord.READ_BLOCKING
                                )
                            } catch (e: Throwable) { -1 }
                            if (ret > 0) {
                                totalRead += ret
                                iterCount++
                            } else if (ret == 0) {
                                // BLOCKING 下较少出现;保留兜底防死循环
                                break
                            } else if (ret == android.media.AudioRecord.ERROR_DEAD_OBJECT) {
                                // v6.7.140-补(方案4): AudioRecord 已死亡(蓝牙/来电切换等),
                                // 重建并刷新局部引用 rec/singleRecord,重建才真正生效。
                                logDetail("audio_dead_object", "AudioRecord dead, rebuilding")
                                val rebuilt = runCatching { rebuildAudioRecord(rec) }.getOrNull()
                                if (rebuilt != null) {
                                    rec = rebuilt
                                    singleRecord = rebuilt
                                    logDetail("audio_dead_object", "rebuilt ok, record refreshed")
                                } else {
                                    // v6.7.142(优化1/2): 重建失败:置 readErr 使故障走 readErr 分支显式告警
                                    // (audioReadErrorCount + audio_read_error),不再被静音吞;
                                    // singleRecord=null 同步切走无采集源分支。
                                    singleRecord = null
                                    readErr = true
                                    logDetail("audio_dead_object", "rebuild failed, singleRecord=null (read error)")
                                }
                                break
                            } else {
                                readErr = true
                                break
                            }
                        }
                        val readElapsedMs = (System.nanoTime() - readStartNs) / 1_000_000L
                        // v6.7.142(优化1): readErr 时 rec 可能已 release,跳过 stop/startRecording,避免对死对象操作。
                        if (readElapsedMs > 500 && !readErr) {
                            logDetail("audio_read_warn", "read blocked ${readElapsedMs}ms, resetting AudioRecord")
                            try {
                                rec.stop()
                                rec.startRecording()
                            } catch (e: Exception) {
                                logDetail("audio_reset_error", "${e.message}")
                            }
                        }
                        // 部分读取诊断:单次未填满 buffer 即停止(或续读后仍未满)都算部分读取,
                        // 记录 bytesRead/请求 供跨机型对照(PTP-AN70 每次 4096 vs GLA 满 buffer)。
                        if (totalRead > 0) {
                            if (totalRead < pcmBuffer.size) {
                                partialReadCount.incrementAndGet()
                                val nowNs = System.nanoTime()
                                if (nowNs - lastPartialLogNs > 5_000_000_000L) {
                                    lastPartialLogNs = nowNs
                                    logDetail("audio_read_partial",
                                        "got=${totalRead}B requested=${pcmBuffer.size}B iters=$iterCount")
                                }
                            }
                            bytesToEncode = totalRead
                            consecutiveZeroReads = 0
                            realDataRead = true
                            // v6.7.95 (改进3): 单路有数据,计入 output 总数(静音判定由后续全零检查负责)
                            audioSilenceOutputTotal.incrementAndGet()
                        } else if (readErr || totalRead < 0) {
                            // 真故障(错误码/异常):独立告警计数,不并入静音路径静默吞掉
                            audioReadErrorCount.incrementAndGet()
                            logDetail("audio_read_error",
                                "read error code=$totalRead consecutiveZeroReads=$consecutiveZeroReads")
                            bytesToEncode = 0
                            Thread.sleep(2)
                            // v6.7.95 (改进3): 单路故障计入 output 静音计数
                            audioSilenceOutputTotal.incrementAndGet()
                            audioSilenceOutputSilent.incrementAndGet()
                        } else {
                            // READ_NON_BLOCKING 本轮无数据:如实跳过,不注入静音覆盖
                            bytesToEncode = 0
                            consecutiveZeroReads++
                            // v6.7.113 (P0-1): 连续零读达阈值且 reset 已耗尽时置位 zeroReadGaveUp,
                            // 让休眠探测分支(1945-2009)生效。旧代码只声明了变量,从未赋值 true,
                            // 休眠探测路径完全死代码,内录长期静音时不会尝试恢复。
                            if (!zeroReadGaveUp && consecutiveZeroReads >= CONSECUTIVE_ZERO_READS_FAILOVER * 4
                                && zeroReadResets >= MAX_ZERO_READ_RESETS) {
                                zeroReadGaveUp = true
                                audioGiveUp = true
                                statGiveUp.incrementAndGet()
                                logDetail("audio_giveup",
                                    "zeroReadGaveUp=true after $consecutiveZeroReads consecutive zero reads, " +
                                        "resets=$zeroReadResets; entering probe mode")
                            }
                            Thread.sleep(2)
                            // v6.7.95 (改进3): 单路无数据计入 output 静音计数
                            audioSilenceOutputTotal.incrementAndGet()
                            audioSilenceOutputSilent.incrementAndGet()
                        }
                    } else {
                        // singleRecord 为 null(未创建/已被释放):无采集源,跳过本 tick
                        bytesToEncode = 0
                        Thread.sleep(2)
                    }

                    if (realDataRead) {
                        lastAudioDataNs = System.nanoTime()
                        audioSilenceInjected = false
                        audioSilenceBytes = 0L
                    }

                    // 追加本次采样到 captureQueue 缓冲:采集线程与编码线程解耦,
                    // 采集线程只管写入 captureQueue,编码线程从 encoderQueue 消费。
                    // 这种双缓冲队列架构(AZ 6.9.9 风格)防止采集抖动影响编码,
                    // 也防止编码器 input queue 满时阻塞采集线程。
                    if (bytesToEncode > 0) {
                        // v6.7.97 (改进3): 锚定音频首块真实数据的墙钟,供 calculateAudioPts
                        // 计算音视频首帧墙钟差,消除启动阶段固定偏差。
                        if (audioFirstCaptureRealtimeNs.get() < 0L) {
                            audioFirstCaptureRealtimeNs.set(System.nanoTime())
                        }
                        // v6.7.44: PTS 统一走墙钟映射(calculateAudioPts),对齐 AZ(Lfg/d->E)。
                        // v6.7.91 (A-1): PCM+PTS 打包成 AudioChunk 原子入队,
                        // 消除旧实现"先 offer 数据再 put PTS"的竞态(编码线程在两步间
                        // 被抢占时 ptsMap.get 返回 -1 -> 整 chunk 被 continue 丢弃)。
                        val ptsUs = calculateAudioPts().coerceAtLeast(lastAudioPtsOutUs)
                        // 有界队列 offer 不带阻塞语义,满则返回 false;
                        // 满即编码线程消费滞后,此时丢弃本块由静音/后续补齐兜底,
                        // 避免采集端无限堆积(旧 captureQueue 只增不减导致积压虚报)。
                        val enqueued = encoderQueue.offer(
                            AudioChunk(pcmBuffer.copyOf(bytesToEncode), ptsUs))
                        audioCaptureTotalChunks.incrementAndGet()
                        if (!enqueued) {
                            capStatDroppedChunks++
                            logDetail("audio_queue_full", "encoderQueue full, dropped ${bytesToEncode}B")
                        }
                        audioFramePts.set(ptsUs)
                        audioCaptureCount.incrementAndGet()
                        audioLastCaptureNs.set(System.nanoTime())

                        // 诊断累计:区分真实数据与静音补位样本量/块数。
                        // 供 audio_cap_stat 判别"真实数据是否充足"与"静音注入是否超速"。
                        if (realDataRead) {
                            capStatRealBytes += bytesToEncode
                            capStatRealChunks++
                            // v6.7.57: 真实非零采样字节统计——区分"读到真实采样"与"读到全零"。
                            // 在 AZ 朴素策略下 bytesRead>0 即使内容为全零也会编码为静音帧,
                            // 该计数用于 PTP-AN70 区分假设A(真实数据被误判)与假设B(捕获交付全零)。
                            val scanLen = minOf(bytesToEncode, pcmBuffer.size / 4)
                            var nz = 0
                            for (i in 0 until scanLen) {
                                if (pcmBuffer[i] != 0.toByte()) {
                                    nz++
                                    if (nz >= 8) break
                                }
                            }
                            if (nz > 0) {
                                capStatNonZeroBytes.addAndGet(bytesToEncode.toLong())
                                // v6.7.95 (改进3): 非零采样,output 不静音
                            } else {
                                // v6.7.94 (P2): "读成功但全零"的块。
                                // silentChunks 只统计 AudioRecord.read 返回 <=0 的读失败,
                                // 这里单独计数让"设备没出声"与"采集到数字零"在日志中可区分,
                                // 否则这类数字静音会一直 AUDIO_HEALTHY,只有扒文件才能发现
                                // (v6.7.90 5.6 秒静音尾巴就是这么漏过去的)。
                                capStatZeroChunks++
                                // v6.7.95 (改进3): 全零块计入 output 静音计数
                                audioSilenceOutputSilent.incrementAndGet()
                            }
                            // v6.7.95 (改进3): 单路路径有数据时计入 output 总数
                            audioSilenceOutputTotal.incrementAndGet()
                        } else {
                            capStatSilentChunks++
                        }
                        audioStreamBytes += bytesToEncode.toLong()
                        // v6.7.95 (改进1): 墙钟锚点制——每块 PCM 累加采样数,用于理论层 PTS 计算。
                        // 双声道:bytes/2=样本数(每样本2字节),再除以声道数得单声道样本数。
                        audioSampleCount += bytesToEncode.toLong() / (actualAudioChannelCount * 2L)
                        // v6.7.58: 采样率自校正(累计编码采样数 vs 墙钟流逝),消除 av_pts_delta 线性漂移
                        calibrateAudioSampleRate()
                    }

                    // 队列深度诊断:仅当编码待处理队列(有界)接近耗尽容量时输出积压日志,
                    // 有界队列 offer 失败即为真实背压;不再用只增不减的累计计数冒充积压。
                    val encoderQueueSize = encoderQueue.size
                    if (encoderQueueSize > 32) {
                        logDetail("audio_capture_backlog",
                            "encoderQueueSize=$encoderQueueSize totalChunks=$audioCaptureTotalChunks")
                    }
                } catch (e: Throwable) {
                    if (isRunning.get()) {
                        logDetail("audio_capture_error", "${e.message}")
                    }
                }

                // 周期诊断:音频时钟速率(每 5s 一次)。float 1.0 = 与墙钟 1:1
                // 对齐;>1 = 音频时钟快于墙钟(静音注入过度,声音被拉长);
                // <1 = 音频时钟慢(可能丢数据)。配合 streams/静音占比判断归因。
                val capNowNs = System.nanoTime()
                val capElapsedMs = (capNowNs - capStatStartNs) / 1_000_000L
                if (capElapsedMs >= 5000) {
                    val capStreamBytes = audioStreamBytes - capStatStartBytes
                    val capFrameDelta = audioOutputFrameCount - capStatStartFrame
                    val capStreamMs = capStreamBytes * 1000L / (actualAudioChannelCount * 2L * AUDIO_SAMPLE_RATE)
                    val capFrameMs = capFrameDelta * 1024L * 1000L / AUDIO_SAMPLE_RATE
                    val capSilenceInWindow = audioSilenceBytes
                    val streamRate = if (capElapsedMs > 0) capStreamMs.toFloat() / capElapsedMs else 1f
                    val frameRate = if (capElapsedMs > 0) capFrameMs.toFloat() / capElapsedMs else 1f
                    val realMs = capStatRealBytes * 1000L / (actualAudioChannelCount * 2L * AUDIO_SAMPLE_RATE)
                    val realRate = if (capElapsedMs > 0) realMs.toFloat() / capElapsedMs else 1f
                    // 判别命中标记:用回归样本自动判断最可能的场景,便于快速定位。
                    val slowNominal = frameRate <= 1.0f + 0.1f && frameRate >= 1.0f - 0.1f
                    val audioOverspeed = frameRate > 1.0f + 0.1f
                    val audioUnderspeed = frameRate < 1.0f - 0.1f
                    val noRealData = capStatRealChunks == 0L
                    val hitTag = when {
                        audioOverspeed && noRealData -> "AUDIO_PURE_SILENCE_OVERSPEED"
                        audioOverspeed && !noRealData -> "AUDIO_MIXED_OVERSPEED"
                        audioUnderspeed && !noRealData -> "AUDIO_REAL_UNDERSPEED"
                        audioUnderspeed && noRealData -> "AUDIO_NO_DATA_UNDERSPEED"
                        slowNominal && noRealData && realRate < 0.9f -> "AUDIO_ONLY_SILENCE"
                        slowNominal && realRate >= 0.9f -> "AUDIO_HEALTHY"
                        else -> "AUDIO_UNSTABLE"
                    }
                    // 学习态:当前音频 PTS 映射模式(clock=系统时钟基准 / frame=帧计数)
                    val learnState = if (audioStartRealtimeUs >= 0) "clock" else "frame"
                    // 对齐态:差异C 音频不再与视频 anchor 互锚,恒为独立墙钟
                    val alignState = "independent"
                    val encoderQueueSize = encoderQueue.size
                    logDetail("audio_cap_stat",
                        "hit=$hitTag winMs=$capElapsedMs streamMs=$capStreamMs " +
                            "streamRate=${"%.3f".format(streamRate)} " +
                            "frameMs=$capFrameMs frameRate=${"%.3f".format(frameRate)} " +
                            "realMs=$realMs realRate=${"%.3f".format(realRate)} " +
                            "realChunks=$capStatRealChunks silentChunks=$capStatSilentChunks " +
                            "zeroChunks=$capStatZeroChunks " +
                            "silenceBytes=$capSilenceInWindow streamBytesTotal=$audioStreamBytes " +
                            "adaptiveLevel=$adaptiveLevel " +
                            "learnState=$learnState alignState=$alignState " +
                            "encQueue=$encoderQueueSize droppedChunks=$capStatDroppedChunks " +
                            // v6.7.91 (A-1): ptsMap 字段已随 audioPtsMap 四件套删除,不再输出。
                            "totalChunks=$audioCaptureTotalChunks " +
                            "partialReads=${partialReadCount.get()} nonZeroBytes=${capStatNonZeroBytes.get()} " +
                            "sampleRate=$realAudioSampleRate measuredRate=$lastMeasuredSampleRate calibMs=$lastCalibElapsedMs")

                    // v6.7.189 (P2-12): 运行时静音告警。内部音频权限/ROM bug 的典型表现是
                    // 全程 nonZeroBytes 不增长,此前只有停止后的 audio_silence 一行,
                    // 用户录完才知道没声音。8s 无增量即告警一次。
                    run {
                        val nonZero = capStatNonZeroBytes.get()
                        val nowWarnMs = SystemClock.elapsedRealtime()
                        if (nonZero > lastNonZeroAudioBytes) {
                            lastNonZeroAudioBytes = nonZero
                            lastNonZeroAudioMs = nowWarnMs
                        } else if (lastNonZeroAudioMs > 0 && !silentWarned &&
                            nowWarnMs - lastNonZeroAudioMs > AUDIO_SILENT_WARN_MS) {
                            silentWarned = true
                            logDetail("audio_silent_warning",
                                "no non-zero audio for ${(nowWarnMs - lastNonZeroAudioMs) / 1000}s; " +
                                    "totalChunks=$audioCaptureTotalChunks zeroChunks=$capStatZeroChunks " +
                                    "nonZeroBytes=$nonZero ch=$actualAudioChannelCount")
                        }
                    }

                    // 对齐 AZ：不运行时动态调整 retry 等级，adaptiveLevel 固定为默认档。
                    // 仅保留 healthy/bad 统计供诊断（audio_adaptive_level 不再变更等级）。
                    adaptiveHealthHistory[adaptiveHealthIdx] = when (hitTag) {
                        "AUDIO_HEALTHY" -> 1
                        "AUDIO_UNSTABLE" -> 0
                        else -> -1
                    }
                    adaptiveHealthIdx = (adaptiveHealthIdx + 1) % ADAPTIVE_WINDOW_LOOKBACK
                    adaptiveTotalWindows++
                    if (adaptiveTotalWindows >= ADAPTIVE_WINDOW_LOOKBACK) {
                        val healthyCount = adaptiveHealthHistory.count { it == 1 }
                        val badCount = adaptiveHealthHistory.count { it == -1 }
                        logDetail("audio_adaptive_level",
                            "fixedLevel=$adaptiveLevel healthy=$healthyCount bad=$badCount (no adaptive change per AZ policy)")
                    }
                    capStatStartNs = capNowNs
                    capStatStartBytes = audioStreamBytes
                    capStatStartFrame = audioOutputFrameCount
                    capStatRealBytes = 0L
                    capStatRealChunks = 0L
                    capStatSilentChunks = 0L
                    capStatDroppedChunks = 0L
                }
            }

            // 停止前先停掉 drain 线程,避免 final flush/drain 期间与编码器并发操作
            audioDrainRunning = false
            try {
                audioDrainThread?.join(1000)
            } catch (e: InterruptedException) {
                // ignore
            }
            audioDrainThread = null

            // drain 一次阻塞模式,清空编码器输出队列释放 input buffer 空间,
            // 使后续 flush 时 dequeueInputBuffer 不因编码器输出满而阻塞超时。
            // v6.7.72: 此处必须传 endOfStream=false。传 true 会在 pad 静音与 flush
            // backlog 之前就向编码器送入 EOS,导致后续 flush 的 dequeueInputBuffer
            // 恒返回负值、空转重试至超时(实测约 5 秒),进而拖住 audioDrainDone
            // latch 与整个 stopAsync。EOS 改由修改 2 在收尾末端统一发送。
            try {
                drainAudioEncoder(false, true)
            } catch (e: Throwable) {
                // ignore
            }

            // 等待视频 drain 完成,拿到最终视频时长,用于音频轨补齐对齐
            try {
                videoDrainDone.await(3, java.util.concurrent.TimeUnit.SECONDS)
            } catch (e: InterruptedException) {
                Thread.currentThread().interrupt()
            }

            // 停止前把 encoderQueue 中未消费的数据全部排空到 audioPendingPcm,避免 1MB 积压被丢弃。
            // v6.7.54: 此步必须放在静音补齐之前——先并入真实音频,再在其后补静音,
            // 保证 audioPendingPcm 布局为 [真实音频][静音]。否则静音在前、真实音频在尾,
            // 下方 flush 若因编码器输入缓冲不可用而丢弃尾部时,丢掉的恰是真实音频
            // (日志 audio_flush_backlog unflushed=30745 bytes at stop 即真实尾音频被丢弃)。
            try {
                // v6.7.91 (A-1): queueDrain 类型从 ByteArray 改为 AudioChunk
                val queueDrain = mutableListOf<AudioChunk>()
                var remaining = encoderQueue.size
                while (remaining > 0) {
                    val drained = encoderQueue.poll(100, java.util.concurrent.TimeUnit.MILLISECONDS)
                    if (drained != null) {
                        queueDrain.add(drained)
                        remaining = encoderQueue.size
                    } else {
                        remaining = 0
                    }
                }
                if (queueDrain.isNotEmpty()) {
                    synchronized(audioPendingLock) {
                        val totalSize = audioPendingLen + queueDrain.sumOf { it.bytes.size }
                        if (totalSize > audioPendingPcm.size) {
                            audioPendingPcm = audioPendingPcm.copyOf(totalSize)
                        }
                        var writePos = audioPendingLen
                        for (chunk in queueDrain) {
                            System.arraycopy(chunk.bytes, 0, audioPendingPcm, writePos, chunk.bytes.size)
                            writePos += chunk.bytes.size
                        }
                        audioPendingLen = writePos
                    }
                    logDetail("audio_stop_drain",
                        "drained ${queueDrain.size} chunks (${queueDrain.sumOf { it.bytes.size }} bytes) from encoderQueue")
                }
            } catch (e: Throwable) {
                logDetail("audio_stop_drain_error", "${e.message}")
            }

            // 音视频时长对齐:若音频已编码的 PCM 量明显短于视频时长对应的量,
            // 追加静音补齐,保证两轨时长匹配,杜绝 MP4 时间轴矛盾导致的 Source error。
            // 静音追加在真实音频之后(见上方 queueDrain 先并入),故 flush 丢弃尾部时
            // 只丢静音、不丢真实音频。
            try {
                val videoEndUs = lastVideoFrameTimeUs
                val audioEndBytes = audioBytesWritten
                val targetBytes = if (videoEndUs > 0) {
                     (videoEndUs * (actualAudioChannelCount * 2).toLong() * AUDIO_SAMPLE_RATE / 1_000_000L)
                        .coerceAtLeast(audioEndBytes)
                } else {
                    audioEndBytes
                }
                var needBytes = (targetBytes - audioEndBytes - audioPendingLen).toInt()
                // 静音补齐量设上限(最多 30 秒音频量),防止视频 PTS 因锚定/降帧
                // 计算异常而虚高时,静音补齐把 buffer 扩容到数百 MB 导致 OOM 或
                // 主线程长时间阻塞。超过上限只补齐到上限,并记日志。
                 val maxPadBytes = (actualAudioChannelCount * 2L).toInt() * AUDIO_SAMPLE_RATE * 30
                if (needBytes > maxPadBytes) {
                    logDetail("audio_align",
                        "pad requested $needBytes bytes capped to $maxPadBytes (videoEndUs=$videoEndUs)")
                    needBytes = maxPadBytes
                }
                if (needBytes > 0) {
                    synchronized(audioPendingLock) {
                        val newSize = audioPendingLen + needBytes
                        if (newSize > audioPendingPcm.size) {
                            audioPendingPcm = audioPendingPcm.copyOf(newSize)
                        }
                        java.util.Arrays.fill(audioPendingPcm, audioPendingLen, newSize, 0.toByte())
                        audioPendingLen = newSize
                    }
                    logDetail("audio_align",
                        "pad $needBytes bytes silence videoEndUs=$videoEndUs " +
                            "audioEndBytes=$audioEndBytes targetBytes=$targetBytes")
                }
            } catch (e: Throwable) {
                logDetail("audio_align_error", "${e.message}")
            }

            // 停止前把 pending 中残留的音频尽量送入编码器,避免丢失结尾数据
            try {
                // 局部单调计数器替代依赖 drain 线程的 lastAudioPtsOutUs:
                // drain 线程可能已把 lastAudioPtsOutUs 推进到很远,用它做下界
                // clamp 会让此处 PTS 跳跃数秒产生静默间隔。
                var localLastPtsUs = -1L
                var pendingOffset = 0
                var waitMs = 0
                while (pendingOffset < audioPendingLen) {
                    val idx = encoder.dequeueInputBuffer(0L)
                    if (idx < 0) {
                        if (waitMs >= PENDING_FLUSH_WAIT_MS) break
                        // v6.7.62: 停止收尾提速——输入缓冲不可用时,先 drain 编码器输出释放
                        // input buffer 槽位,再重试,而不是纯 sleep 空等。此前(仅 sleep)一旦
                        // 编码器输出队列占满,dequeueInputBuffer 持续 <0,大量 backlog 无法喂入,
                        // 最终阻塞 drain 耗掉 3.8s。此处边喂边 drain 让编码器持续流动。
                        try {
                            drainAudioEncoder(false, false)
                        } catch (e: Throwable) {
                            // drain 失败不中断 flush 重试
                        }
                        try {
                            Thread.sleep(1)
                        } catch (e: InterruptedException) {
                            break
                        }
                        waitMs++
                        continue
                    }
                    val inputBuf: ByteBuffer = encoder.inputBuffers[idx]
                    inputBuf.clear()
                    val size = minOf(audioPendingLen - pendingOffset, inputBuf.capacity())
                    inputBuf.put(audioPendingPcm, pendingOffset, size)
                    inputBuf.flip()
                    val chunkStreamStart = audioStreamBytes - audioPendingLen + pendingOffset
                    // v6.7.99: 先乘后除避免整数除法截断精度损失
                    val ptsUs = chunkStreamStart * 1_000_000L / (actualAudioChannelCount * 2L * AUDIO_SAMPLE_RATE)
                    val adjustedPts = if (firstInputAudioPtsUs.get() < 0) {
                        firstInputAudioPtsUs.getAndSet(ptsUs)
                        0L
                    } else {
                        val base = (ptsUs - firstInputAudioPtsUs.get()).coerceAtLeast(0L)
                        if (localLastPtsUs < 0) base else base.coerceAtLeast(localLastPtsUs)
                    }
                    localLastPtsUs = adjustedPts
                    encoder.queueInputBuffer(idx, 0, size, adjustedPts, 0)
                    audioBytesWritten += size
                    pendingOffset += size
                    waitMs = 0
                }
                if (audioPendingLen - pendingOffset > 0) {
                    logDetail("audio_flush_backlog",
                        "unflushed=${audioPendingLen - pendingOffset} bytes at stop")
                }
            } catch (e: Throwable) {
                logDetail("audio_capture_error", "flush backlog failed: ${e.message}")
            }

            // v6.7.72: 严格时序——先把最后一次输出排空,再发送 EOS,最后排出 EOS。
            // 顺序不可颠倒:pad 静音与 flush backlog 必须在 EOS 之前全部完成,
            // 否则编码器一旦进入 EOS 状态就不再接受输入,尾部音频与对齐静音全部丢失。
            try {
                drainAudioEncoder(false, true)
            } catch (e: Throwable) {
                logDetail("audio_capture_error", "final drain failed: ${e.message}")
            }
            try {
                signalAudioEndOfStream(encoder)
                drainAudioOutputLoop(encoder)
            } catch (e: Throwable) {
                logDetail("audio_capture_error", "signal eos failed: ${e.message}")
            }
            audioDrainDone.countDown()
            logDetail("audio_capture", "thread finished")
        }
    }

    /**
     * 音频看门狗静音注入：若超过 AUDIO_SILENCE_TIMEOUT_MS 没有任何有效音频数据,
     * 将 pcmBuffer 清零作为静音帧交给编码器,使编码器持续有输入并最终产出音频轨格式。
     * 返回 true 表示应编码该 buffer（无论是否静音）,返回 false 表示等待摸下的采样或真实数据。
     * 注入一直持续到真实数据恢复,避免 av_pts_delta 无限膨胀。
     */
    private fun maybeInjectSilence(pcmBuffer: ByteArray, bufferSize: Int): Boolean {
        val now = System.nanoTime()
        if (lastAudioDataNs == 0L) {
            lastAudioDataNs = now
            java.util.Arrays.fill(pcmBuffer, 0, bufferSize, 0)
            return true
        }
        // 始终按实时速率注入静音,而不是在 <阈值 的缺口期让音频时钟停走。
        // 音频 PTS 由"喂入编码器的累计字节"推导,若缺口期不喂数据,音频时钟
        // 会停滞而视频时钟(帧序号)持续前进,造成音画偏移随时间线性放大
        // (AN70 内部音频源间歇 read=0 时实测 60s 漂移 ~19s)。补足静音帧让
        // 字节流(=音频时钟)与墙钟 1:1 推进,既保持时钟连续,又因静音帧按
        // 实时帧长产生,真实音频到达时不会产生 2 倍速漂移。
        java.util.Arrays.fill(pcmBuffer, 0, bufferSize, 0)
        audioSilenceBytes += bufferSize.toLong()
        return true
    }
    private fun calculateAudioPts(): Long {
        // v6.7.95 (改进1): 改为墙钟锚点制,对齐 AZ 6.9.10 fg/d.java E() 方法。
        // 理论层:按采样数累加保证长期速率严格等于采样率。
        // 锚点层:用墙钟校准避免暂停期间 AudioRecord 积存的陈旧 PCM 导致漂移。
        // 滞后滤波器:锚点漂移超过 2 倍理论时间戳才更新,抑制线程调度高频抖动。
        // v6.7.97 (改进3): 音视频首帧对齐——音频 PTS 减去 (audioFirstWallNs - videoFirstWallNs)/1000,
        // 消除音频采集启动早于视频首帧输出造成的固定偏差(v6.7.96 实测 ~500ms)。
        // 视频首帧未就绪时按 0 处理,等视频首帧到达再应用偏移。
        val theoryUs = audioSampleCount * 1_000_000L / realAudioSampleRate
        val nowUs = System.nanoTime() / 1000L
        val candidateUs = nowUs - theoryUs

        val avDiffUs = computeAvDiffUs()

        return if (audioPtsAnchorUs < 0L) {
            // 首次锚定
            audioPtsAnchorUs = candidateUs
            // avDiffUs 为负=音频领先视频,需从 PTS 中减去该偏差;
            // avDiffUs 为正=音频滞后视频,需加回。
            // v6.7.111 (Bug B): 与后续分支统一带 audioPtsAnchorUs。旧写法首次分支漏加该项,
            // 首采样 PTS 比稳态低约 candidateUs(当前录制时长),第二采样起被
            // coerceAtLeast(lastAudioPtsOutUs) 单调钳制吸收,属首帧跳变隐患。
            (theoryUs + audioPtsAnchorUs + avDiffUs).coerceAtLeast(0L)
        } else {
            // 滞后滤波:仅当锚点漂移超过 2 倍理论时间戳才更新
            val drift = kotlin.math.abs(candidateUs - audioPtsAnchorUs)
            if (drift > theoryUs * 2) {
                audioPtsAnchorUs = candidateUs
            }
            (theoryUs + audioPtsAnchorUs + avDiffUs).coerceAtLeast(0L)
        }
    }

    // v6.7.58: 采样时钟校准。v6.7.90 (A-1): 改用差分估计。
    // 旧累积平均式 totalSamples/elapsedMs 把"启动预填充缓冲多算的常量偏移"当成
    // 速率误差(实测: 稳态就是 44100Hz, 但累积式在 t=5s 读出 45969、t=10s 45034、
    // t=15s 44722 的单调下降序列)。改用"上次校准点以来的增量"做估计,常量偏移
    // 在差分里自动消掉,measured 趋近标称。限幅 [0.90,1.10]x,一阶平滑禁跳变。
    // v6.7.118 (实机修复): 放宽限幅。HONOR PTP-AN70(sdk=37) 实测 5 次 meatured≈46.2~46.4kHz,
    // 持续超出标称 44100 约 5%(1.052),恰好越过旧 [0.95,1.05] 上限被 return 丢弃,
    // realAudioSampleRate 恒为 44100,音频 PTS 时钟快 ~5%,AV 漂移 -125~-308ms 无法纠偏。
    private fun calibrateAudioSampleRate() {
        val wallUs = System.nanoTime() / 1000L
        val totalSamples = audioStreamBytes / (actualAudioChannelCount * 2L)
        // 首次只锚定,不做估计:此刻分子已累计了一段、分母还是 0,估出来必然虚高。
        if (calibLastWallUs < 0L) {
            calibLastWallUs = wallUs
            calibLastSamples = totalSamples
            // audioStartRealtimeUs 仍保留(learnState="clock" 依赖它 >= 0),
            // 此处同步锚定以兼容旧诊断路径。
            if (audioStartRealtimeUs < 0L) audioStartRealtimeUs = wallUs
            return
        }
        val dSamples = totalSamples - calibLastSamples
        val dUs = wallUs - calibLastWallUs
        // 窗口至少 3 秒、增量样本至少 12 万(约 2.7s 音频)才有统计意义
        if (dUs < 3_000_000L || dSamples < 120_000L) return
        val measured = (dSamples.toDouble() * 1_000_000.0 / dUs).toInt()
        val nominal = AUDIO_SAMPLE_RATE
        val ratio = measured.toDouble() / nominal
        // v6.7.59: 记录实测值供诊断(即使被限幅丢弃也保留原始估算)
        lastMeasuredSampleRate = measured
        lastCalibElapsedMs = dUs / 1000L
        if (ratio < 0.90 || ratio > 1.10) {
            // 即使被限幅丢弃也推进锚点,避免下次仍在旧起点上累计。
            calibLastWallUs = wallUs
            calibLastSamples = totalSamples
            return
        }
        val target = measured.coerceIn((nominal * 0.90).toInt(), (nominal * 1.10).toInt())
        // 一阶平滑;启动期已过,窗口够长,收敛很快
        realAudioSampleRate = ((realAudioSampleRate * 9L + target) / 10L).toInt()
        calibLastWallUs = wallUs
        calibLastSamples = totalSamples
    }

    /**
     * 音频时钟锚定：差异C 删除对 videoStartAnchorUs 的依赖,音频只做自身首帧归零,
     * 不再与视频 PTS 互锚,避免 av_pts_delta 缓增。
     * v6.7.98: 加上 avDiffUs 偏移——此前 audioPtsAccumulatorUs 与视频墙钟 PTS
     * 完全独立推进，音视频首帧墙钟差从未被补偿，实测音频恒领先视频 ~300ms。
     * 单调钳制由调用方完成。
     */
    private fun anchorAudioPtsUs(absPtsUs: Long): Long {
        val avDiffUs = computeAvDiffUs()
        return absPtsUs + avDiffUs
    }

    /**
     * 计算音视频首帧墙钟差，供 anchorAudioPtsUs 补偿。
     * v6.7.98: 此前仅 calculateAudioPts 使用此差值(音频输入侧)，
     * 但音频输出侧 PTS 由 audioPtsAccumulatorUs 独立推进，完全绕过了该偏移。
     * 抽取为独立方法，供输出侧复用。
     */
    private fun computeAvDiffUs(): Long {
        val vFirstNs = videoFirstFrameRealtimeNs.get()
        val aFirstNs = audioFirstCaptureRealtimeNs.get()
        return if (vFirstNs > 0 && aFirstNs > 0) (aFirstNs - vFirstNs) / 1000L else 0L
    }

    /**
     * 音频样本是否应写入 muxer：
     * pre-roll(平移后 <0,即视频首帧之前采集的音频)与视频结束后超长尾均丢弃,
     * 使音频轨时间轴与视频轨严格对齐。
     */
    private fun shouldDropAudioPts(finalPtsUs: Long): Boolean {
        if (finalPtsUs < 0L) return true              // pre-roll:视频首帧之前的音频
        if (videoTrimEndUs > 0L && finalPtsUs > videoTrimEndUs + AUDIO_FRAME_US) return true
        return false
    }

    // v6.7.172 (P0-A): 视频样本是否应写入 muxer,与 shouldDropAudioPts 对称。
    // 停止排空后取 commonEndUs=min(视频末PTS,音频末PTS),把较长一路裁到 commonEndUs。
    // 符号无关:无论音频先结束还是后结束都正确,消除成片"最后 113ms 没声音"。
    private fun shouldDropVideoPts(finalPtsUs: Long): Boolean {
        if (finalPtsUs < 0L) return true
        if (audioTrimEndUs > 0L && finalPtsUs > audioTrimEndUs + VIDEO_PTS_MIN_TICK_US) return true
        return false
    }

private var audioDrainDebugCount = 0

    private fun drainAudioEncoder(endOfStream: Boolean, blocking: Boolean = false) {
        val encoder = audioEncoder ?: return
        val timeoutUs = if (blocking) DEQUEUE_TIMEOUT_US else 2000L
        val bufferInfo = MediaCodec.BufferInfo()
        try {
            var outputIndex = encoder.dequeueOutputBuffer(bufferInfo, timeoutUs)
            var retryCount = 0

            while (true) {
                try {
                    if (outputIndex == MediaCodec.INFO_TRY_AGAIN_LATER) {
                        if (retryCount < 3 && !blocking) {
                            outputIndex = encoder.dequeueOutputBuffer(bufferInfo, 1000L)
                            retryCount++
                            continue
                        }
                        break
                    }

                    if (outputIndex == MediaCodec.INFO_OUTPUT_FORMAT_CHANGED) {
                        val newFormat = encoder.outputFormat
                        pendingAudioFormat = newFormat
                        tryAddAudioTrack()
                        tryStartMuxer()
                        outputIndex = encoder.dequeueOutputBuffer(bufferInfo, timeoutUs)
                        continue
                    }

                    if (outputIndex < 0) {
                        break
                    }

                    audioDrainDebugCount++
                    if (audioDrainDebugCount <= 5) {
                        logDetail("audio_drain_debug",
                            "idx=$outputIndex size=${bufferInfo.size} pts=${bufferInfo.presentationTimeUs} flags=${bufferInfo.flags}")
                    }

                    val outputBuffer = encoder.outputBuffers[outputIndex]
                    val isCodecConfig = (bufferInfo.flags and MediaCodec.BUFFER_FLAG_CODEC_CONFIG) != 0
                    if (outputBuffer != null && bufferInfo.size > 0 && !isCodecConfig) {
                        outputBuffer.position(bufferInfo.offset)
                        outputBuffer.limit(bufferInfo.offset + bufferInfo.size)

                        // v6.7.90 (A-2): 改成纯增量累加。旧写法用"累积帧号 x 当前速率"
                        // 重算整条时间轴,速率一变就把已经发出去的时间戳追溯性改写
                        // (速率高估 3% -> 时间轴慢 3%)。累计误差用 Double 兜住,避免逐帧截断漂移。
                        audioPtsAccumulatorUs += 1024.0 * 1_000_000.0 / realAudioSampleRate
                        lastAudioPtsOutUs = audioPtsAccumulatorUs.toLong()
                        audioOutputFrameCount++

                        // v6.7.171 (P0): 音频 PTS 引用统一起点 recordingT0Us。
                        // 音视频都引用同一单调时钟基准,不再各自维护 anchor,从根上消除发散。
                        // 约束6:用 SystemClock.elapsedRealtime()(单调不跳变),严禁 currentTimeMillis()。
                        // 约束1:不删帧——v6.7.157 已证明删 P 帧破坏参考链致花屏。
                        // 累加器 lastAudioPtsOutUs 仍保留更新(时长计算/调试用)。
                        val wallClockPtsUs = if (recordingT0Us > 0L)
                            (SystemClock.elapsedRealtime() - recordingT0Us)
                        else lastAudioPtsOutUs

                        // 平移对齐到视频主时钟;pre-roll 与视频超长尾帧丢弃。
                        // (用 if(!drop) 包裹写入,不用 continue,确保每次输出帧
                        // 都能走到循环底部的 releaseOutputBuffer 与 EOS 标志检查,
                        // 避免被裁剪的恰为 EOS 帧时漏置 muxerAudioDone 造成二次 signal。)
                        val finalPtsUs = anchorAudioPtsUs(wallClockPtsUs + audioPtsOffsetUs)
                        if (!shouldDropAudioPts(finalPtsUs)) {
                            if (firstAudioFrameTimeUs.get() < 0) {
                                firstAudioFrameTimeUs.getAndSet(finalPtsUs)
                            }
                            // v6.7.173 (BUG-2): 删掉 `|| firstAudioFrameTimeUs == finalPtsUs`。
                            // 原条件本意在捕获首帧,但 firstAudioFrameTimeUs 只在首帧(<0 时 getAndSet)
                            // 写一次,之后恒为首帧 PTS;暂停→恢复→重新锚定后若某帧 PTS 恰好等于首帧值,
                            // 会把 lastAudioFrameTimeUs 回写成首帧值,拉低 aEndUs→拉低 commonEndUs,
                            // 导致成片时长被错误裁短(与 P0-A 对齐目标相悖)。仅保留单调推进。
                            if (finalPtsUs > lastAudioFrameTimeUs) {
                                lastAudioFrameTimeUs = finalPtsUs
                            }
                            bufferInfo.presentationTimeUs = finalPtsUs

if (muxerStarted.get() && audioTrackIndex >= 0) {
                                try {
                                    synchronized(muxerLock) {
                                        // AZ m0() 风格写入前单调钳制:保证 muxer 音频时间轴严格单调且最小间隔 1ms
                                        val clampedMuxPtsUs = if (lastMuxAudioPtsUs >= 0)
                                            kotlin.math.max(lastMuxAudioPtsUs + 1000L, finalPtsUs) else finalPtsUs
                                        lastMuxAudioPtsUs = clampedMuxPtsUs
                                        // v6.7.128: 分片内音频 PTS 重基(惰性锚定:分片内首个音频帧快照全局 PTS)
                                        if (segmentationEnabled) {
                                            if (segmentAudioFirst) {
                                                segmentStartAudioPtsUs = clampedMuxPtsUs
                                                segmentAudioFirst = false
                                            }
                                        }
                                        val segAudioPtsUs = if (segmentationEnabled)
                                            (clampedMuxPtsUs - segmentStartAudioPtsUs).coerceAtLeast(0L)
                                        else clampedMuxPtsUs
                                        bufferInfo.presentationTimeUs = segAudioPtsUs
                                        mediaMuxer?.writeSampleData(audioTrackIndex, outputBuffer, bufferInfo)
                                        // v6.7.120 (被杀保护): 写后同步音频索引记录
                                        indexTracker?.appendSample(false, bufferInfo.size, segAudioPtsUs, true)
                                    }
                                } catch (e: Exception) {
                                    if (!muxerFailed) {
                                        muxerFailed = true
                                        logDetail("muxer_audio_write_error",
                                            "${e.javaClass.simpleName}:${e.message} " +
                                            "track=${audioTrackIndex} size=${bufferInfo.size} " +
                                            "flags=${bufferInfo.flags} pts=${bufferInfo.presentationTimeUs}")
                                        try {
                                            callback?.onError(
                                                IOException("muxer audio write failed: ${e.message}"))
                                        } catch (_: Exception) {}
                                    }
                                }
                            }
                        }
                        outputBuffer.clear()
                    }

                    encoder.releaseOutputBuffer(outputIndex, false)

                    if ((bufferInfo.flags and MediaCodec.BUFFER_FLAG_END_OF_STREAM) != 0) {
                        muxerAudioDone = true
                        logDetail("audio_drain", "end of stream received")
                    }
                } catch (e: Exception) {
                    logDetail("audio_drain_loop_error", "${e.message}")
                }

                outputIndex = encoder.dequeueOutputBuffer(bufferInfo, timeoutUs)
            }

            if (endOfStream && !muxerAudioDone) {
                signalAudioEndOfStream(encoder)
                drainAudioOutputLoop(encoder)
            }

            if (audioTrackIndex < 0 && !audioTrackFailed && endOfStream) {
                audioTrackFailed = true
                logDetail("audio_track", "no audio track produced, marking audio failed")
                tryStartMuxer()
            }
        } catch (e: Throwable) {
            logDetail("audio_drain_error", "${e.message}")
        }
    }

    private fun signalAudioEndOfStream(encoder: MediaCodec) {
        try {
            // 输出队列满时 input buffer 永不可用,先 drain 若干输出帧释放 input 槽,
            // 再尝试注入 EOS,避免 dequeueInputBuffer 超时返回导致 EOS 永远无法注入、
            // muxerAudioDone 恒 false、音频轨无结束标记。
            var inputIndex = encoder.dequeueInputBuffer(DEQUEUE_TIMEOUT_US)
            if (inputIndex < 0) {
                drainAudioOutputLoop(encoder)
                drainAudioEncoder(false)
                inputIndex = encoder.dequeueInputBuffer(DEQUEUE_TIMEOUT_US)
            }
            if (inputIndex >= 0) {
                val pts = if (lastAudioPtsOutUs > 0) lastAudioPtsOutUs
                    else calculateAudioPts().coerceAtLeast(0L)
                encoder.queueInputBuffer(
                    inputIndex, 0, 0, pts, MediaCodec.BUFFER_FLAG_END_OF_STREAM
                )
                logDetail("audio_eos", "queued end-of-stream input buffer")
            } else {
                logDetail("audio_eos", "no input buffer available for EOS after drain retry")
            }
        } catch (e: Exception) {
            logDetail("audio_signal_eos_error", "${e.message}")
        }
    }

    private fun drainAudioOutputLoop(encoder: MediaCodec) {
        var guard = 0
        val bufferInfo = MediaCodec.BufferInfo()
        while (!muxerAudioDone && guard < 50) {
            guard++
            try {
                val outputIndex = encoder.dequeueOutputBuffer(bufferInfo, DEQUEUE_TIMEOUT_US)
                if (outputIndex == MediaCodec.INFO_OUTPUT_FORMAT_CHANGED) {
                    pendingAudioFormat = encoder.outputFormat
                    tryAddAudioTrack()
                    tryStartMuxer()
                    continue
                }
                if (outputIndex < 0) {
                    continue
                }
                try {
                    val outputBuffer = encoder.outputBuffers[outputIndex]
                    val isCodecConfig = (bufferInfo.flags and MediaCodec.BUFFER_FLAG_CODEC_CONFIG) != 0
                    if (outputBuffer != null && bufferInfo.size > 0 && !isCodecConfig) {
                        outputBuffer.position(bufferInfo.offset)
                        outputBuffer.limit(bufferInfo.offset + bufferInfo.size)
                        // v6.7.90 (A-2): 纯增量累加,同 drain 路径 1(见上方注释)。
                        audioPtsAccumulatorUs += 1024.0 * 1_000_000.0 / realAudioSampleRate
                        lastAudioPtsOutUs = audioPtsAccumulatorUs.toLong()
                        audioOutputFrameCount++
                        val finalPtsUs = anchorAudioPtsUs(lastAudioPtsOutUs + audioPtsOffsetUs)
                        if (!shouldDropAudioPts(finalPtsUs)) {
                            if (firstAudioFrameTimeUs.get() < 0) {
                                firstAudioFrameTimeUs.getAndSet(finalPtsUs)
                            }
                            // v6.7.173 (BUG-2): 删掉 `|| firstAudioFrameTimeUs == finalPtsUs`。
                            // 原条件本意在捕获首帧,但 firstAudioFrameTimeUs 只在首帧(<0 时 getAndSet)
                            // 写一次,之后恒为首帧 PTS;暂停→恢复→重新锚定后若某帧 PTS 恰好等于首帧值,
                            // 会把 lastAudioFrameTimeUs 回写成首帧值,拉低 aEndUs→拉低 commonEndUs,
                            // 导致成片时长被错误裁短(与 P0-A 对齐目标相悖)。仅保留单调推进。
                            if (finalPtsUs > lastAudioFrameTimeUs) {
                                lastAudioFrameTimeUs = finalPtsUs
                            }
                            bufferInfo.presentationTimeUs = finalPtsUs
if (muxerStarted.get() && audioTrackIndex >= 0) {
                                try {
                                    synchronized(muxerLock) {
                                        // AZ m0() 风格写入前单调钳制:保证 muxer 音频时间轴严格单调且最小间隔 1ms
                                        val clampedMuxPtsUs = if (lastMuxAudioPtsUs >= 0)
                                            kotlin.math.max(lastMuxAudioPtsUs + 1000L, finalPtsUs) else finalPtsUs
                                        lastMuxAudioPtsUs = clampedMuxPtsUs
                                        // v6.7.128: 分片内音频 PTS 重基(惰性锚定:分片内首个音频帧快照全局 PTS)
                                        if (segmentationEnabled) {
                                            if (segmentAudioFirst) {
                                                segmentStartAudioPtsUs = clampedMuxPtsUs
                                                segmentAudioFirst = false
                                            }
                                        }
                                        val segAudioPtsUs = if (segmentationEnabled)
                                            (clampedMuxPtsUs - segmentStartAudioPtsUs).coerceAtLeast(0L)
                                        else clampedMuxPtsUs
                                        bufferInfo.presentationTimeUs = segAudioPtsUs
                                        mediaMuxer?.writeSampleData(audioTrackIndex, outputBuffer, bufferInfo)
                                        // v6.7.120 (被杀保护): 写后同步音频索引记录
                                        indexTracker?.appendSample(false, bufferInfo.size, segAudioPtsUs, true)
                                    }
                                } catch (e: Exception) {
                                    if (!muxerFailed) {
                                        muxerFailed = true
                                        logDetail("muxer_audio_write_error",
                                            "${e.javaClass.simpleName}:${e.message} " +
                                            "track=${audioTrackIndex} size=${bufferInfo.size} " +
                                            "flags=${bufferInfo.flags} pts=${bufferInfo.presentationTimeUs}")
                                        try {
                                            callback?.onError(
                                                IOException("muxer audio write failed: ${e.message}"))
                                        } catch (_: Exception) {}
                                    }
                                }
                            }
                        }
                        outputBuffer.clear()
                    }
                    encoder.releaseOutputBuffer(outputIndex, false)

                    if ((bufferInfo.flags and MediaCodec.BUFFER_FLAG_END_OF_STREAM) != 0) {
                        muxerAudioDone = true
                        logDetail("audio_drain", "end of stream received")
                    }
                } catch (e: Exception) {
                    logDetail("audio_drain_loop_error", "${e.message}")
                }
            } catch (e: Exception) {
                logDetail("audio_drain_error", "${e.message}")
                break
            }
        }
    }

    private fun setupMuxer() {
        val file = outputFile ?: throw IllegalStateException("output file is null")
        val parentDir = file.parentFile
        if (parentDir != null && !parentDir.exists()) {
            parentDir.mkdirs()
        }
        if (file.exists()) {
            file.delete()
        }
        file.createNewFile()

        // v6.7.128: 分片模式下首片命名为 seg_1.mp4.tmp,manifest 与分片同目录。
        if (segmentationEnabled) {
            // v6.7.175: parentFile 防御(复用上方 3801 已判空的 parentDir,不再裸 !!)。
            val baseDir = parentDir?.absolutePath
                ?: run { logDetail("seg_init", "no parent dir"); return }
            val first = segFileName(1)
            val segPath = File(baseDir, first).absolutePath
            outputFilePath = segPath
            outputFile = File(segPath)
            segmentFile = outputFile
            if (file.absolutePath != segPath) {
                file.delete()
            }
            // 清理上次残留 manifest(本次录制重建)
            try { manifestFileAt(baseDir).delete() } catch (_: Exception) {}
            // 首片元信息写入(后续 appendManifestLine 会补完整行)
            segmentSeq = 0
            segmentStartMs = SystemClock.elapsedRealtime()
            segmentStartPtsUs = 0L
            segmentBytesWritten = 0L
            segmentVideoFirstPtsUs = -1L
            logDetail("segment_init", "first=$first")
        }

        // 始终用文件路径创建 muxer，避免 SAF FileDescriptor 被 use 块关闭后
        // 部分设备(Huawei Android 16+)上 muxer 内部 fd 引用失效导致 writeSampleData 全程报错。
        // SAF 目标通过录制完成后的 safCopyToTree 拷贝实现。
        mediaMuxer = MediaMuxer(
            outputFilePath,
            MediaMuxer.OutputFormat.MUXER_OUTPUT_MPEG_4
        )
        // v6.7.140 (BUG-G): 接通主界面方向设置（此前 RecorderConfig 无该字段，选择无效）。
        // setOrientationHint 只写播放端旋转元数据，不改变已捕获画面；真正转置像素本期不做。
        val orientHint = when (config?.orientation ?: 0) {
            1 -> 90
            else -> 0
        }
        try { mediaMuxer?.setOrientationHint(orientHint) } catch (_: Exception) {}
        logDetail("muxer", "created at $outputFilePath orientHint=$orientHint")
        // v6.7.120 (被杀保护): 打伴生 .idx 索引流(outputFilePath + ".idx")。
        // 失败仅导致本次失去修复能力,不影响录制,故仅置 null。
        try {
            indexOut = java.io.FileOutputStream(File(outputFilePath + ".idx"), false)
        } catch (_: Exception) {
            indexOut = null
        }

        tryAddAudioTrack()
        tryStartMuxer()
    }

    // v6.7.174 (异形屏 P0): 物理屏幕尺寸的唯一来源收敛到 ScreenRecorderApp.realScreenSize,
    // 与 UI/服务层同口径(Android12+ 用 currentWindowMetrics 整屏含 cutout,<12 用 getRealSize)。
    // 本包装仅适配 engine 的入参 free 形态,避免三处各写一套导致参照系漂移。
    private fun getRealScreenSize(): Pair<Int, Int> =
        ScreenRecorderApp.realScreenSize(context)

    private fun setupVirtualDisplay() {
        val cfg = config ?: throw IllegalStateException("config is null")
        val projection = mediaProjection ?: throw IllegalStateException("mediaProjection is null")
        val surface = inputSurface ?: throw IllegalStateException("inputSurface is null")

        val displayName = "ScreenRecorderDisplay"
        // 差异B: 对齐 AZ(Leg/d->i) —— AUTO_MIRROR(16) 自动镜像主屏合成,内容更新投递节奏稳定,
        // 避免 PUBLIC 不镜像主屏导致 fps 偏低;dpi 用设备真实 DisplayMetrics 保证
        // "渲染分辨率=编码分辨率"一致,避免花屏/模糊。
        val flags = DisplayManager.VIRTUAL_DISPLAY_FLAG_AUTO_MIRROR
        // v6.7.174 (异形屏 P0): VD 的 dpi 决定 SurfaceFlinger 在该画布上渲染系统 UI 用的密度。
        // 等比缩小画布(cfg < 物理屏)时 dpi 需随缩放比一起缩,否则状态栏/导航条/通知图标按
        // "全密度"画进小画布,相对画面占比失真甚至被挤压(屏越大、缩放越狠越明显)。
        // 例:640x1400 屏配 480dpi,dpi 不随缩放比缩,状态栏在小画布里占比爆炸。
        // screenShortEdge = 物理整屏短边(来自 getRealScreenSize,与 Service 口径一致)。
        val (physW, physH) = getRealScreenSize()
        val physShortEdge = minOf(physW, physH)
        // v6.7.175 (横屏 dpi): scale 用画布短边与物理短边之比,方向无关。旧逻辑用 cfg.width
        // 作分子:竖屏(画布宽=短边)正确,但横屏时 cfg.width=画布长边,scale≈0.89 而真值 0.5,
        // vdDpi 偏大,横屏小画布里状态栏/导航条相对占比失真。
        val canvasShortEdge = minOf(cfg.width, cfg.height)
        val scale = if (physShortEdge > 0) canvasShortEdge.toFloat() / physShortEdge else 1f
        val realDpi = context.resources.displayMetrics.densityDpi
        val vdDpi = if (scale > 0f && scale < 1f)
            (realDpi * scale).toInt().coerceAtLeast(120)
        else realDpi
        // v6.7.190 (P1-2): cfg.densityDpi 仅作历史兼容传入,虚拟显示器 DPI 恒由
        // realDpi×scale 派生。此前调用方传 320 而真机 560,日志里两个值并存易误判。
        // 此处显式打点说明忽略传入值,口径统一。
        logDetail("virtual_display_dpi",
            "cfgDpi=${cfg.densityDpi} ignored=true realDpi=$realDpi scale=$scale vdDpi=$vdDpi")
        // v6.7.177 (增量B): API33+ 注册 VD 回调。用户在系统"停止共享"通知里断开时,VD onStopped
        // 比 projection.onStop 更早更确定;置 projectionInvalid 后走 stopAsync——v6.7.104 B1 的
        // projection-invalid 旁路会跳过 EOS、按水线截止收尾。与 projection.onStop 双触发无害:
        // stopAsync 有 stopCompleted CAS 幂等。
        val vdCb = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU)
            object : VirtualDisplay.Callback() {
                override fun onStopped() {
                    // v6.7.178 (②): release 链 display.release() 也会触发本回调。
                    // isRunning 在 stopAsync 入口即置 false,而 release 时序在 drain 之后,
                    // 故手动停止收尾期命中本守卫——不置标志、不 post、不改原因,
                    // 避免 vdStopped 覆盖 finalStopReason 造成收尾噪音。
                    if (!isRunning.get()) {
                        logDetail("vd_callback", "onStopped during teardown, ignore")
                        return
                    }
                    logDetail("vd_callback", "onStopped -> graceful stop (vdStopped)")
                    ScreenRecorderApp.projectionInvalid = true
                    if (autoStopReason == null) autoStopReason = "vdStopped"
                    android.os.Handler(android.os.Looper.getMainLooper())
                        .post { stopAsync(android.os.Handler(android.os.Looper.getMainLooper())) }
                }
            }
        else null
        // 待办3: createVirtualDisplay 包裹 SecurityException,防止投屏授权中途失效导致崩溃;
        // 失败则置 null 并记录,由调用侧 forceStop 兜底。
        try {
            virtualDisplay = projection.createVirtualDisplay(
                displayName,
                cfg.width,
                cfg.height,
                vdDpi,
                flags,
                surface,
                vdCb,
                null
            )
            logDetail("virtual_display", "created ${cfg.width}x${cfg.height} dpi=${vdDpi} scale=${"%.3f".format(scale)} flags=AUTO_MIRROR")
        } catch (e: SecurityException) {
            logDetail("virtual_display", "createVirtualDisplay SecurityException: ${e.message}")
            virtualDisplay = null
        }
    }

    /**
     * 在 forceStop 前将音频 pending 缓冲中的残留数据送入编码器，
     * 避免音频采集线程因 forceStop 退出而丢弃 backlog。
     */
    private fun flushAudioBacklog() {
        // v6.7.167: 整体包进 audioPendingLock,与 AudioCaptureThread 上的生产/消费改写
        // (含 copyOf 扩容与末尾 audioPendingLen=0 清零)互斥,杜绝 forceStop 跨线程读改写竞争。
        synchronized(audioPendingLock) {
            val encoder = audioEncoder ?: return
            if (audioPendingLen <= 0) return
            try {
                var pendingOffset = 0
                var waitMs = 0
                while (pendingOffset < audioPendingLen) {
                    val idx = encoder.dequeueInputBuffer(0L)
                    if (idx < 0) {
                        if (waitMs >= PENDING_FLUSH_WAIT_MS) break
                        Thread.sleep(1)
                        waitMs++
                        continue
                    }
                    val inputBuf: ByteBuffer = encoder.inputBuffers[idx]
                    inputBuf.clear()
                    val size = minOf(audioPendingLen - pendingOffset, inputBuf.capacity())
                    inputBuf.put(audioPendingPcm, pendingOffset, size)
                    inputBuf.flip()
                    val chunkStreamStart = audioStreamBytes - audioPendingLen + pendingOffset
                    // v6.7.99: 先乘后除避免整数除法截断精度损失
                    val ptsUs = chunkStreamStart * 1_000_000L / (actualAudioChannelCount * 2L * AUDIO_SAMPLE_RATE)
                    val adjustedPts = if (firstInputAudioPtsUs.get() < 0) {
                        firstInputAudioPtsUs.getAndSet(ptsUs)
                        0L
                    } else {
                        (ptsUs - firstInputAudioPtsUs.get()).coerceAtLeast(lastAudioPtsOutUs)
                    }
                    encoder.queueInputBuffer(idx, 0, size, adjustedPts, 0)
                    audioBytesWritten += size
                    pendingOffset += size
                    waitMs = 0
                }
                if (audioPendingLen - pendingOffset > 0) {
                    logDetail("audio_flush_backlog",
                        "unflushed=${audioPendingLen - pendingOffset} bytes at stop")
                }
                audioPendingLen = 0
            } catch (e: Throwable) {
                logDetail("audio_flush_backlog_error", "${e.message}")
            }
        }
    }

    fun stop() {
        // v6.7.140 (方案3): 标记停止原因
        finalStopReason = "user"
        if (!isRunning.get()) {
            logDetail("stop", "not running")
            return
        }
        if (!stopCompleted.compareAndSet(false, true)) {
            logDetail("stop", "already stopped, ignoring")
            return
        }

        logSection("Recording Stop")

        // v6.7.90 (A-7): stop 时再打一次 resource_footprint,
        // 与周期采样相减即可看 fd/threads/heap 的整场增量。
        logResourceFootprint()

        // 在 forceStop 前冲干音频 pending 数据，避免丢弃
        flushAudioBacklog()

        // flush 清空编码器流水线残留帧会破坏 signalEndOfInputStream 产出的
        // output 侧 EOS（高通 OMX.qcom.video.encoder.avc 实测:先 flush 再 signal
        // 会导致 output 回调永不返回 BUFFER_FLAG_END_OF_STREAM → muxerVideoDone
        // 恒 false → drain 5s 超时）。故 stop 路径不前置 flush,先 signal EOS
        // 让 EOS 正常排出;残留帧由 awaitDrainCompletion 超时 + releaseResources 兜底。

        // signal EOS 确保编码器收到结束信号，异步 callback 会处理剩余输出
        // v6.7.102 (B5) + v6.7.104 (B2): projection 已失效时跳过 signal EOS,直接置
        // muxerVideoDone=true。判定不仅看对象引用,还要看 projectionInvalid 标志——
        // 系统回收 projection 时 mediaProjection/virtualDisplay 字段可能仍非 null,
        // 仅靠对象引用判不出失效,会误走 signalEndOfInputStream 导致 c2.avc EOS 30s 超时。
        val projectionAlive = virtualDisplay != null && mediaProjection != null
            && !ScreenRecorderApp.projectionInvalid
        if (projectionAlive) {
            try {
                val encoder = videoEncoder
                if (encoder != null && encoderReady.get()) {
                    encoder.signalEndOfInputStream()
                    logDetail("stop", "signaled end of input stream")
                }
            } catch (e: Exception) {
                logDetail("stop_signal_error", "${e.message}")
            }
        } else {
            logDetail("stop", "projection invalid, skip EOS and force muxerVideoDone=true (invalid=${ScreenRecorderApp.projectionInvalid})")
            muxerVideoDone = true
        }

        forceStop.set(true)
        isRunning.set(false)

        awaitDrainCompletion()

        // 在 releaseResources 前先停 muxer，隔离阻塞点避免拖累后续资源释放
        flushMuxer()

        releaseResources()

        finalDurationMs = calculateDuration()
        // v6.7.97 (改进1): 先做 SAF 拷贝,再改名到 .mp4,最后才用最终 URI 组 historyPath。
        // v6.7.96 顺序错在 historyPath 先取 safResult.uri(此时是 .recording.tmp),
        // 导致历史记录永远指向 .tmp 产物;renameToFinal 已改用 DocumentsContract.renameDocument
        // 并回传最终 URI,这里据此组 historyPath。
        // v6.7.99: 即使无 SAF(safResult==null),本地 .recording.tmp 也必须改名到 .mp4,
        // 否则本地录制的产物永远残留 .recording.tmp 后缀。
        val safResult = performSafCopy()
        renameToFinal()
        // resolveFinalSize 用 finalSafUri(改名后) 而非 safResult?.uri(改名前),
        // 确保查到的是 .mp4 document 的大小。
        val sizeUri = finalSafUri ?: safResult?.uri
        val historyPath = finalSafUri?.toString() ?: safResult?.uri?.toString() ?: outputFilePath
        finalFileSize = resolveFinalSize(sizeUri, safResult?.bytes ?: 0L)

        logDetail("stop_result", "duration=${finalDurationMs}ms size=${finalFileSize} bytes path=$historyPath")

        // v6.7.95 (改进3): 静音自检报告——录制结束时输出,便于排查"没录上声音"问题。
        logAudioSilenceCheck()

        // —— 学习报告 ——
        // 学习报告：输出本次录制摘要。对齐 AZ：历史数据由 saveRecordingLearnState 在每次录制结束落盘，
        // loadLearnState 读取，applyHistoricalFpsCap 应用。
        logLearnReport()
        saveRecordingLearnState()

        // SAF 与普通路径统一回调 onStopped,确保 Service 侧 recordToHistory + cleanupAndStop
        // 总能执行,避免 SAF 输出时前台通知常驻/状态卡 STOPPING/无历史记录
        callback?.onSegments(getSegmentPaths())
        callback?.onStopped(finalDurationMs, finalFileSize, historyPath)
    }

    // 异步停止:在后台线程执行 drain + 资源释放,完成后通过 callbackHandler
    // 回调 onStopped。适用于 handleStop 等不希望阻塞调用线程的场景。
    // 调用方仍需确保停止前已更新通知文本(如"正在停止")。
    fun stopAsync(callbackHandler: Handler) {
        // v6.7.171 (P2): 手动(UI)停止先置业务原因。stopAsync 是 UI 手动停止的主路径,
        // 全程未设 finalStopReason,导致 forceStop() 守卫 `== "normal"` 前提不成立、必然覆盖成
        // "forceStop",RECORD_SUMMARY 与 record_report_bucket 的 reason_MANUAL 自相矛盾。
        // 置 "user" 后 finalStopReason 非 "normal",forceStop() 守卫为 false 不再覆盖。
        // 保留 v6.7.170 守卫(方向对,系统杀投影/异常路径仍需它标 forceStop)。
        // v6.7.177 (增量A): 原因赋值移到幂等守卫之后。原写在守卫前——被忽略的重复调用
        // (isRunning=false / stopCompleted 已置)也会先把 reason 覆盖成 "user",而
        // RECORD_SUMMARY 是 drain 完成后才读(:4339),会被第二次误写污染。
        // 自动收尾(限额/VD断开)的 autoStopReason 优先于默认 "user"。
        if (!isRunning.get()) {
            logDetail("stopAsync", "not running")
            return
        }
        if (!stopCompleted.compareAndSet(false, true)) {
            logDetail("stopAsync", "already stopped, ignoring")
            return
        }
        finalStopReason = autoStopReason ?: "user"
        logSection("Recording Stop (async)")

        // 在调用线程(callbackHandler 所在线程)上先执行非阻塞的前置准备
        flushAudioBacklog()
        forceStop.set(true)
        isRunning.set(false)

        // drain + 资源释放放在后台线程,不阻塞调用方
        val drainRunnable = Runnable {
            // v6.7.60: 停止路径全段毫秒级计时(复测定位用)
            val t0 = SystemClock.elapsedRealtime()
            logDetail("stop_cmd", "stopAsync begin t=0")
            // v6.7.104 (B1): stopAsync 补 v6.7.102 B5 的 projection 失效判定。
            // stopAsync 是 MediaProjection 系统回收时的主要触发路径(Service 侧异步停止),
            // 若仍走 signalEndOfInputStream,c2.avc 编码器在缺关键帧下永不产出 EOS,
            // awaitDrainCompletion 30s 超时后强制 flush 砍掉尾部若干帧。
            // 判定不仅看对象引用,还要看 projectionInvalid 标志(B2),防止 onStop
            // 后字段未置 null 导致误判。
            val projectionAlive = virtualDisplay != null && mediaProjection != null
                && !ScreenRecorderApp.projectionInvalid
            try {
                if (projectionAlive) {
                    val encoder = videoEncoder
                    if (encoder != null && encoderReady.get()) {
                        encoder.signalEndOfInputStream()
                        logDetail("stopAsync", "signaled end of input stream")
                    }
                } else {
                    logDetail("stopAsync", "projection invalid, skip EOS and force muxerVideoDone=true (invalid=${ScreenRecorderApp.projectionInvalid})")
                    muxerVideoDone = true
                }
            } catch (e: Exception) {
                logDetail("stopAsync_signal_error", "${e.message}")
            }
            logDetail("drain_start", "t=${SystemClock.elapsedRealtime() - t0}ms")

            awaitDrainCompletion()
            // v6.7.178 (⑤-b): 编码器指标透传。getMetrics() API23 公开,返回 PersistableBundle。
            // 只取 api.* 前缀(文档承诺语义,含产出帧数/丢帧数);vendor.* 只报键数不猜语义——
            // 跨机型键名漂移,读死必翻车。锚在 drain_done 之前:编码器此刻尚未释放。
            try {
                val mb = videoEncoder?.getMetrics() ?: android.os.PersistableBundle()
                val apiKeys = mb.keySet().filter { it.startsWith("api.") }
                val apiStr = apiKeys.joinToString(",") { k ->
                    val v = try { mb.getString(k) } catch (_: Exception) {
                        try { mb.getLong(k).toString() } catch (_: Exception) {
                            try { mb.getDouble(k).toString() } catch (_: Exception) { "?" } } }
                    "$k=$v"
                }
                logDetail("enc_metrics", "api=[$apiStr] vendorKeys=${mb.keySet().count { it.startsWith("vendor.") }}")
            } catch (e: Exception) { logDetail("enc_metrics", "error: ${e.message}") }
            logDetail("drain_done", "t=${SystemClock.elapsedRealtime() - t0}ms")
            val drainDoneMs = SystemClock.elapsedRealtime() - t0
            flushMuxer()
            logDetail("muxer_stop_done", "t=${SystemClock.elapsedRealtime() - t0}ms")
            val muxerStopMs = SystemClock.elapsedRealtime() - t0 - drainDoneMs
            releaseResources()
            logDetail("release_done", "t=${SystemClock.elapsedRealtime() - t0}ms")
            val releaseDoneMs = SystemClock.elapsedRealtime() - t0 - drainDoneMs - muxerStopMs

            val dur = calculateDuration()
            // v6.7.97 (改进1): 同 stop() —— 先拷贝、再改名、最后组 historyPath。
            // v6.7.99: 即使无 SAF 也改名本地 .recording.tmp -> .mp4
            // v6.7.189 (P2-16): 停止耗时可拆解。此前只有一个 total,2 秒的停止无法归因。
            val tSaf = SystemClock.elapsedRealtime()
            val safResult = performSafCopy()
            val safMs = SystemClock.elapsedRealtime() - tSaf
            val tRen = SystemClock.elapsedRealtime()
            renameToFinal()
            val renMs = SystemClock.elapsedRealtime() - tRen
            logDetail("stop_timing",
                "drain=${drainDoneMs}ms muxerStop=${muxerStopMs}ms release=${releaseDoneMs}ms " +
                    "safCopy=${safMs}ms(${(safResult?.bytes ?: 0L) / 1024}KB, " +
                    "${if (safMs > 0) (safResult?.bytes ?: 0L) * 1000 / 1024 / 1024 / safMs else 0}MB/s) " +
                    "rename=${renMs}ms total=${SystemClock.elapsedRealtime() - t0}ms")
            val sizeUri = finalSafUri ?: safResult?.uri
            val historyPath = finalSafUri?.toString() ?: safResult?.uri?.toString() ?: outputFilePath
            val size = resolveFinalSize(sizeUri, safResult?.bytes ?: 0L)
            // 同步回到成员变量,供 logLearnReport 输出正确的 finalSize;
            // 否则 AsyncDrainThread 路径该值恒为 0(learn_report finalSize=0)。
            finalFileSize = size
            // v6.7.50: 同步 finalDurationMs,与 stop() 同步路径保持一致,避免
            // getDurationMs() 在异步停止路径返回旧值。
            finalDurationMs = dur

            // v6.7.95 (改进3): 静音自检报告
            logAudioSilenceCheck()

            // 学习报告：输出本次录制摘要。对齐 AZ：历史数据由 saveRecordingLearnState 在每次录制结束落盘，
        // loadLearnState 读取，applyHistoricalFpsCap 应用。
            logLearnReport()
            saveRecordingLearnState()

            // 回调到调用方线程执行 cleanupAndStop 等安全操作。
            // v6.7.108 (修复): 旧实现无条件 callbackHandler.post,若此时 serviceHandler 的
            // Looper 已 quitSafely 退出,post 返回 false 静默丢弃,onStopped 永不执行。
            // 触发链:handleStop 调 stopAsync 后 MediaProjection onStop(系统回收投影)post
            // 到 serviceHandler 跑 cleanupAndStop → onDestroy 又 post cleanupAndStop →
            // serviceThread.quitSafely,而 AsyncDrainThread 此时还在跑 saf_copy/rename,
            // 收尾段 post 已无处投递。后果:recordToHistory 不执行,SAF rename 明明成功
            // (文件已在目标目录),录制历史却查不到这条记录("录制完成但未显示录制历史")。
            // 修复:post 返回 false(Looper 已 quit)时改在当前线程同步执行 onStopped。
            // cleanupAndStop 内 dismissFloatOverlay/showFloatOverlay 等非主线程调用已自动
            // post 到主线程,historyManager 单例带锁,直接执行安全。
            // v6.7.189 (P0-1): 多分片路径列表必须在 post 之前取快照(避免跨线程看到已清理的 segments),
            // 且 onSegments 必须先于 onStopped —— Service 的 onStopped 内部立刻读 pendingSegmentPaths。
            val segPaths = getSegmentPaths()
            val stopBody: () -> Unit = {
                logDetail("onStopped", "total=${SystemClock.elapsedRealtime() - t0}ms segments=${segPaths.size}")
                callback?.onSegments(segPaths)
                callback?.onStopped(dur, size, historyPath)
                Unit
            }
            val posted = callbackHandler.post(stopBody)
            if (!posted) {
                logDetail("onStopped",
                    "callbackHandler quit, posting inline total=${SystemClock.elapsedRealtime() - t0}ms")
                stopBody()
            }
        }
        Thread(drainRunnable, "AsyncDrainThread").start()
    }

    private fun logLearnReport() {
        logSection("Learn Report")
        // v6.7.189 (P1-5): 温度采样汇总(尖峰抑制计数在此落账)。
        logDetail("thermal_summary", "samples=${thermalSampleCount.get()} " +
            "spikeRejected=$thermalSpikeRejected baseline=$thermalBaselineC finalMedian=${thermalTempC()}")
        // v6.7.189 (P1-10): AV 重锚汇总。
        logDetail("av_summary", "reanchor=$reanchorCount finalOffsetMs=${audioPtsOffsetUs / 1000}")
        // v6.7.189 (P1-11) / v6.7.191 (P0-4): 停顿汇总,时间/帧双口径。
        // lostWall 是墙钟口径(超出 300ms 阈值的净时长),lostPts 才是成片里真正缺的时长;
        // missingFrames 用于与 frame_accounting 的 unattributed 交叉验证 —— 旧的单一墙钟口径
        // 无法自证(实测 lost=1555ms 而 frame_accounting 全零,两者互不印证)。
        logDetail("stall_summary",
            "count=$stallCount max=${stallMaxUs / 1000}ms " +
                "lostWall=${(stallTotalUs - stallCount * 300_000L).coerceAtLeast(0L) / 1000}ms " +
                "lostPts=${stallPtsTotalUs / 1000}ms missingFrames=$stallMissingFrames " +
                "frames=$videoFrameSeq targetFps=$targetFps")
        // v6.7.189 (P2-15b) / v6.7.190 (P0-2): 帧会计汇总。恒等式
        //   dequeued = written + attributed + unattributed
        // 旧版只有 captured/written,二者都在同一条成功路径自增,恒等式恒真、无诊断价值。
        // unattributed 必须为 0;非 0 说明还有未归因丢帧路径,那才是真正要查的东西。
        // v6.7.190 (P0-1): 同时输出视频/音频/最终三口径时长,暴露容器时长分叉来源。
        val attributedDrops = dropPaused + dropNonMonotonic + dropTooDense + dropWaitIdr +
            dropTailTrim + dropEosOrIdle + drop4GLimit + dropSwitchFailed
        val vDurMsAcc = if (videoFirstMuxedPtsUs >= 0L && lastMuxedVideoPtsUs >= videoFirstMuxedPtsUs)
            (lastMuxedVideoPtsUs - videoFirstMuxedPtsUs) / 1000L else 0L
        val aDurMsAcc = if (lastAudioFrameTimeUs > 0L && firstAudioFrameTimeUs.get() >= 0L)
            (lastAudioFrameTimeUs - firstAudioFrameTimeUs.get()) / 1000L else 0L
        logDetail("frame_accounting",
            "dequeued=$framesDequeued written=$writtenFrames captured=$capturedFrames " +
                "attributed=$attributedDrops unattributed=${framesDequeued - writtenFrames - attributedDrops} " +
                "dropPaused=$dropPaused dropNonMono=$dropNonMonotonic " +
                "dropTooDense=$dropTooDense dropWaitIdr=$dropWaitIdr dropTailTrim=$dropTailTrim " +
                "dropEosOrIdle=$dropEosOrIdle drop4GLimit=$drop4GLimit dropSwitchFailed=$dropSwitchFailed " +
                "droppedElse=$framesDroppedElse targetFps=$targetFps durMs=$finalDurationMs " +
                "videoDurMs=$vDurMsAcc audioDurMs=$aDurMsAcc " +
                // v6.7.191 (P0-2): 上一版是 |finalDurationMs - vDurMsAcc|,而 finalDurationMs 就是
                // 由 vDurMsAcc 同源算出来的 —— 自己减自己,恒为 0,自证式断言、无诊断价值。
                // 改用跨坐标系的 tailOverrunMs(编码器交回末端超出写入末端+裁剪标记多少),
                // 非 0 才说明"裁了但仍在时长里"。
                "tailOverrunMs=${(kotlin.math.abs(lastVideoFrameTimeUs - lastMuxedVideoPtsUs) +
                    (if (audioTrimEndUs > 0L) audioTrimEndUs else videoTrimEndUs.takeIf { it > 0L } ?: 0L)) / 1000L}")
        val learnState = loadLearnState(context)
        val vSeq = videoFrameSeq
        val vFpsActual = if (lastVideoFrameTimeUs > 0 && firstVideoFrameTimeUs >= 0 && lastVideoFrameTimeUs > firstVideoFrameTimeUs)
            vSeq.toDouble() * 1_000_000.0 / (lastVideoFrameTimeUs - firstVideoFrameTimeUs) else 0.0
        val aBytes = audioBytesWritten
        // v6.7.172 (P0-B): 音频时长改用"已写入 muxer 的 PTS 跨度",与视频、与 duration_calc 同源。
        // 原字节算法 aBytes*1000/(channels*2*sampleRate) 把 pre-roll 与 mux 阶段被丢弃/平移的样本
        // 也算进去,虚高音频时长(实测 9822 vs 真实轨长 9443),导致 A/V 漂移方向被判定反
        // (监控报"音频更长 284ms",MP4 实测"音频更短 113ms")。改用 first/lastAudioFrameTimeUs
        // 后与视频用同一套起止字段,方向相反的问题立刻消失,learn_report 正确报出真实方向。
        // 此改只修正遥测口径,不动任何编码/封装逻辑。
        val aDurationMs = if (lastAudioFrameTimeUs > 0L && firstAudioFrameTimeUs.get() >= 0L)
            (lastAudioFrameTimeUs - firstAudioFrameTimeUs.get()) / 1000L else 0L
        val vDurationMs = if (lastVideoFrameTimeUs > 0 && firstVideoFrameTimeUs >= 0)
            (lastVideoFrameTimeUs - firstVideoFrameTimeUs) / 1000L else 0L
        val osPowerSave = try {
            (context.getSystemService(Context.POWER_SERVICE) as? PowerManager)?.isPowerSaveMode == true
        } catch (_: Exception) { false }
        // v6.7.190 (P1-4): 三个码率互不相等(currentBitrate 是运行时配置值,avgBitrate 是
        // learn 历史平均,而产物真实码率是 finalSize/dur)。补 effectiveMuxBitrate 把产物口径
        // 摆到同一行,三者语义:配置意图 / 历史平均 / 本次实际。
        val durMsForBr = if (vDurationMs > 0L) vDurationMs else (finalDurationMs.takeIf { it > 0L } ?: 1L)
        val effectiveMuxBitrate = if (finalFileSize > 0L) finalFileSize * 8L / durMsForBr else 0L
        logDetail("learn_report",
            "totalRecordings=${learnState.totalRecordings} " +
                "adaptiveLevel=${adaptiveLevel} " +
                "targetFps=${targetFps} actualFps=${"%.1f".format(vFpsActual)} " +
                "currentBitrate=${currentBitrate} " +
                "videoFrames=${vSeq} videoDurationMs=${vDurationMs} " +
                "audioBytes=${aBytes} audioDurationMs=${aDurationMs} " +
                "finalSize=${finalFileSize} " +
                "effectiveMuxBitrate=$effectiveMuxBitrate " +
                "powerSave=${osPowerSave} " +
                "encQueueBacklog=${encoderQueue.size} " +
                "ptsClockFuse=$ptsClockFuseCount " +
                "avgFps=${learnState.avgFps} avgBitrate=${learnState.avgBitrate}")
        // 学习建议
        val suggestions = mutableListOf<String>()
        if (vFpsActual > 0 && vFpsActual < targetFps * 0.8) {
            suggestions.add("video_underperform: actual ${"%.1f".format(vFpsActual)}fps < 80% target ${targetFps}fps, consider downgrading fps")
        }
        if (osPowerSave) {
            // 诊断信息：省电模式开启且 fps 未被强制降低（对齐 AZ/v6.7.32 策略）。
            // 不作为降档建议。actualFps 低于目标是背压自然结果，由编码器自行处理。
            suggestions.add("power_save_active: power save ON, fps NOT downgraded per AZ policy (no runtime fps downgrade)")
        }
        if (encoderQueue.size > 16) {
            suggestions.add("audio_backlog: encoderQueue=${encoderQueue.size}, consider increasing audio encode thread priority")
        }
        if (suggestions.isNotEmpty()) {
            for (s in suggestions) {
                logDetail("learn_suggestion", s)
            }
        }
    }

    /**
     * 保存本次录制的学习数据到 SharedPreferences。
     * 仅当录制有效帧数>0 且 时长≥3秒时生效，防止误触/中断污染历史。
     * 使用滑动窗口平均（窗口 24）更新历史 avgFps 与 avgBitrate。
     * 异步落盘，不影响录制热路径。
     */
    // v6.7.137 (改进1): 读取上次录制实际编码器偏好("hevc"/"avc",由 saveRecordingLearnState 落盘)。
    // 供 start() 回灌: 上次因设备能力被迫选 AVC 时,本次默认不硬试 HEVC。
    private fun learnedEncoderPref(): String? {
        return try {
            context.getSharedPreferences(LEARN_PREFS_NAME, Context.MODE_PRIVATE)
                .getString(KEY_LEARN_ENCODER_PREF, null)
        } catch (e: Exception) { null }
    }

    // v6.7.138 (改进1 缺陷修复): 读取上次 AVC 落盘的 reason。
    // 仅当 "device_cap" 时才允许 start() 回灌压制 useHevc;
    // "manual" 或 null(老数据/兼容) 一律不回灌,尊重用户显式选择。
    private fun learnedReason(): String? {
        return try {
            context.getSharedPreferences(LEARN_PREFS_NAME, Context.MODE_PRIVATE)
                .getString(KEY_LEARN_REASON, null)
        } catch (e: Exception) { null }
    }

    private fun saveRecordingLearnState() {
        val cfg = config ?: return
        val vSeq = videoFrameSeq
        val durMs = finalDurationMs
        // 仅当有实际视频帧且时长≥3秒时学习，防止误触/中断污染数据
        if (vSeq <= 0L || durMs < 3000L) return
        // 实际帧率由视频帧数与首末时间戳计算
        val vFpsActual = if (lastVideoFrameTimeUs > 0L && firstVideoFrameTimeUs >= 0L &&
                lastVideoFrameTimeUs > firstVideoFrameTimeUs) {
            vSeq.toDouble() * 1_000_000.0 / (lastVideoFrameTimeUs - firstVideoFrameTimeUs)
        } else 0.0
        if (vFpsActual <= 0.0) return
        // v6.7.169 (P1 方案B): 学习态 avgFps 用"有效采集帧率"作基数,而非配置帧率,
        // 避免被真实采集帧率(60Hz 屏选 30fps 实编 ~55-60)污染基数。
        // 原 min(vFpsActual, cfg.fps) 把真实值抹成配置值,死循环;
        // v6.7.169 早前改为取真值,又会让 60Hz 屏的 55 进入均值带偏后续决策。
        // 改为 min(vFpsActual, effectiveCaptureFps):配置帧率低于采集能力时取配置值
        // (反映"用户要求 30fps"),高于采集能力时取采集值(反映设备真实上限)。
        // effectiveCaptureFps 由显示刷新率决定,60Hz 屏即 ~60。
        val cappedActual = minOf(vFpsActual, (effectiveCaptureFps.takeIf { it > 0 } ?: cfg.fps.toDouble()).toDouble())
        val prev = loadLearnState(context)
        val n = prev.totalRecordings + 1

        // v6.7.116 (自学习均值修复, 对照 AZ + 数值仿真):
        // 旧实现 window=max(8,n)+样本对折+数值减半, 三处叠加导致:
        //   n=1 时 window=8, prev.avgFps=0 被当 7 份"幻影历史", sample=实测*0.5,
        //   首次落盘 = 实测/16 (43fps->2~3); window 随 n 增长变永不遗忘的累积平均,
        //   偏差永久固化 (连录 20 次仍 27 vs 真值 43), effectiveCap~15 恒取兜底 30fps,
        //   自学习形同虚设, v6.7.113 回弹(依赖 avgFps>=上一档*0.9)永不触发。
        // 修正: 单次平滑 + 有效样本数 effN=min(n,12), 惯性封顶 1/12。
        //   n=1 -> newAvg=真值(冷启动直接播种, 无幻影样本); n>=12 抗抖又随能力变化渐变。
        // 省电/Doze: 降"权重"而非缩小数值——样本仍按实际值, 但只算半份权重,
        //   避免长期均值被系统性拉低 (报告 P1-2)。
        val effN = kotlin.math.min(n, 12)
        val actual = cappedActual
        val powerSave = try {
            (context.getSystemService(Context.POWER_SERVICE) as? PowerManager)
                ?.isPowerSaveMode == true ||
                (context.getSystemService(Context.POWER_SERVICE) as? PowerManager)
                    ?.isDeviceIdleMode == true
        } catch (_: Throwable) { false }
        val k = if (powerSave) 0.5 else 1.0
        var newAvgFps = ((prev.avgFps * (effN - 1) + k * actual) / (effN - 1 + k) + 0.5).toInt()
        // v6.7.189 (P1-8): 学习值显著低于本次实测(差 >20%)判定为历史样本失效
        // (换机 / 换档位 / 长期省电误压),直接向实测值靠拢 85%,一次录制内纠偏,
        // 不再需要十几次录制慢慢爬。只向上纠,不向下纠(设备变差时仍走保守平滑)。
        // 落点日志:learn_reseed(见下)。
        if (vFpsActual > 1.0 && newAvgFps < vFpsActual * 0.8) {
            val corrected = (vFpsActual * 0.85 + 0.5).toInt().coerceAtLeast(newAvgFps)
            logDetail("learn_reseed", "avgFps $newAvgFps -> $corrected (actual=${"%.1f".format(vFpsActual)})")
            newAvgFps = corrected
        }
        // v6.7.140 (BUG-B): 码率平滑公式与帧率对齐——乘以省电权重 k，分母用 (effN-1+k)。
        // 旧实现分母写死 effN 且不乘 k，省电模式低码率按满权重拉低长期均值，与帧率口径分裂。
        val newAvgBitrate = if (prev.totalRecordings > 0) {
            ((prev.avgBitrate * (effN - 1) + k * currentBitrate)
                / (effN - 1 + k) + 0.5).toInt()
        } else currentBitrate
        // v6.7.140 (BUG-C): 省电模式下 adaptiveLevel 不增长，避免把省电降频误记为"设备能力强"。
        val newLevel = if (powerSave) prev.adaptiveLevel
                       else kotlin.math.min(prev.adaptiveLevel + 1, 8)
        logDetail("learn_save",
            "n=$n effN=$effN raw=${"%.1f".format(vFpsActual)} capped=${"%.1f".format(cappedActual)} " +
                "powerSave=$powerSave k=$k newAvgFps=$newAvgFps prevAvg=${prev.avgFps}")
        // v6.7.139 (修复隔次循环): 不再用 cfg.useHevc 判定(回灌场景下它已被压成 false 导致误写 manual)。
        // 以"是否真实尝试过 HEVC 失败"或"是否学习态回灌压制"为准，device_cap 状态得以跨录制连续。
        val encoderReason = when {
            hevcConfigureFailed -> "device_cap"
            hevcSuppressedByLearn -> "device_cap"
            else -> "manual"
        }
        context.getSharedPreferences(LEARN_PREFS_NAME, Context.MODE_PRIVATE).edit()
            .putInt(KEY_LEARN_ADAPTIVE_LEVEL, newLevel)
            .putInt(KEY_LEARN_AVG_FPS, newAvgFps)
            .putInt(KEY_LEARN_AVG_BITRATE, newAvgBitrate)
            .putInt(KEY_LEARN_TOTAL_RECORDINGS, n)
            .putString(
                KEY_LEARN_ENCODER_PREF,
                if (cfg.useHevc && !hevcConfigureFailed && !hevcSuppressedByLearn) "hevc" else "avc"
            )
            .putString(KEY_LEARN_REASON, encoderReason)
            .putBoolean(KEY_LEARN_RESOLUTION_DOWNGRADE, prev.resolutionDowngraded)
            .putLong(KEY_LEARN_CRC32, crc32Of(learnStateFingerprint(
                newLevel, newAvgFps, newAvgBitrate, n,
                if (cfg.useHevc && !hevcConfigureFailed && !hevcSuppressedByLearn) "hevc" else "avc",
                prev.resolutionDowngraded)))
            // v6.7.127 (P1-5): 配置落盘频率极低(每录制结束一次),commit() 同步写无感知代价，
            // 换取 kill() 后 crc+值 一并落盘,避免 apply() 异步丢写造成 crc/值 不可预测组合。
            .commit()
        // v6.7.181 (N1): 若停止时仍处于锁屏态,markScreenUnlocked 未走到,最后一段锁屏
        // 时长不会入账。汇报前补算一次,保证 screenLockedMs 反映整段录制而非只计已解锁段。
        if (screenLockedAtMs >= 0) {
            screenLockedTotalMs += SystemClock.elapsedRealtime() - screenLockedAtMs
            screenLockedAtMs = -1
        }
        // v6.7.140 (方案3): 结构化录制报告——每次录制结束落一条汇总 JSON。
        runCatching {
            val report = org.json.JSONObject().apply {
                put("durationMs", durMs)
                put("frameCount", vSeq)
                put("avgSeqFps", vFpsActual.toInt())
                put("targetFps", cfg.fps)
                put("width", getActualWidth())
                put("height", getActualHeight())
                put("bitrate", currentBitrate)
                put("encoder", if (useHevc) "hevc" else "avc")
                put("powerSave", powerSave)
                put("stopReason", finalStopReason)
                // v6.7.155: 事前容量估算(秒)。满盘为 0,便于事后核对"是不是容量触顶".
                put("remainingSec", estimateRemainingTime())
                put("segmentCount", getSegmentCount())
                // v6.7.180: 锁屏累计时长(ms)。>0 说明录制期间出现过息屏,对应段为锁屏/黑帧。
                put("screenLockedMs", screenLockedTotalMs)
                // v6.7.183: 锁屏保 CPU 是否真的生效。false 且 screenLockedMs>0 = 该段有
                // 黑帧/静音空洞风险(持锁失败或锁被系统审计撤销)。
                put("wakeLockHeld", wakeLockHeld)
                // v6.7.184: 中段锁丢失次数。与 wakeLockHeld 合看才完整:
                // true+>0 = 中段有 CPU 空洞后恢复; false+screenLockedMs>0 = 全程没锁住,风险最高。
                put("wakeLockLostCount", wakeLockLostCount)
            }
            context.getSharedPreferences(LEARN_PREFS_NAME, Context.MODE_PRIVATE)
                .edit().putString("record_report_latest", report.toString()).apply()
        }
        DiagLog.logEvent("RECORD_SUMMARY", "latest report written, stopReason=$finalStopReason")
        // v6.7.178 (⑤-d): AV 偏移分位数 + 漂移率 ppm。1Hz 采样,序号即秒。
        // p95 贴近 p50 且 drift_ppm≈0 = 一次性锚定;持续走高 = 真实漂移。
        try {
            val ord = avDeltaRing.toList()
            if (ord.size >= 10) {
                val srt = ord.sorted()
                val qt = { p: Double -> srt[((srt.size - 1) * p).toInt().coerceAtMost(srt.size - 1)] }
                val headAvg = ord.take(ord.size / 10).average()
                val tailAvg = ord.takeLast(ord.size / 10).average()
                // v6.7.184: spanUs 是 head 与 tail 两段的时间中心距,不是"每段跨度"。
                // 1Hz 采样下 n 段总时长约 n 秒,首尾十分位的中心距 = n − n/10 秒。
                // 原式 (n/10)*1e6 是每段自身跨度,分母小约 9 倍 -> drift_ppm 虚高约 9 倍,
                // 把好机型误判成持续漂移。
                val spanUs = (ord.size - ord.size / 10).coerceAtLeast(1) * 1_000_000.0
                val ppm = ((tailAvg - headAvg) / spanUs * 1_000_000).toLong()
                logDetail("av_quantiles", "n=${ord.size} min=${srt.first()} p50=${qt(0.5)} " +
                    "p95=${qt(0.95)} p99=${qt(0.99)} max=${srt.last()} drift_ppm=$ppm")
            }
        } catch (_: Exception) {}
        // v6.7.178 (⑤-e): PTS 步长直方图。target=1_000_000/fps µs。
        try {
            val targetFpsCfg = config?.fps ?: 0
            logDetail("pts_hist", "burst(≤11µs)=$ptsStepBurst lt20ms=$ptsStepLt20 20-40ms=$ptsStep30 " +
                "40-80ms=$ptsStepHi gt80ms=$ptsStepGt80 max=${ptsStepMaxUs}us " +
                "(target=${if (targetFpsCfg > 0) 1_000_000 / targetFpsCfg else 0}µs)")
        } catch (_: Exception) {}
    }

    // v6.7.97 (改进5): 静音自检收口。所有音频静音计数只在 logAudioSilenceCheck 一处输出，
    // 录制结束(stop/forceStop/stopAsync)各调用一次，避免同一信号被多处打日志。
    private fun logAudioSilenceCheck() {
        val iTot = audioSilenceInternalTotal.get()
        val iSil = audioSilenceInternalSilent.get()
        val oTot = audioSilenceOutputTotal.get()
        val oSil = audioSilenceOutputSilent.get()
        val iSilent = iTot >= 100 && iSil >= iTot * 0.98
        val oSilent = oTot >= 100 && oSil >= oTot * 0.98
        logDetail("audio_silence",
            "internal=${iSil}/${iTot} output=${oSil}/${oTot} " +
                "internalSilent=$iSilent outputSilent=$oSilent " +
                // v6.7.178 (⑤-f): 路径标签解 internal=0/0 歧义。single 内录会话全部喂进
                // output* 桶,internal=0/0 不是丢采样而是命名遗留;标 path 后日志自解释。
                "path=" + if (config?.useInternalAudio == true && config?.useMicAudio == true)
                    "dual" else "single")
    }

    // v6.7.83 (问题B): 返回 SAF 拷贝产出的 document URI;成功后删除本地临时文件,
    // 杜绝"SAF 一份 + 私有目录 temp 一份"的双份孤儿占用(=2×19.28MB)。
    // 拷贝失败则返回 null,本地文件保留(历史仍指向本地,可打开可删除)。
    // v6.7.84 (新增-1/2): 删除本地前先记下字节数 srcLen(供 resolveFinalSize 兜底,否则
    // 本地文件删掉后 File.length() 恒为 0);仅在 SAF 侧字节数与源文件逐字节一致时才删本地,
    // 杜绝"写一半当成功→本地被删→视频永久丢失"。
    private fun performSafCopy(): SafCopyResult? {
        val uri = safOutputUri ?: return null
        val fileName = safTargetFileName.ifEmpty {
            "recording_${System.currentTimeMillis()}.mp4"
        }
        val sourceFile = outputFile ?: return null

        // 删除之前先把大小记下来。resolveFinalSize 的兜底路径要在这里取到大小。
        val srcLen = sourceFile.length()

        val result = try {
            safCopyToTree(sourceFile, uri, fileName, srcLen)
        } catch (e: Exception) {
            logDetail("saf_copy_error", Log.getStackTraceString(e))
            writeEmergencyLog("SAF copy failed: ${e.message ?: e.javaClass.name}", e)
            null
        }
        if (result == null) {
            // 拷贝失败: 本地必须留着,历史仍指向本地,用户还能播能删
            logDetail("saf_copy", "copy failed, keeping local file ${sourceFile.absolutePath}")
            return null
        }
        // 记录 createDocument 产出的目的文件 document URI,供 renameToFinal 改名用。
        // 不能依赖 safOutputUri(tree 目录 URI),renameDocument 只认 document URI。
        safDocumentUri = result.uri
        // v6.7.121 (P1-4): 拷贝成功即写"已导出"标记。若下一步删本地前被杀,下次 findStale
        // 命中该标记会直接删除本地副本,而不在应用目录重复保留/误报未完成录制。
        runCatching {
            outputFilePath?.let { safExportedSet(context, add = it) }
        }
        // SAF 侧字节数与源文件逐字节比对通过,才允许删本地
        try {
            // v6.7.178 (⑤-c): 哈希必须在删文件前取,否则源已不在。
            val hash = if (sourceFile.exists()) sha256Quick(sourceFile) else "na"
            if (sourceFile.exists() && sourceFile.delete()) {
                logDetail("saf_copy",
                    "verified ${result.bytes}B hash=$hash removed local temp ${sourceFile.absolutePath}")
            }
        } catch (_: Exception) {}
        return result
    }

    // v6.7.97 (改进1): 把录制中产物重命名为最终 .mp4,让相册/媒体扫描器识别。
    // SAF 路径走 DocumentsContract.renameDocument(此前用 File.renameTo 对 content URI 无效,
    // 导致 GLA 上产物恒为 "xxx.recording.tmp.mp4");本地路径走 File.renameTo。
    // v6.7.106 (修复): renameDocument 第一参必须传 createDocument 返回的真实 document URI
    // (safDocumentUri),而非目录 tree URI(safOutputUri)。传 tree URI 会抛 IllegalArgumentException
    // ("Invalid URI"),导致 rename_final 保留 .recording.tmp、历史恒指向 tmp 产物,用户看到
    // "录制历史显示异常"(文件永远是 xxx.recording.tmp.mp4)。
    // 改名成功后把最终 URI 保存到 finalSafUri,供 stop/forceStop/stopAsync 回调 onStopped
    // 时把历史记录指向 .mp4 document(而非 .tmp)。改名失败保留 .tmp 状态,不影响回放。
    private fun renameToFinal() {
        finalSafUri = null
        // SAF 路径优先走 DocumentsContract.renameDocument。仅当 SAF 拷贝成功产出了真实
        // document URI(safDocumentUri)时才改名;拷贝失败(safDocumentUri==null)时本地文件
        // 已保留,走下方 File.renameTo 分支把本地 .recording.tmp 改回 .mp4。
        val uri = safDocumentUri
        if (uri != null) {
            val srcName = safTargetFileName.ifEmpty {
                try { uri.lastPathSegment?.let { android.net.Uri.decode(it) } ?: "" } catch (_: Exception) { "" }
            }
            if (srcName.endsWith(".recording.tmp")) {
                val newBase = srcName.dropLast(".recording.tmp".length)
                val mp4Name = if (newBase.isEmpty()) "recording.mp4" else "$newBase.mp4"
                try {
                    val newUri = android.provider.DocumentsContract.renameDocument(
                        context.contentResolver, uri, mp4Name)
                    if (newUri != null) {
                        finalSafUri = newUri
                        logDetail("rename_final", "SAF renamed to $mp4Name uri=$newUri")
                    } else {
                        logDetail("rename_final",
                            "SAF renameDocument returned null for '$srcName' -> '$mp4Name', keeping .tmp")
                    }
                } catch (e: Exception) {
                    logDetail("rename_final",
                        "SAF renameDocument error: ${e.message ?: e.javaClass.name}, keeping .tmp")
                }
            }
            return
        }
        // 本地路径走 File.renameTo
        if (outputFilePath.endsWith(".recording.tmp")) {
            val mp4Path = outputFilePath.dropLast(".recording.tmp".length) + ".mp4"
            val src = File(outputFilePath)
            val dst = File(mp4Path)
            if (!src.exists()) {
                logDetail("rename_final", "source file not found: $outputFilePath")
                return
            }
            try {
                if (src.renameTo(dst)) {
                    outputFilePath = mp4Path
                    outputFile = dst
                    logDetail("rename_final", "local renamed to $mp4Path")
                } else {
                    logDetail("rename_final", "local renameTo failed, keeping .tmp at $outputFilePath")
                }
            } catch (e: Exception) {
                logDetail("rename_final", "local renameTo error: ${e.message}, keeping .tmp")
            }
        }
    }

    // v6.7.83 (问题E): 统一从"SAF 最终 document URI"(而非目录 tree URI)查询文件大小。
    // 旧代码 3 处直接对 safOutputUri(树=目录)query OpenableColumns.SIZE,目录无 SIZE
    // 列,每次都打并列错误且取不到;改查真实 document,失败回退已记录 srcLen。
    // v6.7.84 (新增-3): 传入删除前记下的 srcLen 作最可靠首选值。否则本地文件已被
    // performSafCopy 删除,函数末尾的 outputFile?.length() 恒返回 0,历史 sizeBytes=0。
    private fun resolveFinalSize(safUri: Uri?, knownSize: Long): Long {
        if (knownSize > 0L) return knownSize
        if (safUri != null) {
            try {
                val cursor = context.contentResolver.query(
                    safUri, arrayOf(android.provider.OpenableColumns.SIZE), null, null, null)
                cursor?.use {
                    if (it.moveToFirst()) {
                        val i = it.getColumnIndex(android.provider.OpenableColumns.SIZE)
                        if (i >= 0) return it.getLong(i)
                    }
                } ?: run { return outputFile?.length() ?: 0L }
            } catch (e: Exception) {
                logDetail("saf_file_size_error", "${e.message}")
            }
        }
        return outputFile?.length() ?: 0L
    }

    private fun checkAudioTrackTimeout() {
        if (videoTrackIndex < 0 || muxerStarted.get()) {
            audioTrackWaitStartNs = 0L
            return
        }
        if (audioEncoder == null || audioTrackFailed) return

        if (audioTrackIndex >= 0) {
            audioTrackWaitStartNs = 0L
            return
        }

        if (audioTrackWaitStartNs == 0L) {
            audioTrackWaitStartNs = System.nanoTime()
            return
        }

        // 活跃的 AAC 编码器 configure 成功后、输出首帧前必先返回 INFO_OUTPUT_FORMAT_CHANGED
        // (MediaCodec 规范),即音频格式终会到达,等待不会无限。因此音频轨尚未就绪不再强制
        // 超时降级为 video-only——那会在 muxer.start() 之后才收到格式,导致 start 后 addTrack
        // 抛 IllegalStateException(muxer_audio_write_error 全程报错,录制无声/音轨损坏)。
        // audioTrackFailed 只应由真实失败置位(见 tryAddAudioTrack / EOS 收尾逻辑)。
        // 此处仅持续等待并周期记录,避免对活跃编码器做出错误的时序放弃。
        if (System.nanoTime() - audioTrackWaitStartNs > AUDIO_TRACK_TIMEOUT_NS) {
            logDetail("audio_track",
                "audio track not ready after ${AUDIO_TRACK_TIMEOUT_NS / 1_000_000}ms, keeping waiting " +
                    "(not force-failing, to preserve audio track; muxer start is gated on track readiness)")
            audioTrackWaitStartNs = System.nanoTime()
        }
    }

    private fun awaitDrainCompletion() {
        logDetail("drain_start", "encodingVideo=${videoEncoder != null} encodingAudio=${audioEncoder != null} muxerVideoDone=$muxerVideoDone muxerAudioDone=$muxerAudioDone")
        if (encodeThread == null) {
            videoDrainDone.countDown()
        }
        if (audioThread == null) {
            audioDrainDone.countDown()
        }

        try {
            // 动态超时：基于队列帧数估算，每帧约 15ms + 5s 安全余量
            val videoTimeout = (videoFrameSeq * 15L + 5_000L).coerceAtMost(30_000L)
            val videoDone = videoDrainDone.await(videoTimeout, java.util.concurrent.TimeUnit.MILLISECONDS)
            if (!videoDone && !muxerVideoDone) {
                logDetail("drain_wait", "video drain did not complete in time (${videoTimeout}ms) muxerVideoDone=$muxerVideoDone videoFrameSeq=$videoFrameSeq")
                // flush 编码器清空残留缓冲,避免 releaseResources 时编码器
                // 仍持有未排空的 input/output buffer 导致资源泄漏。
                try {
                    videoEncoder?.let { if (encoderReady.get()) it.flush() }
                } catch (e: Exception) {
                    logDetail("drain_wait_flush", "${e.message}")
                }
            }
            // 兜底锁定视频末帧 PTS:若视频因 forceStop 中断而未走 EOS 分支,
            // 仍以最后已知帧 PTS 作为音频尾裁剪上界,避免音频超长尾缺上界。
            if (videoTrimEndUs <= 0L && lastVideoFrameTimeUs > 0L) {
                videoTrimEndUs = lastVideoFrameTimeUs
            }
        } catch (e: InterruptedException) {
            logDetail("drain_wait", "video await interrupted: ${e.message}")
            Thread.currentThread().interrupt()
        }

        try {
            // v6.7.72: 音频轨 EOS 一旦写入 muxer(muxerAudioDone)即视为音频收尾完成,
            // 不再无条件 await 满 5 秒。原写法先 await 再判 muxerAudioDone,导致即使
            // 音频数据早已完整也要干等到超时,日志表现为 latch=false。
            // v6.7.164: 墙钟改单调时钟。System.currentTimeMillis 受 NTP 校时/用户改时间影响会前跳,
            // 导致循环提前退出、音频尾部被丢弃;同文件视频 drain 已统一用 elapsedRealtime。
            val t0 = android.os.SystemClock.elapsedRealtime()
            val deadline = t0 + 5000L
            var audioDone = muxerAudioDone
            while (!audioDone && android.os.SystemClock.elapsedRealtime() < deadline) {
                audioDone = audioDrainDone.await(200, java.util.concurrent.TimeUnit.MILLISECONDS) || muxerAudioDone
            }
            if (!audioDone && !muxerAudioDone) {
                logDetail("drain_wait", "audio drain did not complete in time muxerAudioDone=$muxerAudioDone")
            } else {
                logDetail("drain_wait", "audio drain completed (muxerAudioDone=$muxerAudioDone latch=$audioDone)")
            }
        } catch (e: InterruptedException) {
            logDetail("drain_wait", "audio await interrupted: ${e.message}")
            Thread.currentThread().interrupt()
        }

        // v6.7.172 (P0-A): 两路排空完成后,取 commonEndUs=min(视频末PTS,音频末PTS),
        // 把较长一路裁到 commonEndUs,消除成片"最后 113ms 没声音"。符号无关:
        // 音频比视频短时裁视频尾,视频比音频短时裁音频尾(音频侧由 shouldDropAudioPts
        // 用 videoTrimEndUs 裁,视频侧由 shouldDropVideoPts 用 audioTrimEndUs 裁)。
        // 视频 EOS 残留帧会在后续 handleVideoOutput 中被 shouldDropVideoPts 裁尾。
        val vEndUs = if (lastVideoFrameTimeUs > 0L) lastVideoFrameTimeUs else 0L
        val aEndUs = lastAudioFrameTimeUs
        val commonEndUs = if (vEndUs > 0L && aEndUs > 0L) minOf(vEndUs, aEndUs) else 0L
        if (commonEndUs > 0L) {
            videoTrimEndUs = commonEndUs
            audioTrimEndUs = commonEndUs
            logDetail("av_trim_align",
                "commonEndUs=$commonEndUs vEnd=$vEndUs aEnd=$aEndUs " +
                    "droppedMs=${((vEndUs + aEndUs) - 2L * commonEndUs) / 1000L}")
        }
    }

    private fun tryStartMuxer() {
        if (muxerStarted.get()) return
        synchronized(muxerLock) {
            if (muxerStarted.get()) return
            if (videoTrackIndex < 0) return
            tryAddAudioTrack()
            if (audioEncoder != null && !audioTrackFailed && audioTrackIndex < 0) return
            val muxer = mediaMuxer ?: return

            try {
                ensureIndexTracker()
                muxer.start()
                muxerStarted.set(true)
                logDetail("muxer", "started with video=$videoTrackIndex audio=$audioTrackIndex")
            } catch (e: Exception) {
                logDetail("muxer_start_error", "${e.message}")
            }
        }
    }

    // v6.7.120 (被杀保护): 在两轨都 addTrack 后、muxer.start 前,用真实轨道参数
    // 惰性构建 .idx Tracker。无 .idx 流或参数缺失则放弃本次索引(降级为改名保留)。
    private fun ensureIndexTracker() {
        if (indexTracker != null || indexOut == null) return
        val vf = videoTrackFormat
        val af = audioTrackFormat
        try {
            val hasV = vf != null
            val hasA = af != null && audioTrackIndex >= 0
            val vcsd0 = idxCsd(vf?.getByteBuffer("csd-0"))
            val vcsd1 = idxCsd(vf?.getByteBuffer("csd-1"))
            val fps = vf?.getInteger(MediaFormat.KEY_FRAME_RATE) ?: config?.fps ?: 30
            val width = vf?.getInteger(MediaFormat.KEY_WIDTH) ?: config?.width ?: 0
            val height = vf?.getInteger(MediaFormat.KEY_HEIGHT) ?: config?.height ?: 0
            val acsd0 = idxCsd(af?.getByteBuffer("csd-0"))
            val sr = af?.getInteger(MediaFormat.KEY_SAMPLE_RATE) ?: 48000
            val ch = af?.getInteger(MediaFormat.KEY_CHANNEL_COUNT) ?: 1
            val codec = if (config?.useHevc == true) 1 else 0
            indexTracker = Mp4Repairer.Tracker(
                hasV, vcsd0, vcsd1, fps, width, height,
                hasA, if (hasA) acsd0 else null, sr, ch, codec, indexOut ?: return,
            )
            // v6.7.122: 抢写+同步头部(csd/尺寸/fps 先落盘), 进程被杀时 .idx 至少保留重建 moov 所需的头部参数。
            indexTracker?.flushHeader()
            (indexOut as? java.io.FileOutputStream)?.fd?.sync()
        } catch (_: Exception) {
            indexTracker = null
        }
    }

    // v6.7.120: 复制 MediaFormat 的 csd ByteBuffer 为字节数组(dup 不影响原 buffer 位置)。
    private fun idxCsd(b: java.nio.ByteBuffer?): ByteArray? {
        if (b == null) return null
        val d = b.duplicate()
        val a = ByteArray(d.remaining())
        d.get(a)
        return a
    }

    private fun tryAddAudioTrack() {
        synchronized(muxerLock) {
            if (audioTrackIndex >= 0 || audioTrackFailed) return
            // muxer 已 start 后禁止再 addTrack:Android MediaMuxer 规定 start 之后
            // 不可追加轨道,否则 writeSampleData/addTrack 都会抛 IllegalStateException,
            // 导致录制有声无轨异常(华为 GLA-AL00 实测全程 muxer_audio_write_error)。
            // 若已 video-only 启动,音频应被跳过,音频数据写入侧也有 muxerStarted 保护。
            // 该守卫必须先于"等视频轨"判定:否则 video-only 启动后 muxer 已 start、
            // videoTrackIndex>=0,音频会一直等到 muxerStarted 分支才失败,路径变复杂。
            if (muxerStarted.get()) {
                pendingAudioFormat = null
                if (audioTrackIndex < 0 && !audioTrackFailed) {
                    audioTrackFailed = true
                    logDetail("audio_track", "muxer already started, audio track skipped")
                }
                return
            }
            // v6.7.190 (P1-3): 强制视频轨先行。音频格式先就绪时(麦克风/内录比视频编码器
            // 早产出格式),音频会抢跑拿到 track 0、视频落 track 1。MPEG_4 里 HEVC
            // (hvc1/hev1) 探测与部分第三方播放器的首轨判定要求视频为 track 0,
            // 音频先行会表现为"能被系统识别却打不开/无画面"。此处等待视频轨到位,
            // 音频格式继续挂在 pendingAudioFormat 上,视频轨添加后会再次调用本函数。
            if (videoTrackIndex < 0) {
                logDetail("audio_track", "wait for video track first (videoTrackIndex=$videoTrackIndex)")
                return
            }
            // muxer 已 start 后禁止再 addTrack:Android MediaMuxer 规定 start 之后
            // 不可追加轨道,否则 writeSampleData/addTrack 都会抛 IllegalStateException,
            // 导致录制有声无轨异常(华为 GLA-AL00 实测全程 muxer_audio_write_error)。
            // 若已 video-only 启动,音频应被跳过,音频数据写入侧也有 muxerStarted 保护。
            if (muxerStarted.get()) {
                pendingAudioFormat = null
                if (audioTrackIndex < 0 && !audioTrackFailed) {
                    audioTrackFailed = true
                    logDetail("audio_track", "muxer already started, audio track skipped")
                }
                return
            }
            val muxer = mediaMuxer ?: return
            val format = pendingAudioFormat ?: return
            try {
                audioTrackIndex = muxer.addTrack(format)
                audioTrackFailed = false
                logDetail("audio_track", "index=$audioTrackIndex")
                audioTrackFormat = if (audioTrackIndex >= 0) format else null
                pendingAudioFormat = null
            } catch (e: Exception) {
                audioTrackFailed = true
                logDetail("audio_track_error", "${e.message}")
            }
        }
    }

    private fun drainVideoEncoder(endOfStream: Boolean) {
        val encoder = videoEncoder ?: return

        // 轮询模式下,主循环退出后剩余的编码器输出须在此显式排空。
        // 若已 signalEndOfInputStream,编码器最终会产出一个带 BUFFER_FLAG_END_OF_STREAM
        // 的输出帧;handleVideoOutput 检测到后置位 muxerVideoDone,排空即完成。
        // 动态超时:基于队列帧数估算,每帧至少 15ms + 5s 安全余量。
        val dynamicTimeout = (videoFrameSeq * 15L + 5_000L).coerceAtMost(30_000L)
        var waitedMs = 0L
        val drainInfo = MediaCodec.BufferInfo()
        while (!muxerVideoDone && waitedMs < dynamicTimeout) {
            val drainStartMs = SystemClock.elapsedRealtime()
            val outIdx = try {
                encoder.dequeueOutputBuffer(drainInfo, 10_000L)
            } catch (e: Exception) {
                logDetail("drain_video_dequeue", "${e.message}")
                break
            }
            when {
                outIdx >= 0 -> {
                    handleVideoOutput(encoder, outIdx, drainInfo)
                }
                outIdx == MediaCodec.INFO_OUTPUT_FORMAT_CHANGED -> {
                    handleOutputFormatChanged()
                }
            }
            waitedMs += SystemClock.elapsedRealtime() - drainStartMs
            if (outIdx < 0 && waitedMs >= dynamicTimeout) break
        }
        if (!muxerVideoDone) {
            logDetail("drain_video", "timed out after ${waitedMs}ms, flushing encoder to unblock release")
            try {
                encoder.flush()
            } catch (e: Exception) {
                logDetail("drain_video_flush", "${e.message}")
            }
        }
        logDetail("drain_video", "finished, endOfStream=$endOfStream videoDone=$muxerVideoDone")
    }

    private fun calculateDuration(): Long {
        // v6.7.163 (BUG-1): 真实时长=媒体 PTS 跨度(muxer 实际写入的时间轴);
        // "帧数÷目标帧率"只是估算,仅当 PTS 全缺失时兜底。
        // v6.7.190 (P0-1): 口径改为**视频轨优先**。av_trim_align 会按 commonEndUs 把视频轨
        // 裁到与音频对齐的公共末端,视频轨因此是容器里的最终内容;旧实现取 maxOf(video,audio)
        // 会在音频尾随更长时把容器时长虚标 100~400ms,播放器按 moov 时长加载后末段只有
        // 声音、画面黑屏/冻结。这里改为:有视频轨就用视频跨度;无视频轨(纯音频会话)才用音频。
        // v6.7.191 (P0-2): 视频跨度的真值改用"真正写入 muxer 的最后一帧"(lastMuxedVideoPtsUs),
        // 不再用 lastVideoFrameTimeUs。后者在 shouldDropVideoPts 之前(编码器输出入口)就被更新,
        // 忠实记录的是"编码器交回的最后一帧",包含被尾巴裁掉的那部分 —— 拿它算容器时长等于把
        // av_trim_align 刚裁掉的时长又加回去,末段黑屏一点没变,只是日志里差值看起来小了。
        var durationUs = 0L
        val vSpanUs = if (videoFirstMuxedPtsUs >= 0L && lastMuxedVideoPtsUs >= videoFirstMuxedPtsUs)
            (lastMuxedVideoPtsUs - videoFirstMuxedPtsUs).coerceAtLeast(0L) else 0L
        val aSpanUs = if (lastAudioFrameTimeUs > 0 && firstAudioFrameTimeUs.get() >= 0)
            (lastAudioFrameTimeUs - firstAudioFrameTimeUs.get()).coerceAtLeast(0L) else 0L
        durationUs = if (vSpanUs > 0L) vSpanUs else aSpanUs
        if (durationUs <= 0L && videoFrameSeq > 0 && targetFps > 0) {
            durationUs = videoFrameSeq * 1_000_000L / targetFps
        }
        // v6.7.191 (P0-2): durationDivergedMs 上一版是 |vSpanUs - aSpanUs|,而 durationUs 就是
        // 由 vSpanUs 算出来的,属于同源自减,恒为 0,自证式断言、无诊断价值。
        // 改为跨坐标系的 tailOverrunMs:编码器交回末端超出"写入末端 + 裁剪标记"多少,
        // 这个量非 0 才说明"裁了但仍在时长里"。
        val trimEndUs = if (audioTrimEndUs > 0L) audioTrimEndUs else (videoTrimEndUs.takeIf { it > 0L } ?: 0L)
        val tailOverrunUs = (lastVideoFrameTimeUs - lastMuxedVideoPtsUs + trimEndUs).coerceAtLeast(0L)
        logDetail(
            "duration_calc",
            "muxed=${videoFirstMuxedPtsUs}..${lastMuxedVideoPtsUs} encEnd=${lastVideoFrameTimeUs} trimEnd=$trimEndUs " +
                "af=${firstAudioFrameTimeUs.get()}..${lastAudioFrameTimeUs} " +
                "seq=${videoFrameSeq}@${targetFps}fps durUs=$durationUs " +
                "videoDurMs=${vSpanUs / 1000L} audioDurMs=${aSpanUs / 1000L} " +
                "tailOverrunMs=${tailOverrunUs / 1000L}"
        )
        return durationUs / 1000
    }

    // SAF 拷贝结果:产出的 document URI + 实际写入的字节数(用于与源文件逐字节比对)。
    private data class SafCopyResult(val uri: Uri, val bytes: Long)

    // v6.7.83 (问题B/F): safCopyToTree 返回最终产物;失败返回 null。v6.7.82 曾引入的
    // "树根目录写流"兜底在问题F中被证实无效:openOutputStream 指向树根(目录 document),向目录
    // 写流必失败。改为 createDocument 失败即返回 null。
    // v6.7.84 (新增-1/2): 校验实际拷贝字节数,杜绝"写一半当成功→本地被删→视频永久丢失";
    // 拷贝/打开失败时把已建出的 0 字节/半成品 document 回滚删除,不在用户目录留垃圾。
    private fun safCopyToTree(sourceFile: File, treeUri: Uri, fileName: String, srcLen: Long): SafCopyResult? {
        val resolver = context.contentResolver
        if (srcLen == 0L) {
            logDetail("saf_copy", "source file is empty, aborting SAF copy")
            return null
        }
        // v6.7.82 (修复): tree URI 不能直接当 createDocument 的父节点。ExternalStorageProvider
        // 只认具体 document URI,直接传 tree URI 会抛 IllegalArgumentException("Invalid URI"),
        // 导致 SAF 输出目录录像丢失。先用 buildDocumentUriUsingTree 把树根转成合法 document URI。
        val treeDocUri = DocumentsContract.buildDocumentUriUsingTree(
            treeUri, DocumentsContract.getTreeDocumentId(treeUri))

        var createdUri: Uri? = null
        // 任何一步失败都把已建出的半成品 document 删掉,不在用户输出目录留 0 字节垃圾
        fun rollback(reason: String): SafCopyResult? {
            logDetail("saf_copy_error", reason)
            if (createdUri != null) {
                try { DocumentsContract.deleteDocument(resolver, createdUri!!) } catch (_: Exception) {}
            }
            return null
        }

        return try {
            val mimeType = "video/mp4"
            createdUri = DocumentsContract.createDocument(resolver, treeDocUri, mimeType, fileName)
                ?: return rollback("createDocument returned null, no ACCEPT document")

            val out = resolver.openOutputStream(createdUri!!, "w")
                ?: return rollback("openOutputStream returned null for $createdUri")

            // copyTo 返回实际写入字节数。旧代码把该返回值整个丢掉,只要流能打开就打 success,
            // performSafCopy 随即删本地文件。若写入中途失败(磁盘满/IO错/被中断),本地已删而
            // SAF 那份是残缺的(无完整 moov,播放器打不开),视频永久丢失且无法恢复。
            val copied = out.use { o ->
                FileInputStream(sourceFile).use { input -> input.copyTo(o, 1 shl 20) }
            }
            if (copied != srcLen) {
                return rollback("size mismatch copied=$copied src=$srcLen")
            }
            logDetail("saf_copy", "success -> $createdUri bytes=$copied src=$srcLen")
            SafCopyResult(createdUri!!, copied)
        } catch (e: Exception) {
            logDetail("saf_copy_error", "createDocument/stream: ${e.message}")
            writeEmergencyLog("SAF copy failed: ${e.message ?: e.javaClass.name}", e)
            rollback("createDocument/stream: ${e.message}")
        }
    }

    // v6.7.128: 切段。全程在 muxerLock 内串行(视频/音频 drain 写入同样持 muxerLock),
    // 编码器不重启——用已 start 的 track format(含 csd)重新 addTrack 到新建 MediaMuxer。
    // 流程:封口旧片(stop + 改名去 .tmp + fsync) -> 新建 muxer -> 重新 addTrack -> start
    //       -> 分片起点字节/PTS 清零 -> manifest 追加一行 + fsync -> 新片 .idx 重建。
    // 调用方保证已在 muxerLock 内(视频写入路径)。失败置 segmentSwitchFailed 停止录制兜底。
    private fun switchSegment(reason: String) {
        val vf = videoTrackFormat
        val af = audioTrackFormat
        val vfOk = vf != null
        val afOk = af != null && audioTrackIndex >= 0
        if (!vfOk && !afOk) return
        try {
            // —— 封口旧片 ——
            val oldFile = outputFilePath
            val oldBytes = segmentBytesWritten
            val oldFirstPts = segmentVideoFirstPtsUs
            val oldPts = segmentStartPtsUs
            val now = SystemClock.elapsedRealtime()
            val oldDurMs = (now - segmentStartMs).coerceAtLeast(0)
            val oldSeq = segmentSeq + 1
            val oldFinalName = segFinalName(oldSeq)
            val vf0 = vf
            val vW = vf0?.getInteger(MediaFormat.KEY_WIDTH) ?: 0
            val vH = vf0?.getInteger(MediaFormat.KEY_HEIGHT) ?: 0

            // muxer.stop() 写出合法 moov(旧片变成独立可播 mp4)
            muxerStarted.set(false)
            try {
                mediaMuxer?.stop()
            } catch (e: Exception) {
                logDetail("segment_old_stop", "${e.message}")
            }
            // v6.7.149 (FIX-A): 封口旧片时不再删 .idx——保留供正常收尾 mergeSegments 重建各片样本
            // (被杀路径本身不经过此处,.idx 本来就在磁盘供 restoreStale)。真正清理在 merge 成功后统一做。
            closeIndexKeepFile()
            // 改名 .tmp -> .mp4(独立可播)
            val oldF = File(oldFile)
            val baseDir = oldF.parentFile!!.absolutePath
            val finalF = File(baseDir, oldFinalName)
            var renamed = false
            if (oldF.exists()) {
                if (oldF.renameTo(finalF)) {
                    renamed = true
                    // v6.7.156 (修4a): 伴生 .idx 跟随 mp4 同步改名。此前 idx 保留 .tmp 名
                    // (seg_1.mp4.tmp.idx),而 merge 按 finalName+".idx" 查 seg_1.mp4.idx,
                    // 三套命名互不匹配 → 分段录制永远 merge 失败、双片残留。
                    try {
                        File(oldFile + ".idx").renameTo(File(finalF.absolutePath + ".idx"))
                    } catch (_: Exception) {}
                    // fsync 目录项,确保改名持久化
                    try {
                        val dirFd = java.io.RandomAccessFile(baseDir, "r").getChannel()
                        try { dirFd.force(true) } finally { dirFd.close() }
                    } catch (_: Exception) {}
                }
            }
            if (!renamed) {
                logDetail("segment_rename_fail", "$oldFile -> $oldFinalName failed")
                segmentSwitchFailed = true
                callback?.onError(IOException("segment rename failed: $oldFinalName"))
                return
            }

            // 记录旧片信息 + manifest 追加一行 + fsync
            segmentSeq = oldSeq
            segments.add(SegmentInfo(
                seq = oldSeq,
                path = finalF.absolutePath,
                durationMs = oldDurMs,
                bytes = oldBytes,
                width = vW,
                height = vH,
            ))
            appendManifestLine(File(baseDir), oldSeq, oldDurMs, oldBytes, vW, vH)
            logDetail("segment_close", "seq=$oldSeq durMs=$oldDurMs bytes=$oldBytes $vW x $vH reason=$reason")

            // —— 新建下一片 ——
            val newSeq = segmentSeq + 1
            val newFile = File(baseDir, segFileName(newSeq)).absolutePath
            try { File(newFile).delete() } catch (_: Exception) {}
            File(newFile).createNewFile()
            mediaMuxer = MediaMuxer(newFile, MediaMuxer.OutputFormat.MUXER_OUTPUT_MPEG_4)
            outputFilePath = newFile
            segmentFile = File(newFile)
            outputFile = File(newFile)   // v6.7.189 (P1-7): 新片必须同步 outputFile,否则进度大小恒 0
            // 新片 .idx 灌流
            try { indexOut = java.io.FileOutputStream(newFile + ".idx", false) } catch (_: Exception) { indexOut = null }

            // —— 重新 addTrack(编码器不重启,复用已 start 的 format/csd) ——
            videoTrackIndex = -1
            audioTrackIndex = -1
            if (vfOk) {
                videoTrackIndex = mediaMuxer!!.addTrack(vf!!)
            }
            if (afOk) {
                audioTrackIndex = mediaMuxer!!.addTrack(af!!)
            }
            // 重建 .idx Tracker(新片)
            ensureIndexTracker()
            mediaMuxer?.start()
            muxerStarted.set(true)

            // v6.7.157 (BUG-3): 分片切换后请求 IDR 并等首帧 IDR 才写入新片。
            // 此前新片首帧是 P 帧(参考上一片末尾的帧),新片是独立文件、解码器找不到那些参考帧,
            // 导致每片开头最多一个 GOP(约 2 秒)花屏/绿屏。编码器不重启,GOP 继续走,
            // 所以必须主动 requestKeyFrame,且丢弃请求后、新 IDR 到来前的 P 帧。
            pendingSegIdr = vfOk  // 仅视频分片需要等 IDR;纯音频分片不适用
            if (vfOk) {
                segIdrDropCount = 0  // v6.7.159 (NEW-BUG-1): 有界丢弃计数器归零
                segIdrWaitStartMs = SystemClock.elapsedRealtime()  // v6.7.189 (P1-9): 墙钟等待起点
                requestKeyFrame(videoEncoder)
            }
            logDetail("seg_wait_idr", "seq=$newSeq pendingIdr=$pendingSegIdr")

            // —— 新片起点清零(字节 + PTS 重基) ——
            segmentBytesWritten = 0L
            segmentVideoFirstPtsUs = -1L
            segmentStartMs = now
            // 分片内 PTS 重基:新片起点的全局 PTS 作为本片的 segmentStartPtsUs,
            // 写入 muxer 时减掉它,令本片 PTS 从 0 开始(每片独立时间轴)。
            segmentStartPtsUs = segmentStartGlobalPtsUs
            // 音频惰性锚定:分片内首个音频帧会快照自己的全局 PTS 作为起点
            segmentAudioFirst = true
            logDetail("segment_open", "seq=$newSeq startPts=$segmentStartPtsUs reason=$reason")
        } catch (e: Exception) {
            logDetail("segment_switch_error", "${e.javaClass.simpleName}:${e.message}")
            segmentSwitchFailed = true
            try {
                callback?.onError(IOException("segment switch failed: ${e.message}"))
            } catch (_: Exception) {}
        }
    }

    // v6.7.128: 全局 PTS 锚(切段时记录当前全局 PTS,作为新片重基起点)。
    // 由视频写入路径在每帧写入前更新(全局单调,不随分片重置)。
    @Volatile private var segmentStartGlobalPtsUs = 0L

    // v6.7.128: 当前录制的已封口分片路径列表(供 onSegments 回调 + 历史条目)。
    fun getSegmentPaths(): List<String> = segments.map { it.path }

    // v6.7.128: 当前录制总分片数(已封口 + 当前片,分片启用时)。
    fun getSegmentCount(): Int = if (segmentationEnabled) segmentSeq + 1 else 1

    // v6.7.128: 当前录制的总字节(所有分片 + 当前片已写)。
    fun getTotalSegmentBytes(): Long =
        (segments.sumOf { it.bytes } + segmentBytesWritten).coerceAtLeast(0L)

    private fun flushMuxer() {
        try {
            synchronized(muxerLock) {
                mediaMuxer?.let { muxer ->
                    // muxerFailed 时也尝试 stop():即使有单帧写失败,尽量写出合法的
                    // moov 原子供播放器解析;仅当 stop 本身抛异常(如状态已损坏)才放弃,
                    // 交由 releaseResources 直接 release。旧代码因 muxerFailed 直接跳过
                    // stop,产出头尾结构不完整的 MP4。
                    if (muxerStarted.get()) {
                        try {
                            muxer.stop()
                        } catch (e: Exception) {
                            logDetail("flush_muxer_stop", "${e.message}")
                        }
                    }
                }
            }
            // v6.7.120 (被杀保护): 正常/forceStop 进程内收尾都会走到这里,muxer.stop
            // 已写出合法 moov,.idx 不再需要,关闭并删除伴生索引。真"被杀"(进程死亡)
            // 不会执行此处,.idx 留在磁盘供下次启动 findStaleRecordings/restoreStale 重建 moov。
            // v6.7.149 (FIX-A): 分片模式下改用不删 .idx 的 closeIndexKeepFile——末片 .idx 须保留到
            // mergeSegmentsToFinal 重建合并样本;非分片原路径仍删。
            if (segmentationEnabled && !segmentSwitchFailed && muxerStarted.get()) {
                closeIndexKeepFile()
                closeLastSegment()
                mergeSegmentsToFinal()
            } else {
                closeAndDeleteIndex()
            }
        } catch (e: Exception) {
            logDetail("flush_muxer_error", "${e.message}")
            closeAndDeleteIndex()
        }
    }

    // v6.7.149 (FIX-A): 正常收尾时把已封口分片(.mp4)+末片合并为单一最终 mp4。
    // 合并后 outputFile/outputFilePath 指向产物,下游 performSafCopy/renameToFinal/history
    // 一律吃单文件(与未分片一致),随后清理分片、各自 .idx、manifest。任一分片 .idx 缺失/
    // 损坏导致合并失败则保留分片(多片各自可播),不丢数据。仅在有 >=2 片时合并(单片段直名已够)。
    private fun mergeSegmentsToFinal() {
        if (!segmentationEnabled) return
        if (segments.size < 2) {
            // 单片:不需要合并。v6.7.150 (BUG-3) 但 closeLastSegment 已把它改名为 seg_1.mp4,
            // renameToFinal 只在 outputFilePath 以 .recording.tmp 结尾时触发,单片不会走,
            // 导出名会变成 seg_1.mp4(且下次录制重名冲突/覆盖 SAF)。这里改回最终录制名。
            if (segments.size == 1) {
                val finalPath = recordingFinalBasePath.ifEmpty { outputFilePath }
                val src = File(outputFilePath)
                val dst = File(finalPath)
                if (src.absolutePath != dst.absolutePath && src.exists()) {
                    SafeDeleteUtil.delete(dst, "merge_single_dst_conflict", force = true)
                    if (src.renameTo(dst)) {
                        outputFile = dst
                        outputFilePath = dst.absolutePath
                        logDetail("segment_single", "renamed ${src.name} -> ${dst.name}")
                    }
                }
                // v6.7.191 (P0-6): .idx 是 restoreStale 重建 moov 的唯一索引,是崩溃/拷贝失败时
                // 的最后一道保命绳。旧实现改名后立刻删 .idx 与 manifest,而这一步发生在
                // renameToFinal / SAF 拷贝**之前** —— 一旦后续 SAF 拷贝失败,本地文件成了唯一副本,
                // 而修复所需索引已经不存在,只能退化成 NAL 扫描,成功率显著降低。
                // 多片分支(下方 5611 起)早就做到了"先 probe 确认可播再删分片",单片分支是明显不对称,
                // 这里补齐:先 probe,不可播则连同 .idx 与 manifest 全部保留供 restoreStale 使用。
                val singleTarget = outputFile ?: src
                val (singlePlayable, _, singleDurUs) = probeRepairedMp4(singleTarget)
                logDetail("segment_single_probe",
                    "file=${singleTarget.name} playable=$singlePlayable durMs=${singleDurUs / 1000L}")
                if (!singlePlayable) {
                    logDetail("segment_single_keep_idx",
                        "probe failed, keeping .idx + manifest for restoreStale (file=${singleTarget.name})")
                    return
                }
                try {
                    segments.forEach { seg ->
                        val idx = idxFileFor(seg.seq)
                        SafeDeleteUtil.delete(idx, "merge_single_idx")
                    }
                    val dir = singleTarget.parentFile ?: return
                    SafeDeleteUtil.delete(manifestFileAt(dir.absolutePath), "merge_single_manifest", force = true)
                } catch (_: Exception) {}
                return
            }
        }
        try {
            val mergedPath = recordingFinalBasePath.ifEmpty {
                var p = outputFilePath
                if (p.endsWith(".mp4")) p else (p + ".mp4")
            }
            val inputs = segments.map { Pair(idxFileFor(it.seq), File(it.path)) }
            // v6.7.189 (P0-2): 失败必须留下可诊断的现场 —— 每片的 mp4 / idx 存在性与字节数。
            // 过往全靠猜:idx 缺失、idx 为空、csd 不一致、帧率不一致,四种原因日志里长得一模一样。
            val inputsDiag = inputs.joinToString(" | ") { (idx, mp4) ->
                "seg=${mp4.name} mp4=${mp4.exists()}/${mp4.length()}B " +
                    "idx=${idx.exists()}/${if (idx.exists()) idx.length() else 0}B"
            }
            val out = Mp4Repairer.mergeSegments(inputs, mergedPath)
            if (out == null) {
                logDetail("segment_merge_fail", "arcs=${segments.size} dest=$mergedPath inputs=[$inputsDiag]")
                // 合并失败 = 各片仍独立可播,绝不能静默丢弃:登记为多片历史条目供用户逐片取回。
                keepSegmentsAsHistory()
                return
            }
            // v6.7.150 (改进1): 合并产物先 probe 确认可播放,再接管 outputFile 并删分片。
            // 顺序不可反——合并一旦出错(如 mdat 溢出/某片 .idx 缺失)会把坏文件导出 SAF,
            // 同时把各自可播的分片全删,不可回退。
            val (playable, _, durUs) = probeRepairedMp4(out)
            if (!playable) {
                // v6.7.188h (改造6): 探针失败不再删除产物。改为改名保留为 _merge_keep,
                // 并连同分片一起登记历史(带"可能不完整"标记),由用户决定去留。
                // 删除是唯一不可逆的操作,保留的成本仅一份磁盘占用,且 StorageGc 已有容量回收。
                val kept = renameKeep(out)
                logDetail("segment_merge",
                    "probe failed dur=${durUs / 1_000_000L}s kept=${kept?.name ?: "rename_failed"} " +
                        "arcs=${segments.size}")
                registerPartialHistory(kept ?: out, segments.map { it.path })
                keepSegmentsAsHistory()
                return
            }
            // 合并成功且可播:产物接管 outputFile/outputFilePath,清除分段轨迹供单文件历史
            outputFile = out
            outputFilePath = out.absolutePath
            // 清理:各分片 .mp4 + .idx + manifest
            segments.forEach { seg ->
                SafeDeleteUtil.delete(File(seg.path), "merge_seg")
                SafeDeleteUtil.delete(idxFileFor(seg.seq), "merge_seg_idx")
            }
            val dir = out.parentFile
            if (dir != null) {
                SafeDeleteUtil.delete(manifestFileAt(dir.absolutePath), "merge_manifest", force = true)
            }
            segmentSeq = 0
            segments.clear()
            segmentationEnabled = false
            logDetail("segment_merge",
                "merged ${inputs.size} arcs -> ${out.name} bytes=${out.length()} dur=${durUs / 1_000_000L}s")
        } catch (e: Exception) {
            logDetail("segment_merge_error", "${e.message}")
        }
    }

    // v6.7.188h (改造6): 把探针失败的合并产物改名保留,绝不删除。
    // 命名对齐本仓既有约定(restoreStale 用 _interrupted/_restored),
    // 用 _merge_keep 区分"合并产物不完整"而非"单文件损坏"。
    private fun renameKeep(src: java.io.File): java.io.File? {
        if (!src.exists()) return null
        val base = src.name.removeSuffix(".mp4")
        val dst = java.io.File(src.parentFile, "${base}_merge_keep.mp4")
        return try {
            SafeDeleteUtil.delete(dst, "merge_keep_conflict", force = true)  // 覆盖旧同名保留件
            if (src.renameTo(dst)) dst else null
        } catch (_: Exception) { null }
    }

    // v6.7.188h (改造6): 把未能合并成功的分片登记为历史条目,复用 segmentPaths 多分片能力。
    // note=partial_merge_keep 供历史 UI 显示"可能不完整"角标。
    private fun keepSegmentsAsHistory() {
        try {
            if (segments.isEmpty()) return
            val first = segments.firstOrNull() ?: return
            RecordingHistoryManager.get(context).add(
                RecordingEntry(
                    fileName = File(first.path).name,
                    path = first.path,
                    durationMs = segments.sumOf { it.durationMs },
                    sizeBytes = segments.sumOf { it.bytes },
                    width = first.width,
                    height = first.height,
                    timestamp = System.currentTimeMillis(),
                    codecName = videoEncoderName,
                    segmentPaths = segments.map { it.path },
                    note = "partial_merge_keep",
                    stopReason = "MANUAL",
                    playable = true
                )
            )
            logDetail("segment_keep", "registered ${segments.size} arcs as history")
        } catch (e: Exception) {
            logDetail("segment_keep_error", "${e.message}")
        }
    }

    // v6.7.188h (改造6): 登记"部分合并产物"。note=merge_keep_maybe_incomplete 供 UI 显示角标,
    // 与 keepSegmentsAsHistory 的条目区分(一个是被合并出的文件,一个是原始分片)。
    private fun registerPartialHistory(merged: java.io.File, segPaths: List<String>) {
        try {
            RecordingHistoryManager.get(context).add(
                RecordingEntry(
                    fileName = merged.name,
                    path = merged.absolutePath,
                    durationMs = 0L,                   // 探针失败取不到时长,置 0 由 UI 兜底显示
                    sizeBytes = merged.length(),
                    width = 0,
                    height = 0,
                    timestamp = System.currentTimeMillis(),
                    codecName = videoEncoderName,
                    segmentPaths = segPaths,
                    note = "merge_keep_maybe_incomplete",
                    stopReason = "MANUAL",
                    playable = true
                )
            )
        } catch (e: Exception) {
            logDetail("merge_keep_register_error", "${e.message}")
        }
    }

    // v6.7.156 (修4c): 分片 k 的伴生 .idx 路径 = 分片最终名 + ".idx"。
    // 修4a 已保证封口时 idx 随 mp4 同步改名,故 merge/清理统一按 finalName+".idx" 查,
    // 与 seg_<seq>.mp4.tmp.idx(写入期)不再并存,三套命名收拢为一套。
    private fun idxFileFor(seq: Int): java.io.File {
        val baseDir = outputFile?.parentFile?.absolutePath
            ?: File(outputFilePath).parentFile?.absolutePath ?: "."
        return java.io.File(baseDir, segFinalName(seq) + ".idx")
    }

    // v6.7.128: 封口最后一片(改名 + manifest 行 + FINAL),供正常收尾调用。
    // 调用时 muxer 已 stop(见 flushMuxer),.idx 已关闭。
    private fun closeLastSegment() {
        try {
            val lastFile = outputFilePath
            val lastBytes = segmentBytesWritten
            val now = SystemClock.elapsedRealtime()
            val lastDurMs = (now - segmentStartMs).coerceAtLeast(0)
            val vf = videoTrackFormat
            val vW = vf?.getInteger(MediaFormat.KEY_WIDTH) ?: 0
            val vH = vf?.getInteger(MediaFormat.KEY_HEIGHT) ?: 0
            val seq = segmentSeq + 1
            val finalName = segFinalName(seq)
            val oldF = File(lastFile)
            val baseDir = oldF.parentFile!!.absolutePath
            val finalF = File(baseDir, finalName)
            if (oldF.exists() && oldF.renameTo(finalF)) {
                // v6.7.176 (BUG-边角-1): 末段 .idx 跟随 .mp4 同步改名,与 switchSegment:4848 对齐。
                // 此前末段只改 .mp4、索引停在 seg_N.mp4.tmp.idx,而 idxFileFor 按 seg_N.mp4.idx
                // 查,mergeSegmentsToFinal 对末段 readIndex 找不到 → 合并失败、只留 N 个分段碎片 +
                // 孤儿 seg_N.mp4.tmp.idx。单段不触发(segments.size<2 不走 merge),多段正常停止必现。
                try {
                    File(oldF.absolutePath + ".idx").renameTo(File(finalF.absolutePath + ".idx"))
                } catch (_: Exception) {}
                try {
                    val dirFd = java.io.RandomAccessFile(baseDir, "r").getChannel()
                    try { dirFd.force(true) } finally { dirFd.close() }
                } catch (_: Exception) {}
                segmentSeq = seq
                segments.add(SegmentInfo(seq, finalF.absolutePath, lastDurMs, lastBytes, vW, vH))
                appendManifestLine(File(baseDir), seq, lastDurMs, lastBytes, vW, vH)
                // 当前录制产物路径指向最后一片(供 renameToFinal/history 使用)
                outputFilePath = finalF.absolutePath
                outputFile = finalF
                logDetail("segment_last_close", "seq=$seq durMs=$lastDurMs bytes=$lastBytes $vW x $vH")
                writeManifestFinal(File(baseDir))
            } else {
                logDetail("segment_last_rename_fail", "$lastFile -> $finalName")
            }
        } catch (e: Exception) {
            logDetail("segment_last_error", "${e.message}")
        }
    }

    // v6.7.120 (被杀保护): 关闭并丢弃 .idx 灌流。仅进程内正常收尾调用。
    private fun closeAndDeleteIndex() {
        try { indexTracker?.closeDiscard() } catch (_: Exception) {}
        indexTracker = null
        try { indexOut?.close() } catch (_: Exception) {}
        indexOut = null
        try { File(outputFilePath + ".idx").delete() } catch (_: Exception) {}
    }

    // v6.7.149 (FIX-A): 关闭 .idx 灌流但保留 .idx 文件。分片收尾合并需要各分片(含末片)的
    // .idx 重建合并样本,只可关不可删;删除推迟到 merge 成功后统一清理(见 mergeSegmentsToFinal)。
    private fun closeIndexKeepFile() {
        try { indexTracker?.closeDiscard() } catch (_: Exception) {}
        indexTracker = null
        try { indexOut?.close() } catch (_: Exception) {}
        indexOut = null
    }

    // v6.7.140-补(方案4): 返回重建后的新实例供调用方刷新局部引用(singleRecord)。
    // v6.7.173 (BUG-1): 改为"先成功构建并校验,再释放旧对象"。原实现先 release 旧、再建新的,
    // 一旦新建因瞬时资源争用/构造异常失败,旧记录已释放、audioRecord 被置 null,纯内录(无 mic
    // 兜底)路径下音频采集源彻底丢失,录制静默继续成"无声视频"。与兄弟函数
    // rebuildInternalAudioRecord"先建再释放"一致。失败保留旧记录返回 old,调用方继续用旧源。
    private fun rebuildAudioRecord(old: android.media.AudioRecord): android.media.AudioRecord? {
        val minBufferSize = AudioRecord.getMinBufferSize(
            AUDIO_SAMPLE_RATE,
            AudioFormat.CHANNEL_IN_MONO,
            AUDIO_PCM_FORMAT
        ) * AUDIO_BUFFER_SIZE_MULTIPLIER
        val newRecord = try {
            AudioRecord(
                MediaRecorder.AudioSource.MIC,
                AUDIO_SAMPLE_RATE,
                AudioFormat.CHANNEL_IN_MONO,
                AUDIO_PCM_FORMAT,
                minBufferSize
            )
        } catch (e: Throwable) {
            logDetail("audio_rebuild", "creation failed: ${e.message}")
            return old
        }
        if (newRecord.state != AudioRecord.STATE_INITIALIZED) {
            logDetail("audio_rebuild", "initialization failed")
            try { newRecord.release() } catch (_: Exception) {}
            return old
        }
        try { newRecord.startRecording() } catch (_: Exception) {
            logDetail("audio_rebuild", "start failed")
            try { newRecord.release() } catch (_: Exception) {}
            return old
        }
        try { old.release() } catch (_: Exception) {}
        audioRecord = newRecord
        logDetail("audio_rebuild", "rebuild ok")
        return newRecord
    }

    // v6.7.142(优化5): 双录内部轨重建——复刻 setupInternalAudioCapture 的 PlaybackCapture 构建
    // (monoChannel 一致 + usage 降级链)。先构建成功再 release 旧对象,失败不改 audioRecord 引用。
    private fun rebuildInternalAudioRecord(): android.media.AudioRecord? {
        if (Build.VERSION.SDK_INT < Build.VERSION_CODES.Q) return null
        val projection = mediaProjection ?: return null
        // 双录即 MIXED,与 setupInternalAudioCapture(monoChannel=true) 一致:mono 保证与 mic 声道对齐。
        val internalChannelMask = AudioFormat.CHANNEL_IN_MONO
        val audioFormat = AudioFormat.Builder()
            .setEncoding(AUDIO_PCM_FORMAT)
            .setSampleRate(AUDIO_SAMPLE_RATE)
            .setChannelMask(internalChannelMask)
            .build()
        val minBufferSize = AudioRecord.getMinBufferSize(
            AUDIO_SAMPLE_RATE, internalChannelMask, AUDIO_PCM_FORMAT
        ) * AUDIO_BUFFER_SIZE_MULTIPLIER
        val newRecord = buildPlaybackAudioRecord(
            projection, audioFormat, minBufferSize,
            listOf(
                USAGE_SET_MEDIA_GAME_UNKNOWN,
                USAGE_SET_MEDIA_GAME,
                USAGE_SET_MEDIA
            )
        ) ?: run {
            logDetail("dual_audio_dead_object", "internal rebuild: all usage sets failed")
            return null
        }
        try { audioRecord?.release() } catch (_: Exception) {}
        try { newRecord.startRecording() } catch (_: Exception) {}
        logDetail("dual_audio_dead_object", "internal rebuilt ok")
        return newRecord
    }

    // v6.7.142(优化5): 双录麦克风轨重建——复刻 setupMicAudioCapture 的 MIC 构建。
    // 先构建成功再 release 旧对象,失败不改 micAudioRecord 引用。
    private fun rebuildMicAudioRecord(): android.media.AudioRecord? {
        val minBufferSize = AudioRecord.getMinBufferSize(
            AUDIO_SAMPLE_RATE, AudioFormat.CHANNEL_IN_MONO, AUDIO_PCM_FORMAT
        ) * AUDIO_BUFFER_SIZE_MULTIPLIER
        val newRecord = try {
            AudioRecord(
                MediaRecorder.AudioSource.MIC,
                AUDIO_SAMPLE_RATE,
                AudioFormat.CHANNEL_IN_MONO,
                AUDIO_PCM_FORMAT,
                minBufferSize
            )
        } catch (e: Throwable) {
            logDetail("dual_audio_dead_object", "mic rebuild creation failed: ${e.message}")
            return null
        }
        if (newRecord.state != AudioRecord.STATE_INITIALIZED) {
            logDetail("dual_audio_dead_object", "mic rebuild init failed")
            newRecord.release()
            return null
        }
        try { micAudioRecord?.release() } catch (_: Exception) {}
        try { newRecord.startRecording() } catch (_: Exception) {}
        logDetail("dual_audio_dead_object", "mic rebuilt ok")
        return newRecord
    }

    private fun releaseResources() {
        logSection("Release Resources")

        // 先停并 join 音频 drain 线程,再 stop 音频编码器。
        // 否则 drain 线程仍在 dequeueOutputBuffer 时 stop() 编码器
        // 会抛 IllegalStateException,或 drain 与 stop 并发导致输出丢失。
        try {
            audioDrainRunning = false
            audioDrainThread?.join(2000)
            audioDrainThread = null
        } catch (e: Exception) {
            logDetail("release_drain_thread", "${e.message}")
        }

        try {
            videoEncoder?.let { encoder ->
                try {
                    encoder.stop()
                } catch (e: Exception) {
                    logDetail("release_video_stop", "${e.message}")
                }
                try {
                    encoder.release()
                } catch (e: Exception) {
                    logDetail("release_video_release", "${e.message}")
                }
                videoEncoder = null
            }
        } catch (e: Exception) {
            logDetail("release_video_error", "${e.message}")
        }

        try {
            audioEncoder?.let { encoder ->
                try {
                    encoder.stop()
                } catch (e: Exception) {
                    logDetail("release_audio_stop", "${e.message}")
                }
                try {
                    encoder.release()
                } catch (e: Exception) {
                    logDetail("release_audio_release", "${e.message}")
                }
                audioEncoder = null
            }
        } catch (e: Exception) {
            logDetail("release_audio_error", "${e.message}")
        }

        val releasedAudioRecord = audioRecord
        audioRecord = null
        // v6.7.50: 关闭 AudioRecordingCallback 执行器,防止单线程 executor 泄漏
        try {
            internalAudioExecutor?.shutdown()
            internalAudioExecutor = null
        } catch (e: Exception) {
            logDetail("release_audio_executor", "${e.message}")
        }
        try {
            releasedAudioRecord?.let { record ->
                try {
                    if (record.recordingState == AudioRecord.RECORDSTATE_RECORDING) {
                        record.stop()
                    }
                } catch (e: Exception) {
                    logDetail("release_audiorecord_stop", "${e.message}")
                }
                try {
                    record.release()
                } catch (e: Exception) {
                    logDetail("release_audiorecord_release", "${e.message}")
                }
            }
        } catch (e: Exception) {
            logDetail("release_audiorecord_error", "${e.message}")
        }

        try {
            val releasedMicRecord = micAudioRecord
            micAudioRecord = null
            micFallbackAttempted = false
            if (releasedMicRecord != null && releasedMicRecord !== releasedAudioRecord) {
                releasedMicRecord.let { record ->
                    try {
                        if (record.recordingState == AudioRecord.RECORDSTATE_RECORDING) {
                            record.stop()
                        }
                    } catch (e: Exception) {
                        logDetail("release_mic_audiorecord_stop", "${e.message}")
                    }
                    try {
                        record.release()
                    } catch (e: Exception) {
                        logDetail("release_mic_audiorecord_release", "${e.message}")
                    }
                }
            }
        } catch (e: Exception) {
            logDetail("release_mic_audiorecord_error", "${e.message}")
        }

        try {
            audioCaptureHandler?.removeCallbacksAndMessages(null)
            audioThread?.quitSafely()
            audioThread = null
            audioCaptureHandler = null
            audioEncodeHandler?.removeCallbacksAndMessages(null)
            audioEncodeThread?.quitSafely()
            audioEncodeThread = null
            audioEncodeHandler = null
        } catch (e: Exception) {
            logDetail("release_audio_thread", "${e.message}")
        }

        try {
            encodeHandler?.removeCallbacksAndMessages(null)
            encodeThread?.quitSafely()
            encodeThread = null
            encodeHandler = null
        } catch (e: Exception) {
            logDetail("release_encode_thread", "${e.message}")
        }

        try {
            virtualDisplay?.let { display ->
                try {
                    display.setSurface(null)
                } catch (_: Exception) {}
                display.release()
                virtualDisplay = null
            }
        } catch (e: Exception) {
            logDetail("release_virtualdisplay", "${e.message}")
        }

        // v6.7.102 (B4): MediaProjection 从未被 stop 是 Android 12+ 上用户反复看到
        // "是否允许录屏"授权弹窗的根因——进程被系统 kill (OOM/崩溃/强退) 时 service
        // 的 cleanupAndStop 不会执行,projection 永远挂在系统里。engine 是持有 projection
        // 引用的最直接位置,在此处兜底 stop 覆盖所有异常退出路径。
        try {
            mediaProjection?.let { projection ->
                try {
                    projection.stop()
                } catch (e: Exception) {
                    logDetail("release_projection_stop", "${e.message}")
                }
            }
            mediaProjection = null
        } catch (e: Exception) {
            logDetail("release_projection_error", "${e.message}")
        }

        try {
            inputSurface?.let { surface ->
                surface.release()
                inputSurface = null
            }
        } catch (e: Exception) {
            logDetail("release_inputsurface", "${e.message}")
        }

        try {
            synchronized(muxerLock) {
                mediaMuxer?.let { muxer ->
                    try {
                        muxer.release()
                    } catch (e: Exception) {
                        logDetail("release_muxer_release", "${e.message}")
                    }
                    mediaMuxer = null
                }
            }
        } catch (e: Exception) {
            logDetail("release_muxer_error", "${e.message}")
        }

        muxerStarted.set(false)
        encoderReady.set(false)
        videoTrackIndex = -1
        audioTrackIndex = -1
        audioTrackFailed = false

        logDetail("release", "all resources released")
    }

    fun forceStop() {
        // v6.7.140 (方案3): 标记停止原因
        // v6.7.169 (P2): forceStop 仅作"兜底收尾",不覆盖业务侧已确定的停止原因。
        // 原逻辑无脑置 "forceStop",导致 MANUAL/SHAKE/DURATION 停止链路(cleanupAndStop->forceStop)
        // 最终全部报告 forceStop,RECORD_SUMMARY 与 ScreenRecorderService.lastStopReason 自相矛盾。
        // 仅当尚未由业务侧置位时才写 "forceStop"——系统杀投影/异常路径此前 finalStopReason 为默认
        // "normal",会被正确标成 forceStop;手动停止路径已被 forceStop() 前置置成 "user"/"error"等。
        if (finalStopReason == "normal") finalStopReason = "forceStop"
        if (!stopCompleted.compareAndSet(false, true)) {
            logDetail("force_stop", "already stopped, ignoring")
            return
        }

        logSection("Force Stop")
        forceStop.set(true)
        isRunning.set(false)

        // v6.7.101 (B4): forceStop 也先 flush 音频 pending 积压。
        // 旧实现仅在 stop() 和 stopAsync() 里调 flushAudioBacklog(),forceStop 路径缺失。
        // 当 MediaProjectionCallback.onStop(系统杀掉投影)或异常路径触发 forceStop 时,
        // audioPendingPcm 里未 flush 的 PCM(可能包含真实音频 + 静音补齐)会永久丢弃,
        // 表现为录制被系统中断场景下尾部音频缺失。
        flushAudioBacklog()

        // 不前置 flush：与 stop() 路径一致，避免先 flush 再 signalEndOfInputStream
        // 导致 EOS 永不返回（高通 OMX 编码器实测）。
        // v6.7.102 (B5) + v6.7.104 (B2): forceStop 常见触发源就是"系统回收 MediaProjection"
        // (MediaProjectionCallback.onStop 会调 forceStop)。此时 virtualDisplay 的
        // surface 已因 projection 失效而停止投帧,编码器 input 无新帧;若仍按常规
        // signalEndOfInputStream 走 EOS 路径,c2.avc 编码器在缺关键帧前提下永不
        // 产出 END_OF_STREAM,output 回调恒返 INFO_TRY_AGAIN_LATER,awaitDrainCompletion
        // 30s 超时后被强制 flush,成片尾帧被砍掉、音画不同步。
        // 判定不仅看对象引用(v6.7.102 B5),还要看 projectionInvalid 标志(B2)——
        // 对象字段在 onStop 后仍可能非 null,仅靠引用判不出失效。
        val projectionAlive = virtualDisplay != null && mediaProjection != null
            && !ScreenRecorderApp.projectionInvalid
        if (projectionAlive) {
            try {
                videoEncoder?.signalEndOfInputStream()
            } catch (e: Exception) {
                logDetail("force_stop_signal", "${e.message}")
            }
        } else {
            logDetail("force_stop", "projection invalid, skip EOS and force muxerVideoDone=true (invalid=${ScreenRecorderApp.projectionInvalid})")
            muxerVideoDone = true
        }

        awaitDrainCompletion()

        flushMuxer()

        releaseResources()

        finalDurationMs = calculateDuration()
        // v6.7.97 (改进1): 同 stop() —— 先拷贝、再改名、最后组 historyPath。
        // v6.7.99: 即使无 SAF 也改名本地 .recording.tmp -> .mp4
        val safResult = performSafCopy()
        renameToFinal()
        val sizeUri = finalSafUri ?: safResult?.uri
        val historyPath = finalSafUri?.toString() ?: safResult?.uri?.toString() ?: outputFilePath
        finalFileSize = resolveFinalSize(sizeUri, safResult?.bytes ?: 0L)

        // v6.7.95 (改进3): 静音自检报告
        logAudioSilenceCheck()

        callback?.onSegments(getSegmentPaths())
        callback?.onStopped(finalDurationMs, finalFileSize, historyPath)
    }

    fun isRecording(): Boolean = isRunning.get()

    fun pause() {
        if (!isRunning.get() || isPaused.getAndSet(true)) return
        // v6.7.95 (改进1): 对齐 AZ 6.9.10 fg/r.java 暂停分支——不做任何时间戳动作。
        // pause() 只摘除 VirtualDisplay surface,编码器暂停期间不再空转。
        // 音频 PTS 锚点在 resume() 中重置,从时间轴上剪掉暂停时长。
        lastPauseRealtimeNs = System.nanoTime()
        // v6.7.60: 暂停时把 VirtualDisplay 的 surface 摘除,立即停止向编码器投递新帧。
        // 此前暂停只丢弃编码器输出(表面仍持续投帧),编码器在暂停期间仍在空转消耗资源、
        // 且暂停画面实际并未真正冻结(仍有内部渲染)。setSurface(null) 后显示不再投帧,
        // 编码器不再产出新帧,实现"暂停即停画面";恢复时 setSurface(inputSurface) 续接。
        stopVirtualDisplayFeeding()
        logDetail("pause", "paused")
    }

    fun resume() {
        if (!isRunning.get() || !isPaused.compareAndSet(true, false)) return
        val pauseDurationNs = System.nanoTime() - lastPauseRealtimeNs
        val current = videoFirstFrameRealtimeNs.get()
        if (current >= 0) {
            videoFirstFrameRealtimeNs.getAndAdd(pauseDurationNs)
        }
        // v6.7.111 (Bug A): 音频墙钟锚点必须与视频对称推进。computeAvDiffUs() =
        // (aFirstNs - vFirstNs)/1000,若只给 videoFirstFrameRealtimeNs 加 pauseDuration 而
        // audioFirstCaptureRealtimeNs 不动,暂停恢复后 avDiffUs 会比真实值小"累计暂停时长",
        // 该差值经 anchorAudioPtsUs 作用到输出侧 PTS,导致暂停恢复后整条音轨比视频轨提前
        // 约暂停总时长(未暂停录制不受影响)。2182 行仅在 <0 时 set 首次值,后续不覆盖,
        // 故此处累加不会被冲掉。
        if (audioFirstCaptureRealtimeNs.get() > 0L) {
            audioFirstCaptureRealtimeNs.getAndAdd(pauseDurationNs)
        }
        // v6.7.95 (改进1): 重置音频墙钟锚点,从音频时间轴上剪掉暂停时长。
        // 对齐 AZ 6.9.10 fg/d.java L() 方法: B.set(-1L)。
        // 纯算术无副作用,天然免疫"暂停期间积了多少 PCM"这个不确定量,
        // 且滞后滤波器顺带抑制线程调度抖动。
        audioPtsAnchorUs = -1L
        // v6.7.60: 恢复投帧,编码器重新收到 surface 帧,时间轴由上面 PTS 偏移保持连续
        resumeVirtualDisplayFeeding()
        logDetail("resume", "resumed, pauseDurationUs=${pauseDurationNs / 1000L}")
    }

    // 暂停/恢复的 VirtualDisplay 投帧控制。仅摘除/恢复 surface,不销毁
    // VirtualDisplay,避免重建耗时与编码器 surface 失联风险;setSurface(null) 后
    // DisplayManager 停止向该 surface 投帧,编码器 input 侧不再有新帧。
    private fun stopVirtualDisplayFeeding() {
        try {
            virtualDisplay?.let { it.setSurface(null) }
        } catch (e: Exception) {
            logDetail("pause_vd_stop", "${e.message}")
        }
    }

    private fun resumeVirtualDisplayFeeding() {
        try {
            virtualDisplay?.let { it.setSurface(inputSurface) }
        } catch (e: Exception) {
            logDetail("resume_vd_start", "${e.message}")
        }
    }

    fun getCurrentFps(): Int = currentFps

    // v6.7.153: 截图用句柄。返回录制当前持有的 VirtualDisplay 与编码器输入面,
    // ScreenshotHelper 把 VD 输出面短暂切到 ImageReader 抓一帧再切回——全程只有一条
    // VirtualDisplay,不动 createVirtualDisplay(API34+ 二次调用会 SecurityException +
    // 系统 onStop 杀掉录制)。
    fun recordingVirtualDisplay(): VirtualDisplay? = virtualDisplay
    fun encoderInputSurface(): android.view.Surface? = inputSurface

    // v6.7.154: 截图的恢复目标面。暂停中 VD 已被 setSurface(null) 摘除投帧,截图抓完
    // 必须切回 null 而非 inputSurface——否则画面重新投给编码器,但 isPaused 仍为 true,
    // 录制在用户以为暂停时被静默续录,且 isPaused 与真实投帧状态矛盾。
    fun currentFeedSurface(): android.view.Surface? =
        if (isPaused.get()) null else inputSurface
    fun isPausedNow(): Boolean = isPaused.get()
    // v6.7.157 (改动5): 录制 VD 真实尺寸(截图 ImageReader 必须与 VD 同尺寸才能抓到帧)。
    fun recordingWidth(): Int = config?.width ?: 0
    fun recordingHeight(): Int = config?.height ?: 0

    // v6.7.128: 降档可视化——录制中 UI 显示降档状态/码率/锁死标记/原因。
    fun isDowngradeActive(): Boolean = downgradeActive
    fun isDowngradeLatched(): Boolean = downgradeLatched
    fun getDowngradeReason(): String =
        if (!downgradeActive) ""
        else run {
            val tempC = thermalTempC()
            val battery = readBatteryPercent()
            when {
                // v6.7.189 (P1-6): 原因串反映真实判定条件,不再硬编码绝对阈值。
                tempC in 1..120 && thermalBaselineC > 0 &&
                    tempC >= thermalBaselineC + THERMAL_OVER_BASELINE ->
                    "overheat(temp>=baseline+$THERMAL_OVER_BASELINE,base=${thermalBaselineC})"
                battery in 0..100 && battery < 20 -> "battery<20%(actual=$battery)"
                else -> "active"
            }
        }
    // v6.7.128: 降档元数据(历史条目用)。返回 (是否降档, 首次降档相对时刻ms, 最低码率, 是否锁死)
    fun getDowngradeMeta(): Triple<Boolean, Long, Int> =
        Triple(downgradeActive || downgradeFirstAtMs > 0L, downgradeFirstAtMs, if (downgradeMinBitrate > 0L) downgradeMinBitrate.toInt() else -1)
    fun getDowngradeLatchedAtStop(): Boolean = downgradeLatched

    fun getCurrentBitrate(): Int = currentBitrate

    // v6.7.128: encoder 实际输出尺寸(从 OUTPUT_FORMAT_CHANGED 后的 videoTrackFormat 读)。
    // 分辨率回显示 encoder 实际档位(等比 fit / 2K/4K clamp 后的真实值),非 UI 请求值。
    fun getActualWidth(): Int = videoTrackFormat?.getInteger(MediaFormat.KEY_WIDTH) ?: -1

    fun getActualHeight(): Int = videoTrackFormat?.getInteger(MediaFormat.KEY_HEIGHT) ?: -1

    fun getVideoEncoderName(): String = videoEncoderName

    fun getOutputFilePath(): String = outputFilePath

    fun getDurationMs(): Long = finalDurationMs

    fun getFileSize(): Long = finalFileSize

    private fun startEncodeLoop() {
        encodeThread = HandlerThread("EncodeLoopThread", Process.THREAD_PRIORITY_DISPLAY)
        encodeThread?.start()
        encodeHandler = Handler(encodeThread!!.looper)

        encodeHandler?.post {
            val encoder = videoEncoder ?: run {
                videoDrainDone.countDown()
                return@post
            }

            // 视频时钟速率诊断:统计视频 PTS 增量 vs 墙钟流逝,周期上报。
            var vCapStatStartNs = System.nanoTime()
            var vCapStatStartPtsUs = lastVideoFrameTimeUs
            var vCapStatStartSeq = videoFrameSeq
            var vCapStatStartFrameCount = frameCount

            try {
                // 轮询模式:主循环主动 dequeueOutputBuffer 取编码器输出,即时写入 muxer。
                // 对齐 AZ 6.9.9 架构。编码器输出不足(省电/SF 投帧节流)时 dequeue 返回
                // TRY_AGAIN,循环仅做轻量保活与周期诊断,不空转忙等。
                val pollBufferInfo = MediaCodec.BufferInfo()
                while (isRunning.get() && !forceStop.get() && !muxerVideoDone) {
                    try {
                        checkAudioTrackTimeout()
                        // —— 显式轮询编码器视频输出 ——
                        val enc = videoEncoder
                        if (enc != null) {
                            // v6.7.184: 暂停期退避。暂停时投影已摘、无新帧可喂,
                            // 2ms 超时 + 1ms sleep 等于每秒约 330 次唤醒,纯 CPU 空转;
                            // 暂停+锁屏场景这 330 次唤醒还会推迟 Doze 生效。
                            // 100s 超时 + 50ms sleep 足够:恢复暂停必然先亮屏解锁,
                            // 最长延迟约 150ms,人眼不可感知。
                            val outIdx = enc.dequeueOutputBuffer(pollBufferInfo, if (isPaused.get()) 100_000L else 2000L)
                            when {
                                outIdx >= 0 -> {
                                    handleVideoOutput(enc, outIdx, pollBufferInfo)
                                }
                                outIdx == MediaCodec.INFO_OUTPUT_FORMAT_CHANGED -> {
                                    handleOutputFormatChanged()
                                }
                                outIdx == MediaCodec.INFO_OUTPUT_BUFFERS_CHANGED -> {
                                    // 输出 buffer 集合重建,无需处理(每次通过 getOutputBuffer 获取)
                                }
                            }
                        }
                        // v6.7.184: 同 dequeue 退避,暂停期 50ms 节拍,恢复后回到 1ms。
                        Thread.sleep(if (isPaused.get()) 50L else 1L)
                    } catch (e: Exception) {
                        if (isRunning.get()) {
                            logDetail("encode_loop_error", "${e.message}")
                        }
                    }
                    reportProgress()

                    // 周期诊断:视频时钟速率(每 5s 一次)
                    val vCapNowNs = System.nanoTime()
                    val vCapElapsedMs = (vCapNowNs - vCapStatStartNs) / 1_000_000L
                    if (vCapElapsedMs >= 5000) {
                        // v6.7.95: 暂停/恢复瞬间 VideoCapture 有明显的 surface 摘除/重挂空洞,
                        // 会拉低 ptRate/seqFps 造成 VIDEO_UNDERSPEED / LOW_FPS_WARNING 误报。
                        // 暂停窗口内跳出统计:重置窗口起点,等真正恢复采集后再计,不污染帧率判定。
                        if (isPaused.get()) {
                            vCapStatStartNs = vCapNowNs
                            vCapStatStartPtsUs = lastVideoFrameTimeUs
                            vCapStatStartSeq = videoFrameSeq
                            vCapStatStartFrameCount = frameCount
                            vCapMaxWallGapUs = 0L
                            vCapMaxPtsGapUs = 0L
                            logDetail("video_cap_stat", "hit=PAUSED_SKIP winMs=$vCapElapsedMs (paused, skip fps window)")
                            continue
                        }
                        val vCapPtsDelta = lastVideoFrameTimeUs - vCapStatStartPtsUs
                        val vCapSeqDelta = videoFrameSeq - vCapStatStartSeq
                        val vCapPtsMs = vCapPtsDelta / 1000L
                        val vCapRate = if (vCapElapsedMs > 0) vCapPtsMs.toFloat() / vCapElapsedMs else 1f
                        val seqFps = if (vCapElapsedMs > 0) vCapSeqDelta * 1000f / vCapElapsedMs else 0f
                        // v6.7.97 (改进4): 改用 seqFps 作为主判据。ptRate 依赖 ptsMs 量化
                        // (1ms 精度)，5s 窗口内 1 帧抖动就会引起判定翻转，容易误报 VIDEO_UNDERSPEED。
                        // seqFps 由帧序号 / 墙钟推出，反映编码器真实产出帧率。
                        // 阈值：targetFps*0.9 视为健康下限，targetFps*1.1 视为上限。
                        // 首个窗口无视频输出时打 VIDEO_WARMUP，避免启动阶段假阴性。
                        // v6.7.98: 弱机实测 seqFps 恒定 ~42-50fps(60fps 目标)，
                        // 每 5s 触发 VIDEO_UNDERSPEED 属于设备能力上限而非"欠速异常"。
                        // 改用 targetFps*0.6 作为异常下限，区分"设备能力上限"与"编码异常"。
                        val vWarmup = vCapSeqDelta <= 0
                        val vOverLimit = seqFps > targetFps * 1.1f
                        val vHealthy = seqFps >= targetFps * 0.6f && seqFps <= targetFps * 1.1f
                        val vUnderspeed = seqFps < targetFps * 0.6f && vCapSeqDelta > 0
                        val vIdle = targetFps <= 0
                        val vHit = when {
                            vWarmup -> "VIDEO_WARMUP"
                            vIdle -> "VIDEO_IDLE"
                            vOverLimit -> if (vCapRate > 1.0f + 0.1f) "VIDEO_OVERSPEED_LIMIT_FAIL" else "VIDEO_OVERSPEED"
                            vHealthy -> "VIDEO_HEALTHY"
                            vUnderspeed -> "VIDEO_UNDERSPEED"
                            else -> "VIDEO_UNSTABLE"
                        }
                        // v6.7.98: 新增 DEVICE_CAP 标签——当 seqFps 低于 0.9 但高于 0.6
                        // 时，说明设备编码器能力上限低于目标帧率，属于硬件限制而非异常。
                        // 此前此类场景每 5s 触发 VIDEO_UNDERSPEED，属于误报。
                        if (vHit == "VIDEO_HEALTHY" && seqFps < targetFps * 0.9f) {
                            logDetail("video_cap_stat",
                                "hit=VIDEO_DEVICE_CAP seqFps=${"%.1f".format(seqFps)} " +
                                    "< 90% target ${targetFps} (device encoder limit, not underspeed)")
                        }
                        // 视频学习态:async=异步回调模式 / poll=轮询模式
                        val vLearnState = "poll"
                        logDetail("video_cap_stat",
                            ("hit=$vHit winMs=$vCapElapsedMs ptsMs=$vCapPtsMs seqDelta=$vCapSeqDelta " +
                                "ptRate=%.3f seqFps=%.1f targetFps=%d learnState=$vLearnState " +
                                "maxWallGapMs=${vCapMaxWallGapUs / 1000L} maxPtsGapMs=${vCapMaxPtsGapUs / 1000L}")
                                .format(vCapRate, seqFps, targetFps))
                        vCapMaxWallGapUs = 0L
                        vCapMaxPtsGapUs = 0L
                        // 独立实际帧率降级:基于 frameCount 而非 videoFrameSeq,
                        // 避免墙钟 PTS 导致 vCapRate 接近 1.0 而掩盖帧率不足。
                        // 取 frameCount 的 5s 增量,若持续低于 targetFps*0.8 则降档。
                        // 关闭:144fps 场景下编码器输出帧率 *0.8 阈值(115.2fps)极易误触,
                        // 降低 operating-rate 后 SF 投帧与编码器消费速率不匹配导致撕裂。
                        // 对齐 AZ 架构:不录制中降帧,让编码器自行处理跟不上时的帧丢弃。
                        val actualFrameDelta = frameCount - vCapStatStartFrameCount
                        val actualFps = if (vCapElapsedMs > 0) actualFrameDelta * 1000f / vCapElapsedMs else 0f
                        // v6.7.48: 降档预警(纯观测、不动作)。原"would reduce to X (disabled)"
                        // 单次日志升级为连续计数:actualFps < 0.8*target 持续 >=5s 时回调 onWarning,
                        // 帮助区分编码器吞吐瓶颈 vs SF 投帧瓶颈(弱机/144fps 下不误触、不降档)。
                        val lowFps = actualFps > 0 && targetFps > FRAME_DROPPED_MIN_FPS &&
                            actualFps < targetFps * 0.8f
                        if (lowFps) {
                            lowFpsWarningCount++
                            if (lowFpsWarningCount >= LOW_FPS_WARNING_SECONDS) {
                                logDetail("video_cap_stat",
                                    "LOW_FPS_WARNING actualFps=${"%.1f".format(actualFps)} " +
                                        "< 80% target $targetFps for ${lowFpsWarningCount}s " +
                                        "(observation only, no downgrade)")
                                runCatching { callback?.onWarning(
                                    "actualFps=${"%.1f".format(actualFps)} 持续 ${lowFpsWarningCount}s 低于 80% 目标 $targetFps（编码器吞吐或 SF 投帧瓶颈，仅观测不降档）"
                                ) }
                                lowFpsWarningCount = 0
                            }
                        } else {
                            lowFpsWarningCount = 0
                        }
                        vCapStatStartNs = vCapNowNs
                        vCapStatStartPtsUs = lastVideoFrameTimeUs
                        vCapStatStartSeq = videoFrameSeq
                        vCapStatStartFrameCount = frameCount
                    }
                }

                if (!muxerVideoDone) {
                    drainVideoEncoder(true)
                }
            } catch (e: Throwable) {
                logDetail("encode_loop", "fatal: ${e.message}")
            } finally {
                videoDrainDone.countDown()
            }

            logDetail("encode_loop", "finished, frames=$frameCount")
        }
    }

    // 轮询模式输出统计:EncodeLoopThread 主动 dequeueOutputBuffer 取编码器输出,
    // 传入 handleVideoOutput 写入 muxer。
    private var lastFrameWallNs = 0L
    private var lastFramePtsUs = 0L
    // v6.7.52: 5s 诊断窗口内最大相邻输出墙钟间隔/最大 PTS 间隔,量化投帧/编码掉帧
    // gap(日志里 seq 841/871/961 的 1.09s~2.16s 大间隔),区分 SF 投帧中断与编码背压。
    private var vCapMaxWallGapUs = 0L
    private var vCapMaxPtsGapUs = 0L
    // v6.7.95: 移除未引用字段 vCapWindowPrevWallNs / lastFrameDroppedNs /
    // FRAME_DROPPED_THROTTLE_NS(ERROR_FRAME_DROPPED 节流逻辑已不存在,三个符号仅声明处出现)。
    // v6.7.53: 掉帧/停滞窗口关键帧恢复请求节流。检测到输出间隔超过阈值(投帧/编码
    // 停滞窗口,如省电 SF 投帧中断、GC、编码背压)后,请求编码器在恢复时立即输出关键帧,
    // 对齐 AZ request-sync 用法,避免长时间停顿后首帧仍为 P 帧导致画面模糊/断层。
    private var lastStallSyncNs = 0L
    private val STALL_SYNC_THROTTLE_NS: Long = 2_000_000_000L
    private val STALL_SYNC_GAP_US: Long = 500_000L
    private val FRAME_DROPPED_MIN_FPS: Int = 30
    private val videoFirstFrameRealtimeNs = AtomicLong(-1L)
    @Volatile private var lastWrittenPtsUs = -1L
    @Volatile private var surfaceLost = java.util.concurrent.atomic.AtomicBoolean(false)

    // ===== 撕裂/连贯性诊断累计器 =====
    // 用于判断录制画面是否连贯、是否存在潜在撕裂。每一类可能的撕裂来源对应一组计数。
    // 每 DIAG_PERIOD_FRAMES 帧输出一份连贯性报告,便于定位到具体环节。
    // -- 1. 帧去重计数(墙钟 PTS 冗余帧被丢弃)——冗余帧过多说明 SF 投帧率高于编码输出率
    private var diagDedupCount = 0
    // -- 2. 帧间隔抖动(PTS 间隔相对目标帧间隔的偏离)——抖动过大说明编码器/SF 投帧不稳定
    private var diagJitterSumUs = 0L
    private var diagJitterMinUs = Long.MAX_VALUE
    private var diagJitterMaxUs = 0L
    private var diagJitterN = 0
    // -- 3. 墙钟 vs PTS 偏差(实际投帧墙钟间隔累计 vs PTS 推进,判断投帧率漂移)
    private var diagWallSumUs = 0L
    private var diagPtsDeltaSumUs = 0L
    // -- 4. 编码器输出间隔过短次数(疑似积压/背压导致的 burst)
    private var diagBurstFrameCount = 0
    // -- 5. 掉帧/大间隔次数(间隔 > 1.5x 目标帧间隔,疑似丢帧导致的画面跳变)
    private var diagDropFrameCount = 0
    private var diagDropMaxUs = 0L
    // -- 6. 输出到写 muxer 的墙钟耗时(检测编码/写盘是否阻塞导致处理滞后)
    // v6.7.95: 移除未引用字段 diagLastMuxerWriteNs(仅声明处出现,用时由局部 writeStartNs 覆盖)。
    private var diagMuxerWriteMaxUs = 0L
    // -- 6b. (已移除 v6.7.95)编码耗时 = 输出帧 PTS 相对真实墙钟的滞后。
    //         该指标因 wallElapsedUs 与 selfPtsUs 同式相减恒为 0,定位瓶颈改用 wall2muxer_max。
    // -- 7. 重置起始锚点线程安全计数器(用于首帧锚定诊断)
    private var diagAnchorCount = 0
    private var diagFrameCount = 0L
    private val DIAG_PERIOD_FRAMES: Long = 300L
    // 相邻写入帧的墙钟/PTS 参考,用于计算间隔抖动
    private var prevWriteWallNs = 0L
    private var prevWritePtsUs = 0L

    private fun resetTearingDiag() {
        diagDedupCount = 0
        diagJitterSumUs = 0L
        diagJitterMinUs = Long.MAX_VALUE
        diagJitterMaxUs = 0L
        diagJitterN = 0
        diagWallSumUs = 0L
        diagPtsDeltaSumUs = 0L
        diagBurstFrameCount = 0
        diagDropFrameCount = 0
        diagDropMaxUs = 0L
        diagMuxerWriteMaxUs = 0L
        diagAnchorCount = 0
        // v6.7.95: wall_avg 分母修复——此前 diagFrameCount 不在本函数的重置列表里,
        // 是从录制开始累计的总数,而 diagWallSumUs 每 300 帧清零,wall_avg = 窗口和/总帧数
        // 随 1/N 衰减,纯噪声(日志实测 frames=3600 时 wall_avg=1476us=窗口和/3600)。
        // 补上归零,让 wall_avg 只覆盖本窗口(= frameInterval 附近)真正有意义。
        diagFrameCount = 0L
    }

    // 输出撕裂/连贯性诊断报告
    private fun reportTearingDiag(currentPtsUs: Long) {
        if (diagJitterN == 0) { resetTearingDiag(); return }
        val avgJitterUs = diagJitterSumUs / diagJitterN
        val frameIntervalUs = if (targetFps > 0) 1_000_000L / targetFps else 33334L
        val wallToPtsMs = if (diagFrameCount > 0) diagWallSumUs / diagFrameCount else 0L
        logDetail("tearing_diag",
            "frames=${diagFrameCount} pts=${currentPtsUs}us targetFps=${targetFps} " +
            "dedup=${diagDedupCount} " +
            "jitter_avg=${avgJitterUs}us min=${diagJitterMinUs}us max=${diagJitterMaxUs}us " +
            "(target=${frameIntervalUs}us) " +
            "burst=${diagBurstFrameCount} drop=${diagDropFrameCount} dropMax=${diagDropMaxUs}us " +
            "wall2muxer_max=${diagMuxerWriteMaxUs}us " +
            "wall_avg=${wallToPtsMs}us anchor=${diagAnchorCount}")
        resetTearingDiag()
    }

    private fun handleVideoOutput(codec: MediaCodec, index: Int, info: MediaCodec.BufferInfo) {
        framesDequeued++   // v6.7.190 (P0-2): 编码器交回帧总数(含后续被丢弃的),恒等式左端
        try {
            val now = System.nanoTime()
            val outputBuffer = codec.getOutputBuffer(index)
            if (outputBuffer != null) {
                if (isPaused.get()) {
                    // 暂停期间也要检查 EOS:若恰在暂停中编码器产出带 EOS 标志的帧,
                    // 必须置位 muxerVideoDone,否则 videoDrainDone latch 永不 countDown,
                    // awaitDrainCompletion 会等到超时(最多 30s)。
                    if ((info.flags and MediaCodec.BUFFER_FLAG_END_OF_STREAM) != 0) {
                        muxerVideoDone = true
                    }
                    dropPaused++   // v6.7.189 (P2-15b): 丢帧归因——暂停丢弃
                    outputBuffer.clear()
                    codec.releaseOutputBuffer(index, false)
                    return
                }
                if (info.size > 0) {
                    // v6.7.190 (P0-2): 本帧最终是否写入 muxer 成功。函数尾部据此把
                    // "编码器交回但从未写入"的帧单独归因为 dropEosOrIdle,
                    // 使 dequeued = written + attributed + unattributed 可证伪。
                    var frameWritten = false
                    val frameIntervalUs = if (targetFps > 0) 1_000_000L / targetFps else 33334L

                    // 差异A: 视频 PTS 完全信任编码器输出渲染时间戳,仅首帧归零 + 单调递增钳制,
                    // 对齐 AZ(Lfg/h$a -> m0)。不做墙钟量化、不做音频锚定、不做 dedup,
                    // 让 fps 统计=编码器真实产出帧率,消除 av_pts_delta 缓增来源。
                    if (videoFirstPtsUs < 0L) {
                        videoFirstPtsUs = info.presentationTimeUs
                        firstVideoFrameTimeUs = 0L
                        // v6.7.52: 修复墙钟锚点死代码——此前 videoFirstFrameRealtimeNs 从未被
                        // 置位(恒为 -1),导致 frame_debug 的 wallMs 与 encodeLag/撕裂诊断全部失效。
                        // 此处记录真实首帧输出墙钟,作为统一墙钟锚点与视频时钟速率诊断基准。
                        videoFirstFrameRealtimeNs.set(now)
                    }
                    // v6.7.157 (P0-1) 删除"删已编码 P 帧"逻辑:此处曾按 targetFps 丢非关键帧
                    // (45fps=每4帧丢1、30fps=每2帧丢1)并全丢 avSync 漂移帧。删除是花屏根治——
                    // H.264/HEVC 的 P 帧参考前面帧,删掉中间帧会导致后续解码拿错参考帧,
                    // 表现首帧(IDR 独立解码)正常、后续撕裂/绿块。帧率控制必须在编码前完成
                    // (启动期历史封顶/分片边界重建编码器),绝不能在编码后删帧。必剪/剪映铁律。
                    // avSyncDropActive 漂移改为纯日志容忍(方差几十~150ms 不可察觉,花屏是灾难),
                    // 不再丢帧;降档态只降码率(安全),不再删帧。"不花屏优先"。
                    if (avSyncDropActive && videoFirstPtsUs >= 0L &&
                        (info.flags and MediaCodec.BUFFER_FLAG_KEY_FRAME) == 0 &&
                        info.presentationTimeUs > videoFirstPtsUs) {
                        // ponytail: 容忍漂移,不删帧——宁可轻微音画偏移,绝不破坏 PTS 参考链。
                        avSyncDropCount++
                        if (avSyncDropCount <= 3)
                            logDetailL1("av_sync_drop", "tolerate drift #${avSyncDropCount} (no frame drop)")
                    }
                    // v6.7.124 (Bug2/3 修复): 视频 PTS 统一信任编码器输出渲染时间戳(首帧归零),
                    // 对齐 AZ(Lfg/h$a -> m0)。此前(4625)用 (now - videoFirstFrameRealtimeNs) 的
                    // dequeue 墙钟打点:当 capture_stall(编码器积压/背压)发生时,没有帧被 dequeue,
                    // 视频 PTS 停步,而音频 accumulator 按采样计数持续推进 → 恢复后音频领先视频
                    // (av_pts_delta 恒负,实测 -294ms)。编码器渲染时间戳自采集帧时即固定,不因
                    // dequeue 推迟而塌陷,与音频"内容量驱动"一致。videoFirstFrameRealtimeNs 仅保留
                    // 供 wallMs/encodeLag 墙钟诊断,不再作为 PTS 来源。
                    // v6.7.191 (P0-5): 单调钳制加"虚高熔断"。coerceAtLeast(lastWrittenPtsUs)
                    // 是 muxer 的硬要求,但 lastWrittenPtsUs 永不回落:编码器在背压恢复后可能
                    // 交回倒退时间戳,一旦把 PTS 顶到虚高点,之后每一帧都从那个虚高点继续,
                    // 系统性偏大会同时污染时长(vSpanUs 虚长)、漂移(avDeltaUs 虚大,可能触发
                    // 不该触发的重锚)、学习帧率(actualFps 虚低,误导降档)。
                    // 熔断规则:钳制位移超过 3 个帧间隔即认为时间戳不可信,改用墙钟重建。
                    val frameIntervalUs0 = if (targetFps > 0) 1_000_000L / targetFps else 33334L
                    val rawPtsUs = if (videoFirstPtsUs >= 0L) info.presentationTimeUs - videoFirstPtsUs else -1L
                    val clampShiftUs = lastWrittenPtsUs - rawPtsUs
                    val maxTrustedShiftUs = frameIntervalUs0 * 3
                    val selfPtsUs = if (rawPtsUs >= lastWrittenPtsUs) {
                        rawPtsUs
                    } else if (rawPtsUs < 0L || clampShiftUs <= maxTrustedShiftUs) {
                        // 首帧走原墙钟路径;小幅倒退属正常钳制。
                        if (rawPtsUs < 0L) {
                            ((now - videoFirstFrameRealtimeNs.get()) / 1000L).coerceAtLeast(lastWrittenPtsUs)
                        } else {
                            lastWrittenPtsUs
                        }
                    } else {
                        // 大幅倒退:时间戳不可信,用墙钟重建并记一次熔断。
                        // 语句需独立成行并显式返回 Long,否则该分支类型推断为 Unit 与其余分支冲突。
                        ptsClockFuseCount++
                        logDetail("pts_clock_fuse",
                            "raw=$rawPtsUs last=${lastWrittenPtsUs} shift=$clampShiftUs count=$ptsClockFuseCount")
                        ((now - videoFirstFrameRealtimeNs.get()) / 1000L).coerceAtLeast(lastWrittenPtsUs)
                    }

                    lastVideoFrameTimeUs = selfPtsUs
                    lastWrittenPtsUs = selfPtsUs
                    info.presentationTimeUs = selfPtsUs
                    trackPtsInterval(selfPtsUs)
                    videoFrameSeq++
                    diagFrameCount++

                    // v6.7.95: 移除失效的 encodeLagUs 计量。此前 wallElapsedUs 与 selfPtsUs 都是
                    // (now - videoFirstFrameRealtimeNs)/1000,二者相减恒为 0,日志里
                    // enc_max 在全周期恒等于 0us,一直在误导"编码不耗时"的判断。
                    // (真实混流耗时改由 wall2muxer_max 反映。)

                    // ===== 撕裂/连贯性诊断统计 =====
                    // 基于相邻两帧的墙钟间隔与 PTS 间隔,判断投帧/编码稳定性。
                    val wallGapUs = if (prevWriteWallNs > 0) (now - prevWriteWallNs) / 1000L else 0L
                    prevWriteWallNs = now
                    val ptsGapUs = if (prevWritePtsUs > 0) selfPtsUs - prevWritePtsUs else 0L
                    prevWritePtsUs = selfPtsUs
                    // v6.7.52: 5s 窗口最大输出间隔累计(供 video_cap_stat 上报量化掉帧 gap)
                    if (wallGapUs > vCapMaxWallGapUs) vCapMaxWallGapUs = wallGapUs
                    if (ptsGapUs > vCapMaxPtsGapUs) vCapMaxPtsGapUs = ptsGapUs
                    // v6.7.89 (L-4): 单帧空洞超过 300ms 单独打点,便于定位卡顿来源。
                    // 逐帧诊断/tearing_diag 都是窗口均值,大 gap 会被稀释掉;这里阈值命中即打。
                    // v6.7.95: 加 paused 字段——暂停/恢复瞬间 VirtualDisplay surface 摘除/重挂
                    // 会制造固定 31~50ms 的空洞,但这些是假警报(共现率 8/8)。打上标记便于区分。
                    if (wallGapUs > 300_000L) {
                        stallCount++
                        stallTotalUs += wallGapUs
                        // v6.7.191 (P0-4): 同时累计 PTS 维度空洞与估算缺帧数。
                        // wallGap 是墙钟间隔,PTS 是内容时间轴,两者不是同一时钟;
                        // 只有 ptsGap 才等于"成片里真正缺了多久"。stall_summary 的 lost 此前
                        // 只有墙钟口径,与 frame_accounting 的帧数账之间没有任何可交叉验证的等式
                        // (实测 lost=1555ms 而 frame_accounting 全零,二者互不印证)。
                        val stallPtsGapUs = if (ptsGapUs > 0L) ptsGapUs else 0L
                        stallPtsTotalUs += stallPtsGapUs
                        val stallExpectedFrames = if (targetFps > 0) (wallGapUs * targetFps / 1_000_000L) else 0L
                        stallMissingFrames += (stallExpectedFrames - 1L).coerceAtLeast(0L)
                        if (wallGapUs > stallMaxUs) stallMaxUs = wallGapUs
                        logDetail("capture_stall",
                            "wallGap=${wallGapUs}us ptsGap=${stallPtsGapUs}us expectedFrames=$stallExpectedFrames " +
                            "missingFrames=${(stallExpectedFrames - 1L).coerceAtLeast(0L)} " +
                            "paused=${isPaused.get()} atPts=${selfPtsUs}us seq=$videoFrameSeq " +
                            "heap=${Runtime.getRuntime().totalMemory() - Runtime.getRuntime().freeMemory()} count=$stallCount")
                        // v6.7.189 (P1-11): 窗口内 >=5 次停顿 → 记一次窗口告警。
                        // 不改帧率(与"录制中不热改帧率"策略一致),只输出信号供后续定位/人工判断。
                        if (stallCount - stallWindowBase >= STALL_WINDOW_MAX) {
                            logDetail("capture_stall_window",
                                "stalls=${stallCount - stallWindowBase} in 60s, max=${stallMaxUs / 1000}ms " +
                                    "seq=$videoFrameSeq fps=$targetFps")
                            stallWindowBase = stallCount
                        }
                    }
                    if (ptsGapUs > 0) {
                        // 帧间隔抖动 = |实际 PTS 间隔 - 目标帧间隔|
                        val jitterUs = kotlin.math.abs(ptsGapUs - frameIntervalUs)
                        diagJitterSumUs += jitterUs
                        if (jitterUs < diagJitterMinUs) diagJitterMinUs = jitterUs
                        if (jitterUs > diagJitterMaxUs) diagJitterMaxUs = jitterUs
                        diagJitterN++
                        diagWallSumUs += wallGapUs
                        diagPtsDeltaSumUs += ptsGapUs
                        // burst:输出间隔显著小于目标(编码器积压/背压突发)
                        if (ptsGapUs < frameIntervalUs / 2) {
                            diagBurstFrameCount++
                        }
                        // drop:输出间隔显著大于目标(疑似 SF 投帧中断或编码掉帧)
                        if (ptsGapUs > frameIntervalUs * 3 / 2) {
                            diagDropFrameCount++
                            if (ptsGapUs > diagDropMaxUs) diagDropMaxUs = ptsGapUs
                        }
                        // v6.7.53: 掉帧/停滞窗口恢复——输出间隔超过 500ms(16~18s 区间
                        // 视频 PTS 停滞、timing frames 骤降的同类窗口)时,请求编码器在
                        // 恢复后立即输出关键帧,对齐 AZ request-sync 用法,避免长时间
                        // 停顿后画面断层。节流 2s 防频繁请求。
                        if (ptsGapUs > STALL_SYNC_GAP_US) {
                            val nowNsForSync = System.nanoTime()
                            if (nowNsForSync - lastStallSyncNs > STALL_SYNC_THROTTLE_NS) {
                                lastStallSyncNs = nowNsForSync
                                requestKeyFrame(codec)
                                logDetail("video_stall_sync",
                                    "gap=${ptsGapUs}us wallGap=${wallGapUs}us seq=$videoFrameSeq " +
                                        "requested keyframe after stall window")
                            }
                        }
                    }
                    // 周期输出撕裂诊断报告(每 DIAG_PERIOD_FRAMES 帧)
                    if (diagFrameCount % DIAG_PERIOD_FRAMES == 0L) {
                        reportTearingDiag(selfPtsUs)
                    }

                    // 逐帧画面诊断日志: wallClock, 帧间隔, PTS, 码率
                    if (videoFrameSeq % 30L == 1L) {
                        val nowNs = System.nanoTime()
                        val wallMs = (nowNs - videoFirstFrameRealtimeNs.get()) / 1_000_000L
                        val gapUs = if (lastFrameWallNs > 0) (nowNs - lastFrameWallNs) / 1000L else 0L
                        lastFrameWallNs = nowNs
                        val prevGap = if (lastFramePtsUs > 0) selfPtsUs - lastFramePtsUs else 0L
                        lastFramePtsUs = selfPtsUs
                        logDetail("frame_debug",
                            "seq=$videoFrameSeq pts=${selfPtsUs}us wallMs=${wallMs}ms " +
                            "gap=${gapUs}us ptsGap=${prevGap}us " +
                            "fps=$targetFps br=$targetBitrate")
                    }

                    outputBuffer.position(info.offset)
                    outputBuffer.limit(info.offset + info.size)

                    if (muxerStarted.get() && videoTrackIndex >= 0 && !isPaused.get()) {
                        // v6.7.105: 4GiB 单文件边界防护。逐帧在写入前检查累计写入字节,
                        // 到安全水线(4GiB-64MiB)触发一次安全收尾。
                        // 避免 MediaMuxer 写到接近 4GiB 时 moov 32-bit 索引溢出导致
                        // 产物损坏却仍被 renameToFinal 写成 .mp4("录完了打不开")。
                        // 到水线即 onError,引擎走完整 finalize,内容截止在水线附近,
                        // 产出可 seek 的完整文件,而非 4GiB 撞毁。
                        if (videoBytesWritten >= MUXER_4G_SAFE_LIMIT_BYTES) {
                            onMuxer4GLimitReached()
                            drop4GLimit++   // v6.7.190 (P0-2): 丢帧归因——4GiB 水线截断
                            outputBuffer.clear()
                            codec.releaseOutputBuffer(index, false)
                            return
                        }
                        try {
                            // v6.7.95: 移除失效的 enc_avg 计量——encoderPhaseStartNs 在
                            // dequeueOutputBuffer 返回后才赋值,测的是 getOutputBuffer+position 的
                            // 耗时,与编码无关;此前该值按"纳秒"除 1000 倍导致恒为 0ms。
                            // 真实混流耗时由 wall2muxer_max 反映(本机 p50 9.5ms / max 16.1ms)。
                            val writeStartNs = System.nanoTime()
                            synchronized(muxerLock) {
                                // v6.7.128: 切段检测(时间/字节阈值先到先切),与写入同锁串行,
                                // 切段时编码器不重启,帧流不中断。切段后本帧落到新片。
                                if (segmentationEnabled && !segmentSwitchFailed && muxerStarted.get()) {
                                    val nowMs = SystemClock.elapsedRealtime()
                                    // v6.7.189 (P1-9): 预请求 IDR。分片到期前 800ms 先要关键帧,
                                    // 切段时 IDR 已在路上,把"等 IDR"从阻塞路径变成零等待。
                                    if (!segIdrPreRequested &&
                                        nowMs - segmentStartMs >= SEGMENT_DURATION_MS - SEG_IDR_PRE_REQUEST_MS) {
                                        requestKeyFrame(codec)
                                        segIdrPreRequested = true
                                    }
                                    if ((nowMs - segmentStartMs) >= SEGMENT_DURATION_MS ||
                                        segmentBytesWritten >= SEGMENT_MAX_BYTES) {
                                        segIdrPreRequested = false
                                        // 记录本帧的全局 PTS 作为新片重基起点(切段后用)
                                        segmentStartGlobalPtsUs = info.presentationTimeUs
                                        switchSegment(
                                            if (segmentBytesWritten >= SEGMENT_MAX_BYTES) "bytes" else "duration"
                                        )
                                        if (segmentSwitchFailed) {
                                            dropSwitchFailed++   // v6.7.190 (P0-2): 丢帧归因——切段失败
                                            outputBuffer.clear()
                                            codec.releaseOutputBuffer(index, false)
                                            return
                                        }
                                        // 切段后 lastMuxVideoPtsUs 需重置(新片时间轴从 0 起)
                                        lastMuxVideoPtsUs = -1L
                                    }
                                }
                                // v6.7.177 (增量A): 全局限额检测。与切段检测同锁同钟 elapsedRealtime,
                                // 1s 节流。命中只置 reason,收尾 post 到锁外——drain 链会再拿 muxerLock,
                                // 锁内直呼 stopAsync 虽 monitor 可重入不死锁,但会把 drain 排进本回调栈内,
                                // 时序难读。
                                val cfg0 = config
                                if (autoStopReason == null && cfg0 != null &&
                                    (cfg0.recLimitBytes > 0L || cfg0.recLimitDurationMs > 0L)) {
                                    val nowMs2 = SystemClock.elapsedRealtime()
                                    if (nowMs2 - limitCheckLastMs >= 1000L) {
                                        limitCheckLastMs = nowMs2
                                        val totalBytes = getTotalSegmentBytes()
                                        val elapsedMs = nowMs2 - recordingT0Us
                                        if (cfg0.recLimitBytes > 0L && totalBytes >= cfg0.recLimitBytes) {
                                            autoStopReason = "limitBytes"
                                        } else if (cfg0.recLimitDurationMs > 0L && elapsedMs >= cfg0.recLimitDurationMs) {
                                            autoStopReason = "limitDuration"
                                        }
                                        autoStopReason?.let {
                                            logDetail("auto_limit", "hit=$it totalBytes=$totalBytes elapsedMs=$elapsedMs")
                                        }
                                    }
                                }
                                // v6.7.157 (BUG-3): 新片等待首帧 IDR。请求 IDR 后、新 IDR 到来前,
                                // 到达的都是非关键帧(参考上一片末尾的帧),写入新片会让解码器花屏。
                                // 此时新片还没写入任何帧,丢弃这些帧是安全的(不破坏已写入帧的参考链)。
                                // EOS 帧必须放行,否则 muxerVideoDone 永不置位、停止会等到超时。
                                if (pendingSegIdr) {
                                    val isKey = (info.flags and MediaCodec.BUFFER_FLAG_KEY_FRAME) != 0
                                    val isEos = (info.flags and MediaCodec.BUFFER_FLAG_END_OF_STREAM) != 0
                                    // v6.7.189 (P1-9): 等待上限按墙钟 500ms(预请求后通常 0 等待);
                                    // SEG_IDR_DROP_MAX 保留为次级兜底,防极端设备永久不发 IDR。
                                    val waitedMs = SystemClock.elapsedRealtime() - segIdrWaitStartMs
                                    if (!isKey && !isEos && waitedMs < SEG_IDR_WAIT_MS &&
                                        segIdrDropCount < SEG_IDR_DROP_MAX) {
                                        segIdrDropCount++
                                        dropWaitIdr++   // v6.7.189 (P2-15b): 丢帧归因——等 IDR
                                        logDetail("seg_drop_p_before_idr",
                                            "pts=${info.presentationTimeUs} dropped=$segIdrDropCount waitedMs=$waitedMs (new segment waiting for IDR)")
                                        outputBuffer.clear()
                                        codec.releaseOutputBuffer(index, false)
                                        return
                                    }
                                    pendingSegIdr = false
                                    if (segIdrDropCount > 0) {
                                        logDetail("seg_idr_timeout",
                                            "gave up after $segIdrDropCount P frames / ${waitedMs}ms; writing P frame")
                                    }
                                    segIdrDropCount = 0
                                    logDetail("seg_first_idr", "pts=${info.presentationTimeUs} (new segment ready)")
                                }
                                 // v6.7.62: 视频轨 PTS 写入前严格单调钳制,
                                 // 保证 muxer 视频时间轴严格单调。
                                 // v6.7.91 (5.5): 最小步长从 +1µs 改为 +VIDEO_PTS_MIN_TICK_US(11µs),
                                 // 即 1 个 90kHz timescale 单位。旧 +1µs 在 timescale=90000 下
                                 // 转换为 0.09 单位,取整为 0,两帧 PTS 可能相同(非严格单调)。
                                 // v6.7.171 (P0): 视频 PTS 覆盖为"统一时钟 - 录制起点",与音频共享
                                 // 同一 recordingT0Us 单调时钟,从根上消除两时钟发散。
                                 // 约束6:用 SystemClock.elapsedRealtime()(单调不跳变),严禁 currentTimeMillis()。
                                 // 约束1:不删帧——v6.7.157 已证明删 P 帧破坏参考链致花屏。
                                  val wallClockVidPtsUs = if (recordingT0Us > 0L)
                                      (SystemClock.elapsedRealtime() - recordingT0Us)
                                  else info.presentationTimeUs
                                  info.presentationTimeUs = wallClockVidPtsUs
                                  // v6.7.172 (P0-A): 视频末端对齐。停止排空后 commonEndUs 已写入
                                  // audioTrimEndUs,超过它的视频帧丢弃,把视频裁到音频结束点,
                                  // 消除成片"最后 113ms 没声音"(音频轨比视频轨短)。仅裁尾部,
                                  // 录制中不丢帧(约束 C1)。EOS 帧(info.size==0)不进此块,不受影响。
                                  if (shouldDropVideoPts(wallClockVidPtsUs)) {
                                      dropTailTrim++   // v6.7.189 (P2-15b): 丢帧归因——尾部对齐裁剪
                                      codec.releaseOutputBuffer(index, false)
                                      return
                                  }
                                 val clampedVidPtsUs = if (lastMuxVideoPtsUs >= 0)
                                     kotlin.math.max(lastMuxVideoPtsUs + VIDEO_PTS_MIN_TICK_US, info.presentationTimeUs)
                                 else info.presentationTimeUs
                                 lastMuxVideoPtsUs = clampedVidPtsUs
                                 // v6.7.178 (⑤-e): pts 步长直方图。墙钟打戳下"卡顿恢复=突发压帧",
                                 // burst(≤11µs 即最小钳制被用满)增长即成片微观卡帧信号;
                                 // lt20ms 占多数即证实驱动无视目标 fps 限速。
                                 if (lastPtsForHist >= 0) {
                                     val step = clampedVidPtsUs - lastPtsForHist
                                     if (step <= VIDEO_PTS_MIN_TICK_US) ptsStepBurst++
                                     else if (step < 20_000L) ptsStepLt20++
                                     else if (step < 40_000L) ptsStep30++
                                     else if (step < 80_000L) ptsStepHi++
                                     else ptsStepGt80++
                                     if (step > ptsStepMaxUs) ptsStepMaxUs = step
                                 }
                                 lastPtsForHist = clampedVidPtsUs
                                // v6.7.128: 分片内 PTS 重基——写入 muxer 前减掉本片起点的全局 PTS,
                                // 令每片时间轴从 0 起(独立可播)。全局 lastMuxVideoPtsUs 不随分片重置,
                                // 保证跨片单调锚定仍用于诊断。
                                val segPtsUs = if (segmentationEnabled)
                                    (clampedVidPtsUs - segmentStartPtsUs).coerceAtLeast(0L)
                                else clampedVidPtsUs
                                info.presentationTimeUs = segPtsUs
                                if (segmentationEnabled && segmentVideoFirstPtsUs < 0) {
                                    segmentVideoFirstPtsUs = clampedVidPtsUs
                                }
                                mediaMuxer?.writeSampleData(videoTrackIndex, outputBuffer, info)
                                frameWritten = true
                                writtenFrames++   // v6.7.189 (P2-15b): 写入侧计数
                                capturedFrames++   // v6.7.190 (P0-2): 语义=编码器交回且未被任何归因分支丢弃
                                // v6.7.191 (P0-2): 记录真正写入 muxer 的最后一帧 PTS(墙钟坐标系,
                                // 与 audioTrimEndUs 同源)。lastVideoFrameTimeUs 在 shouldDropVideoPts
                                // 之前就被更新,记录的是"编码器交回的最后一帧",包含被尾巴裁掉的部分,
                                // 不能拿来当容器时长真值。
                                lastMuxedVideoPtsUs = wallClockVidPtsUs
                                if (videoFirstMuxedPtsUs < 0L) videoFirstMuxedPtsUs = wallClockVidPtsUs
                                // v6.7.120 (被杀保护): 写后同步 22B 索引记录
                                indexTracker?.appendSample(
                                    true, info.size, segPtsUs,
                                    (info.flags and MediaCodec.BUFFER_FLAG_KEY_FRAME) != 0)
                                if (segmentationEnabled) segmentBytesWritten += info.size
                            }
                            // v6.7.177 (增量A): 限额命中后把收尾 post 到主线程执行 stopAsync。
                            // 这里在 muxerLock 之外,避免 drain 链二次拿锁的时序难读;
                            // autoStopScheduled CAS 保证只调度一次(limit 命中仅一次)。
                            if (autoStopReason != null && autoStopScheduled.compareAndSet(false, true)) {
                                android.os.Handler(android.os.Looper.getMainLooper()).post {
                                    stopAsync(android.os.Handler(android.os.Looper.getMainLooper()))
                                }
                            }
                            val writeDurUs = (System.nanoTime() - writeStartNs) / 1000L
                            if (writeDurUs > diagMuxerWriteMaxUs) diagMuxerWriteMaxUs = writeDurUs
                            videoBytesWritten += info.size
                            frameCount++
                        } catch (e: Exception) {
                            // v6.7.50: 写失败(如磁盘满)置 muxerFailed 后立即回调 onError 让上层
                            // 停止,避免每帧重复抛异常/重复尝试 IO。onError 在上层异步清理。
                            if (!muxerFailed) {
                                muxerFailed = true
                                logDetail("muxer_video_write_error", "${e.message}")
                                try {
                                    callback?.onError(
                                        IOException("muxer video write failed: ${e.message}"))
                                } catch (_: Exception) {}
                            }
                        }
                    }
                    // v6.7.190 (P0-2): 编码器交回的非空帧最终未写入 muxer(muxer 未就绪/未开轨/
                    // 写失败/muxerFailed 等)。此前被 releaseOutputBuffer 静默吞掉,是 unattributed
                    // 的隐性来源,这里单独归因,保证帧会计恒等式可证伪。
                    if (!frameWritten) dropEosOrIdle++
                    outputBuffer.clear()
                } else {
                    // v6.7.190 (P0-2): 零字节帧(EOS 空帧/编码器空转)。非内容帧,单独归因,
                    // 不占 unattributed,保证恒等式右侧能覆盖全部 dequeued。
                    dropEosOrIdle++
                }
                codec.releaseOutputBuffer(index, false)
            } else {
                codec.releaseOutputBuffer(index, false)
            }

            if ((info.flags and MediaCodec.BUFFER_FLAG_END_OF_STREAM) != 0) {
                muxerVideoDone = true
                if (videoTrimEndUs <= 0L) {
                    videoTrimEndUs = lastVideoFrameTimeUs
                }
                logDetail("encode_loop", "end of stream, videoTrimEndUs=$videoTrimEndUs")
            }
        } catch (e: Throwable) {
            logDetail("video_output_error", "${e.message}")
            logDetail("video_output_error", "${e.stackTraceToString()}")
            val msg = e.message ?: e.javaClass.name
            if (msg.contains("SURFACE_LOST", ignoreCase = true)) {
                surfaceLost.set(true)
                logDetail("surface_lost", "detected, marking for recovery")
            }
            writeEmergencyLog("handleVideoOutput fatal: $msg", e)
        }
    }

    private fun handleOutputFormatChanged() {
        val encoder = videoEncoder ?: return
        try {
            val newFormat = encoder.outputFormat
            logDetail("format_changed", "$newFormat")

            // —— 编码器真实能力回读：对比硬件实际采纳的配置与目标值,暴露静默降级 ——
            val actualFps = if (newFormat.containsKey(KEY_FRAME_RATE)) newFormat.getInteger(KEY_FRAME_RATE) else null
            val actualBitrate = if (newFormat.containsKey(KEY_BIT_RATE)) newFormat.getInteger(KEY_BIT_RATE) else null
            val actualWidth = if (newFormat.containsKey(MediaFormat.KEY_WIDTH)) newFormat.getInteger(MediaFormat.KEY_WIDTH) else null
            val actualHeight = if (newFormat.containsKey(MediaFormat.KEY_HEIGHT)) newFormat.getInteger(MediaFormat.KEY_HEIGHT) else null
            // v6.7.177 (增量C-2) / v6.7.178 (③纠偏): 回读 B帧实际值。KEY_MAX_B_FRAMES 在
            // createVideoFormat 已钉死为 0;若驱动无视(actualB>0)即高危信号:解码序≠显示序将
            // 破坏 PTS 单调钳制与 .idx 重建不变量。黑名单机制另立,本版只出信号。
            // 注意:key 缺失时回读值为 0(非"驱动遵守钉死"),仅代表"编码器未上报",
            // 无法据此判定 B帧状态——判定实际 B帧只能靠 actualB>0 的反向证据。
            val actualB = try {
                if (newFormat.containsKey(MediaFormat.KEY_MAX_B_FRAMES))
                    newFormat.getInteger(MediaFormat.KEY_MAX_B_FRAMES) else 0
            } catch (_: Exception) { -1 }
            val mismatch = mutableListOf<String>()
            if (actualFps != null && targetFps > 0 && actualFps != targetFps) mismatch.add("fps want=$targetFps got=$actualFps")
            // v6.7.178 (⑦): KEY_MAX_FPS_TO_ENCODER 是 CDD 建议值,高通/HONOR 等无视它、
            // 按显示投帧节奏吃帧(实测 120Hz 屏 30fps 配置仍得 ~53fps)。显式出信号:
            // actualFps > target*1.2 即判"限速被忽略",供机型归类。不硬卡帧率(强改要引入
            // 运行时丢帧/重定时,违反不丢帧约束,且会重蹈 v6.7.13x 撕裂覆辙)。
            if (actualFps != null && targetFps > 0 && actualFps > targetFps * 1.2) {
                mismatch.add("fps_cap_ignored want=${targetFps} got=$actualFps")
            }
            if (actualBitrate != null && targetBitrate > 0 && actualBitrate != targetBitrate) mismatch.add("bitrate want=$targetBitrate got=$actualBitrate")
            // v6.7.189 (P0-3): 编码器没吃下这个码率,就必须把内部真值改回来,
            // 否则下游降档/学习全部基于虚高值(真机实测 boost 改到 51M 而编码器仍是 14M,
            // 过热保护被推迟 4 档)。
            if (actualBitrate != null && actualBitrate > 0 && targetBitrate > 0 &&
                actualBitrate < targetBitrate * 0.9) {
                logDetail("bitrate_boost_ineffective",
                    "want=$targetBitrate actual=$actualBitrate -> rollback (codec ignored setParameters)")
                targetBitrate = actualBitrate
                currentBoostFactor = 1.0
            }
            if (actualWidth != null && actualHeight != null) {
                val wantW = alignToEven(config?.width ?: 0)
                val wantH = alignToEven(config?.height ?: 0)
                if (wantW > 0 && (actualWidth != wantW || actualHeight != wantH)) {
                    mismatch.add("size want=${wantW}x${wantH} got=${actualWidth}x$actualHeight")
                }
            }
            logDetail("readback", "actual fps=$actualFps bitrate=$actualBitrate size=${actualWidth}x$actualHeight " +
                "bframes=$actualB" +
                " target fps=$targetFps bitrate=$targetBitrate" +
                (if (mismatch.isEmpty()) " (匹配)" else " MISMATCH: ${mismatch.joinToString("; ")}"))

            if (videoTrackIndex < 0) {
                synchronized(muxerLock) {
                    if (videoTrackIndex < 0) {
                        videoTrackIndex = mediaMuxer?.addTrack(newFormat) ?: -1
                        logDetail("video_track", "index=$videoTrackIndex")
                        videoTrackFormat = if (videoTrackIndex >= 0) newFormat else null
                    }
                }
            }

            tryStartMuxer()
        } catch (e: Exception) {
            logDetail("format_changed_error", "${e.message}")
        }
    }

    private fun trackPtsInterval(pts: Long) {
        if (ptsCount > 0) {
            val interval = pts - framePtsCounter
            ptsIntervalSum += interval
            healthWindowSumUs.addAndGet(interval)
            healthWindowCount.incrementAndGet()
            if (interval < ptsIntervalMin) ptsIntervalMin = interval
            if (interval > ptsIntervalMax) ptsIntervalMax = interval
        }
        framePtsCounter = pts
        if (firstVideoFrameTimeUs < 0) {
            firstVideoFrameTimeUs = pts
        }
        lastVideoFrameTimeUs = pts
        ptsCount++
    }

    private fun reportProgress() {
    // 墙钟节流:距上次回调 < 1000ms 直接跳过,从根源消灭同一帧计数被反复触发
    // 的过频回调(frameCount % N 在 frameCount 停滞时会恒成立)。Service 侧业务
    // 每秒才刷新一次 UI,此处按墙钟节流即可,无需帧计数门控。
    val nowMs = SystemClock.elapsedRealtime()
    if (nowMs - lastProgressReportMs < 1000) return
    lastProgressReportMs = nowMs
    runCatching {
        checkFrameRateHealth()
        val durationMs = calculateDuration()
        // v6.7.189 (P1-7): 双保险——多分片场景大小 = 已封口分片之和 + 当前片实时长度。
        val fileSize = if (segmentationEnabled)
            getTotalSegmentBytes().takeIf { it > 0L } ?: (segmentFile?.length() ?: 0L)
        else
            (outputFile?.takeIf { it.exists() }?.length() ?: 0L)
                .takeIf { it > 0L } ?: (segmentFile?.length() ?: 0L)
        DiagLog.log("onProgress(durationMs=$durationMs fileSize=$fileSize frameCount=$frameCount videoSeq=$videoFrameSeq)")
        checkFreeSpace()
        callback?.onProgress(durationMs, fileSize)
    }
    // v6.7.140-补(方案2): 最近窗口实测帧率——按墙钟秒采样,统计本秒内新增视频帧数,
    // 反映"当前"吞吐而非全程平均;中途掉帧下一窗口立即反映到 runtimeDropWindowFps,
    // maybeStepDowngrade(5539-5540) 即可及时触发丢帧降档。
    // v6.7.190 (P0-3): 窗口门槛从 500ms 抬到 800ms。reportProgress 有 1s 墙钟节流,
    // 一次 capture_stall 落在窗口起点时会把 dMs 拉到 1000ms 而 dSeq 只有个位数,
    // 得到一次假的超低 fps。短窗口样本不足,不参与判定(返回 0)。
    runtimeDropWindowFps = if (videoFrameSeq > 0L && lastDropWindowWallMs > 0L) {
        val dSeq = videoFrameSeq - lastDropWindowSeq
        val dMs = nowMs - lastDropWindowWallMs
        if (dSeq > 0L && dMs >= 800L) (dSeq * 1000L / dMs).toInt().coerceIn(0, 240) else 0
    } else 0
    // v6.7.190 (P0-3): 窗口自身观测点。降级判定要求连续 3 个可信窗口(sub-70% 目标),
    // drop_window 是"单窗口单次采样就定罪"改为"持续性证据"的可追溯依据。
    logDetail("drop_window",
        "fps=$runtimeDropWindowFps targetFps=$targetFps " +
            "dSeq=${videoFrameSeq - lastDropWindowSeq} dMs=${nowMs - lastDropWindowWallMs} " +
            "streak=$frameDropWindowStreak")
    lastDropWindowSeq = videoFrameSeq
    lastDropWindowWallMs = nowMs
    // —— 周期性健康监控：实际产出帧率 + 音视频 pts 偏移(每 ~1s 墙钟) ——
            try {
                val fps = if (firstVideoFrameTimeUs >= 0 && lastVideoFrameTimeUs > firstVideoFrameTimeUs) {
                    videoFrameSeq.toDouble() * 1_000_000.0 / (lastVideoFrameTimeUs - firstVideoFrameTimeUs)
                } else 0.0
                val avDeltaUs = if (lastVideoFrameTimeUs > 0 && lastAudioFrameTimeUs > 0) {
                    lastVideoFrameTimeUs - lastAudioFrameTimeUs
                } else 0L
                val audioBytes = audioBytesWritten
                val audioStream = audioStreamBytes
                val audioPtsUs = if (audioBytes > 0)
                    // v6.7.100 (B4): 诊断日志 PTS 精度——先乘后除,与 v6.7.99 数据路径
                    // 的 L2431/L2905 保持一致,消除旧表达式的先除后乘精度损失(~0.2ms)。
                    audioBytes * 1_000_000L / ((actualAudioChannelCount * 2L) * AUDIO_SAMPLE_RATE)
                else 0L
                val audioStreamPtsUs = if (audioStream > 0)
                    audioStream * 1_000_000L / ((actualAudioChannelCount * 2L) * AUDIO_SAMPLE_RATE)
                else 0L
                // v6.7.183: 诊断串采样 1s→5s。DiagLog 已异步批量落盘,但字符串构建(多次
                // "%.1f".format 装箱 + 拼接)每秒一次是纯浪费。av_pts_delta 环形缓冲仍保持
                // 1Hz 采样(见下方 addLast),不影响 RECORD_SUMMARY 的分位数与 ppm 统计。
                if (nowMs - lastHealthSampleMs >= 5000L) {
                    lastHealthSampleMs = nowMs
                    logDetail("health", "frames=$frameCount(videoSeq=$videoFrameSeq) " +
                        "actual_fps=${"%.1f".format(fps)} target_fps=$targetFps " +
                        "av_pts_delta_us=${if (avDeltaUs >= 0) "+" else ""}$avDeltaUs (video-audio) " +
                        "audio_pts_us=$audioPtsUs stream_pts_us=$audioStreamPtsUs")
                }
                // v6.7.178 (⑤-d): 1Hz 采样 av_pts_delta 进环形缓冲,1Hz 封顶 2h。
                // RECORD_SUMMARY 出分位数 + 漂移率 ppm,区分"一次性锚定"还是"持续漂移"。
                avDeltaRing.addLast(avDeltaUs)
                while (avDeltaRing.size > 7200) avDeltaRing.pollFirst()

                // —— 日志强化: av_pts_delta 漂移率监控(B层) ——
                // v6.7.90 (A-6): 阈值从 500ms 收紧到 100ms(实测 820ms 摆动 0 次触发),
                // 并新增累积告警:abs(avDelta)>200ms 即打(单会话一次)。
                if (lastHealthWallMs != 0L) {
                    val wallDeltaMs = nowMs - lastHealthWallMs
                    val driftDeltaUs = avDeltaUs - lastAvDeltaUs
                    if (kotlin.math.abs(driftDeltaUs) > 100_000L) {
                        logDetail("av_drift",
                            "delta_drift=${if (driftDeltaUs >= 0) "+" else ""}${driftDeltaUs / 1000L}ms " +
                            "over ${wallDeltaMs}ms window av_delta_us=$avDeltaUs " +
                            "audio_pts_us=$audioPtsUs")
                    }
                    // v6.7.191 (P0-3): 累积与"200ms 告警阈值"解耦。
                    // 旧实现把累积器写在 abs(avDeltaUs) > 200ms 分支内部,else 分支清零 ——
                    // 真实漂移是抖动的(实测 -100 / +115 / -977 交替),只要有一个窗口回落到
                    // 200ms 内,累积器与窗口计数就全清,触发难度没有实质下降。
                    // 现所有窗口都累积;告警与重锚各自判断;清零只在累积真的回到滞回容差
                    // (50ms)以内时才做,避免抖动把累积冲掉。
                    avDriftAccumUs += avDeltaUs
                    avDriftWindowCount++
                    logDetail("av_drift_window",
                        "deltaUs=$avDeltaUs accumUs=$avDriftAccumUs windows=$avDriftWindowCount " +
                            "offsetMs=${audioPtsOffsetUs / 1000L}")
                    if (kotlin.math.abs(avDeltaUs) > 200_000L && !avCumulativeWarned) {
                        avCumulativeWarned = true
                        logDetail("av_drift_cumulative",
                            "abs_av_delta=${avDeltaUs / 1000L}ms exceeded 200ms")
                    }
                    if (avDriftWindowCount >= AV_REANCHOR_WINDOWS &&
                        kotlin.math.abs(avDriftAccumUs) > AV_REANCHOR_US) {
                        // v6.7.191 (P0-1): 补偿方向必须与 avDeltaUs 的符号相反,这是本版最高危的一处。
                        // avDeltaUs = video - audio,正值 = 视频超前 = 音频**滞后**;
                        // 音频 PTS 需要被**推大**才能追上视频,故对 avDeltaUs>0 要 +=。
                        // 本仓 3779 行的 avDiffUs = audio - video(符号恰好相反),它"为正=滞后需加回"
                        // 的语义不能照搬到 avDeltaUs —— 上一版误取 -= 会把滞后的音频再往前推,发散。
                        val step = avDriftAccumUs / 2
                        audioPtsOffsetUs += step
                        reanchorCount++
                        logDetail("av_reanchor",
                            "#$reanchorCount accum=${avDriftAccumUs / 1000}ms step=${step / 1000}ms " +
                                "lastDelta=${avDeltaUs / 1000}ms windows=$avDriftWindowCount " +
                                "offset=${audioPtsOffsetUs / 1000}ms")
                        avDriftAccumUs = 0L
                        avDriftWindowCount = 0
                    } else if (kotlin.math.abs(avDriftAccumUs) < 50_000L) {
                        // 滞回清零:只有累积真的回到 50ms 内才算"漂移已消失"。
                        avDriftAccumUs = 0L
                        avDriftWindowCount = 0
                    }
                    // v6.7.149 (FIX-C): 加实际修正动作(不只打日志)——视频轨 PTS 领先音频超过阈值时
                    // 置位 avSyncDropActive。v6.7.157 (P0-1): 不再删帧(删 P 帧破坏参考链致花屏),
                    // 仅置位作"容忍日志"开关。录屏场景几十~150ms 音画偏移不可察觉,花屏才是灾难。
                    // 仅处理"视频领先"(avDeltaUs>0):音频领先的负漂移本就由音频静音/锚定承载。
                    if (avDeltaUs > 300_000L) {
                        if (!avSyncDropActive) {
                            avSyncDropActive = true
                            logDetail("av_sync_drop",
                                "enabled av_delta_us=$avDeltaUs video-leads-audio (tolerate, no frame drop)")
                        }
                    } else if (avDeltaUs < 80_000L) {
                        if (avSyncDropActive) {
                            avSyncDropActive = false
                            logDetail("av_sync_drop",
                                "disabled av_delta_us=$avDeltaUs tolerated=$avSyncDropCount")
                        }
                    }
                }
                lastAvDeltaUs = avDeltaUs
                lastHealthWallMs = nowMs

                // —— 日志强化: C层热/CPU 采样(约1s,独立于帧循环) ——
                // v6.7.95: 移除 cap_avg/enc_avg/mux_avg 三个失效指标——
                // cap_avg 统计的是音频阻塞读却按视频帧数平均(恒等于 1000/fps 同义反复),
                // enc_avg 单位错恒为 0,唯一真实的混流耗时由 wall2muxer_max 反映。
                // 相关累计器 statCaptureNs/statEncoderNs/statMuxerNs/statFramesAcc 已一并删除。
                val zr = statZeroReads.get()
                val rs = statResets.get()
                val gu = statGiveUp.get()
                val ae = audioReadErrorCount.get()
                if (zr > 0 || rs > 0 || gu > 0 || ae > 0) {
                    logDetail("audio_stat", "zeroReads=$zr resets=$rs giveUp=$gu readErrors=$ae")
                }
                // C层: 温度/CPU 频率采样(读 sysfs,约1s一次,失败静默)
                if (nowMs - lastThermalSampleMs >= 1000L) {
                    lastThermalSampleMs = nowMs
                    val curFreqHz = readCpuFreqKHz(0)
                    val maxFreqHz = readCpuMaxFreqKHz(0)
                    // v6.7.189 (P1-5): 采样只在此处发生一次;判定只读中位数。
                    sampleThermalTempC()
                    val tempC = thermalTempC()
                    thermalSampleCount.incrementAndGet()
                    if (curFreqHz > 0) thermalSampledCurMs.set(curFreqHz)
                    if (maxFreqHz > 0) thermalSampledMaxMs.set(maxFreqHz)
                    // v6.7.57: thermal 无效值掩码——GLA-AL00 等机型无对应 sysfs 节点会读到 -274C
                    // 等异常值,属无害,输出 NA 避免误判设备过热。合理温度窗口 [-10, 120] 之外置 NA。
                    val tempDisplay = if (tempC in -10..120) "$tempC" else "NA($tempC)"
                    logDetail("thermal", "cpu0=${curFreqHz}kHz/max=${maxFreqHz}kHz temp=${tempDisplay}C " +
                        "samples=${thermalSampleCount.get()} " +
                        "median=${tempC}C ring=${thermalRing.size} spikeRejected=$thermalSpikeRejected")
                }
                // 降档触发/步进检测(复用热采样约 1s 窗口;maybeStepDowngrade 内部 5s 步进节流)
                maybeStepDowngrade()
                // v6.7.188h (改造1): boost 周期重估,与 5s health 周期同源,零新增定时器。
                applyBoostPeriodic(nowMs)

                // v6.7.90 (A-7): 采样间隔从 10 分钟降到 30 秒。
                // 旧值 600s 在短录制里只能打一次,无法判断 fd/threads 是否随时间增长(泄漏)。
                // 30s 周期 + stop 时一次,两次相减即可看增量。
                if (nowMs - lastLeakSampleMs >= 30_000L) {
                    lastLeakSampleMs = nowMs
                    logResourceFootprint()
                }
            } catch (e: Throwable) {
                logDetail("health", "monitor error: ${e.message}")
            }
    }

    // 每 10 分钟采样点运行时状态(/状态)
    @Volatile private var lastLeakSampleMs = 0L

    // v6.7.183: health 诊断串采样时刻(5s 周期,见 reportProgress)。
    @Volatile private var lastHealthSampleMs = 0L

    /** v6.7.45 层级二: 输出堆/RSS/fd/线程快照,用于长时间录制的资源泄漏回归。
     * fd 与线程数反映句柄/线程是否随录制单调爬升;堆内存反映无界增长。
     * 该打点仅记录,不做任何干预(对齐 AZ 不运行时降级)。 */
    private fun logResourceFootprint() {
        try {
            val rt = Runtime.getRuntime()
            val usedMb = (rt.totalMemory() - rt.freeMemory()) / 1024 / 1024
            val totalMb = rt.totalMemory() / 1024 / 1024
            val maxMb = rt.maxMemory() / 1024 / 1024
            val fdCount = try {
                java.io.File("/proc/self/fd").list()?.size ?: -1
            } catch (_: Throwable) { -1 }
            val threadCount = try {
                val t = Thread.getAllStackTraces()
                t.size
            } catch (_: Throwable) { -1 }
            val rssMb = try {
                val lines = java.io.File("/proc/self/status").readLines()
                var rss = -1L
                for (l in lines) {
                    if (l.startsWith("VmRSS:")) {
                        rss = l.substringAfter(":").trim().substringBefore("kB").trim().toLongOrNull() ?: -1L
                    }
                }
                if (rss > 0) rss / 1024 else -1L
            } catch (_: Throwable) { -1L }
            logDetail("resource_footprint", "heap_used=${usedMb}MB total=${totalMb}MB max=${maxMb}MB " +
                "rss=${rssMb}MB fd=$fdCount threads=$threadCount elapsedSec=${SystemClock.elapsedRealtime() / 1000}")
        } catch (e: Throwable) {
            logDetail("resource_footprint", "sample error: ${e.message}")
        }
    }

    /**
     * 基于实际 PTS 间隔检测持续掉帧。
     * Surface 输入模式下编码器吞吐不足时 input surface 自动丢帧，
     * dequeue 不阻塞导致 tryAgain 降级永不触发，此处用帧间隔窗口主动识别并降级，
     * 使视频时间轴贴近音频时间轴，缓解音画不匹配。
     */
    // —— 日志强化 C层: 热/CPU 采样辅助(sysfs 只读,失败静默返回 0) ——
    private fun readCpuFreqKHz(cpu: Int): Long {
        return try {
            val f = java.io.File("/sys/devices/system/cpu/cpu$cpu/cpufreq/scaling_cur_freq")
            if (f.exists()) f.readText().trim().toLong() / 1000L else 0L
        } catch (_: Throwable) { 0L }
    }
    private fun readCpuMaxFreqKHz(cpu: Int): Long {
        return try {
            val f = java.io.File("/sys/devices/system/cpu/cpu$cpu/cpufreq/cpuinfo_max_freq")
            if (f.exists()) f.readText().trim().toLong() / 1000L else 0L
        } catch (_: Throwable) { 0L }
    }
    /** v6.7.151 (缺陷A): 读 SoC 温度(°C),取所有 thermal_zone 的最大值。
     *  原实现写死 thermal_zone0/temp 且固定 /1000——zone 编号与硬件无关,0 号在多数机型是
     *  电池/GPU/环境温区甚至恒 0,且内核单位不统一(毫摄氏度 40000=40℃ vs 0.1℃ 400=40℃),
     *  直接 /1000 在后者得 0.4℃,tempValid(1..120) 排除后 overheat 恒 false,热降档成摆设。
     *  修复:遍历 /sys/class/thermal 下所有 thermal_zoneN,按 type 偏好 cpu/soc/aoc/gpu
     *  等主芯片温区,取全部可读温区的最大值(对过热判定最保守),并按数值幅度归一单位。
     *  ponytail: 单位归一是幅度启发式,已知天花板——个别厂商导出仍可能越界,但"多区取最大
     *  + 幅度归一"覆盖绝大多数真机,远优于单 zone0。读失败静默返回 0(不参与判定)。 */
    /** v6.7.189 (P1-5): 纯读取:取所有 thermal_zone 的最大温度(毫摄氏度归一),不写缓冲。
     *  采样与判定分离——health 打点 1s 采样一次,判定只读中位数,绝不就地 raw 读一次就决策。 */
    private fun readThermalZoneMaxC(): Int {
        return try {
            val dir = java.io.File("/sys/class/thermal")
            val zones = dir.listFiles { f -> f.name.startsWith("thermal_zone") } ?: return 0
            var maxC = 0
            for (z in zones) {
                val t = try { File(z, "temp").readText().trim() } catch (_: Throwable) { continue }
                val raw = t.toLongOrNull() ?: continue
                if (raw <= 0) continue
                // 单位归一:毫摄氏度(>1000,如 42000)、0.1℃(200..1000,如 420)、其余按毫摄氏度
                val c = when {
                    raw > 1000 -> (raw / 1000).toInt()
                    raw > 200  -> (raw / 10).toInt()
                    else       -> 0   // 过小视为无效(可能是 0.001℃ 或其他单位)
                }
                if (c > maxC) maxC = c
            }
            maxC
        } catch (_: Throwable) { 0 }
    }

    /** v6.7.189 (P1-5): 采样,每 1s 由 health 打点调用一次。
     *  尖峰(与当前中位数差 >15℃)直接丢弃。 */
    private fun sampleThermalTempC() {
        val raw = readThermalZoneMaxC()
        if (raw !in 1..120) return
        if (thermalRing.size >= 3) {
            val med = thermalRing.sorted()[thermalRing.size / 2]
            if (kotlin.math.abs(raw - med) > THERMAL_SPIKE_C) { thermalSpikeRejected++; return }
        }
        thermalRing.addLast(raw)
        if (thermalRing.size > THERMAL_MEDIAN_N) thermalRing.removeFirst()
    }

    /** v6.7.189 (P1-5): 判定用:只读最近 N 次采样的中位数,不采样。缓冲为空返回 0(视为无效)。 */
    private fun thermalTempC(): Int {
        if (thermalRing.isEmpty()) return 0
        val s = thermalRing.sorted()
        return s[s.size / 2]
    }

    /** 电量百分比(0..100);-1 = 读取失败(不参与降档判定) */
    private fun readBatteryPercent(): Int {
        return try {
            val intent = context.registerReceiver(null, IntentFilter(Intent.ACTION_BATTERY_CHANGED)) ?: return -1
            val level = intent.getIntExtra(BatteryManager.EXTRA_LEVEL, -1)
            val scale = intent.getIntExtra(BatteryManager.EXTRA_SCALE, -1)
            if (level < 0 || scale <= 0) -1 else (level * 100 / scale).coerceIn(0, 100)
        } catch (_: Throwable) { -1 }
    }

    /** 周期降档判定(health loop 约 1s 调用一次)。
      *  触发器: 电量<20% 或 温度相对基线 +THERMAL_OVER_BASELINE(6℃) 进入降档态;
      *          基线取前若干次有效读数的中位数(首读即确立),基线未确立时 overheat=false(开局不误降档);
      *          回弹须温度 ≤ baseline+THERMAL_RECOVER_OVER_BASE(2℃) 且 电量>30(防阈值边缘反复横跳)。
      *  一级: 每 5s 渐进降/升一档 20%,floor = userBitrate/4 与 4M 取高,回弹目标 = 用户设定码率。
      *  失败锁死: 回弹后 30s 内再次触发降档 → 本次录制锁死降档档位、不再回弹(防震荡最终兜底)。
      *  稳定观察期: 温度/电量回到安全须持续 10s 才回弹(防阈值边缘抖动反复横跳)。
      *  ponytail: 降码率用 setParameters 热改(与 requestKeyFrame 同 API),不重建 encoder。 */
    private fun maybeStepDowngrade() {
        val nowMs = SystemClock.elapsedRealtime()
        if (nowMs - lastDowngradeCheckMs < 1000L) return
        lastDowngradeCheckMs = nowMs
        val battery = readBatteryPercent()
        // v6.7.189 (P1-5): 判定只读中位数,绝不就地采样。
        val tempC = thermalTempC()
        val tempValid = tempC in 1..120
        // v6.7.157 (修B2): 相对基线拟合。首 N 次有效读数中位数作 baseline(此期间先按绝对阈值
        // 保守降档),之后 overheat/recover 都相对 baseline 判定。常态 50-53℃ 被当 baseline,
        // 不再误报;升到 81℃ 这类异常尖峰仍 +6℃ 命中。
        val overheat: Boolean
        if (tempValid) {
            // v6.7.157 (改动4): baseline 首读即确立,不再等 5 次收敛也不再用绝对阈值兜底。
            // 原实现开局前 5 秒用 THERMAL_DOWNGRADE_C=50 兜底,本机起步 53C > 50 会误触发降档,
            // 之后基线收敛才恢复——开局白挨一刀。首读 53 即 baseline(用中位数防首次尖峰),
            // 之后 59 才算过热;81C 尖峰仍命中,开局不再误降档。
            if (thermalBaselineSamples.size < THERMAL_BASELINE_SAMPLES) {
                thermalBaselineSamples.add(tempC)
                if (thermalBaselineSamples.size == THERMAL_BASELINE_SAMPLES) {
                    thermalBaselineC = sanitizeBaseline(
                        thermalBaselineSamples.sorted()[THERMAL_BASELINE_SAMPLES / 2])
                } else if (thermalBaselineSamples.size >= 2 && thermalBaselineC <= 0) {
                    thermalBaselineC = sanitizeBaseline(
                        thermalBaselineSamples.sorted()[thermalBaselineSamples.size / 2])
                }
                overheat = thermalBaselineC > 0 && tempC >= thermalBaselineC + THERMAL_OVER_BASELINE
            } else {
                // v6.7.188h (改造5): 采样收敛后基线带钳制地缓慢自适应。
                // 只在"未过热"时小幅微调,每 30s 最多动 1℃,总幅度限 ±8℃;
                // 机身预热后基线能跟上真实环境,避免开局偏热导致保护失效。
                if (thermalBaselineC > 0 && tempC < thermalBaselineC + THERMAL_OVER_BASELINE) {
                    maybeAdaptBaseline(tempC, nowMs)
                }
                overheat = thermalBaselineC > 0 && tempC >= thermalBaselineC + THERMAL_OVER_BASELINE
            }
        } else {
            overheat = false
        }
        val lowBattery = battery in 0..100 && battery < 20
        // v6.7.188h (改造2): 区分"电源策略"与"真实性能压力"。省电模式在部分 ROM 常驻为真,
        // 作为硬阻断会导致降档后永不回弹。改为独立标记 + 单独浅降策略。
        // 用户可在设置中关闭"省电模式影响码率"(默认开启,保持既有行为)。
        val pm = context.getSystemService(Context.POWER_SERVICE) as? PowerManager
        val powerSaveRaw = pm?.isPowerSaveMode == true
        val deviceIdle = pm?.isDeviceIdleMode == true
        val powerSave = (powerSaveRaw || deviceIdle) &&
            PreferencesManager(context).isAllowPowerSaveDowngrade()
        // v6.7.140 (方案2): 实测掉帧触发降档——复用现有 maybeStepDowngrade 状态机，
        // 只增加"进入降档态"的触发源，降档态内降码率+丢帧、回升、锁死逻辑全部复用。
        // v6.7.149 (FIX-C/D): FIX-C 的 AV 同步主动丢帧会让 runtimeDropWindowFps 骤降,
        // 那是有意的 PTS 对齐丢帧,非热/电/性能压力,不应计入 frameDrop 触发降档(误降码率)。
        // v6.7.190 (P0-3): 单窗口不定罪。窗口 fps 由 1s 节流的 reportProgress 驱动,
        // 一次 capture_stall(实测 1012ms 空洞)恰落在窗口起点时,该窗口只有个位数 dSeq,
        // 得到假的超低 fps 并立即把码率砍 19%(实测 80M→72M→64.8M,同段还报 VIDEO_OVERSPEED)。
        // 改为"连续 3 个可信窗口都低于 70% 目标"才认定;windowLow 断链即清零 streak。
        val windowLow = runtimeDropWindowFps > 0 && targetFps > 0 &&
            runtimeDropWindowFps < targetFps * 0.7
        frameDropWindowStreak = if (windowLow) frameDropWindowStreak + 1 else 0
        val frameDrop = frameDropWindowStreak >= 3 && !avSyncDropActive
        // v6.7.188h (改造2): 真·压力(过热/低电/严重掉帧)走完整降档链 + 严格回弹;
        // 省电模式单独走"浅降 1 档",不作为回弹阻断项。
        val hardPressure = overheat || lowBattery || frameDrop
        val softPressure = powerSave && !hardPressure
        val shouldDowngrade = hardPressure || softPressure
        // v6.7.149 (FIX-D): 回升判定补掉帧缓解闸——除温度/电量回弹外,还须当前掉帧已回到
        // 目标帧率 90% 以上(实际产出不再大幅掉帧)才允许渐升码率。防此前仅因 frameDrop 触发
        // 降档、码率降下后掉帧刚缓解即 10s 回升、随后再度掉帧的反复横跳。
        val frameEased = !(frameDrop && runtimeDropWindowFps > 0 && targetFps > 0 &&
            runtimeDropWindowFps < targetFps * 0.9)
        // 回弹条件:温度回到基线附近(且不超过热线)且 电量>30 且 省电/闲置已解除(且当前不超降档线,且掉帧已缓解)
        // v6.7.188h (改造2): 回弹不再被 powerSave 硬阻断 —— 只要"当前没有真实压力"且掉帧已
        // 缓解,就允许回升。省电模式下的浅降由 softPressure 单独控制,不与回弹打架。
        val recoverEnough = (!overheat) && (!lowBattery) && frameEased &&
            (if (tempValid) (thermalBaselineC <= 0 || tempC <= thermalBaselineC + THERMAL_RECOVER_OVER_BASE) else true) &&
            (battery !in 0..100 || battery >= 30)

        // ---- 进入降档态 ----
        if (shouldDowngrade) {
            recoverCandidateStartMs = 0L // 重新降档则清除回升稳定观察窗口
            if (!downgradeActive) {
                downgradeActive = true
                softDowngradeSteps = 0   // v6.7.188h (改造2): 进入降档态时复位浅降计数
                // v6.7.128: 记录首次降档时刻(录制相对) + 初始码率
                downgradeFirstAtMs = SystemClock.elapsedRealtime() - startTimeNs / 1_000_000L
                if (downgradeMinBitrate <= 0L) downgradeMinBitrate = targetBitrate.toLong()
                // 失败锁死:回弹后 RUN_LATCH_MS 内再次过热/低电 → 锁死档位,本次录制不再回弹
                if (lastRampUpAtMs > 0 && nowMs - lastRampUpAtMs < RUN_LATCH_MS) {
                    downgradeLatched = true
                    // v6.7.189 (P1-6): reason 反映真实判定条件,不再硬编码 THERMAL_DOWNGRADE_C。
                    val reason = when {
                        overheat   -> "overheat(temp>=baseline+$THERMAL_OVER_BASELINE,base=${thermalBaselineC})"
                        lowBattery -> "battery<20(actual=$battery)"
                        powerSave  -> "power_save"
                        else       -> "runtime_frame_drop"
                    }
                    logHealth("downgrade",
                        "enter_after_rampup battery=$battery temp=${tempC}C latch=LOCKED " +
                        "floor=${prepareFloor()} reason=$reason " +
                        "recover_needs=temp<=base+${THERMAL_RECOVER_OVER_BASE}&&battery>=30 for 10s")
                } else {
                    val reason = when {
                        overheat   -> "overheat(temp>=baseline+$THERMAL_OVER_BASELINE,base=${thermalBaselineC})"
                        lowBattery -> "battery<20(actual=$battery)"
                        powerSave  -> "power_save"
                        else       -> "runtime_frame_drop"
                    }
                    logHealth("downgrade",
                        "enter battery=$battery temp=${tempC}C bitrate=${targetBitrate} " +
                        "floor=${prepareFloor()} reason=$reason " +
                        "latched=false recover_needs=temp<=base+${THERMAL_RECOVER_OVER_BASE}&&battery>=30 for 10s")
                }
            }
        }

        if (!downgradeActive) return
        if (downgradeLatched) {
            // 锁死态:只允许继续降/保持 floor(当温度仍降?),不允许回弹。若未到 floor 可继续降。
            val floor = prepareFloor()
            if (targetBitrate > floor && downgradeSteps < MAX_DOWNGRADE_STEPS && nowMs - lastBitrateStepMs >= 5000L) {
                lastBitrateStepMs = nowMs
                val nextBr = (targetBitrate * DOWNGRADE_MUL_NUM / DOWNGRADE_MUL_DEN).coerceAtLeast(floor)
                // v6.7.149 (FIX-E): 先留旧值再 setEncoderBitrate(该调用会改写 targetBitrate),
                // 否则日志打印的"旧值"实为改写后的下档值,恒"阶梯->自身"丢失真实降档信息。
                val oldBr = targetBitrate
                setEncoderBitrate(nextBr)
                if (nextBr < downgradeMinBitrate) downgradeMinBitrate = nextBr.toLong()
                downgradeSteps++
                logHealth("downgrade", "latched bitrate $oldBr -> ${nextBr} floor=$floor steps=$downgradeSteps/$MAX_DOWNGRADE_STEPS")
            }
            return
        }

        // ---- 降档(仍过热/低电,非锁死) ----
        // v6.7.188h (改造2): hardPressure 每次 -10%(既有 DOWNGRADE_MUL 9/10);
        // softPressure(纯省电)同样每档 -10%,但最多浅降 SOFT_MAX_DOWNGRADE_STEPS 档。
        if (shouldDowngrade) {
            val floor = prepareFloor()
            val stepNum = if (hardPressure) DOWNGRADE_MUL_NUM else SOFT_DOWNGRADE_NUM
            val stepDen = if (hardPressure) DOWNGRADE_MUL_DEN else SOFT_DOWNGRADE_DEN
            val softAllowed = hardPressure || softDowngradeSteps < SOFT_MAX_DOWNGRADE_STEPS
            if (targetBitrate > floor && downgradeSteps < MAX_DOWNGRADE_STEPS &&
                softAllowed && nowMs - lastBitrateStepMs >= 5000L) {
                lastBitrateStepMs = nowMs
                val nextBr = (targetBitrate * stepNum / stepDen).coerceAtLeast(floor)
                // v6.7.149 (FIX-E): 同 latched 分支,先留旧值再改。
                val oldBr = targetBitrate
                setEncoderBitrate(nextBr)
                if (nextBr < downgradeMinBitrate) downgradeMinBitrate = nextBr.toLong()
                downgradeSteps++
                if (softPressure && !hardPressure) softDowngradeSteps++
                logHealth("downgrade",
                    "bitrate $oldBr -> ${nextBr} floor=$floor steps=$downgradeSteps/$MAX_DOWNGRADE_STEPS " +
                    "hard=$hardPressure soft=$softPressure reason=${downgradeReason(overheat, lowBattery, powerSave, frameDrop)}")
            }
            recoverCandidateStartMs = 0L
            return
        }

        // ---- 回升 ----
        if (!shouldDowngrade && recoverEnough) {
            if (recoverCandidateStartMs == 0L) {
                recoverCandidateStartMs = nowMs
            } else if (nowMs - recoverCandidateStartMs >= RECOVER_STABLE_MS) {
                // 稳定期达标,渐升回用户设定码率
                val goal = userBitrate
                if (targetBitrate < goal) {
                    if (nowMs - lastBitrateStepMs >= 5000L) {
                        lastBitrateStepMs = nowMs
                        val up = (targetBitrate * 5 / 4).coerceAtMost(goal)
                        // v6.7.149 (FIX-E): 先留旧值再改,恢复 rampup 真实两档日志。
                        val oldBr = targetBitrate
                        setEncoderBitrate(up)
                        if (up >= goal) {
                            lastRampUpAtMs = nowMs // 记录回弹至顶时刻,供失败锁死判定
                            downgradeActive = false
                            recoverCandidateStartMs = 0L
                            logHealth("downgrade", "recovered battery=$battery temp=${tempC}C -> $goal")
                        } else {
                            logHealth("downgrade", "rampup $oldBr -> $up goal=$goal")
                        }
                    }
                } else {
                    // 已是目标码率:解除降档态
                    lastRampUpAtMs = nowMs
                    downgradeActive = false
                    recoverCandidateStartMs = 0L
                    logHealth("downgrade", "recovered battery=$battery temp=${tempC}C")
                }
            }
        } else {
            recoverCandidateStartMs = 0L // 条件中断,重计稳定期
        }
    }

    /** 降档最低档位 = 用户设定码率的 1/4 与固定最低 4M 取高 */
    private fun prepareFloor(): Int {
        return kotlin.math.max(userBitrate / 4, MIN_DOWNGRADE_BITRATE)
    }

    // v6.7.188h (改造5): 物理不合理的基线直接回退常量,防传感器标定异常导致保护永久失效。
    // v6.7.190 (P1-5): 与 maybeAdaptBaseline 的自适应区间统一。旧实现只按物理上限(65℃)放行,
    // 允许 62℃ 这类值落盘,而自适应上限只有 61℃ —— 读回后被静默钳制,两处口径不一致。
    private fun sanitizeBaseline(raw: Int): Int {
        if (raw <= 0 || raw > BASELINE_PHYSICAL_MAX_C) return BASELINE_FALLBACK_C
        return raw.coerceIn(
            BASELINE_FALLBACK_C - BASELINE_ADAPT_RANGE_C,
            BASELINE_FALLBACK_C + BASELINE_ADAPT_RANGE_C * 2
        )
    }

    // v6.7.188h (改造5): 基线自适应。规则刻意保守 —— 只做小幅、低频、双向钳制的修正,
    // 绝不因一次读数就漂移(防"阈值边缘反复横跳",该问题已用 10s 稳定观察期解决)。
    // 调用方保证仅在未过热时调用(过热态下基线不动,防保护期间基线被抬升)。
    private var lastBaselineAdaptMs = 0L
    private fun maybeAdaptBaseline(tempC: Int, nowMs: Long) {
        if (tempC !in 1..120) return
        if (nowMs - lastBaselineAdaptMs < BASELINE_ADAPT_INTERVAL_MS) return
        lastBaselineAdaptMs = nowMs
        val lowerBound = BASELINE_FALLBACK_C - BASELINE_ADAPT_RANGE_C
        val upperBound = BASELINE_FALLBACK_C + BASELINE_ADAPT_RANGE_C * 2
        when {
            // 记录温度明显更低:真实环境更凉,基线下修(受下限钳制)
            tempC < thermalBaselineC - 1 && thermalBaselineC > lowerBound ->
                thermalBaselineC -= 1
            // 记录温度略高但未过热:缓慢上修,跟随设备预热(受上限钳制)
            tempC > thermalBaselineC && tempC < thermalBaselineC + THERMAL_OVER_BASELINE - 1 &&
                thermalBaselineC < upperBound ->
                thermalBaselineC += 1
        }
        // v6.7.189 (P1-6): 真正对 baseline 施加钳制。此前 bounds 只用于 when 的进入条件,
        // 打印出的区间与生效值无关,是典型的"日志说谎"(实测 baseline=84 而 bounds 打印 [37..61])。
        val before = thermalBaselineC
        thermalBaselineC = thermalBaselineC.coerceIn(lowerBound, upperBound)
        logDetail("thermal_baseline",
            "baseline=${thermalBaselineC}C temp=${tempC}C clamped=[$lowerBound..$upperBound]" +
                (if (before != thermalBaselineC) " (raw=$before)" else ""))
    }

    // v6.7.188h (改造2): 省电模式降档原因结构化分类(借鉴 B 的错误码状态机思想)。
    private fun downgradeReason(o: Boolean, b: Boolean, p: Boolean, f: Boolean): String = when {
        o -> "overheat"
        b -> "low_battery"
        f -> "runtime_frame_drop"
        p -> "power_save_shallow"
        else -> "unknown"
    }

    private fun setEncoderBitrate(br: Int) {
        targetBitrate = br
        currentBitrate = br
        try {
            val enc = videoEncoder ?: return
            val b = android.os.Bundle()
            b.putInt(MediaCodec.PARAMETER_KEY_VIDEO_BITRATE, br)
            enc.setParameters(b)
        } catch (_: Throwable) {}
    }

    /** v6.7.188h (改造1): 按当前真实采集帧率周期重估 boost 系数。
     *  由既有的 5s health 周期调用(与 maybeStepDowngrade 同源,零新增定时器)。
     *  滞后区间:系数变化需超过 ±15% 才生效,避免帧率抖动导致码率频繁跳变。 */
    private fun applyBoostPeriodic(nowMs: Long) {
        if (boostBaseBitrate <= 0) return
        if (nowMs - lastBoostEvalMs < BOOST_EVAL_INTERVAL_MS) return
        lastBoostEvalMs = nowMs
        // 降档态中不做 boost 重估,避免与降档链互相打架(降档优先)
        if (downgradeActive) return
        val cfg = config ?: return
        // v6.7.189 (P0-3): 单一真值源。
        //   denom  = 实际生效目标帧率(targetFps,已按 learn 封顶),不是 cfg.fps(用户请求值)
        //   liveFps= 实测产出帧率;窗口未就绪时退到 targetFps(而非屏幕刷新率)
        // 屏幕刷新率与编码帧率无关,禁止出现在任何码率计算里。
        val denom = if (targetFps > 0) targetFps else cfg.fps
        if (denom <= 0) return
        val liveFps = when {
            runtimeDropWindowFps > 0 -> runtimeDropWindowFps.toDouble()
            targetFps > 0            -> targetFps.toDouble()
            else                     -> cfg.fps.toDouble()
        }.coerceIn(1.0, 240.0)
        // 上限从 2.5 收到 1.5:本仓不追求"刷新率对齐",只补回被摊薄的每帧比特
        val target = (liveFps / denom.toDouble()).coerceIn(1.0, BOOST_FACTOR_MAX)
        val delta = kotlin.math.abs(target - currentBoostFactor) / currentBoostFactor
        if (delta < BOOST_HYSTERESIS) return          // 滞后区间内不动
        currentBoostFactor = target
        applyBoost(target, "periodic live=${"%.1f".format(liveFps)} denom=$denom")
    }

    /** v6.7.188h (改造1): 把系数落到编码器;始终以 boostBaseBitrate 为基数,杜绝系数连乘漂移。 */
    private fun applyBoost(factor: Double, tag: String) {
        if (boostBaseBitrate <= 0) return
        // v6.7.191 (P0-7): boost 不得越过降档地板。降档发生在过热/掉帧后,地板是"系统实际还能吃多少"
        // 的实测下限;boost 若把它顶回去,等于刚降完档又立刻撞回同一个热墙,触发降级→回升→再降级的震荡。
        // 此前只有 applyBoostPeriodic 入口有 downgradeActive 守卫,startup 路径与直接调用点都不受保护。
        // 把约束下沉到 applyBoost 本身,所有调用点一次性覆盖。降档地板本身不变:回弹后仍按地板回退。
        val downgradeFloor = downgradeMinBitrate
        if (downgradeActive && downgradeFloor > 0L) {
            logDetail("boost_skip_floor",
                "$tag factor=${"%.2f".format(factor)} boostBase=$boostBaseBitrate floor=$downgradeFloor")
            return
        }
        val target = (boostBaseBitrate.toLong() * factor)
            .coerceAtLeast(1_000_000.0).toLong().toInt()
            .coerceAtMost(USER_BITRATE_HARD_CAP)
        if (target == targetBitrate) return
        val old = targetBitrate
        setEncoderBitrate(target)
        if (downgradeMinBitrate > 0L && target < downgradeMinBitrate) {
            downgradeMinBitrate = target.toLong()
        }
        logDetail("bitrate_boost",
            "$tag factor=${"%.2f".format(factor)} bitrate $old -> $target base=$boostBaseBitrate " +
                "targetFps=$targetFps liveFps=${"%.1f".format(if (runtimeDropWindowFps > 0) runtimeDropWindowFps.toDouble() else targetFps.toDouble())}")
    }

    private fun checkFrameRateHealth() {
        if (healthWindowCount.get() < 15) {
            healthWindowSumUs.set(0)
            healthWindowCount.set(0)
            return
        }
        val avgIntervalUs = healthWindowSumUs.get() / healthWindowCount.get()
        val targetIntervalUs = 1_000_000L / targetFps
        healthWindowSumUs.set(0)
        healthWindowCount.set(0)
        val now = SystemClock.elapsedRealtimeNanos()

        if (avgIntervalUs > targetIntervalUs * 6 / 5) {
            // 持续掉帧：仅打日志，不在录制中降帧率。
            // 原因（v6.7.154 明确）：MediaCodec 帧率是 configure 时定死的，setParameters 热改
            // 不可靠；要真正换帧率必须重建 encoder + inputSurface + VD setSurface 到新面 +
            // muxer 用新 format 重新 addTrack（KEY_FRAME_RATE 变了旧 format 不能复用）。而
            // switchSegment 只碰 muxer 不碰 encoder（注释明确「编码器不重启」），且当前 output
            // buffer 正被 handleVideoOutput 处理，重建要在 releaseOutputBuffer 之后，那意味着
            // 触发「双切段」。更关键：Mp4Repairer.mergeSegments 假设所有分片同 fps/codec/csd
            // （只取首片头算全局 frameDurUs，用单一 RepairSpec buildMoov），任一中间片改帧率
            // 会让合并产物后半段播放速度错、音画错位——比不降更糟。
            // 降帧收益已由 performPixelThroughputCheck 的启动预降覆盖（1280x2800 -> 50fps）。
            // 录制中热降帧留到能同时改 mergeSegments 做异构检测的独立版本。
            logDetail(
                "adaptive",
                "frame rate below target: avgInterval=${avgIntervalUs}us target=${targetIntervalUs}us, " +
                    "fps=$targetFps bitrate=$targetBitrate (no runtime fps change; see v6.7.154 note)"
            )
        }
        // 中等区间（稳定或略偏）：AZ 无录制中回升，仅打日志
    }

    /**
     * 当负载稳定时自动回升一档帧率/码率，避免长时间停留在低档。
     * 优先回升码率(对吞吐影响小)，再回升帧率。返回是否发生了回升。
     */
    private fun alignToEven(value: Int): Int {
        return if (value % 2 == 0) value else value + 1
    }

private fun logDetail(tag: String, message: String) {
        DiagLog.log("[${Thread.currentThread().name}] $tag $message")
    }

    // v6.7.128 L1: 帧级诊断(高频),只写内存环形缓冲不落盘,零 IO。供 handleVideoOutput
    // 等逐帧/高频调用使用;需要落盘证据的走 logDetail 或 logHealth。
    private fun logDetailL1(tag: String, message: String) {
        DiagLog.logFrameDiag(tag, message)
    }

    // v6.7.128 L2: 周期健康快照(每 5s 一次,低频),实时落盘。供降档触发/回弹、
    // 分辨率生效/帧率证据等 needs-proof 的场景。
    @PublishedApi
    internal fun logHealth(tag: String, message: String) {
        DiagLog.logEvent(tag, message)
    }

    private fun logSection(title: String) {
        val separator = "══════════════════════════════════════════════════"
        Log.d(TAG, "$separator")
        Log.d(TAG, "  $title")
        Log.d(TAG, "$separator")
        logSink?.invoke("$separator\n  $title\n$separator")
    }

    /**
     * 录制开始时的环境快照：设备型号/Android版本、内存、省电模式、
     * 是否为前台录制。便于事后复现偶发降帧/卡顿。
     */
    // v6.7.47: 移除音频焦点抢占(registerAudioFocus/unregisterAudioFocus 两方法整体删除)。
    // 依据: AZ 6.9.10 反编译全 dex 扫描,录屏主类 Lfg 及内录/音频链路无任何
    // requestAudioFocus/abandonAudioFocus(仅在 exoplayer/gms/inmobi 等第三方库出现)。
    // 即 AZ 录屏从不抢焦点,因此永不打断正在播放的音乐/视频。
    // 原实现 requestAudioFocus(AUDIOFOCUS_GAIN) 会强制当前持有焦点的播放器失去焦点,
    // 导致开始录屏瞬间音乐/视频被暂停——这是"开始录屏打断媒体"的唯一根因。
    // 内录 AudioRecord 用 addMatchingUsage(MEDIA/GAME/UNKNOWN) 捕获系统混音输出,
    // 不依赖音频焦点机制,删除后录屏音频采集不受影响。
    // 原 LOSS/GAIN 分支的"停/拉回 AudioRecord"副作用由 v6.7.44 的 AudioRecordingCallback
    // + 探测自愈链路(检测非零 PCM 自动 resume)完全覆盖,故一并移除。

    // v6.7.183: 节流门。上轮检查时刻 + 上轮余量是否已低于紧急线。
    // StatFs 是系统调用,正常录制磁盘余量几乎不变,每 1s 查一次是无谓开销;
    // 但余量逼近 MIN_FREE_SPACE_BYTES 时必须保持 1s 灵敏度,磁盘满止损不能退化为 5s 延迟。
    private var lastFreeSpaceCheckMs = 0L
    private var lastFreeBelowMin = false
    private fun checkFreeSpace() {
        val nowMs = SystemClock.elapsedRealtime()
        // ponytail: 二档节流(健康 5s / 逼近满 1s),不是精确余量预测;真机若个别 OEM
        // 磁盘满时仍偶发晚 4s 止损,再改为按 lastFreeBytes 变化量触发。
        if (lastFreeBelowMin || nowMs - lastFreeSpaceCheckMs >= 5000) {
            lastFreeSpaceCheckMs = nowMs
            doCheckFreeSpace()
        }
    }

    private fun doCheckFreeSpace() {
        try {
            val dir = outputFile?.parentFile ?: return
            val stat = StatFs(dir.absolutePath)
            val free = stat.availableBlocksLong * stat.blockSizeLong
            if (lastFreeBytes > 0 && free < MIN_FREE_SPACE_BYTES) {
                logDetail("disk_full", "free=$free bytes < $MIN_FREE_SPACE_BYTES, stopping recording")
                callback?.onError(IOException("disk full: ${free} bytes remaining"))
            }
            lastFreeBytes = free
            lastFreeBelowMin = free < MIN_FREE_SPACE_BYTES
            if (free < MIN_FREE_SPACE_BYTES * 2) {
                logDetail("disk_low", "free=$free bytes")
            }
        } catch (e: Exception) {
            logDetail("disk_check_error", "${e.message}")
        }
    }

    // v6.7.105: 4GiB 单文件边界到达时的安全收尾入口。
    // 与磁盘满一致的触发方式:通过 onError 让上层 cleanupAndStop 走完整 finalize,
    // 保证产物是"内容截止在水线附近"的可播放文件,而不是撞 4GiB 后 moov 损坏
    // 仍被 rename 成 .mp4 的坏文件。onError 内部已做幂等,重复触发安全。
    private fun onMuxer4GLimitReached() {
        if (muxer4gTriggered.compareAndSet(false, true)) {
            logDetail("muxer_4g_limit",
                "videoBytesWritten=$videoBytesWritten >= $MUXER_4G_SAFE_LIMIT_MB MiB, stopping recording safely")
            try {
                callback?.onError(IOException("recording reached MP4 4GiB limit (~$MUXER_4G_SAFE_LIMIT_MB MiB), stopping to keep file playable"))
            } catch (_: Exception) {}
        }
    }

    // v6.7.155: 事前容量估算——按当前码率(视频 targetBitrate + 音频 128kbps)估算
    // outputFile 所在分区剩余容量还能录多久(秒)。磁盘满返回 0。供主界面录制前弹窗
    // 展示"预计可录制约 X 小时(剩余 Y GB)",以及 RECORD_SUMMARY 里记录 remainingSec。
    fun estimateRemainingTime(): Long {
        return try {
            val dir = outputFile?.parentFile ?: return 0L
            val stat = StatFs(dir.absolutePath)
            val free = stat.availableBlocksLong * stat.blockSizeLong
            val videoBps = targetBitrate.coerceAtLeast(1)
            val audioBps = AUDIO_BIT_RATE
            val bytesPerSec = videoBps / 8L + audioBps / 8L
            if (bytesPerSec <= 0) 0L else free / bytesPerSec
        } catch (e: Exception) {
            logDetail("estimate_error", "${e.message}")
            0L
        }
    }

    // v6.7.178 (⑤-c): 成品快速哈希。≤200MB 全量;更大文件取首尾各 4MB + 长度盐,
    // 成本 <50ms。只用于日志指纹识别(区分两次同尺寸录制),不做完整性证明。
    private fun sha256Quick(f: java.io.File): String = try {
        val md = java.security.MessageDigest.getInstance("SHA-256")
        val cap = 4L * 1024 * 1024
        java.io.FileInputStream(f).use { ins ->
            val buf = ByteArray(64 * 1024)
            if (f.length() <= 200L * 1024 * 1024) {
                var n = ins.read(buf)
                while (n > 0) { md.update(buf, 0, n); n = ins.read(buf) }
            } else {
                var rem = cap
                while (rem > 0) {
                    val n = ins.read(buf, 0, minOf(rem, buf.size.toLong()).toInt())
                    if (n <= 0) break
                    md.update(buf, 0, n)
                    rem -= n
                }
                // v6.7.184: 原 skip 目标是 L - cap,即末尾 cap 的起点,结果"尾段"和
                // 刚读的头段重复(或头段已读满 cap 时尾段根本不再入哈希),指纹区分度失效。
                // 应为 L - 2*cap:跳过头段之后那 4MB,再读真正的末尾 4MB。
                // InputStream.skip 可能短跳,必须 while 循环按实际返回值扣减。
                var toSkip = f.length() - cap * 2
                while (toSkip > 0) {
                    val s = ins.skip(toSkip)
                    if (s <= 0) break
                    toSkip -= s
                }
                rem = cap
                while (rem > 0) {
                    val n = ins.read(buf, 0, minOf(rem, buf.size.toLong()).toInt())
                    if (n <= 0) break
                    md.update(buf, 0, n)
                    rem -= n
                }
                md.update(f.length().toString().toByteArray())
            }
        }
        md.digest().joinToString("") { "%02x".format(it) }.take(16)
    } catch (_: Exception) { "na" }

    private fun logEnvironmentSnapshot() {
        try {
            val mem = ActivityManager.MemoryInfo()
            (context.getSystemService(Context.ACTIVITY_SERVICE) as? ActivityManager)?.getMemoryInfo(mem)
            val availableMb = mem.availMem / (1024 * 1024)
            val powerManager = context.getSystemService(Context.POWER_SERVICE) as? PowerManager
            val powerSave = powerManager?.isPowerSaveMode == true
            val interactive = powerManager?.isInteractive == true
            logDetail("env", "device=${Build.MANUFACTURER} ${Build.MODEL} sdk=${Build.VERSION.SDK_INT} " +
                "rel=${Build.VERSION.RELEASE} availableMem=${availableMb}MB powerSave=$powerSave interactive=$interactive")
            // v6.7.178 (⑤-a): env2 硬件基准。SOC_MODEL 为 API31+,老设备回落 HARDWARE;
            // 内核串走 os.version(公开属性);fingerprint 只留末段防冗长。
            val soc = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S)
                "${Build.SOC_MANUFACTURER} ${Build.SOC_MODEL}" else Build.HARDWARE
            logDetail("env2", "soc=$soc abi=${Build.SUPPORTED_ABIS.first()} " +
                "kernel=${System.getProperty("os.version")} " +
                "fp=${Build.FINGERPRINT.substringAfterLast('/').take(24)} " +
                "tz=${java.util.TimeZone.getDefault().id}")
            // 显示链路基准:决定缩放/色偏能否归因(120Hz 屏直接解释 capture_fps 偏高)。
            try {
                val disp = (context.getSystemService(Context.DISPLAY_SERVICE) as
                    android.hardware.display.DisplayManager).getDisplay(android.view.Display.DEFAULT_DISPLAY)
                // Display.Mode 无 maxRefreshRate 字段,取 Mode.getRefreshRate()(当前生效模式)
                val hz = disp.mode.refreshRate
                val hdr = disp.hdrCapabilities.supportedHdrTypes
                    ?.joinToString(",") { it.toString() } ?: "none"
                // 宽色域用 isWideColorGamut()(Display 无 supportedColorModes 集合)
                val wide = disp.isWideColorGamut
                // realMetrics 是 @hide,只能用 getRealMetrics(出参)取真实 dpi(含 cutout)
                val dm = android.util.DisplayMetrics()
                @Suppress("DEPRECATION")
                disp.getRealMetrics(dm)
                val dpi = dm.densityDpi
                logDetail("display_caps", "maxHz=${"%.1f".format(hz)} hdr=[$hdr] wide=$wide " +
                    "rot=${disp.rotation * 90}° dpi=$dpi")
            } catch (_: Exception) {}
        } catch (e: Throwable) {
            logDetail("env", "snapshot error: ${e.message}")
        }
    }

    private fun writeEmergencyLog(message: String, throwable: Throwable? = null) {
        try {
            val baseDir = if (outputFilePath.isNotEmpty()) {
                val f = File(outputFilePath)
                f.parentFile ?: File(context.getExternalFilesDir(null), "logs")
            } else {
                File(context.getExternalFilesDir(null), "logs")
            }
            val emergencyDir = File(baseDir, EMERGENCY_DIR_NAME)
            if (!emergencyDir.exists()) {
                emergencyDir.mkdirs()
            }
            val emergencyLog = File(emergencyDir, "emergency_${System.currentTimeMillis()}.log")
            val errorSource = throwable?.let {
                "\nErrorSource:\n${Log.getStackTraceString(it)}"
            } ?: ""
            emergencyLog.appendText(
                """
                === EMERGENCY LOG ===
                Time: ${System.currentTimeMillis()}
                Message: $message
                Config: ${config?.let { "${it.width}x${it.height} fps=${it.fps} bitrate=${it.bitrate}" } ?: "null"}
                VideoEncoder: $videoEncoderName
                AudioEncoder: $audioEncoderName
                OutputPath: $outputFilePath
                UseHevc: $useHevc
                HevcConfigureFailed: $hevcConfigureFailed
                FrameCount: $frameCount
                Duration: ${calculateDuration()}ms
                FileSize: ${outputFile?.length() ?: 0} bytes
                PtsCount: $ptsCount
                PtsIntervalAvg: ${if (ptsCount > 1) ptsIntervalSum / (ptsCount - 1) else 0}
                PtsIntervalMin: ${if (ptsIntervalMin < Long.MAX_VALUE) ptsIntervalMin else 0}
                PtsIntervalMax: ${if (ptsIntervalMax > Long.MIN_VALUE) ptsIntervalMax else 0}
                BuildCalledFrom: ${Log.getStackTraceString(Throwable())}
                $errorSource
                =========================
                
                """.trimIndent()
            )
            logDetail("emergency_log", "written to $emergencyLog")
            // v6.7.115: 最多保留 3 个 emergency 日志文件，避免异常反复时无限累积。
            // 按修改时间降序排列，保留最新的 3 个，删除其余的。
            try {
                val files = emergencyDir.listFiles { _, name -> name.endsWith(".log") } ?: emptyArray()
                if (files.size > 3) {
                    files.sortedByDescending { it.lastModified() }.drop(3).forEach { it.delete() }
                }
            } catch (_: Exception) { }
        } catch (e: Exception) {
            Log.e(TAG, "Failed to write emergency log: ${e.message}")
        }
    }

}