package com.monkeycode.screenrecorder

import android.content.Intent
import android.os.Build
import android.os.Bundle
import android.media.projection.MediaProjectionManager
import android.widget.Toast
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AppCompatActivity

/** v6.9.10 (AZ 一体四子球): 透明 Activity,仅承载 MediaProjection 授权弹窗,授权完即 finish。
 *
 *  为什么需要它:MediaProjection 授权必须走 Activity 结果回调,悬浮窗无 Activity 上下文,
 *  录制中/非录制态截图与"开始录制"入口都需要先经过一次授权弹窗。
 *
 *  授权结果存入 ScreenRecorderApp 全局 pending,再由对应路径(Service/ACTION_PREPARE
 *  或 ScreenshotHelper.captureStandalone)消费。
 *
 *  registerForActivityResult 需要 ComponentActivity 生命周期,故继承 AppCompatActivity。 */
class CaptureActivity : AppCompatActivity() {

    companion object {
        const val EXTRA_MODE = "mode" // "record" | "shot"
    }

    private val projectionLauncher = registerForActivityResult(
        ActivityResultContracts.StartActivityForResult()
    ) { result ->
        val data = result.data
        if (intent?.getStringExtra(EXTRA_MODE) == "shot") handleShot(result.resultCode, data)
        else handleRecord(result.resultCode, data)
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        // 透明无 UI:仅用于弹出系统 MediaProjection 授权框,授权完 finish。
        val pm = getSystemService(MediaProjectionManager::class.java)
        try {
            projectionLauncher.launch(pm.createScreenCaptureIntent())
        } catch (e: Exception) {
            Toast.makeText(this, "无法发起屏幕授权", Toast.LENGTH_SHORT).show()
            finish()
        }
    }

    private fun handleRecord(resultCode: Int, data: Intent?) {
        if (resultCode == RESULT_OK && data != null) {
            // 与 MainActivity.mediaProjectionLauncher 完全同源:深拷贝 data 防 token 失效
            ScreenRecorderApp.pendingResultCode = resultCode
            ScreenRecorderApp.pendingResultData = Intent(data)
            ScreenRecorderApp.pendingMediaProjection = null
            val i = Intent(this, ScreenRecorderService::class.java).apply {
                action = ScreenRecorderService.ACTION_PREPARE
            }
            try {
                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) startForegroundService(i)
                else startService(i)
            } catch (e: Exception) {
                Toast.makeText(this, "启动录制失败", Toast.LENGTH_SHORT).show()
            }
        } else {
            Toast.makeText(this, "未获取屏幕录制授权", Toast.LENGTH_LONG).show()
        }
        finish()
    }

    private fun handleShot(resultCode: Int, data: Intent?) {
        if (resultCode == RESULT_OK && data != null) {
            ScreenshotHelper.captureStandalone(this, resultCode, data) { uri ->
                runOnUiThread {
                    Toast.makeText(
                        this,
                        if (uri != null) "截图已保存" else "截图失败",
                        Toast.LENGTH_SHORT
                    ).show()
                }
                finish()
            }
        } else {
            Toast.makeText(this, "未获取屏幕截图授权", Toast.LENGTH_LONG).show()
            finish()
        }
    }
}
