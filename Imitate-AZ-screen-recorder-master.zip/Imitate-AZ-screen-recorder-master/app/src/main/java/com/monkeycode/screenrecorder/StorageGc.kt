package com.monkeycode.screenrecorder

import android.content.Context
import android.util.Log
import java.io.File

/**
 * v6.7.188g: 录像产物自动垃圾回收。
 *
 * 设计原则（对齐项目「低占用 + 启动零重活」）：
 *  - 只做 O(历史条数) 的 stat 与按序删除，绝不扫描磁盘、绝不解析媒体、绝不在启动阻塞主线程。
 *  - 删除对象恒为「最旧的已完成条目」，且必须跳过 SafeDeleteUtil 保护项（历史/受保护文件）。
 *  - 多分片条目（segmentPaths 非空）连分片一起删，避免残留孤儿被 scanOrphans 重复报「待修复」。
 *  - 任何异常都吞掉：GC 失败不应影响录制主流程。
 */
object StorageGc {

    private const val TAG = "StorageGc"

    /** 容量上限：默认 20 GiB。超过后按时间从旧到新删，直到回到阈值内。 */
    const val DEFAULT_MAX_BYTES = 20L * 1024 * 1024 * 1024
    /** 条数上限：默认 200 条。 */
    const val DEFAULT_MAX_ENTRIES = 200
    /** 超龄天数：默认 30 天，超过即回收（无论容量是否超）。 */
    const val DEFAULT_MAX_AGE_DAYS = 30L
    /** 连续两次 GC 的最小间隔，避免收尾/启动高频触发。 */
    private const val MIN_INTERVAL_MS = 60_000L
    /** 单次最多删除条数，防止极端情况下一次删太多造成卡顿。 */
    private const val MAX_DELETE_PER_RUN = 30

    @Volatile private var lastRunMs = 0L

    /**
     * 轻量入口。可在冷启动与录制收尾后调用；内部有 60s 节流。
     * @param context 上下文
     * @param maxBytes 容量上限
     * @param maxEntries 条数上限
     * @param maxAgeDays 超龄天数
     */
    fun maybeGc(
        context: Context,
        maxBytes: Long = DEFAULT_MAX_BYTES,
        maxEntries: Int = DEFAULT_MAX_ENTRIES,
        maxAgeDays: Long = DEFAULT_MAX_AGE_DAYS,
    ) {
        val now = System.currentTimeMillis()
        if (now - lastRunMs < MIN_INTERVAL_MS) return
        lastRunMs = now
        try {
            runGc(context, maxBytes, maxEntries, maxAgeDays)
        } catch (t: Throwable) {
            Log.w(TAG, "gc failed: ${t.message}")
        }
    }

    private fun runGc(context: Context, maxBytes: Long, maxEntries: Int, maxAgeDays: Long) {
        val hm = RecordingHistoryManager.get(context.applicationContext)
        val all = hm.getAll().sortedBy { it.timestamp }   // 旧 -> 新
        if (all.isEmpty()) return

        val cutoffMs = System.currentTimeMillis() - maxAgeDays * 24 * 3600 * 1000L
        var totalBytes = all.sumOf { e -> e.sizeBytes.coerceAtLeast(0L) }
        var live = all.toMutableList()
        var deleted = 0

        // 1) 超龄回收
        for (e in all) {
            if (deleted >= MAX_DELETE_PER_RUN) break
            if (e.timestamp > 0L && e.timestamp < cutoffMs) {
                if (deleteEntry(context, e)) {
                    deleted++
                    totalBytes -= e.sizeBytes.coerceAtLeast(0L)
                    live.remove(e)
                }
            }
        }

        // 2) 条数配额回收（仍从最旧开始）
        while (live.size > maxEntries && deleted < MAX_DELETE_PER_RUN) {
            val oldest = live.firstOrNull() ?: break
            if (deleteEntry(context, oldest)) {
                deleted++
                totalBytes -= oldest.sizeBytes.coerceAtLeast(0L)
                live.removeAt(0)
            } else break
        }

        // 3) 容量配额回收
        while (totalBytes > maxBytes && deleted < MAX_DELETE_PER_RUN) {
            val oldest = live.firstOrNull() ?: break
            if (deleteEntry(context, oldest)) {
                deleted++
                totalBytes -= oldest.sizeBytes.coerceAtLeast(0L)
                live.removeAt(0)
            } else break
        }

        if (deleted > 0) {
            // 同步历史：按 path 精确匹配删除，避免误删
            val removedPaths = all.filter { it !in live }.map { it.path }.toSet()
            hm.delete { it.path in removedPaths }
            hm.reload()
            Log.i(TAG, "gc done deleted=$deleted remaining=${live.size} bytes=$totalBytes")
        }
    }

    /** 删除单个条目：主文件 + 分片；受保护文件跳过返回 false。 */
    private fun deleteEntry(context: Context, e: RecordingEntry): Boolean {
        val main = File(e.path)
        if (main.exists() && SafeDeleteUtil.isProtected(main)) return false
        var ok = true
        // 多分片残留一并清理，防止孤儿被 scanOrphans 再次报「待修复」
        e.segmentPaths.forEach { p ->
            val sf = File(p)
            if (sf.exists() && !SafeDeleteUtil.isProtected(sf)) {
                SafeDeleteUtil.delete(sf, "storage_gc_segment")
            }
        }
        if (main.exists()) {
            ok = SafeDeleteUtil.delete(main, "storage_gc_entry")
        }
        return ok
    }
}
