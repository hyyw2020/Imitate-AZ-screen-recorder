package com.monkeycode.screenrecorder

import java.io.File
import java.io.RandomAccessFile
import java.nio.ByteBuffer
import java.nio.ByteOrder

// v6.7.140 (必修1): 追加 HEVC 修复支持。原实现仅支持 AVC(硬编码 codec=0,buildVideoStsd 固定写 avc1)。
// 新增：Tracker 构造含 codec 参数；readIndex/readIndexHeader 读取 codec；repair/repairByScan 按
// spec.codec 分流：AVC 保持现有逻辑，HEVC 走 buildHvcC+buildStsdHevc；NAL scan 按 HEVC NAL
// 类型(VPS=32/SPS=33/PPS=34/AUD=35/slice first_slice_segment_in_pic_flag)切分访问单元。
// 向后兼容：旧 .idx 字节[1]=0(AVC)，旧数据 codec=null 按 AVC 处理。

/**
 * v6.7.120: 被杀/崩溃中断 MP4 的轻量 moov 重建。
 *
 * 背景: MediaMuxer(MPEG_4 输出)在进程被杀时不执行 stop(),文件缺失 moov 索引,播放器无法打开。
 * 录制期由 [Tracker.appendSample] 把每帧(size/pts/sync/相对偏移)与轨道 csd 追加进伴生 .idx 文件;
 * .idx 在磁盘上,杀进程后仍在。启动扫描时 repair() 依 .idx 重建 moov,追加到 mdat 之后,文件可播。
 *
 * 纯 java.* 实现(无 Android 依赖)以便 JVM 自检验证结构。
 *
 * ── 已知天花板(ponytail) ──
 * 用"MediaMuxer(MPEG_4)把样本按 writeSampleData 调用顺序连续写进唯一 mdat、无空隙无重排"假设推
 * 算样本相对偏移(Tracker 内 runningTotal)。修复时用真实扫描到的 mdat 数据起点 + 已存相对偏移得
 * 绝对偏移。这是 Android MediaMuxer 标准行为;若 OEM 缓冲/重排,修复仍是结构合法 MP4 但个别 stco
 * 偏差 → 部分片段不可寻址,不影响首段,绝不破坏原文件(失败保留原名)。升级路径:修复时按 AVC
 * length-prefixed NAL 回读 mdat 校正偏移(需真机杀文件比对)。仅支持 AVC(默认编码);HEVC 由调用方
 * 降级为改名保留。
 */
object Mp4Repairer {

    /** v6.7.122: 最近一次 repairByScan 恢复的样本数, 供调用方估算时长; -1 表示未扫描。 */
    @Volatile var lastScanSampleCount: Int = -1


    // ==================== .idx 写入(录制热路径) ====================
    class Tracker(
        val hasVideo: Boolean,
        val videoCsd0: ByteArray?,
        val videoCsd1: ByteArray?,
        val fps: Int,
        val width: Int,
        val height: Int,
        val hasAudio: Boolean,
        val audioCsd0: ByteArray?,
        val sampleRate: Int,
        val channels: Int,
        // v6.7.140 (必修1): 视频编解码器类型,0=AVC,1=HEVC。写入 idx 头部字节[1],供读取侧分支。
        val codec: Int = 0,
        out: java.io.OutputStream,
    ) {
        private val out = java.io.BufferedOutputStream(out, 64 * 1024)
        // 底层写对象(仅当入参是 FileOutputStream 才非 null),用于 fd.sync 真正落盘。
        // v6.7.125: 修复 v6.7.122 flushHeader 的 (out as? FileOutputStream) 死代码——
        // out 是 BufferedOutputStream,该 cast 恒 null,fsync 从未触达磁盘。
        private val fileOut: java.io.FileOutputStream? = out as? java.io.FileOutputStream
        private var relOffset = 0L
        private var failed = false
        // v6.7.125: 周期 fsync 计数。每 256 个样本对 .idx 做 flush+fd.sync,把断电/杀进程
        // 丢尾窗口从 25~99s(BOS 64KB 攒 2978 样本才自动落一次)压到 4~9s。热路径仅一次
        // 无锁原子加+比较,零锁零阻塞;每次 sync 数据量仅 ~5.6KB(256×22B),开销可忽略。
        private val sampleCounter = java.util.concurrent.atomic.AtomicInteger(0)
        // v6.7.188h (改造4): 上次 fsync 的单调时刻。用 elapsedRealtime,免疫墙钟跳变(对齐 v6.7.164)。
        @Volatile private var lastSyncAtMs = 0L
        private companion object {
            const val SYNC_EVERY_SAMPLES = 256
            // v6.7.188h (改造4): 时间兜底周期。低帧率场景下样本数阈值可能十几秒才触发,故补时间触发。
            const val SYNC_EVERY_MS = 3_000L
        }

        init {
            try {
                val head = ByteBuffer.allocate(8).order(ByteOrder.BIG_ENDIAN)
                head.putInt(0x534C5244)                 // "SLRD"
                head.putShort(1)
                head.putShort(0)
                write(head.array())
                if (hasVideo) {
                    // v6.7.140 (必修1): 写入真实 codec 类型,避免 HEVC 被误标为 AVC。
                    write(byteArrayOf(1, codec.toByte()))             // hasVideo, codec(0=AVC/1=HEVC)
                    val b = ByteBuffer.allocate(12 + 4 + (videoCsd0?.size ?: 0) + 4 + (videoCsd1?.size ?: 0))
                        .order(ByteOrder.BIG_ENDIAN)
                    b.putInt(width); b.putInt(height); b.putInt(fps)
                    writeLenBytes(b, videoCsd0); writeLenBytes(b, videoCsd1)
                    write(b.array())
                } else {
                    write(byteArrayOf(0))
                }
                if (hasAudio) {
                    write(byteArrayOf(1))
                    val b = ByteBuffer.allocate(8 + 4 + (audioCsd0?.size ?: 0)).order(ByteOrder.BIG_ENDIAN)
                    b.putInt(sampleRate); b.putInt(channels)
                    writeLenBytes(b, audioCsd0)
                    write(b.array())
                } else {
                    write(byteArrayOf(0))
                }
            } catch (_: Exception) {
                failed = true
            }
        }

        /** v6.7.122: 同步 flush 头部(csd/size/fps)。被杀保护:避免头留在 64KB 缓冲
         * 未落盘,导致进程被杀时 .idx 是 0 字节、丢 csd,修复拿不到参数。 */
        fun flushHeader() {
            if (failed) return
            try { out.flush() } catch (_: Exception) { failed = true }
            // v6.7.122: fd.sync 确保 OS 缓存中的头部真正落盘, 防止被杀后读不到。
            // v6.7.125: 改用 fileOut(底层 FileOutputStream)——此前的 (out as? FileOutputStream)
            // 因 out 是 BufferedOutputStream 恒 null, fsync 从未执行。
            try { fileOut?.fd?.sync() } catch (_: Exception) {}
        }

        /** 录制热路径:每写一个样本调用一次。 */
        fun appendSample(isVideo: Boolean, size: Int, ptsUs: Long, sync: Boolean) {
            if (failed) return
            try {
                val b = ByteBuffer.allocate(22).order(ByteOrder.BIG_ENDIAN)
                b.put(if (isVideo) 1 else 0)
                b.put(if (sync) 1 else 0)
                b.putLong(ptsUs)
                b.putInt(size)
                b.putLong(relOffset)
                write(b.array())
                relOffset += size
                // v6.7.125: 低频周期 fsync——每 256 样本 flush+fd.sync 一次,把断电/杀进程
                // 丢尾窗口从分钟级压到秒级。计数器由音视频样本共同累加。
                // v6.7.125a: flush 失败必须置 failed——否则缓冲仅 ~5.6KB 时的周期 flush 被吞、
                // failed 保持 false,后续 write 只写内存缓冲而磁盘 .idx 缺段,若 BOS 攒满 64KB
                // 后又 flush 成功,缺失段永久丢失,readIndex 偏少 + repair 按 rel 推错位。
                // 仅 fd.sync 失败允许跳过(不影响已成功写入的索引)。
                // v6.7.188h (改造4): 双触发 —— 每 256 样本 或 每 3 秒,任一满足即 fsync。
                // 高帧率走样本数(开销随数据量摊薄),低帧率走时间(保证窗口上限 3s)。
                val bySamples = sampleCounter.incrementAndGet() >= SYNC_EVERY_SAMPLES
                val nowSync = android.os.SystemClock.elapsedRealtime()
                val byTime = lastSyncAtMs != 0L && (nowSync - lastSyncAtMs) >= SYNC_EVERY_MS
                if (bySamples || byTime) {
                    sampleCounter.set(0)
                    lastSyncAtMs = nowSync
                    try { out.flush() } catch (_: Exception) { failed = true; return }
                    try { fileOut?.fd?.sync() } catch (_: Exception) {}
                }
                // 首次写入时初始化时间锚点
                if (lastSyncAtMs == 0L) lastSyncAtMs = nowSync
            } catch (_: Exception) {
                failed = true
            }
        }

        /** 正常收尾(muxer.stop 成功)时关闭并丢弃。 */
        fun closeDiscard() {
            try { out.flush() } catch (_: Exception) {}
            try { out.close() } catch (_: Exception) {}
        }

        fun isFailed(): Boolean = failed

        private fun write(b: ByteArray) { out.write(b) }
    }

    private fun writeLenBytes(buf: ByteBuffer, b: ByteArray?) {
        buf.putInt(b?.size ?: 0)
        if (b != null) buf.put(b)
    }

    // ==================== 读取 .idx ====================
    data class SampleSpec(val isVideo: Boolean, val size: Int, val ptsUs: Long, val sync: Boolean, val offset: Long = -1L)
    data class RepairSpec(
        val hasVideo: Boolean,
        val videoCsd0: ByteArray?, val videoCsd1: ByteArray?,
        val fps: Int, val width: Int, val height: Int,
        val hasAudio: Boolean, val audioCsd0: ByteArray?,
        val sampleRate: Int, val channels: Int,
        // v6.7.140 (必修1): 视频编解码器类型,0=AVC,1=HEVC,null 表示旧数据兼容 AVC。
        val codec: Int = 0,
        val samples: List<SampleSpec>,
    )

    /** v6.7.122: 只读头部(含 0 个样本)。NAL 扫描修复用:头部 csd 被杀保护 flushHeader 已落盘,
     * 即使 .idx 无样本也可取得 csd/size/fps。 */
    fun readIndexHeader(idxFile: File): RepairSpec {
        val ra = RandomAccessFile(idxFile, "r")
        try {
            val magic = ByteArray(4)
            ra.readFully(magic)
            val expect = "SLRD".toByteArray(Charsets.ISO_8859_1)
            if (!magic.contentEquals(expect)) throw java.io.IOException("bad idx magic")
            val ver = ra.readUnsignedShort()
            if (ver < 1) throw java.io.IOException("idx ver $ver")
            ra.readUnsignedShort()
            val hasVideo = ra.readUnsignedByte() == 1
            var v0: ByteArray? = null
            var v1: ByteArray? = null
            var fps = 0
            var w = 0
            var h = 0
            var codecInt = 0
            if (hasVideo) {
                // v6.7.140 (必修1): 读取 codec 字段,旧 .idx 字节[1]=0(AVC)兼容。
                codecInt = ra.readUnsignedByte()
                w = ra.readInt()
                h = ra.readInt()
                fps = ra.readInt()
                v0 = readLen(ra)
                v1 = readLen(ra)
            }
            val hasAudio = ra.readUnsignedByte() == 1
            var a0: ByteArray? = null
            var sr = 0
            var ch = 0
            if (hasAudio) {
                sr = ra.readInt()
                ch = ra.readInt()
                a0 = readLen(ra)
            }
            // v6.7.140: 构造 RepairSpec 时透传 codec,0=AVC,1=HEVC,null 或无效值退 AVC。
            val codecParsed = if (codecInt == 1) 1 else 0
            return RepairSpec(hasVideo, v0, v1, fps, w, h, hasAudio, a0, sr, ch, codecParsed, emptyList())
        } finally {
            ra.close()
        }
    }

    fun readIndex(idxFile: File): RepairSpec {
        val ra = RandomAccessFile(idxFile, "r")
        try {
            val magic = ByteArray(4)
            ra.readFully(magic)
            val expect = "SLRD".toByteArray(Charsets.ISO_8859_1)
            if (!magic.contentEquals(expect)) throw java.io.IOException("bad idx magic")
            val ver = ra.readUnsignedShort()
            if (ver < 1) throw java.io.IOException("idx ver $ver")
            ra.readUnsignedShort()
            val hasVideo = ra.readUnsignedByte() == 1
            var v0: ByteArray? = null
            var v1: ByteArray? = null
            var fps = 0
            var w = 0
            var h = 0
            var codecInt = 0
            if (hasVideo) {
                // v6.7.140 (必修1): 读取 codec 字段(与 readIndexHeader 同步)。
                codecInt = ra.readUnsignedByte()
                w = ra.readInt()
                h = ra.readInt()
                fps = ra.readInt()
                v0 = readLen(ra)
                v1 = readLen(ra)
            }
            val hasAudio = ra.readUnsignedByte() == 1
            var a0: ByteArray? = null
            var sr = 0
            var ch = 0
            if (hasAudio) {
                sr = ra.readInt()
                ch = ra.readInt()
                a0 = readLen(ra)
            }
            // v6.7.140: 构造 RepairSpec 时透传 codec,0=AVC,1=HEVC,null 或无效值退 AVC。
            val codecParsed = if (codecInt == 1) 1 else 0
            val samples = ArrayList<SampleSpec>()
            while (ra.filePointer + 22 <= ra.length()) {
                val isV = ra.readUnsignedByte() == 1
                val sync = ra.readUnsignedByte() == 1
                val pts = ra.readLong()
                val size = ra.readInt()
                ra.skipBytes(8)  // 跳过写入端记录的相对偏移(repair 由累计大小重算)
                samples.add(SampleSpec(isV, size, pts, sync))
            }
            if (samples.isEmpty()) throw java.io.IOException("idx has no samples")
            return RepairSpec(hasVideo, v0, v1, fps, w, h, hasAudio, a0, sr, ch, codecParsed, samples)
        } finally {
            ra.close()
        }
    }

    private fun readLen(ra: RandomAccessFile): ByteArray {
        val len = ra.readInt()
        if (len < 0 || len > 1024 * 1024) throw java.io.IOException("csd len $len")
        val b = ByteArray(len)
        if (len > 0) ra.readFully(b)
        return b
    }

    // ==================== repair() ====================
    data class RepairResult(val ok: Boolean, val repaired: Boolean, val message: String?)

    /** 重建 [tmpPath] 的 moov,追加到 mdat 之后,输出 "$tmpPath.repaired"; 不动 [tmpPath]。 */
    fun repair(tmpPath: String, idxFile: File): RepairResult {
        var spec = try { readIndex(idxFile) } catch (e: Exception) {
            return RepairResult(false, false, "idx: ${e.message}")
        }
        if (!spec.hasVideo) return RepairResult(false, false, "no video")
        // v6.7.140 (必修1): AVC 要求 csd-0+csd-1(SPS/PPS 分离),HEVC 仅需 csd-0(VPS+SPS+PPS 通常合并在 csd-0)。
        if (spec.videoCsd0 == null) return RepairResult(false, false, "no video csd-0")
        if (spec.codec == 0 && spec.videoCsd1 == null) return RepairResult(false, false, "no avc csd-1")
        if (spec.samples.isEmpty()) return RepairResult(false, false, "empty samples")
        if (!spec.samples.any { it.isVideo }) return RepairResult(false, false, "no video samples")
        val tmp = File(tmpPath)
        if (!tmp.exists() || tmp.length() <= 0L) return RepairResult(false, false, "tmp missing")

        val mdat = try { scanMdat(tmp) } catch (e: Exception) {
            return RepairResult(false, false, "scan: ${e.message}")
        }
        val mdatStart = mdat.dataStart
        val mdatLen = mdat.byteLen
        // v6.7.168: 尾部半帧钳制。原逻辑 total>mdatLen 即整文件放弃退化 repairByScan,
        // 丢精确 PTS 且大文件全量 NAL 扫描极慢极耗资源(与 C6 冲突)。改为逐样本累加,
        // 遇到 (off+size)>mdatLen 的撕裂末帧即丢弃,保住前面所有完整样本。
        val total = spec.samples.fold(0L) { a, s -> a + s.size }
        if (total > mdatLen) {
            val kept = ArrayList<SampleSpec>(spec.samples.size)
            var off = 0L
            for (s in spec.samples) {
                if (off + s.size > mdatLen) break
                kept.add(s.copy(offset = off))
                off += s.size
            }
            if (kept.isEmpty()) return RepairResult(false, false, "no complete sample in mdat")
            DiagLog.logEvent("REPAIR", "clamp dropped tail: kept=${kept.size}/${spec.samples.size} samples")
            // 后续 buildMoov 用钳制后的样本重建,而非整文件放弃
            spec = spec.copy(samples = kept)
        }

        try {
            val moov = buildMoov(spec, mdatStart)
            val outPath = "$tmpPath.repaired"
            writeRepaired(tmp, mdat, moov, outPath)
return RepairResult(true, true, null)
        } catch (e: Exception) {
            try { File("$tmpPath.repaired").delete() } catch (_: Exception) {}
            val stack = e.stackTraceToString().replace("\n", " | ")
            val cause = (e.message ?: e.javaClass.simpleName) + "  " + stack.take(400)
            return RepairResult(false, false, "repair: $cause")
        }
    }

    /** v6.7.122: 不依赖 .idx 的纯 NAL 扫描重建(仿 AZ untrunc 思路)。入参 header 提供 csd/size/fps,
     * 通过解析 mdat 内 AVCC length-prefixed H.264 NAL,按首片 first_mb_in_slice==0 切分访问单元成样本。
     * 返回带样本的 RepairSpec;解析失败/校验不过返回 null(调用方改名保留)。 */
    fun repairByScan(tmpPath: String, idxFile: File): RepairResult {
        val header = try { readIndexHeader(idxFile) } catch (e: Exception) {
            return RepairResult(false, false, "idx header: ${e.message}")
        }
        if (!header.hasVideo || header.videoCsd0 == null)
            return RepairResult(false, false, "scan: no video csd-0")
        // v6.7.140 (必修1): scan 路径仅 AVC 分支要求 csd-1(HEVC 参数集合并在 csd-0);
        // 若 header 有 csd-1 也接受,但 HEVC 扫描路径不使用它。
        if (header.codec == 0 && header.videoCsd1 == null)
            return RepairResult(false, false, "scan: no avc csd-1")
        if (header.fps <= 0 || header.width <= 0 || header.height <= 0)
            return RepairResult(false, false, "scan: bad params ${header.width}x${header.height}@${header.fps}")
        val tmp = File(tmpPath)
        if (!tmp.exists() || tmp.length() <= 0L) return RepairResult(false, false, "tmp missing")
        val mdat = try { scanMdat(tmp) } catch (e: Exception) {
            return RepairResult(false, false, "scan: ${e.message}")
        }
        val frameDurUs = 1_000_000L / header.fps
        val videoSamples = try {
            // v6.7.140 (必修1): 按 codec 分流 NAL 扫描路径。
            if (header.codec == 1) scanHevcAccessUnits(tmp, mdat.dataStart, mdat.byteLen, frameDurUs)
            else scanAccessUnits(tmp, mdat.dataStart, mdat.byteLen, frameDurUs)
        } catch (e: Exception) {
            return RepairResult(false, false, "nal: ${e.message}")
        }
        if (videoSamples.isEmpty()) return RepairResult(false, false, "nal: no video samples recovered")
        lastScanSampleCount = videoSamples.size
        val spec = RepairSpec(
            hasVideo = true,
            videoCsd0 = header.videoCsd0, videoCsd1 = header.videoCsd1,
            fps = header.fps, width = header.width, height = header.height,
            // 音频无法从交错流可靠复原, 重建为纯视频 mp4(始终可播)。
            hasAudio = false, audioCsd0 = null, sampleRate = 0, channels = 0,
            // v6.7.140 (必修1): 透传扫描时的 codec,供 buildMoov/buildVideoStsd 分支。
            codec = header.codec,
            samples = videoSamples,
        )
        try {
            val moov = buildMoov(spec, mdat.dataStart)
            val outPath = "$tmpPath.repaired"
            writeRepaired(tmp, mdat, moov, outPath)
            // 校验样本字节总量不得超 mdat, 防止 stco 越界。
            val total = spec.samples.fold(0L) { a, s -> a + s.size }
            if (total > mdat.byteLen) {
                File(outPath).delete()
                return RepairResult(false, false, "nal: samples $total > mdat ${mdat.byteLen}")
            }
            return RepairResult(true, true, null)
        } catch (e: Exception) {
            try { File("$tmpPath.repaired").delete() } catch (_: Exception) {}
            return RepairResult(false, false, "repair: ${e.message}")
        }
    }

    /** v6.7.149 (FIX-A): 把多个已封口分片(.mp4,各自合法 moov+mdat)合并为单一可播 mp4。
     *  杀进程恢复策略:封口分片各自可播,只剩末片需 restoreStale;正常收尾则把全部分片合回单文件,
     *  历史/SAF 导出仍只吃单文件(播放/导出不因分片退化)。
     *  实现:复用 .idx(每样本 size/pts/sync,偏移由累计大小重算)+ scanMdat(每分片 mdat 载起点),
     *  把全部分片 mdat 载荷顺序拼进一个合并 mdat,样本 offset 记为其在合并 mdat 中的相对位置,
     *  PTS 按"每轨每片累计时长"重基(保留分片内音画对齐与跨片连续性),最后用 buildMoov 重建单一 moov。
     *  不出货 moov 的 mp4 均可直接拼插;编码器跨分片不重启,各片首参数同一套。
     *  @param segments 每项 = (idx 文件, 分片 mp4 文件)。须按 seq 升序、已封口(改名 .mp4)。
     *  @return 合并产物文件;任一分片 .idx 缺失/损坏/样本越界则返回 null(调用方保留分片)。 */
    fun mergeSegments(segments: List<Pair<java.io.File, java.io.File>>, outPath: String): java.io.File? {
        if (segments.isEmpty()) return null
        val header = try { readIndexHeader(segments[0].first) } catch (e: Exception) { DiagLog.logEvent("REPAIR", "merge fail readIndexHeader=${e.message}"); return null }
        if (!header.hasVideo || header.videoCsd0 == null) return null
        if (header.codec == 0 && header.videoCsd1 == null) return null
        try {
            val out = java.io.RandomAccessFile(outPath, "rw").use { ra ->
                ra.setLength(0)
                // ftyp(定长 24 字节标准 isom 头),之后是 mdat 盒子头 + 载荷,最后追加 moov。
                // buildMoov 的 stco 需指向 mdat 载荷的绝对文件偏移(mdatStart),故先确定 ftyp 长。
                val ftyp = box("ftyp",
                    byteArrayOf(
                        'i'.code.toByte(), 's'.code.toByte(), 'o'.code.toByte(), 'm'.code.toByte(),      // major_brand
                        0, 0, 0, 0,                                                                        // minor_version
                        'i'.code.toByte(), 's'.code.toByte(), 'o'.code.toByte(), 'm'.code.toByte(),       // compatible[0]
                        'm'.code.toByte(), 'p'.code.toByte(), '4'.code.toByte(), '2'.code.toByte(),       // compatible[1]
                        'm'.code.toByte(), 'p'.code.toByte(), '4'.code.toByte(), '1'.code.toByte(),       // compatible[2]
                    ))  // -> 8 + 20 = 28 字节
                ra.write(ftyp)
                // mdat 盒子头:v6.7.150 (BUG-1) 固定按 64 位 largesize 格式(16 字节)预留占位。
                // 原 8 字节 32 位头在合并产物 >2GiB 时 (8+combRel).toInt() 溢出成负数,mov 按错误
                // size 找 moov 报 Source error;分片 60s/1GiB 兜底下 4K80M 约 4 分钟即 ~2.4GiB 必撞。
                // 统一用 64 位格式,永远正确,代价仅每文件多 8 字节。载荷起点 = ftyp 后 16 字节。
                val mdatStart = ra.filePointer + 16
                ra.write(ByteArray(16))                      // 占位,循环后回填 version+type+64位 size
                // v6.7.150 (BUG-2): 片间 PTS 重基基线须加上"上一片最后样本的帧间隔",否则下一片
                // 首样本 pts 与上一片末样本 pts 相同(0 时长帧),接缝处顿帧/音画错位。
                val frameDurUs = 1_000_000L / header.fps.coerceAtLeast(1)
                val audioFrameDurUs = if (header.sampleRate > 0)
                    (1024L * 1_000_000L / header.sampleRate.toLong()) else 21_333L
                val combined = ArrayList<SampleSpec>(1024)
                var combRel = 0L
                // 每轨累计时长,用于对分片 PTS 重基(保持连续时间轴)
                var vidBaseUs = 0L
                var audBaseUs = 0L
                val buf = ByteArray(256 * 1024)
                for ((idxFile, mp4File) in segments) {
                    val spec = try { readIndex(idxFile) } catch (e: Exception) { DiagLog.logEvent("REPAIR", "merge fail readIndex=${e.message}"); return null }
                    if (!spec.hasVideo || spec.videoCsd0 == null) return null
                    if (spec.codec == 0 && spec.videoCsd1 == null) return null   // v6.7.164: 补守卫,与 repair()/repairByScan() 一致
                    val mdat = try { scanMdat(mp4File) } catch (e: Exception) { DiagLog.logEvent("REPAIR", "merge fail scanMdat=${e.message}"); return null }
                    val inRa = java.io.RandomAccessFile(mp4File, "r")
                    try {
                        var segRel = 0L
                        var segVidMax = 0L
                        var segAudMax = 0L
                        for (s in spec.samples) {
                            val src = mdat.dataStart + segRel
                            inRa.seek(src)
                            var left = s.size
                            while (left > 0) {
                                val n = inRa.read(buf, 0, kotlin.math.min(buf.size, left))
                                if (n <= 0) return null
                                ra.write(buf, 0, n)
                                left -= n
                            }
                            val rebased = if (s.isVideo) s.ptsUs + vidBaseUs else s.ptsUs + audBaseUs
                            // v6.7.150 (BUG-4): 样本对象全量常驻,超限放弃合并(走保留多分片路径,分片各自可播)。
                            // 144Hz/长录制对象可达数万 MB;阈值 150 万约 60fps 6.9 小时,远超实际录制。
                            if (combined.size >= 1_500_000) return null
                            // offset = 该样本在合并 mdat 载荷中的相对位置(0 基准),buildMoov 以 mdatStart 绝对化
                            combined.add(SampleSpec(s.isVideo, s.size, rebased, s.sync, combRel))
                            if (s.isVideo) { if (rebased > segVidMax) segVidMax = rebased } else { if (rebased > segAudMax) segAudMax = rebased }
                            segRel += s.size
                            combRel += s.size
                        }
                        // v6.7.150 (BUG-2): 基线推进加一帧间隔,避免片间首尾样本 PTS 相同。
                        if (segVidMax >= vidBaseUs) vidBaseUs = segVidMax + frameDurUs
                        if (segAudMax >= audBaseUs) audBaseUs = segAudMax + audioFrameDurUs
                    } finally { inRa.close() }
                }
                // 回填 mdat 盒子头(v6.7.150 BUG-1):64 位 largesize 格式——
                // size(4)=1 标记 + type "mdat"(4) + length(8)=16+载荷字节数。
                val mdatEnd = ra.filePointer
                ra.seek(mdatStart - 16)
                val sizeB = ByteBuffer.allocate(16).order(ByteOrder.BIG_ENDIAN)
                    .putInt(1)                                     // largesize flag: 后续是 64 位长度
                    .put("mdat".toByteArray(Charsets.ISO_8859_1))
                    .putLong(16L + combRel)                        // 盒子总长 = 16 字节头 + 载荷
                    .array()
                ra.write(sizeB)
                ra.seek(mdatEnd)
                val global = RepairSpec(
                    hasVideo = header.hasVideo, videoCsd0 = header.videoCsd0, videoCsd1 = header.videoCsd1,
                    fps = header.fps, width = header.width, height = header.height,
                    hasAudio = header.hasAudio, audioCsd0 = header.audioCsd0,
                    sampleRate = header.sampleRate, channels = header.channels,
                    codec = header.codec, samples = combined,
                )
                ra.write(buildMoov(global, mdatStart))
                ra.fd.sync()
            }
            return java.io.File(outPath)
        } catch (_: Exception) {
            try { java.io.File(outPath).delete() } catch (_: Exception) {}
            return null
        }
    }

    /** 返回按访问单元切分的纯视频样本序列。交错 mdat 中音频(AAC)帧会被当作无效 NAL 丢弃,
     * 仅接受 nal_unit_type∈{1..9} 且切片头可解析的 NAL,排除偶发假命中。样本 pts 用 fix帧长累积。
     * 返回空列表表示解析失败(调用方改为改名保留)。
     * 容错: readUe 失败时把该 VCL NAL 当作新帧首片(单片帧正确,多片帧多切但可播)。 */
    private fun scanAccessUnits(f: File, mdatStart: Long, mdatLen: Long, frameDurUs: Long): List<SampleSpec> {
        val samples = ArrayList<SampleSpec>(4096)
        RandomAccessFile(f, "r").use { ra ->
            var rel = 0L
            var pendingSei = -1L   // 挂起 SEI 的 rel-start,-1=无(前导只计入首个 AU)
            var auStart = -1L
            var auSize = 0L
            var auSync = false
            var frameIdx = -1
            val lenBuf = ByteArray(4)
            while (rel + 4 < mdatLen) {
                ra.seek(mdatStart + rel)
                if (ra.read(lenBuf) < 4) break
                val naluLen = ((lenBuf[0].toLong() and 0xFF) shl 24) or
                    ((lenBuf[1].toLong() and 0xFF) shl 16) or
                    ((lenBuf[2].toLong() and 0xFF) shl 8) or (lenBuf[3].toLong() and 0xFF)
                if (naluLen <= 0 || naluLen > 8L * 1024 * 1024) break   // 无效长度→视为损坏尾部
                if (rel + 4 + naluLen > mdatLen) break
                ra.seek(mdatStart + rel + 4)
                val hdr = ra.readUnsignedByte()
                val nalType = hdr and 0x1F
                val inAu = auStart >= 0
                when (nalType) {
                    6 -> if (!inAu && pendingSei < 0) pendingSei = rel   // SEI
                    1, 2, 5 -> { // VCL slice
                        val firstMb = readUe(ra, naluLen.toInt() - 1)
                        // readUe 失败时首片一律当新帧(避免 readUe 失败时 pos 偏斜后续全部错位)
                            if (!inAu || firstMb == -1L) {
                                // 封包前一访问单元(若存在)
                                if (inAu && auSize > 0)
                                    samples.add(SampleSpec(true, auSize.coerceIn(0L, Int.MAX_VALUE.toLong()).toInt(), frameDurUs * frameIdx, auSync, auStart))
                                auStart = if (pendingSei >= 0) pendingSei else rel
                                auSize = (rel - auStart) + 4 + naluLen
                                auSync = nalType == 5
                                pendingSei = -1
                                frameIdx++
                            } else if (firstMb == 0L) {
                                // first_mb_in_slice==0 ⇒ 新一帧: 封包前一访问单元
                                samples.add(SampleSpec(true, auSize.coerceIn(0L, Int.MAX_VALUE.toLong()).toInt(), frameDurUs * frameIdx, auSync, auStart))
                                auStart = if (pendingSei >= 0) pendingSei else rel
                                auSize = (rel - auStart) + 4 + naluLen
                                auSync = nalType == 5
                                pendingSei = -1
                                frameIdx++
                        } else {
                            // 同帧下一片
                            auSize += 4 + naluLen
                            if (nalType == 5) auSync = true
                        }
                    }
                    7, 8, 9 -> { /* SPS/PPS/AUD 跳过(已在 avcC 中),不触发新帧 */ }
                    else -> { /* 非 H.264 类型(音频/噪声)跳过 */ }
                }
                rel += 4 + naluLen
            }
            if (auStart >= 0 && auSize > 0 && frameIdx >= 0)
                samples.add(SampleSpec(true, auSize.coerceIn(0L, Int.MAX_VALUE.toLong()).toInt(), frameDurUs * frameIdx, auSync, auStart))
        }
        if (samples.size < 2) return emptyList()
        for (s in samples) if (s.size <= 0) return emptyList()
        // 样本字节总计不得超过 mdat, 防止 stco 越界
        val total = samples.fold(0L) { a, s -> a + s.size }
        if (total > mdatLen) return emptyList()
        return samples
    }

    /** 读 NAL 负载(忽略 1 字节 hdr)开头的 Exp-Golomb ue(v), 即 slice header 的 first_mb_in_slice。
     * 去 emulation-prevention(00 00 03→00 00)。失败返 -1。
     * 调用前 ra 必须位于 1 字节 hdr 之后,函数结束后 ra 位于该 NAL 负载末尾。 */
    private fun readUe(ra: RandomAccessFile, maxLen: Int): Long {
        if (maxLen < 1) return -1L
        val payload = ByteArray(maxLen)
        var n = 0
        while (n < maxLen) { val r = ra.read(payload, n, maxLen - n); if (r < 0) break; n += r }
        if (n < 1) return -1L
        // 去 emulation prevention
        val body = ByteArray(n)
        var bi = 0
        var z = 0
        var i = 0
        while (i < n) {
            val b = payload[i].toInt() and 0xFF
            if (z >= 2 && b == 3) { i++; z = 0; continue }
            body[bi++] = b.toByte()
            z = if (b == 0) z + 1 else 0
            i++
        }
        // ue(v): 数前导 0 直到遇到 1, 再读 zeros 位信息
        var cursor = 0          // body 中的 bit 游标
        var zeros = 0
        // 读前导 0
        while (true) {
            val byteIdx = cursor ushr 3
            if (byteIdx >= bi) return -1L
            val bit = (body[byteIdx].toInt() ushr (7 - (cursor and 7))) and 1
            cursor++
            if (bit == 1) break
            zeros++
            if (zeros > 31) return -1L
        }
        if (zeros == 0) return 0L   // 值 0 不需要信息位
        var codeNum = 1L
        for (j in 0 until zeros) {
            val byteIdx = cursor ushr 3
            if (byteIdx >= bi) return -1L
            val bit = (body[byteIdx].toInt() ushr (7 - (cursor and 7))) and 1
            cursor++
            codeNum = (codeNum shl 1) or bit.toLong()
        }
        return codeNum - 1L
    }

    // v6.7.140 (必修1): HEVC NAL 扫描分支。HEVC mdat 格式与 AVC 不同:
    // - NAL 类型在 NAL Unit Header (2B) 中: bits[1..5] = nal_unit_type
    // - VPS=32, SPS=33, PPS=34, AUD=35; slice 用 first_slice_segment_in_pic_flag==1 切 AU
    // - csd-0 通常含 VPS+SPS+PPS(length-prefixed),由 buildHvcC 解析入 hvcC
    // - 本函数只切分 VCL NAL(slices),参数集在 buildStsdHevc 中单独组装
    private fun scanHevcAccessUnits(f: File, mdatStart: Long, mdatLen: Long, frameDurUs: Long): List<SampleSpec> {
        val samples = ArrayList<SampleSpec>(4096)
        RandomAccessFile(f, "r").use { ra ->
            var rel = 0L
            var auStart = -1L
            var auSize = 0L
            var auSync = false
            var frameIdx = -1
            val lenBuf = ByteArray(4)
            while (rel + 4 < mdatLen) {
                ra.seek(mdatStart + rel)
                if (ra.read(lenBuf) < 4) break
                val naluLen = ((lenBuf[0].toLong() and 0xFF) shl 24) or
                    ((lenBuf[1].toLong() and 0xFF) shl 16) or
                    ((lenBuf[2].toLong() and 0xFF) shl 8) or (lenBuf[3].toLong() and 0xFF)
                if (naluLen <= 0 || naluLen > 8L * 1024 * 1024) break
                if (rel + 4 + naluLen > mdatLen) break
                ra.seek(mdatStart + rel + 4)
                // HEVC NAL unit header: 2 bytes, nal_unit_type = bits[1..5] of first byte
                if (naluLen < 2) { rel += 4 + naluLen; continue }
                val hdr0 = ra.readUnsignedByte()
                val hdr1 = ra.readUnsignedByte()
                val nalType = (hdr0 ushr 1) and 0x3F
                val firstSliceFlag = (hdr1 and 0x80) != 0
                when (nalType) {
                    32 -> { /* VPS - 跳过,参数集由 buildHvcC 处理 */ }
                    33 -> { /* SPS - 跳过 */ }
                    34 -> { /* PPS - 跳过 */ }
                    35 -> { /* AUD - 跳过 */ }
                    68, 69 -> { /* ISO/IEC 23008-2 HEVC sub-layer reference picture set - 跳过 */ }
                    in 0..31 -> { // VCL NAL (tier 0)
                        if (firstSliceFlag) {
                            // 封包前一访问单元(若存在)
                            if (auSize > 0)
                                samples.add(SampleSpec(true, auSize.coerceIn(0L, Int.MAX_VALUE.toLong()).toInt(), frameDurUs * frameIdx, auSync, auStart))
                            auStart = rel
                            auSize = 4 + naluLen
                            auSync = nalType == 19 // IDR_W_RADL or IDR_N_LP
                            frameIdx++
                        } else {
                            // 同帧下一片
                            auSize += 4 + naluLen
                        }
                    }
                    else -> { /* 其他非VCL跳过 */ }
                }
                ra.skipBytes((naluLen - 2).toInt())
                rel += 4 + naluLen
            }
            if (auStart >= 0 && auSize > 0 && frameIdx >= 0)
                samples.add(SampleSpec(true, auSize.coerceIn(0L, Int.MAX_VALUE.toLong()).toInt(), frameDurUs * frameIdx, auSync, auStart))
        }
        if (samples.size < 2) return emptyList()
        for (s in samples) if (s.size <= 0) return emptyList()
        val total = samples.fold(0L) { a, s -> a + s.size }
        if (total > mdatLen) return emptyList()
        return samples
    }



    private class Mdat(val dataStart: Long, val byteLen: Long, val ftypEnd: Long = 0L)

    // v6.7.188f: 根因修复——原实现复制整份 tmp 再 append 新 moov,导致产物含两个 moov,
    // MediaExtractor 取首个(坏)moov→时长0/样本0→探针失败→产物被删→不写历史。
    // 现只取 ftyp[0,ftypEnd) + mdat盒[dataStart-8, EOF) + 单一新 moov。
    private fun writeRepaired(tmp: File, mdat: Mdat, moov: ByteArray, outPath: String) {
        val ftypEnd = mdat.ftypEnd.coerceAtLeast(0L)
        val mdatBoxStart = (mdat.dataStart - 8).coerceAtLeast(0L)
        val total = tmp.length()
        // 防御:结构异常(无 ftyp / mdat 越界)时回退"整文件复制+append",绝不写出截断文件。
        val useStrip = ftypEnd > 0L && mdatBoxStart >= 0L && mdatBoxStart < total
        RandomAccessFile(tmp, "r").use { inRa ->
            RandomAccessFile(outPath, "rw").use { out ->
                out.setLength(0)
                val buf = ByteArray(256 * 1024)
                if (useStrip) {
                    copyRegion(inRa, out, 0L, ftypEnd, buf)                    // 1) ftyp
                    copyRegion(inRa, out, mdatBoxStart, total - mdatBoxStart, buf) // 2) mdat 盒(含 8B 盒头)
                } else {
                    copyRegion(inRa, out, 0L, total, buf)                       // 回退:整文件
                }
                out.write(moov)                                                  // 3) 单一新 moov
                out.fd.sync()
            }
        }
    }

    private fun copyRegion(inRa: RandomAccessFile, out: RandomAccessFile, start: Long, len: Long, buf: ByteArray) {
        var pos = start
        var remaining = len
        while (remaining > 0) {
            val n = kotlin.math.min(buf.size.toLong(), remaining).toInt()
            inRa.seek(pos)
            val r = inRa.read(buf, 0, n)
            if (r <= 0) break
            out.write(buf, 0, r)
            pos += r; remaining -= r
        }
    }

    private fun scanMdat(f: File): Mdat {
        RandomAccessFile(f, "r").use { ra ->
            var pos = 0L
            var ftypEnd = 0L
            while (true) {
                ra.seek(pos)
                val header = ByteArray(8)
                if (ra.read(header) < 8) throw java.io.IOException("truncated at $pos")
                val size = u32(header, 0)
                val type = String(header, 4, 4, Charsets.ISO_8859_1)
                val dataStart: Long
                val boxEnd: Long
                when {
                    size == 0L -> { dataStart = pos + 8; boxEnd = f.length() }
                    size == 1L -> {
                        ra.seek(pos + 8)
                        val sb = ByteArray(8); ra.readFully(sb)
                        boxEnd = pos + u64(sb, 0); dataStart = pos + 16
                    }
                    else -> { dataStart = pos + 8; boxEnd = pos + size }
                }
                when (type) {
                    "ftyp" -> ftypEnd = boxEnd
                    "mdat" -> {
                        if (ftypEnd <= 0L) throw java.io.IOException("no ftyp")
                        // v6.7.188f: 多带 ftypEnd,供 writeRepaired 跳过被杀写出的"未完成旧 moov"。
                        return Mdat(dataStart, boxEnd - dataStart, ftypEnd)
                    }
                }
                pos = boxEnd
                if (pos >= f.length()) throw java.io.IOException("no mdat")
            }
        }
    }

    // ==================== moov ====================
    private fun buildMoov(spec: RepairSpec, mdatStart: Long): ByteArray {
        val video = spec.samples.filter { it.isVideo }
        val audio = spec.samples.filter { !it.isVideo }
        val vOff = ArrayList<Long>(video.size)
        val aOff = ArrayList<Long>(audio.size)
        var rel = 0L
        for (s in spec.samples) {
            val abs = if (s.offset >= 0L) mdatStart + s.offset else {
                val r = mdatStart + rel
                rel += s.size; r
            }
            if (s.isVideo) vOff.add(abs) else aOff.add(abs)
        }
        val traks = ArrayList<ByteArray>()
        var durUs = 0L
        if (video.isNotEmpty()) {
            traks.add(buildVideoTrak(spec, video, vOff))
            durUs = video.last().ptsUs
        }
        if (audio.isNotEmpty() && spec.hasAudio) {
            traks.add(buildAudioTrak(spec, audio, aOff))
            if (audio.last().ptsUs > durUs) durUs = audio.last().ptsUs
        }
        val moov = box("moov", buildMvhd(durUs.coerceAtLeast(0L)) + concat(traks))
        return moov
    }

    private fun buildVideoTrak(spec: RepairSpec, samples: List<SampleSpec>, offsets: List<Long>): ByteArray {
        val ts = 90000
        val durTicks = ticks(samples.last().ptsUs - samples.first().ptsUs.coerceAtMost(0L), ts).coerceAtLeast(1L)
        val tkhd = buildTkhd(1, durTicks, true, spec.width, spec.height)
        val mdhd = buildMdhd(ts, durTicks)
        val hdlr = buildHdlr("vide", "VideoHandler".toByteArray(Charsets.ISO_8859_1))
        val vmhd = buildVmhd()
        val stbl = buildStbl(true, spec, samples, offsets, ts)
        val minf = box("minf", vmhd + box("dinf", buildDref()) + stbl)
        return box("trak", tkhd + box("mdia", mdhd + hdlr + minf))
    }

    private fun buildAudioTrak(spec: RepairSpec, samples: List<SampleSpec>, offsets: List<Long>): ByteArray {
        val ts = spec.sampleRate
        val durTicks = ticks(samples.last().ptsUs - samples.first().ptsUs.coerceAtMost(0L), ts).coerceAtLeast(1L)
        val tkhd = buildTkhd(2, durTicks, false, 0, 0)
        val mdhd = buildMdhd(ts, durTicks)
        val hdlr = buildHdlr("soun", "SoundHandler".toByteArray(Charsets.ISO_8859_1))
        val smhd = buildSmhd()
        val stbl = buildStbl(false, spec, samples, offsets, ts)
        val minf = box("minf", smhd + box("dinf", buildDref()) + stbl)
        return box("trak", tkhd + box("mdia", mdhd + hdlr + minf))
    }

    private fun buildMvhd(durUs: Long): ByteArray {
        val b = ByteBuffer.allocate(100).order(ByteOrder.BIG_ENDIAN)
        b.putInt(0)                                    // version_flags
        b.putInt(0); b.putInt(0)                        // creation/modification
        b.putInt(1000)                                  // timescale
        b.putInt(((durUs / 1000L).coerceAtMost(0xFFFFFFFFL)).toInt())
        b.putInt(0x00010000)                            // rate 1.0
        b.putShort(0x0100)                              // volume 1.0
        b.putShort(0)                                   // reserved
        b.putLong(0)                                    // reserved 8
        b.putInt(0x00010000); b.putInt(0); b.putInt(0)  // matrix 9×int32(36B)
        b.putInt(0); b.putInt(0x00010000); b.putInt(0)
        b.putInt(0); b.putInt(0); b.putInt(0x40000000)
        b.putInt(0); b.putInt(0); b.putInt(0)           // pre_defined[0..2]
        b.putInt(0); b.putInt(0); b.putInt(0)           // pre_defined[3..5]
        b.putInt(1)                                     // next_track_id
        return box("mvhd", b.array())
    }

    private fun buildTkhd(trackId: Int, durTicks: Long, video: Boolean, w: Int, h: Int): ByteArray {
        val b = ByteBuffer.allocate(92).order(ByteOrder.BIG_ENDIAN)
        b.putInt(0x00000007)                            // version_flags: enabled|inMovie|inPreview
        b.putInt(0); b.putInt(0)                        // creation/mod
        b.putInt(trackId)
        b.putInt(0)                                     // reserved
        b.putInt(durTicks.coerceAtMost(0xFFFFFFFFL).toInt())
        b.putLong(0L)                                   // reserved 8
        b.putShort(0); b.putShort(0)                    // layer, group
        b.putShort(if (video) 0 else 0x0100)            // volume
        b.putShort(0)                                   // reserved
        // matrix: 9×int32(36 字节), 单位矩阵
        b.putInt(0x00010000); b.putInt(0); b.putInt(0)
        b.putInt(0); b.putInt(0x00010000); b.putInt(0)
        b.putInt(0); b.putInt(0); b.putInt(0x40000000)
        b.putInt(w shl 16)                              // width 16.16
        b.putInt(h shl 16)                              // height 16.16
        return box("tkhd", b.array())
    }

    private fun buildMdhd(timescale: Int, durTicks: Long): ByteArray {
        val b = ByteBuffer.allocate(32).order(ByteOrder.BIG_ENDIAN)
        b.putInt(0)
        b.putInt(0); b.putInt(0)
        b.putInt(timescale)
        b.putInt(durTicks.coerceAtMost(0xFFFFFFFFL).toInt())
        b.putShort(0x55C4)                              // language "und"
        b.putShort(0)                                   // pre_defined
        return box("mdhd", b.array())
    }

    private fun buildHdlr(tag: String, name: ByteArray): ByteArray {
        val b = ByteBuffer.allocate(8 + 4 + 4 + 4 + 4 + 4 + name.size + 1).order(ByteOrder.BIG_ENDIAN)
        b.putInt(0)                                     // version_flags
        b.putInt(0)                                     // pre_defined
        b.put(tag.toByteArray(Charsets.ISO_8859_1))     // handler_type
        b.putInt(0); b.putInt(0)                        // reserved
        b.put(name)
        b.put(0)
        return box("hdlr", b.array())
    }

    private fun buildVmhd(): ByteArray {
        val b = ByteBuffer.allocate(12).order(ByteOrder.BIG_ENDIAN)
        b.putInt(1)                                     // copy
        b.putShort(0); b.putShort(0); b.putShort(0)     // opcolor
        b.putShort(0)
        return box("vmhd", b.array())
    }

    private fun buildSmhd(): ByteArray {
        val b = ByteBuffer.allocate(8).order(ByteOrder.BIG_ENDIAN)
        b.putInt(0)                                     // version_flags
        b.putShort(0); b.putShort(0)                    // balance, reserved
        return box("smhd", b.array())
    }

    private fun buildDref(): ByteArray {
        val url = box("url ", byteArrayOf(0, 0, 0, 1))
        val dref = ByteBuffer.allocate(8 + url.size).order(ByteOrder.BIG_ENDIAN)
        dref.putInt(0)                                  // version_flags
        dref.putInt(1)                                  // entry_count
        dref.put(url)
        return box("dref", dref.array())
    }

    private fun buildStbl(video: Boolean, spec: RepairSpec, samples: List<SampleSpec>, offsets: List<Long>, timescale: Int): ByteArray {
        val stsd = if (video) buildVideoStsd(spec) else buildAudioStsd(spec)
        val stts = buildStts(samples, video, spec, timescale)
        val stsc = buildStsc(samples.size)
        val stsz = buildStsz(samples)
        val stco = buildStco(offsets)
        return box("stbl", stsd + stts + stsc + stsz + stco)
    }

    private fun buildVideoStsd(spec: RepairSpec): ByteArray {
        // v6.7.140 (必修1): 按 codec 分支构建 AVC 或 HEVC sample entry。
        return if (spec.codec == 1) buildStsdHevc(spec) else buildStsdAvc(spec)
    }

    private fun buildStsdAvc(spec: RepairSpec): ByteArray {
        // v6.7.164: null 安全——不依赖调用方守卫。CSD 缺失无法构造合法 avcC,
        // 抛受控 IOException 由上层统一转 RepairResult(false, ...),避免 !! NPE 使进程崩。
        val csd0 = spec.videoCsd0
        val csd1 = spec.videoCsd1
        if (csd0 == null || (spec.codec == 0 && csd1 == null)) {
            throw java.io.IOException("avc csd missing csd0=${csd0 != null} csd1=${csd1 != null}")
        }
        // codec==0 时 csd1 已排除 null;codec!=0 时 buildAvcC 实际不读取 csd1(仅 codec==0 用),
        // 但签名要求非空,这里用空字节兜底,语义无害(不会进入使用该值的分支)。
        val avcC = buildAvcC(csd0, csd1 ?: ByteArray(0))
        // avc1 sample entry
        val b = ByteBuffer.allocate(86 + avcC.size).order(ByteOrder.BIG_ENDIAN)
        b.put(ByteArray(6))                             // reserved
        b.putShort(1)                                   // data_reference_index
        b.putShort(0); b.putShort(0)                    // pre_defined, reserved
        b.putInt(0); b.putInt(0); b.putInt(0)           // pre_defined[3]
        b.putShort(spec.width.toShort()); b.putShort(spec.height.toShort()) // width/height (16-bit)
        b.putInt(0x00480000); b.putInt(0x00480000)      // h/v resolution 72dpi
        b.putInt(0)                                     // reserved
        b.putShort(1)                                   // frame_count
        b.put(ByteArray(12))                            // compressorname
        b.putShort(0x0018)                              // depth
        b.putShort(-1)                                  // pre_defined (-1)
        b.putInt(avcC.size)                             // avcC box size
        b.put(avcC)
        return box("stsd", wrapStsd(box("avc1", b.array())))
    }

    // v6.7.140 (必修1): 构造 HEVC hvc1 sample entry + hvcC box。
    // HEVCDecoderConfigurationRecord: VPS/SPS/PPS 通常合并在 csd-0(length-prefixed Annex-B NAL),
    // 解析出三个 NAL 后按 3GPP TS 26.123 组装。
    private fun buildStsdHevc(spec: RepairSpec): ByteArray {
        val csd0 = spec.videoCsd0 ?: return buildStsdAvc(spec)
        val hvcC = try { buildHvcC(csd0) } catch (_: Exception) {
            // 解析失败退 AVC,保证至少产出一个可尝试打开的文件
            return buildStsdAvc(spec)
        }
        // hvc1 sample entry (ISO/IEC 14496-12, Annex C)
        val b = ByteBuffer.allocate(86 + hvcC.size).order(ByteOrder.BIG_ENDIAN)
        b.put(ByteArray(6))                             // reserved
        b.putShort(1)                                   // data_reference_index
        b.putShort(0); b.putShort(0)                    // pre_defined, reserved
        b.putInt(0); b.putInt(0); b.putInt(0)           // pre_defined[3]
        b.putShort(spec.width.toShort()); b.putShort(spec.height.toShort()) // width/height (16-bit)
        b.putInt(0x00480000); b.putInt(0x00480000)      // h/v resolution 72dpi
        b.putInt(0)                                     // reserved
        b.putShort(1)                                   // frame_count
        b.put(ByteArray(32))                            // compressorname (空)
        b.putShort(0x0018)                              // depth
        b.putShort(-1)                                  // pre_defined (-1)
        b.putInt(0); b.putInt(0); b.putInt(0)           // pre_defined (hvc1 额外 12 字节)
        b.putInt(hvcC.size)                             // hvcC box size
        b.put(hvcC)
        return box("stsd", wrapStsd(box("hvc1", b.array())))
    }

    // v6.7.140 (必修1): 从 csd-0 中解析 VPS/SPS/PPS 并构造 HEVCDecoderConfigurationRecord (hvcC)。
    // csd-0 通常是 length-prefixed Annex-B NAL 序列 (4字节长度+NAL payload),兼容纯 Annex-B
    // (以 00 00 00 01 或 00 00 01 起始码开头)也通过剥离前导零字节处理。
    private fun buildHvcC(csd0: ByteArray): ByteArray {
        val nalus = extractNalusFromCsd(csd0)
        var vps: ByteArray? = null
        var sps: ByteArray? = null
        var pps: ByteArray? = null
        for (n in nalus) {
            if (n.size < 2) continue
            val nalType = (n[1].toInt() ushr 1) and 0x3F
            when (nalType) {
                32 -> if (vps == null) vps = n
                33 -> if (sps == null) sps = n
                34 -> if (pps == null) pps = n
            }
        }
        if (sps == null) return buildHvcCFallback()
        val profile = sps[2].toInt() and 0xFF
        val tier = (sps[3].toInt() and 0x80) shr 7
        val level = sps[4].toInt() and 0xFF
        // parallelismType=0, chromaFormat=1(4:2:0), bitDepthLuma=8, bitDepthChroma=8
        // avgFrameRate=0, constantFrameRate=0
        val lenBuf = ByteBuffer.allocate(4).order(ByteOrder.BIG_ENDIAN)
        val payload = java.io.ByteArrayOutputStream()
        // general_profile_space / tier_flag / general_profile_idc / general_level_idc
        payload.write(0); payload.write(tier); payload.write(profile); payload.write(level)
        payload.write(0xFC); payload.write(0); payload.write(0); payload.write(0) // 6bits+reserved
        payload.write(1); payload.write(1); payload.write(8); payload.write(8) // chromaFormat=1, bitDepth*
        payload.write(0); payload.write(0) // avgFrameRate=0, constantFrameRate=0
        // numOfArrays=3
        payload.write(3)
        for (arr in listOf(vps to 32, sps to 33, pps to 34)) {
            val nalu = arr.first ?: continue
            payload.write(1); payload.write(1) // array_completeness=1, reserved=0
            lenBuf.clear(); lenBuf.putInt(nalu.size); payload.write(lenBuf.array())
            payload.write(nalu)
        }
        return box("hvcC", payload.toByteArray())
    }

    // v6.7.140 (必修1): 解析失败时的保守 hvcC。profile=Main(1), level=30,
    // VPS/SPS/PPS 写空 NAL 让播放器能打开文件(画质退化为最低要求)。
    private fun buildHvcCFallback(): ByteArray {
        val payload = java.io.ByteArrayOutputStream()
        payload.write(0); payload.write(0); payload.write(1); payload.write(30) // profile=Main, level=30
        payload.write(0xFC); payload.write(0); payload.write(0); payload.write(0)
        payload.write(1); payload.write(1); payload.write(8); payload.write(8)
        payload.write(0); payload.write(0)
        payload.write(3)
        for ((_, _) in listOf(32 to true, 33 to true, 34 to true)) {
            payload.write(1); payload.write(1)
            payload.write(0); payload.write(0); payload.write(0); payload.write(0) // 0-length NAL
        }
        return box("hvcC", payload.toByteArray())
    }

    // v6.7.140 (必修1): 从 csd 字节中提取 length-prefixed (4B length+NAL) 或
    // Annex-B (00 00 00 01 / 00 00 01 起始码)格式的 NAL 列表。
    private fun extractNalusFromCsd(csd: ByteArray): List<ByteArray> {
        val result = mutableListOf<ByteArray>()
        var i = 0
        while (i < csd.size) {
            // 查找起始码: 优先 00 00 00 01 (4B), 其次 00 00 01 (3B)
            val startLen = when {
                i + 4 <= csd.size && csd[i] == 0.toByte() && csd[i+1] == 0.toByte() &&
                    csd[i+2] == 0.toByte() && csd[i+3] == 1.toByte() -> 4
                i + 3 <= csd.size && csd[i] == 0.toByte() && csd[i+1] == 0.toByte() &&
                    csd[i+2] == 1.toByte() -> 3
                else -> 0
            }
            if (startLen == 0) { i++; continue }
            var end = -1
            var j = i + startLen
            while (j + 4 <= csd.size) {
                if (csd[j] == 0.toByte() && csd[j+1] == 0.toByte() && csd[j+2] == 0.toByte() && csd[j+3] == 1.toByte()) {
                    end = j; break
                }
                j++
            }
            if (end < 0) end = csd.size
            result.add(csd.copyOfRange(i, end))
            i = end
        }
        return result
    }

    private fun wrapStsd(sampleEntry: ByteArray): ByteArray {
        val w = ByteBuffer.allocate(8 + sampleEntry.size).order(ByteOrder.BIG_ENDIAN)
        w.putInt(0); w.putInt(1)                        // version_flags, entry_count
        w.put(sampleEntry)
        return w.array()
    }

    private fun buildAvcC(csd0: ByteArray, csd1: ByteArray): ByteArray {
        val sps = if (csd0.size > 4) csd0.copyOfRange(4, csd0.size) else csd0
        val pps = if (csd1.size > 4) csd1.copyOfRange(4, csd1.size) else csd1
        val profile = if (sps.size > 1) sps[1].toInt() and 0xFF else 66
        val compat = if (sps.size > 2) sps[2].toInt() and 0xFF else 0
        val level = if (sps.size > 3) sps[3].toInt() and 0xFF else 10
        val b = ByteBuffer.allocate(7 + 3 + sps.size + 3 + pps.size).order(ByteOrder.BIG_ENDIAN)
        b.put(1)                                        // configurationVersion
        b.put(profile.toByte())
        b.put(compat.toByte())
        b.put(level.toByte())
        b.put(0xFF.toByte())                            // lengthSizeMinusOne=3
        b.put(0xE1.toByte())                            // 1 SPS
        b.putShort(sps.size.toShort()); b.put(sps)
        b.put(1.toByte())                               // 1 PPS
        b.putShort(pps.size.toShort()); b.put(pps)
        return box("avcC", b.array())
    }

    private fun buildAudioStsd(spec: RepairSpec): ByteArray {
        val esds = buildEsds(spec.audioCsd0)
        val b = ByteBuffer.allocate(36 + esds.size).order(ByteOrder.BIG_ENDIAN)
        b.put(ByteArray(6))
        b.putShort(1)                                   // data_reference_index
        b.putShort(0); b.putShort(0); b.putShort(0)     // reserved
        b.putShort(2); b.putShort(16)                   // channelcount, samplesize
        b.putShort(0); b.putShort(0)                    // pre_defined, reserved
        b.putInt(spec.sampleRate shl 16)                // samplerate 16.16
        b.putInt(esds.size)
        b.put(esds)
        return box("stsd", wrapStsd(box("mp4a", b.array())))
    }

    private fun buildEsds(audioCsd0: ByteArray?): ByteArray {
        val asc = audioCsd0 ?: ByteArray(2)
        // DecoderSpecificInfo
        val dsiPayload = concat(byteArrayOf(0x05), sizeOfDesc(asc.size), asc)
        // DecoderConfigDescriptor
        val dcdBody = ByteBuffer.allocate(13 + dsiPayload.size).order(ByteOrder.BIG_ENDIAN)
        dcdBody.put(0x40)                               // objectTypeIndication = MPEG-4 Audio
        dcdBody.put(0x15)                               // streamType=Audio<<2 | reserved1
        dcdBody.put(ByteArray(3))                       // bufferSizeDB (0)
        dcdBody.put(ByteArray(4))                       // maxBitrate
        dcdBody.put(ByteArray(4))                       // avgBitrate
        dcdBody.put(dsiPayload)
        val dcdPayload = dcdBody.array()
        val dcd = concat(byteArrayOf(0x04), sizeOfDesc(dcdPayload.size), dcdPayload)
        // SLConfigDescriptor
        val slc = byteArrayOf(0x06, 0x01, 0x02)
        // ES_Descriptor
        val esBody = concat(dcd, slc)
        val es = concat(byteArrayOf(0x03), sizeOfDesc(esBody.size), esBody)
        // esds = version_flags(4) + ES_Descriptor
        val vf = ByteBuffer.allocate(4 + es.size).order(ByteOrder.BIG_ENDIAN)
        vf.putInt(0); vf.put(es)
        return box("esds", vf.array())
    }

    

    private fun sizeOfDesc(size: Int): ByteArray {
        return if (size < 0x80) byteArrayOf(size.toByte())
        else byteArrayOf(((size shr 7) or 0x80).toByte(), (size and 0x7F).toByte())
    }

    private fun buildStts(samples: List<SampleSpec>, video: Boolean, spec: RepairSpec, timescale: Int): ByteArray {
        val single = if (video) (spec.fps.takeIf { it > 0 }?.let { 1_000_000L / it } ?: 40_000L)
            else if (spec.sampleRate > 0) (1_000_000L * 1024 / spec.sampleRate) else 46_440L
        val deltas = ArrayList<Long>()
        for (i in samples.indices) {
            val d = if (i < samples.size - 1)
                (samples[i + 1].ptsUs - samples[i].ptsUs).coerceAtLeast(1L)
            else single.coerceAtLeast(1L)
            deltas.add(ticks(d, timescale).coerceAtLeast(1L))
        }
        val body = ByteBuffer.allocate(8 + deltas.size * 8).order(ByteOrder.BIG_ENDIAN)
        body.putInt(0)
        body.putInt(deltas.size)
        for (d in deltas) { body.putInt(1); body.putInt(d.toInt()) }
        return box("stts", body.array())
    }

    private fun buildStsc(count: Int): ByteArray {
        val b = ByteBuffer.allocate(20).order(ByteOrder.BIG_ENDIAN)
        b.putInt(0)
        b.putInt(1)
        b.putInt(1); b.putInt(1); b.putInt(1)          // first_chunk=1, samples_per_chunk=1, desc_index=1
        return box("stsc", b.array())
    }

    private fun buildStsz(samples: List<SampleSpec>): ByteArray {
        val b = ByteBuffer.allocate(20 + samples.size * 4).order(ByteOrder.BIG_ENDIAN)
        b.putInt(0)
        b.putInt(0)                                     // sample_size=0 (variable)
        b.putInt(samples.size)
        for (s in samples) b.putInt(s.size)
        return box("stsz", b.array())
    }

    // v6.7.150 (BUG-1): 样本绝对偏移超 32 位(合并产物 >4GiB,含 mdatStart 基)时改用 co64,
    // 否则 stco 的 putInt(o.toInt()) 溢出成错误偏移,播放器读错样本。修复单文件路径偏移恒小,
    // 走原 32 位 stco 分支(兼容既有输出)。
    private fun buildStco(offsets: List<Long>): ByteArray {
        if (offsets.any { it > 0xFFFFFFFFL }) {
            val b64 = ByteBuffer.allocate(16 + offsets.size * 8).order(ByteOrder.BIG_ENDIAN)
            b64.putInt(0)
            b64.putInt(offsets.size)
            for (o in offsets) b64.putLong(o)
            return box("co64", b64.array())
        }
        val b = ByteBuffer.allocate(16 + offsets.size * 4).order(ByteOrder.BIG_ENDIAN)
        b.putInt(0)
        b.putInt(offsets.size)
        for (o in offsets) b.putInt(o.toInt())
        return box("stco", b.array())
    }

    // ==================== helpers ====================
    private fun box(type: String, payload: ByteArray): ByteArray {
        val b = ByteBuffer.allocate(8 + payload.size).order(ByteOrder.BIG_ENDIAN)
        b.putInt(8 + payload.size)
        b.put(type.toByteArray(Charsets.ISO_8859_1))
        b.put(payload)
        return b.array()
    }

    private fun concat(parts: List<ByteArray>): ByteArray {
        val n = parts.fold(0) { a, p -> a + p.size }
        val out = ByteArray(n)
        var off = 0
        for (p in parts) { System.arraycopy(p, 0, out, off, p.size); off += p.size }
        return out
    }

    private fun concat(vararg parts: ByteArray): ByteArray = concat(parts.asList())

    private fun ticks(us: Long, ts: Int): Long = if (ts > 0) us * ts / 1_000_000L else 0L

    private fun u32(b: ByteArray, off: Int): Long =
        ((b[off].toLong() and 0xFF) shl 24) or ((b[off + 1].toLong() and 0xFF) shl 16) or
            ((b[off + 2].toLong() and 0xFF) shl 8) or (b[off + 3].toLong() and 0xFF)

    private fun u64(b: ByteArray, off: Int): Long = (u32(b, off) shl 32) or u32(b, off + 4)

    private fun selfCheck(): String {
        val checks = StringBuilder()
        var tmpF: java.io.File? = null
        var idxF: java.io.File? = null
        try {
            val idxOut = java.io.ByteArrayOutputStream()
            val t = Tracker(true,
                ByteArray(10) { 1 }, ByteArray(8) { 2 }, 60, 1920, 1080,
                true, ByteArray(4) { 3 }, 48000, 2, 0, idxOut)
            t.appendSample(true, 120, 0, true)
            t.appendSample(false, 64, 23220, true)
            t.appendSample(true, 90, 16667, false)
            t.appendSample(false, 60, 46440, true)
            t.appendSample(true, 80, 33334, false)
            t.closeDiscard()
            val idxBytes = idxOut.toByteArray()
            tmpF = java.io.File.createTempFile("mrp", ".recording.tmp")
            idxF = java.io.File.createTempFile("mrp", ".idx")
            idxF.writeBytes(idxBytes)
            tmpF.writeBytes(buildFakeKilledFile(120 + 64 + 90 + 60 + 80))

            val spec = readIndex(idxF)
            checks.appendLine("samples=${spec.samples.size} expected=5 got=${spec.samples.size}")
            checks.appendLine("fps=${spec.fps} w=${spec.width} h=${spec.height} sr=${spec.sampleRate}")
            val r = repair(tmpF.absolutePath, idxF)
            checks.appendLine("repair=$r")
            val repFile = File("${tmpF.absolutePath}.repaired")
            checks.appendLine("repaired_size=${if (repFile.exists()) repFile.length() else -1}")
            checks.appendLine("has_moov=${indexOfWord(repFile.readBytes(), "moov".toByteArray()) >= 0}")
            checks.appendLine("has_stco=${indexOfWord(repFile.readBytes(), "stco".toByteArray()) >= 0}")

            // 断言
            val sb = StringBuilder()
            sb.appendLine("=== Mp4Repairer self-check ===")
            sb.append(checks)
            val pass = r.ok && r.repaired &&
                spec.samples.size == 5 &&
                repFile.exists() &&
                indexOfWord(repFile.readBytes(), "moov".toByteArray()) >= 0
            sb.appendLine("RESULT=${if (pass) "PASS" else "FAIL"}")
            // v6.7.149 (FIX-A): 一并跑分片合并自检,让单一 selfCheck 入口同时覆盖 repair 与 merge。
            sb.appendLine(selfCheckMerge())
            // v6.7.155: isPlayableFile 自检——构造两临时文件:一个带 moov 头应为可播,
            // 一个仅 ftyp 无 moov 应为损坏。assert 触发即 FAIL。
            var okF: java.io.File? = null; var badF: java.io.File? = null
            try {
                okF = java.io.File.createTempFile("pl_ok", ".mp4").apply {
                    writeBytes(byteArrayOf(0,0,0,24, 'f'.code.toByte(),'t'.code.toByte(),'y'.code.toByte(),'p'.code.toByte()) + "moov".toByteArray())
                }
                badF = java.io.File.createTempFile("pl_bad", ".mp4").apply {
                    writeBytes(byteArrayOf(0,0,0,24, 'f'.code.toByte(),'t'.code.toByte(),'y'.code.toByte(),'p'.code.toByte()) + "mdat".toByteArray())
                }
                val plOk = isPlayableFile(okF.absolutePath)
                val plBad = isPlayableFile(badF.absolutePath)
                sb.appendLine("=== Mp4Repairer playable self-check ===")
                sb.appendLine("ok_file=${if (plOk) "true" else "false"} bad_file=${if (plBad) "true" else "false"}")
                if (!plOk || plBad) sb.appendLine("RESULT=FAIL") else sb.appendLine("RESULT=PASS")
            } finally { okF?.delete(); badF?.delete() }
            return sb.toString()
        } finally {
            tmpF?.delete(); idxF?.delete()
            File("${tmpF?.absolutePath}.repaired").delete()
        }
    }

    // v6.7.149 (FIX-A): mergeSegments 自检。构造两个"已封口分片"(ftyp+mdat)+各自的 .idx,
    // 断言合并产物结构合法:含 ftyp/mdat/moov/stco/stsz/stts,mdat 载荷等于各片之和,
    // stco 全部落在合并 mdat 载荷区间内(越界即 stco 指向错位)。任一断言不过即 FAIL。
    private fun selfCheckMerge(): String {
        val sb = StringBuilder("=== Mp4Repairer merge self-check ===")
        var s1: java.io.File? = null; var i1: java.io.File? = null
        var s2: java.io.File? = null; var i2: java.io.File? = null
        var out: java.io.File? = null
        try {
            fun makeSeg(samples: List<Triple<Boolean, Int, Long/*ptsUs*/>>, bytes: Int, csd0: ByteArray): Triple<java.io.File, java.io.File, Long> {
                val idxOut = java.io.ByteArrayOutputStream()
                val t = Tracker(true, csd0, ByteArray(8) { 2 }, 60, 1920, 1080,
                    true, ByteArray(4) { 3 }, 48000, 2, 0, idxOut)
                for ((isV, size, pts) in samples) t.appendSample(isV, size, pts, true)
                t.closeDiscard()
                val sf = java.io.File.createTempFile("seg", ".mp4")
                sf.writeBytes(buildFakeKilledFile(bytes))
                val if_ = java.io.File.createTempFile("segi", ".idx")
                if_.writeBytes(idxOut.toByteArray())
                return Triple(sf, if_, bytes.toLong())
            }
            val csd0 = ByteArray(12) { 0x67.toByte() }
            val (sf1, if1, b1) = makeSeg(
                listOf(Triple(true, 120, 0L), Triple(false, 64, 0L), Triple(true, 90, 16667L)),
                120 + 64 + 90, csd0)
            val (sf2, if2, b2) = makeSeg(
                listOf(Triple(true, 100, 0L), Triple(true, 80, 16667L), Triple(false, 56, 23220L)),
                100 + 80 + 56, csd0)
            s1 = sf1; i1 = if1; s2 = sf2; i2 = if2
            out = java.io.File.createTempFile("merged", ".mp4")
            val merged = mergeSegments(listOf(Pair(if1, sf1), Pair(if2, sf2)), out.absolutePath)
            sb.appendLine("merged_null=${merged == null}")
            fun f(file: java.io.File?): Boolean = file != null && file.exists() && file.length() > 0L
            sb.appendLine("merged_exists=${f(merged)}")
            val data = merged?.readBytes()
            val hasMDat = data != null && indexOfWord(data, "mdat".toByteArray()) >= 0
            val hasMoov = data != null && indexOfWord(data, "moov".toByteArray()) >= 0
            val hasStco = data != null && indexOfWord(data, "stco".toByteArray()) >= 0
            val hasStsz = data != null && indexOfWord(data, "stsz".toByteArray()) >= 0
            val hasStts = data != null && indexOfWord(data, "stts".toByteArray()) >= 0
            sb.appendLine("mdat=$hasMDat moov=$hasMoov stco=$hasStco stsz=$hasStsz stts=$hasStts")
            val total = b1 + b2
            sb.appendLine("sample_total=$total merged_size=${data?.size}")
            var stcoOk = false
            var largesizeOk = false
            if (data != null) {
                val mdatIdx = indexOfWord(data, "mdat".toByteArray())
                // v6.7.150 (BUG-1): mdat 改用 64 位 largesize 盒头(size=1|"mdat"|8字节长度),
                // 载荷起点 = "mdat" 类型串之后 12 字节,而非 32 位盒头的 +8。
                val mdatStart = mdatIdx + 12
                largesizeOk = mdatIdx >= 4 && data[mdatIdx - 1].toInt() == 1 &&
                    data[mdatIdx - 2].toInt() == 0 && data[mdatIdx - 3].toInt() == 0 && data[mdatIdx - 4].toInt() == 0
                val offs = readStcoOffsets(data)
                stcoOk = offs.isNotEmpty() && offs.all { it >= mdatStart && it < mdatStart + total }
                sb.appendLine("stco_count=${offs.size} stco_in_bounds=$stcoOk largesize=$largesizeOk mdatStart=$mdatStart")
            }
            val pass = merged != null && hasMDat && hasMoov && hasStco && hasStsz && hasStts &&
                stcoOk && largesizeOk
            sb.appendLine("RESULT_MERGE=${if (pass) "PASS" else "FAIL"}")
            return sb.toString()
        } finally {
            s1?.delete(); i1?.delete(); s2?.delete(); i2?.delete(); out?.delete()
        }
    }

    // v6.7.122: NAL 扫描修复自检。构造 ftyp+mdat 含 SPS/PPS/SEI/IDR + N 个 P 帧, 验证 scanAccessUnits/repairByScan。
    private fun selfCheckScan(): String {
        val sb = StringBuilder("=== Mp4Repairer scan self-check ===")
        var tmpF: java.io.File? = null
        var idxF: java.io.File? = null
        try {
            // 1) 用 Tracker 写合法头部(.idx): 60fps 1920x1080 纯视频。
            val idxOut = java.io.ByteArrayOutputStream()
            val t = Tracker(true, ByteArray(16) { 5 }, ByteArray(8) { 6 }, 60, 1920, 1080,
                false, null, 0, 0, 0, idxOut)
            t.flushHeader()
            idxF = java.io.File.createTempFile("mrp", ".idx")
            idxF.writeBytes(idxOut.toByteArray())

            // 2) 合成 AVCC 流: 每帧一个 slice(first_mb=0), SPS+PPS 仅首帧前。
            val nal = ArrayList<ByteArray>()
            nal.add(int(0x67, 1, 2, 3)); nal.add(int(0x68, 4, 5))
            val frameCount = 3
            for (i in 0 until frameCount) {
                nal.add(int(0x06, 0x01))            // SEI
                if (i == 0) nal.add(int(0x65, 0x80)) // IDR first_mb=0
                else nal.add(int(0x41, 0x80))        // P   first_mb=0
            }
            val mdat = java.io.ByteArrayOutputStream()
            for (n in nal) {
                val len = n.size
                mdat.write((len ushr 24) and 0xFF); mdat.write((len ushr 16) and 0xFF)
                mdat.write((len ushr 8) and 0xFF); mdat.write(len and 0xFF)
                mdat.write(n)
            }
            val ftyp = box("ftyp", "isom".toByteArray(Charsets.ISO_8859_1) + byteArrayOf(0, 0, 0, 1) +
                "isom".toByteArray(Charsets.ISO_8859_1))
            val file = ftyp + box("mdat", mdat.toByteArray())
            tmpF = java.io.File.createTempFile("mrp", ".recording.tmp")
            tmpF.writeBytes(file)

            // 3) mdat 起止。
            val md = scanMdat(tmpF)
            val samples = scanAccessUnits(tmpF, md.dataStart, md.byteLen, 1_000_000L / 60)
            sb.appendLine("scanSamples=${samples.size} expected=$frameCount")

            // 4) 整条 repairByScan 链路。
            lastScanSampleCount = -1
            val r = repairByScan(tmpF.absolutePath, idxF)
            val rep = File(tmpF.absolutePath + ".repaired")
            sb.appendLine("scanRepair=$r samples=${lastScanSampleCount}")
            sb.appendLine("scanRepaired=${rep.exists()} size=${if (rep.exists()) rep.length() else -1}")
            sb.appendLine("scanHasMoov=${if (rep.exists()) indexOfWord(rep.readBytes(), "moov".toByteArray()) >= 0 else false}")

            // v6.7.124 (Bug1 回归): stco 必须指向真实 AU 起点(旧逻辑按累计尺寸推导,跳过
            // SPS/PPS/SEI 前导字节导致 stco 指向错位偏移,修复后解码出垃圾)。
            val stco = if (rep.exists()) readStcoOffsets(rep.readBytes()) else LongArray(0)
            val offsOk = stco.size >= samples.size && samples.indices.all { stco[it] == md.dataStart + samples[it].offset }
            sb.appendLine("stco=${stco.toList()} auOffsets=${samples.map { md.dataStart + it.offset }} offsOk=$offsOk")

            val pass = samples.size == frameCount && r.ok && r.repaired && rep.exists() &&
                lastScanSampleCount == frameCount && indexOfWord(rep.readBytes(), "moov".toByteArray()) >= 0 && offsOk
            sb.appendLine("RESULT=${if (pass) "PASS" else "FAIL"}")
            return sb.toString()
        } finally {
            tmpF?.delete(); idxF?.delete()
            File("${tmpF?.absolutePath}.repaired").delete()
        }
    }

    private fun int(vararg b: Int): ByteArray = ByteArray(b.size) { b[it].toByte() }

    // v6.7.122: NAL 扫描自检验证 readUe 失败时的容错路径(所有 VCL NAL 当作单片帧)。
    private fun selfCheckScanFallback(): String {
        val sb = StringBuilder("=== Mp4Repairer scan fallback self-check ===")
        var tmpF: java.io.File? = null
        var idxF: java.io.File? = null
        try {
            val idxOut = java.io.ByteArrayOutputStream()
            val t = Tracker(true, ByteArray(16) { 5 }, ByteArray(8) { 6 }, 30, 868, 1920,
                false, null, 0, 0, 0, idxOut)
            t.flushHeader()
            idxF = java.io.File.createTempFile("mrp", ".idx")
            idxF.writeBytes(idxOut.toByteArray())
            // 每个 VCL NAL payload 全是 0x00, readUe 返回 -1 → 每个 NAL 当成独立帧。
            val nal = ArrayList<ByteArray>()
            val frameCount = 4
            for (i in 0 until frameCount) {
                nal.add(int(0x06, 0x01))       // SEI
                nal.add(int(0x41) + ByteArray(5) { 0 })  // P-slice, payload=all-zero → readUe=-1
            }
            val mdat = java.io.ByteArrayOutputStream()
            for (n in nal) {
                val len = n.size
                mdat.write((len ushr 24) and 0xFF); mdat.write((len ushr 16) and 0xFF)
                mdat.write((len ushr 8) and 0xFF); mdat.write(len and 0xFF)
                mdat.write(n)
            }
            val ftyp = box("ftyp", "isom".toByteArray(Charsets.ISO_8859_1) + byteArrayOf(0, 0, 0, 1) +
                "isom".toByteArray(Charsets.ISO_8859_1))
            val file = ftyp + box("mdat", mdat.toByteArray())
            tmpF = java.io.File.createTempFile("mrp", ".recording.tmp")
            tmpF.writeBytes(file)
            val r = repairByScan(tmpF.absolutePath, idxF)
            val rep = File(tmpF.absolutePath + ".repaired")
            sb.appendLine("scanRepair=$r samples=${lastScanSampleCount}")
            sb.appendLine("scanRepaired=${rep.exists()} hasMoov=${if (rep.exists()) indexOfWord(rep.readBytes(), "moov".toByteArray()) >= 0 else false}")
            val pass = r.ok && r.repaired && rep.exists() && lastScanSampleCount == frameCount
            sb.appendLine("RESULT=${if (pass) "PASS" else "FAIL"}")
            return sb.toString()
        } finally {
            tmpF?.delete(); idxF?.delete()
            File("${tmpF?.absolutePath}.repaired").delete()
        }
    }

    private fun buildFakeKilledFile(totalSampleBytes: Int): ByteArray {
        val ftyp = box("ftyp", "isom".toByteArray(Charsets.ISO_8859_1) + byteArrayOf(0, 0, 0, 1) +
            "isom".toByteArray(Charsets.ISO_8859_1) + "avc1".toByteArray(Charsets.ISO_8859_1))
        val mdatData = ByteArray(totalSampleBytes) { 0xAA.toByte() }
        val mdat = box("mdat", mdatData)
        return ftyp + mdat
    }

    /** 解析首个 stco box 的 chunk 偏移表(绝对文件偏移)。用于 selfCheckScan 验证 Bug1:
     * scan 修复后 stco 必须指向真实访问单元起点(mdatStart+auStart),而非按累计尺寸推导的错位偏移。 */
    private fun readStcoOffsets(data: ByteArray): LongArray {
        val i = indexOfWord(data, "stco".toByteArray())
        if (i < 0) return LongArray(0)
        var p = i + 4 + 4                       // skip tag + version_flags + entry_count prefix
        if (p + 4 > data.size) return LongArray(0)
        val entryCount = u32(data, p).toInt()
        p += 4
        val out = ArrayList<Long>(entryCount)
        for (k in 0 until entryCount) {
            if (p + 4 > data.size) break
            out.add(u32(data, p)); p += 4
        }
        return out.toLongArray()
    }

    private fun indexOfWord(haystack: ByteArray, needle: ByteArray): Int {
        outer@ for (i in 0..haystack.size - needle.size) {
            for (j in needle.indices) if (haystack[i + j] != needle[j]) continue@outer
            return i
        }
        return -1
    }

    /** v6.7.155: 轻量产物可播放性校验。MediaMuxer 正常 stop 的 mp4，moov 在文件头
     *  (faststart)或文件尾；被杀重建的 mp4 moov 追加在 mdat 之后。读文件头 64KB + 尾 1MB
     *  找 "moov" 即可判定，不用整文件 readBytes 占内存。返回 true 表示找到 moov 索引。
     *  供 recordToHistory 入库时校验，损坏产物置 playable=false 并在历史显示"已损坏"。 */
    fun isPlayableFile(path: String): Boolean {
        return try {
            val f = java.io.File(path)
            if (!f.exists() || f.length() < 24) return false
            java.io.RandomAccessFile(f, "r").use { ra ->
                var hasMoov = false
                // 头 64KB(ftyp + faststart 的 moov 通常在此)
                val headLen = minOf(64 * 1024L, ra.length())
                val head = ByteArray(headLen.toInt())
                ra.seek(0); ra.readFully(head)
                if (indexOfWord(head, "moov".toByteArray()) >= 0) hasMoov = true
                // 尾 1MB(moov 在 mdat 之后的重建产物)
                if (!hasMoov) {
                    val tailLen = minOf(1L * 1024 * 1024, ra.length())
                    val tail = ByteArray(tailLen.toInt())
                    ra.seek(ra.length() - tailLen); ra.readFully(tail)
                    if (indexOfWord(tail, "moov".toByteArray()) >= 0) hasMoov = true
                }
                hasMoov
            }
        } catch (_: Exception) { false }
    }
    // kotlin.text.minOf fallback
    private fun minOf(a: Long, b: Long): Long = if (a < b) a else b
}