package com.monkeycode.screenrecorder

import android.content.Context
import android.os.Build
import android.os.Handler
import android.os.HandlerThread
import android.os.SystemClock
import android.util.Log
import com.monkeycode.screenrecorder.BuildConfig
import java.io.File
import java.io.FileWriter
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import java.util.concurrent.ConcurrentLinkedQueue
import java.util.concurrent.atomic.AtomicInteger

/**
 * 轻量诊断日志：内存缓冲 + 后台线程批量落盘。
 * 运行期所有模块（服务/引擎/悬浮窗/UI/未捕获崩溃）统一写入同一份按天归档的日志文件，
 * 导出一个文件即可覆盖全部信息。
 *
 * v6.7.87: P0-2 重写 —— 消除热路径开销(诊断报告定位的卡顿帮凶)：
 *  - 缓冲改为 Entry 对象并配 AtomicInteger 计数，替代原本 O(n) 的 queue.size();
 *  - wallclock/date 格式化延迟到落盘线程，且复用 ThreadLocal 的 SimpleDateFormat,
 *    不再每行 new SimpleDateFormat;
 *  - 达到缓冲上限时把 flush 投递到后台线程执行,不再在调用线程内同步 flush。
 */
object DiagLog {
    private const val TAG = "DiagLog"
    private const val BUFFER_LIMIT = 512          // 内存缓冲条数，达到即触发落盘
    private const val FLUSH_INTERVAL_MS = 500L    // 兜底：每 500ms 落盘一次
    // 内存缓冲硬上限:即使日志线程未启动(从未 start)也防止 queue 无限增长
    private const val MAX_QUEUE_CAPACITY = 8192

    private class Entry(
        val uptime: Long,
        val thread: String,
        val tag: String?,
        val msg: String
    )

    private val queue = ConcurrentLinkedQueue<Entry>()
    // 用原子计数替代 queue.size() 的 O(n) 遍历(v6.7.87 P0-2)
    private val count = AtomicInteger(0)
    private var writer: FileWriter? = null
    private var diagFile: File? = null
    private var thread: HandlerThread? = null
    private var handler: Handler? = null
    private var started = false
    // v6.7.107 (D1): 区分"从未 start"与"已 stop"两种语义。stop() 时置位;
    // logCrash 只在 everStopped 时跳过。首次录制前的崩溃此前被 !started 守卫误拦,
    // 而这类启动期崩溃恰恰最需要日志证据。
    private var everStopped = false

    // wallclock/date 格式化只在落盘线程复用,避免逐行 new SimpleDateFormat(v6.7.87 P0-2)
    private val TIME_FMT: ThreadLocal<SimpleDateFormat> = object : ThreadLocal<SimpleDateFormat>() {
        override fun initialValue() = SimpleDateFormat("HH:mm:ss.SSS", Locale.getDefault())
    }
    private val DATE_FMT: ThreadLocal<SimpleDateFormat> = object : ThreadLocal<SimpleDateFormat>() {
        override fun initialValue() = SimpleDateFormat("yyyy-MM-dd", Locale.getDefault())
    }

    // 统计指标
    private var maxUpdateViewLayoutMs = 0L
    private var lastMoveElapsed = 0L
    private var moveCount = 0
    private var moveGapMaxMs = 0L
    private var lastOnProgressElapsed = 0L
    private var onProgressMinGapMs = Long.MAX_VALUE
    private var lastLogFlushMs = 0L

    @Synchronized
    fun start(context: Context) {
        // v6.7.109 (B1): everStopped 曾只在 stop() 置位而 start() 不复位,clearLogs 的
        // stop->start 重开会令崩溃日志永久丢失。重启后须复位,仅当本会话确实 stop 才跳过。
        everStopped = false
        if (started) return
        try {
            if (contextRef == null) contextRef = context.applicationContext
            ensureWriterLocked()
            thread = HandlerThread("DiagLogThread").apply { start() }
            handler = Handler(thread!!.looper)
            handler?.postDelayed(flushRunnable, FLUSH_INTERVAL_MS)
            started = true
            val ver = try { BuildConfig.VERSION_NAME } catch (_: Throwable) { "unknown" }
            val device = Build.MANUFACTURER + " " + Build.MODEL + " (sdk=" + Build.VERSION.SDK_INT + ")"
            val availMemMb = try {
                val mi = android.app.ActivityManager.MemoryInfo()
                val am = context.getSystemService(Context.ACTIVITY_SERVICE) as android.app.ActivityManager
                am.getMemoryInfo(mi)
                (mi.availMem / 1024 / 1024).toString()
            } catch (_: Throwable) { "?" }
            log("=== diag session start === version=$ver device=$device availMem=${availMemMb}MB wallclock=${System.currentTimeMillis()} uptime=${SystemClock.uptimeMillis()}")
            log("=== session boundary ===")
        } catch (e: Exception) {
            started = false
            android.util.Log.e(TAG, "start failed", e)
            try {
                // logDir 有 filesDir 兜底必然可写，把失败原因落盘，导出时能拿到
                val dir = ScreenRecorderApp.logDir(context)
                java.io.File(dir, "diag_start_error.txt").appendText(
                    java.text.SimpleDateFormat("yyyyMMdd_HHmmss", java.util.Locale.US).format(java.util.Date()) +
                    " start failed: $e\n"
                )
            } catch (_: Exception) {}
        }
    }

    /** 记录时是否受 BuildConfig.DEBUG 门控。
     * release 构建下为 false 时所有 log() 调用被静默跳过，导致诊断日志为空。
     * 关闭门控以保证 release 版也能排查录屏故障；配合内存缓冲 + 批量落盘，
     * 不会造成逐条磁盘 I/O。 */
    private const val GATED_BY_DEBUG = false

    /** 追加一条未捕获崩溃记录到主日志文件，并同步落盘。
     * 崩溃处理必须在进程终止前保证写盘，故不走内存缓冲队列，直接同步写入；
     * 若尚未调用 start()，则懒加载打开当天文件，保证崩溃记录始终落在同一主日志文件。
     * v6.7.100 (B5): 已 stop 后不再重新打开 writer。旧实现在 logCrash 里调
     * ensureWriterLocked(),若 stop() 已经把 writer 置 null,会重新创建 FileWriter
     * 并留在静态字段里无人 close(崩溃后进程一般退出会释放,但短暂泄漏 + 与
     * started=false 不一致会误导后续 log 调用)。若 stop 已执行则直接返回 null,
     * 由异常处理器决定是否走系统 log 兜底。
     * v6.7.107 (D1): 用 everStopped 区分"已 stop"与"从未 start"。首次录制前
     * (未 start) 发生的崩溃此前被 !started 守卫全部丢弃,这类启动期崩溃恰恰最
     * 需要日志;现仅 everStopped 时才跳过,未启动时仍懒加载写盘。 */
    @JvmStatic
    @Synchronized
    fun logCrash(threadName: String, stackTrace: String, recordState: String, lastError: String):
        java.io.File? {
        try {
            if (everStopped) {
                android.util.Log.e(TAG, "logCrash skipped: DiagLog stopped, not reopening writer")
                return null
            }
            ensureWriterLocked()
            val w = writer ?: return null
            val ts = SystemClock.uptimeMillis()
            val format = java.text.SimpleDateFormat("HH:mm:ss.SSS", Locale.getDefault())
            val wc = format.format(Date())
            w.append("[$ts][$threadName] === UNCAUGHT EXCEPTION === wallclock=$wc\n")
            w.append("[$ts][$threadName] Thread: $threadName\n")
            w.append("[$ts][$threadName] RecordState: $recordState\n")
            w.append("[$ts][$threadName] lastError: $lastError\n")
            stackTrace.split("\n").forEach { w.append("[$ts][$threadName] $it\n") }
            w.append("[$ts][$threadName] === END ===\n")
            w.flush()
            return diagFile
        } catch (e: Exception) {
            android.util.Log.e(TAG, "logCrash error", e)
            return null
        }
    }

    /** 确保 writer 已打开（懒初始化，供 start() 与 logCrash() 共用）。调用方需持锁。
     * v6.7.45: 增加按大小轮转 —— DiagLog 每 500ms flush 一次,长时间录制(2400h)单文件会
     * 无限增长耗尽存储并拖慢 IO。超过 MAX_FILE_BYTES(20MB) 即滚到带序号的新文件,
     * 保留最近若干段,超龄自动删除,防止日志本身吃掉磁盘。 */
    private const val MAX_FILE_BYTES = 20L * 1024 * 1024      // 20MB 单文件上限
    private const val MAX_ROTATED_FILES = 5                   // 最多保留 5 个(含当前)
    private const val ROTATE_SUFFIX = ".rot"
    // v6.7.107 (D2): 主文件保留天数,超龄的 diag_*.log 在主文件 rollover 时一并清理
    private const val MAX_LOG_KEEP_DAYS = 7

    @Synchronized
    private fun rolloverIfNeededLocked() {
        val f = diagFile ?: return
        val day = SimpleDateFormat("yyyyMMdd", Locale.US).format(Date())
        val ver = try { BuildConfig.VERSION_NAME } catch (_: Throwable) { "unknown" }
        // v6.7.102 (B9): 双重触发条件——(1) 文件超 MAX_FILE_BYTES,(2) 日期与文件名中的
        // 日期段不一致(跨天)。旧逻辑只在 size 阈值上触发,跨天时 diagFile 仍指向昨天的
        // 文件、且 ensureWriterLocked 因 writer 非空直接 return,新内容全部 append 到
        // "昨天"文件里;若此时达到 20MB 才滚动,新文件用当天日期但归档清理取前 5 个
        // lastModified,同一日期不同秒级可能互相冲掉,昨天的超大文件永远不进归档列表。
        val sameDay = f.name.contains("_$day.log") || f.name.contains("_$day.$ROTATE_SUFFIX")
        if (f.length() < MAX_FILE_BYTES && sameDay) return
        try {
            writer?.flush()
            writer?.close()
        } catch (_: Exception) {}
        // 归档名加秒级时间戳保证全局唯一,即使同一日期多段 rollover 也不冲撞。
        val ts = SimpleDateFormat("HHmmssSSS", Locale.US).format(Date())
        val archived = File(f.parentFile, "diag_${ver}_${day}_$ts$ROTATE_SUFFIX")
        try {
            if (f.exists()) f.renameTo(archived)
        } catch (_: Exception) {}
        diagFile = File(dirName, "diag_${ver}_$day.log")
        try {
            writer = FileWriter(diagFile, true)
        } catch (_: Exception) {
            writer = null
        }
        // 清理过期文件:保留最新的 MAX_ROTATED_FILES 个 .rot 归档
        try {
            val archivedList = (dirName.listFiles { _, n -> n.endsWith(ROTATE_SUFFIX) } ?: emptyArray<File>())
                .sortedByDescending { it.lastModified() }
            for (i in MAX_ROTATED_FILES until archivedList.size) {
                archivedList[i].delete()
            }
        } catch (_: Exception) {}
        // v6.7.107 (D2): 跨天前退出的主文件(未触发 rollover 的 diag_*.log)永不清理,
        // 日志目录按"每天最多一个主文件"无界增长(每文件 20MB,数月可累计数百 MB)。
        // 此处删除 mtime 早于 MAX_LOG_KEEP_DAYS 天且非当前 diagFile 的主文件。
        try {
            val cutoff = System.currentTimeMillis() - MAX_LOG_KEEP_DAYS * 86400_000L
            val mainFiles = dirName.listFiles { _, n -> n.startsWith("diag_") && n.endsWith(".log") }
                ?: emptyArray<File>()
            for (f in mainFiles) {
                if (f != diagFile && f.lastModified() < cutoff) {
                    f.delete()
                }
            }
        } catch (_: Exception) {}
    }

    private var dirName: java.io.File = java.io.File(".")

    private fun ensureWriterLocked() {
        if (writer != null && diagFile != null) {
            // v6.7.102 (B9): 无条件调 rolloverIfNeededLocked,内部按 size 与日期一致性
            // 双重判定是否真的需要滚动,不需在此处短路 return。
            rolloverIfNeededLocked()
            return
        }
        val ctx = contextRef ?: return
        val dir = ScreenRecorderApp.logDir(ctx)
        dirName = dir
        if (!dir.exists()) dir.mkdirs()
        val day = SimpleDateFormat("yyyyMMdd", Locale.US).format(Date())
        val ver = try { BuildConfig.VERSION_NAME } catch (_: Throwable) { "unknown" }
        diagFile = File(dir, "diag_${ver}_$day.log")
        writer = FileWriter(diagFile, true)
    }

    /** 供日志句需要 context 的场景暂存，仅初始化一次 */
    private var contextRef: Context? = null
    var appContext: Context
        get() = contextRef ?: error("DiagLog appContext not initialized")
        set(value) { contextRef = value.applicationContext }

    @Synchronized
    fun stop() {
        if (!started) return
        started = false
        everStopped = true
        flushNow()
        try { writer?.close() } catch (_: Exception) {}
        writer = null
        handler?.removeCallbacksAndMessages(null)
        thread?.quitSafely()
        thread = null
        handler = null
        diagFile = null
    }

    @JvmStatic
    fun log(msg: String) {
        if (GATED_BY_DEBUG && !BuildConfig.DEBUG) return
        dropOldestIfFull()
        queue.add(Entry(SystemClock.uptimeMillis(), Thread.currentThread().name, null, msg))
        count.incrementAndGet()
        if (count.get() >= BUFFER_LIMIT) maybeScheduleFlush()
    }

    /** 带墙钟时间的单行日志，同时写 uptime 与 wallclock，用于需要精确时间佐证的事件。
     * v6.7.81 新增——供 UI 交互、权限流程、报错等需要"几点发生"证据的场景调用。 */
    @JvmStatic
    fun logEvent(tag: String, msg: String) {
        if (GATED_BY_DEBUG && !BuildConfig.DEBUG) return
        dropOldestIfFull()
        queue.add(Entry(SystemClock.uptimeMillis(), Thread.currentThread().name, tag, msg))
        count.incrementAndGet()
        if (count.get() >= BUFFER_LIMIT) maybeScheduleFlush()
    }

    // ================= v6.7.128 L1 帧级诊断环形缓冲 =================
    // 裁决2(日志分级):info/debug 只写内存环形缓冲、不落盘,零 IO 不影响性能;
    // warn/error 实时落盘(现有 logEvent/logDetail 通道)。崩溃或反馈时
    // dumpFrameDiag 把 L1 环形缓冲倒出,补全"release 全量可观测"。
    private const val FRAME_DIAG_BYTE_CAP = 512L * 1024L          // 512KB
    private val frameDiagQueue = ConcurrentLinkedQueue<String>()
    private val frameDiagBytes = AtomicInteger(0)

    /** 帧级诊断(高频,默认只写内存环形缓冲,不落盘)。调用方需要帧级证据落盘时
     *  应改用 logEvent/logDetail。对释放 buffer 等逐帧高频调用零 IO。 */
    @JvmStatic
    fun logFrameDiag(tag: String, msg: String) {
        val line = "[${SystemClock.uptimeMillis()}][${Thread.currentThread().name}][$tag] $msg"
        // v6.7.165: line.length 是字符数,含中文时低估字节数;按 UTF-8 实际字节计数。
        val bytes = line.toByteArray(Charsets.UTF_8).size
        frameDiagQueue.add(line)
        frameDiagBytes.addAndGet(bytes)
        var total = frameDiagBytes.get()
        // 达到硬上限丢最老,保留最近,防无限增长(与主 queue 的 dropOldestIfFull 同理念)
        while (total > FRAME_DIAG_BYTE_CAP) {
            val head = frameDiagQueue.poll() ?: break
            frameDiagBytes.addAndGet(-head.toByteArray(Charsets.UTF_8).size)
            total = frameDiagBytes.get()
        }
    }

    /** 倒出 L1 环形缓冲全部内容(供崩溃倒出/用户反馈收集)。倒后清空。
     *  以单块字符串返回,便于写入崩溃日志或导出。 */
    @JvmStatic
    fun dumpFrameDiag(): String {
        val sb = StringBuilder(frameDiagQueue.size * 48)
        var head = frameDiagQueue.poll()
        while (head != null) {
            sb.append(head).append('\n')
            // v6.7.165: 与 logFrameDiag 口径一致,按 UTF-8 实际字节减去
            frameDiagBytes.addAndGet(-head.toByteArray(Charsets.UTF_8).size)
            head = frameDiagQueue.poll()
        }
        return sb.toString()
    }

    /** 缓冲达到硬上限时丢弃最老的条目,保留最近日志,防止无限增长占用内存 */
    private fun dropOldestIfFull() {
        while (count.get() >= MAX_QUEUE_CAPACITY) {
            queue.poll()
            count.decrementAndGet()
        }
    }

    // v6.7.134: 内存压力分级清理入口。onTrimMemory 调用,把未落盘的诊断日志丢最老、
    // 保留最近 [keep] 条。轻量(无 IO、无锁竞争,ConcurrentLinkedQueue.poll O(1)),
    // 可安全在主线程调用。录制态由调用方按 level 决定是否更激进(不触碰编码器/缓冲/正在写入的 tmp)。
    fun trimQueue(keep: Int) {
        val n = count.get()
        if (n <= keep) return
        var drop = n - keep
        while (drop-- > 0) {
            if (queue.poll() == null) break
            count.decrementAndGet()
        }
        Log.w(TAG, "trimQueue to $keep (was $n)")
    }

    /** 达到缓冲上限时:后台线程已启动则投递到后台落盘,否则(从未 start)退化为同步 flush */
    private fun maybeScheduleFlush() {
        if (handler != null) {
            handler?.removeCallbacks(flushRunnable)
            handler?.post(flushRunnable)
        } else {
            flushNow()
        }
    }

    /** 记录一次 updateViewLayout 耗时，超阈值自动打点 */
    @JvmStatic
    fun recordUpdateViewLayoutMs(ms: Long) {
        if (ms > maxUpdateViewLayoutMs) maxUpdateViewLayoutMs = ms
        if (ms > 30) log("updateViewLayout_SLOW=${ms}ms peak=$maxUpdateViewLayoutMs")
    }

    /** 记录相邻 MOVE 事件间隔，超阈值自动打点 */
    @JvmStatic
    fun recordMoveGap(): Long {
        val now = SystemClock.uptimeMillis()
        val gap = if (lastMoveElapsed == 0L) 0L else now - lastMoveElapsed
        lastMoveElapsed = now
        moveCount++
        if (gap > moveGapMaxMs) moveGapMaxMs = gap
        if (gap > 100) log("MOVE_GAP=${gap}ms count=$moveCount peak=${moveGapMaxMs}ms")
        return gap
    }

    // v6.7.189 (P2-13): 手势起点复位。lastMoveElapsed 跨手势累计,首个 MOVE 会把
    // "上次手势结束到本次"的整段空档算成主线程卡顿,peak 一旦被污染就永久显示假值
    // (真机实测 38852ms)。在 ACTION_DOWN 首行调用,手势间空档不计入 MOVE 间隔。
    @JvmStatic
    fun resetMoveGap() { lastMoveElapsed = 0L; moveCount = 0 }

    /** 记录 onProgress 到达频率，间隔 <100ms 视为过频。
     * v6.7.87: 修复 lastOnProgressElapsed 仅在首次调用时赋值、其余次永不更新的 bug ——
     * 原逻辑每次都用同一首时间戳算间隔,gap 不断增大导致误报 onProgress_TOO_FREQ。 */
    @JvmStatic
    fun recordOnProgressGap(): Long {
        val now = SystemClock.uptimeMillis()
        val gap = if (lastOnProgressElapsed != 0L) now - lastOnProgressElapsed else 0L
        lastOnProgressElapsed = now
        if (gap != 0L) {
            if (gap < onProgressMinGapMs) onProgressMinGapMs = gap
            if (gap < 100) log("onProgress_TOO_FREQ gap=${gap}ms min=$onProgressMinGapMs")
        }
        return gap
    }

    @JvmStatic
    fun getDiagFilePath(): String = diagFile?.absolutePath ?: ""

    private val flushRunnable: Runnable = Runnable {
        flushNow()
        handler?.postDelayed(flushRunnable, FLUSH_INTERVAL_MS)
    }

    @Synchronized
    private fun flushNow() {
        try {
            val t0 = SystemClock.uptimeMillis()
            val w = writer ?: return
            val wcFmt = TIME_FMT.get()!!
            val dateFmt = DATE_FMT.get()!!
            var entry = queue.poll()
            while (entry != null) {
                count.decrementAndGet()
                val wc = wcFmt.format(Date())
                val line = if (entry.tag != null) {
                    val date = dateFmt.format(Date())
                    "[${entry.uptime}][$wc][$date][${entry.thread}][${entry.tag}] ${entry.msg}"
                } else {
                    "[${entry.uptime}][$wc][${entry.thread}] ${entry.msg}"
                }
                w.append(line).append('\n')
                entry = queue.poll()
            }
            w.flush()
            val spend = SystemClock.uptimeMillis() - t0
            if (spend > lastLogFlushMs) lastLogFlushMs = spend
            if (spend > 20) {
                android.util.Log.d(TAG, "flush overspeed ${spend}ms peak=$lastLogFlushMs")
            }
            // v6.7.101 (B2): 热路径也要触发文件大小滚动。旧实现 rollover 只在
            // ensureWriterLocked 里调,而热路径 log()/logEvent()/flushNow() 完全不经过
            // ensureWriterLocked,导致 MAX_FILE_BYTES 20MB 上限形同虚设,长时间录制
            // 单文件无限增长;.rot 归档清理也永不执行(v6.7.45 的修复意图未生效)。
            // 这里在 flush 完成后立即检查一次,与热路径节奏一致,单文件到达阈值即滚动。
            if (writer != null && diagFile != null) {
                rolloverIfNeededLocked()
            }
        } catch (e: Exception) {
            android.util.Log.e(TAG, "flush error", e)
        }
    }
}
