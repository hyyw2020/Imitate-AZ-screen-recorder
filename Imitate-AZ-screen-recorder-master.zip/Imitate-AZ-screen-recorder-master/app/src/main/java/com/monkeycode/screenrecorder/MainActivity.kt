package com.monkeycode.screenrecorder

import android.app.Activity
import android.content.BroadcastReceiver
import android.content.ClipData
import android.content.ClipboardManager
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.content.res.ColorStateList
import android.media.projection.MediaProjectionManager
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.os.Environment
import android.os.StatFs
import android.provider.Settings
import android.view.View
import android.view.WindowManager
import android.widget.Button
import android.widget.LinearLayout
import android.widget.TextView
import android.widget.Toast
import androidx.activity.ComponentActivity
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AppCompatDelegate
import androidx.core.content.ContextCompat
import com.google.android.material.dialog.MaterialAlertDialogBuilder
import java.io.File
import java.io.FileOutputStream
import java.util.zip.ZipEntry
import java.util.zip.ZipOutputStream

class MainActivity : ComponentActivity() {

    // v6.7.177 (P2-B): clearLogs 保留最近 N 份 diag_*.log。崩溃排障需要保留现场,
    // 全清会让"App 崩溃后用户再启动"时上一次现场消失。N=5 覆盖约一周的启动次数。
    private companion object {
        const val KEEP_DIAG_LOGS = 5
    }

    private lateinit var prefsManager: PreferencesManager
    private lateinit var historyManager: RecordingHistoryManager
    private var currentConfig = RecorderConfig()
    // v6.7.190 (P1-2): dpi 不再硬编码 320。旧值与真机 560 不符,且会被 Service 原样
    // 传进 RecorderConfig 打日志,造成"配置 320 / 实际 560"的口径矛盾。改取设备真实 dpi;
    // 引擎侧 createVirtualDisplay 仍按 realDpi×scale 派生,两处同源。
    private var currentQuality = QualityParams(
        1920, 1080, 60, 24_000_000, 128_000, resources.displayMetrics.densityDpi)
    // v6.7.101 (B7): effectiveBitrate 已迁移到 ScreenRecorderApp.effectiveBitrate
    // 全局字段,Activity 回收重建后仍能恢复,不再用 Activity 私有字段。
    private var isDarkMode = false
    private var isRecording = false
    private var isReceiverRegistered = false
    // v6.7.50: 记录上次已提示的录制错误,onStart 时若 lastError 有新增内容则 Toast,
    // 让用户感知录制失败(如磁盘满/编码器错误),避免静默失败无提示。
    private var lastShownError: String? = null
    // v6.7.65: Bug4 悬浮窗权限被拒跳设置后的"待授权"标记。
    // 置位后 onStart/onResume 复查仍缺权限时,按钮显示"待授权"并禁用,引导用户重新开始。
    private var pendingOverlayGrant = false
    // v6.7.81: 上次已记录的主按钮可见状态,用于变化时打点,避免每次刷新重复刷日志。
    private var lastUiButtonState: String? = null

    private val mediaProjectionLauncher = registerForActivityResult(
        ActivityResultContracts.StartActivityForResult()
    ) { result ->
        val data = result.data
        DiagLog.logEvent("PERM", "mediaProjection result code=${result.resultCode} dataNull=${data == null}")
        android.util.Log.d("MainActivity", "mediaProjection result: code=${result.resultCode} dataNull=${data == null}")
        // 授权数据已全程存入全局,由 service 独立重建 MediaProjection。
        // 注意:即使 Activity 在授权对话框期间被系统回收(isDestroyed),用户刚完成授权
        // 回到前台,此时仍应启动服务;跳过会导致"录制约1秒即停+无日志"。后台启动限制
        // 的防护放在 startPrepareService 内部 try-catch,而非用 isDestroyed 阻断整个流程。
        if (result.resultCode == RESULT_OK && data != null) {
            ScreenRecorderApp.pendingResultCode = result.resultCode
            // v6.7.51: 用 Intent(data) 深拷贝 extras,避免浅拷贝 clone() 共享 mExtras
            // 引用导致的 MediaProjection token 丢失(浅拷贝下 bundle 共享,反序列化时
            // token 可能失效 -> service 重建投影失败 -> projection==null -> 无日志自停)。
            ScreenRecorderApp.pendingResultData = Intent(data)
            ScreenRecorderApp.pendingMediaProjection = null
            startServiceWithProjection()
        } else {
            // v6.7.90 (P3-4.7): 取消授权补结构化日志,区分"用户主动取消"与"系统拒绝/授权丢失"。
            // v6.7.190 (P0-7): 两类反馈分开提示,并把 recordState 复位到 IDLE。
            // resultCode==RESULT_CANCELED 是用户点了系统弹窗的"取消",dataNull==true 是
            // 系统根本没回数据(授权被拒/超时)。旧实现只有一条 Toast 且不区分,
            // 也不复位状态,表现为"点了没反应",首录失败时会被当成 App 卡死。
            DiagLog.logEvent("PERM",
                "mediaProjection canceled code=${result.resultCode} dataNull=${data == null} " +
                    "resultOk=${result.resultCode == RESULT_OK}")
            android.util.Log.w("MainActivity", "mediaProjection cancelled or no data")
            if (!isFinishing && !isDestroyed) {
                Toast.makeText(this,
                    if (data == null) "未获得录屏授权（系统未返回数据），请重试并选择\"立即开始\""
                    else "录屏授权被取消，已回到待机状态",
                    Toast.LENGTH_LONG).show()
                ScreenRecorderApp.recordState = RecordState.IDLE
                updateRecordingState()
            }
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        prefsManager = PreferencesManager(this)
        // v6.7.101 (B1): 使用进程级单例,避免与 Service 侧各自持独立内存快照
        // 造成跨实例覆盖(用户删除/清空可能被 Service 下次 add 用旧内存复活)。
        historyManager = RecordingHistoryManager.get(this)

        // v6.7.129 (A): 深色三态——由 AppCompatDelegate.setDefaultNightMode 驱动,
        // uiMode 资源限定符自动解析 token,不再手动选 Theme_ScreenRecorder_Dark。
        applySavedNightMode()
        isDarkMode = isNightNow(this)
        currentConfig = prefsManager.loadConfig()
        // v6.7.107 (U1): 恢复上次画质设置。旧实现 currentQuality 只在内存,配置变更后
        // 全部回落默认值,用户选好的分辨率/帧率/码率/方向静默丢失。
        currentQuality = prefsManager.loadQuality()

        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        applyTheme()
        setupViews()
        updatePreviewCard()
        updateSettingsValues()
        loadRecentHistory()
        updateFreeSpace()
        // v6.7.188g: 冷启动轻量 GC(60s 节流 + 内存列表,无目录扫描)
        StorageGc.maybeGc(this)
        // v6.7.81: 主界面全部可见元素初始值统一落日志,便于"页面上看到什么,日志里就能佐证对应值"。
        DiagLog.logEvent("UI", "onCreate done dark=$isDarkMode audio=${currentConfig.audioMode} " +
            "res=${currentQuality.width}x${currentQuality.height}@${currentQuality.frameRate} " +
            "bitrate=${currentQuality.videoBitRate} orient=${currentQuality.orientation} " +
            "state=${ScreenRecorderApp.recordState} lastError=${ScreenRecorderApp.lastError ?: "null"}")
        // v6.7.146 (P2-8): 首次启动引导。纯文案 3 步,不内置视频(体积敏感)。
        // 借鉴剪映 ScreenRecordGuideDialog。标记写入后不再重复。
        if (!prefsManager.isGuideShown()) {
            showFirstRunGuide()
            prefsManager.setGuideShown()
        }
    }

    // v6.7.146 (P2-8): 3 步纯文案新手引导,连续 3 个 MessageDialog 串联,
    // 最后「开始使用」关闭。复用 MaterialAlertDialogBuilder,无新依赖。
    private fun showFirstRunGuide() {
        val steps = listOf(
            "第 1 步：点击「开始录制」即可录屏。录制前可先设置倒计时与时长上限。",
            "第 2 步：录制中悬浮球可暂停/继续/停止，也可用摇一摇快速停止。",
            "第 3 步：录制完成后可在历史中分享、重命名、添加备注或导出。"
        )
        fun showStep(idx: Int) {
            if (idx >= steps.size) return
            MaterialAlertDialogBuilder(this)
                .setTitle("欢迎使用 (${idx + 1}/${steps.size})")
                .setMessage(steps[idx])
                .setPositiveButton(if (idx == steps.size - 1) "开始使用" else "下一步") { _, _ ->
                    showStep(idx + 1)
                }
                .setNegativeButton("跳过", null)
                .setCancelable(false)
                .show()
        }
        showStep(0)
    }

    // v6.7.146 (P2-8): 录完一键分享最近一条录制。复用现有 shareVideo(entry)。
    private fun shareLatestRecording() {
        historyManager.reload()
        val latest = historyManager.getRecent(1).firstOrNull()
        if (latest != null) {
            shareVideo(latest)
        } else {
            Toast.makeText(this, "没有可分享的历史记录", Toast.LENGTH_SHORT).show()
        }
    }

    override fun onStart() {
        super.onStart()
        val filter = IntentFilter().apply {
            addAction(ScreenRecorderService.ACTION_HISTORY_CHANGED)
            addAction(ScreenRecorderService.ACTION_RECORDING_STOPPED)
            addAction(ScreenRecorderService.ACTION_RECORDING_STARTED)
            // v6.7.95 (P0): 暂停/恢复状态变更广播。Service 以自己为真相源广播真实状态,
            // Activity 收到后刷新按钮/横幅,消除此前暂停/恢复界面滞后最长 6.9s 的问题。
            addAction(ScreenRecorderService.ACTION_RECORD_STATE_CHANGED)
        }
        if (!isReceiverRegistered) {
            registerReceiver(historyReceiver, filter,
                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) RECEIVER_NOT_EXPORTED else 0)
            isReceiverRegistered = true
        }
        syncRecordingState()
        // v6.7.50: 若上次录制以失败收尾且错误信息未提示过,则 Toast 告知用户。
        // 幂等:用 lastShownError 记录已提示内容,避免每次 onStart 重复弹。
        val err = ScreenRecorderApp.lastError
        if (!err.isNullOrBlank() && err != lastShownError) {
            lastShownError = err
            Toast.makeText(this, "录制失败: ${err.lineSequence().firstOrNull()}", Toast.LENGTH_LONG).show()
        }
        updateFreeSpace()
    }

    // P1-1: onResume 复查悬浮窗权限——录制进行中(含从最近任务/通知栏恢复)若权限被回收,
    // 提示用户去开启;仅提示不中断,保持"即使无球也能录"的降级语义。
    override fun onResume() {
        super.onResume()
        // v6.7.180: 录制进行中保持本窗口屏幕常亮,与悬浮球窗口的 FLAG_KEEP_SCREEN_ON 双保险。
        // 纯窗口标志,零权限、零电池豁免;非录制态不加,避免本 App 空闲时也钉住屏幕。
        if (ScreenRecorderApp.recordState == RecordState.RECORDING) {
            window.addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
        }
        // v6.7.72: 无条件按全局状态刷新一次。用户停在主界面点停止时不会走
        // onStart/onRestart,若 ACTION_RECORDING_STOPPED 广播因任何原因丢失,
        // 这里是最后一道兜底,保证按钮不会永久停在"停止中…"。
        updateRecordingState()
        // v6.7.179: 历史面板刷新。receiver 在 onPause/onStop 注销,恢复前台后由
        // onResume 无条件重载,保证从锁屏/其他 App 返回、或录制结束后返回时列表为最新。
        loadRecentHistory()
        // v6.7.133: 检测被杀/崩溃中断残留, 自动恢复进历史(不弹 UI)。录制进行中原样跳过。
        autoRestoreStaleRecordings()
        try {
            // v6.7.65: 从悬浮窗权限设置页返回时,复查权限并复位「待授权」状态。
            // 已授权 -> 清除标记,按钮恢复「开始录制」;仍未授权 -> 保持「待授权」并提示引导,
            // 用户需重新点击开始录制(流程不会在授权后自动继续,明确提示避免误以为按钮异常)。
            if (pendingOverlayGrant) {
                if (Build.VERSION.SDK_INT < Build.VERSION_CODES.M || Settings.canDrawOverlays(this)) {
                    pendingOverlayGrant = false
                    updateRecordingState()
                } else {
                    updateRecordingState()
                    Toast.makeText(
                        this,
                        R.string.overlay_grant_required_toast,
                        Toast.LENGTH_LONG
                    ).show()
                }
            }
            val st = ScreenRecorderApp.recordState
            val active = st == RecordState.RECORDING || st == RecordState.PAUSED ||
                st == RecordState.STARTING || st == RecordState.PREPARING
            if (active && Build.VERSION.SDK_INT >= Build.VERSION_CODES.M
                && !Settings.canDrawOverlays(this)) {
                Toast.makeText(
                    this,
                    "悬浮窗权限已失效，录制悬浮球可能无法显示，请在设置中开启",
                    Toast.LENGTH_LONG
                ).show()
            }
        } catch (_: Exception) {
            // 权限复查失败不应影响 Activity 恢复
        }
    }

    private fun syncRecordingState() {
        // v6.7.49: 按钮状态唯一来源 = 全局 ScreenRecorderApp.recordState。
        // 去掉 STOPPING 视为 active(STOPPING 即已发起停止、不再录制),避免停止流程
        // 期间 onStart 把按钮状态错误覆盖回「停止录制」。统一由 updateRecordingState() 驱动。
        // v6.7.95: 之前 updateRecordingState() 被粘在第 170 行注释行尾,整行都是注释,
        // 函数体为空(编译通过但空转),导致用户从后台切回前台时 onStart 兜底刷新失效。
        updateRecordingState()
        // v6.7.101 (B7): 录制中切回前台时,同步 refresh 预览卡片。
        // 之前 effectiveBitrate 是 Activity 私有字段,重建后归 -1 且 STARTED 广播
        // 已发出不会重发,onStart 只 refresh 按钮不 refresh 预览 → UI 显示请求码率
        // 而非 clamp 后的实际值,与录制中真实参数脱钩。现在 effectiveBitrate 移入
        // 全局字段(ScreenRecorderApp.effectiveBitrate),此处顺带刷新预览让 UI 一致。
        updatePreviewCard()
    }

    // v6.7.49: 状态单一来源 —— 仅依据全局 recordState 刷新按钮文本与本地 isRecording。
    // 不再允许 stopRecording/onRecordingStopped/startPrepareService 各自直接 setText,
    // 消除「本地 isRecording + 按钮文本」与「全局 recordState」互相覆盖的竞态。
    private fun updateRecordingState() {
        val st = ScreenRecorderApp.recordState
        val active = st == RecordState.RECORDING || st == RecordState.PAUSED ||
            st == RecordState.STARTING || st == RecordState.PREPARING
        // v6.7.65: Bug4——悬浮窗权限被拒待授权中(且非录制/停止进行时),按钮显示「待授权」并禁用。
        // 与真实录制状态不冲突:录制已运行时优先显示「停止录制」。
        val waitingPermission = pendingOverlayGrant && !active && st != RecordState.STOPPING
        val startTextRes = when {
            st == RecordState.STOPPING -> R.string.stopping_recording
            waitingPermission -> R.string.pending_overlay_permission
            active -> R.string.stop_recording
            else -> R.string.start_recording
        }
        isRecording = active

        val btnStart = findViewById<Button>(R.id.btnStart)
        // v6.7.88 (Ch4): btnStart 双角色——空闲态="开始"(primary),录播态="停止"(stop_red)。
        // 点按行为见 handleStartRecording()(按 active 判定 start/stop),按钮角色与此一致。
        btnStart.text = getString(startTextRes)
        btnStart.isEnabled = st != RecordState.STOPPING && !waitingPermission
        val startColor = if (active && !waitingPermission && st != RecordState.STOPPING)
            R.color.stop_red else R.color.primary
        btnStart.backgroundTintList = ColorStateList.valueOf(ContextCompat.getColor(this, startColor))

        // v6.7.88 (Ch4): 暂停/继续按钮——仅录播中可见(暂停态显示"继续",录制态显示"暂停")。
        // 启动/准备/停止收尾/空闲态一律隐藏,避免无意义的可点项。
        val btnPause = findViewById<Button>(R.id.btnPause)
        val showPause = st == RecordState.RECORDING || st == RecordState.PAUSED
        btnPause.visibility = if (showPause) View.VISIBLE else View.GONE
        btnPause.text = getString(
            if (st == RecordState.PAUSED) R.string.resume_recording else R.string.pause_recording
        )
        btnPause.isEnabled = st == RecordState.RECORDING || st == RecordState.PAUSED

        // v6.7.88 (Ch4): 暂停横幅——录播暂停时提示用户点继续恢复。
        findViewById<View>(R.id.pausedBanner).visibility =
            if (st == RecordState.PAUSED) View.VISIBLE else View.GONE

        // STOPPING 或等待权限授权中均禁用按钮,避免触发无效操作

        // v6.7.188i: 门禁模型由"显式黑名单式清单"改为"默认全禁 + 白名单放行 + 拦截器兜底"。
        // 旧 14 行 findViewById 清单式写法,新增控件默认漏网(实测 10 个漏网项)。
        // 集中数组 + 遍历,ViewGroup.setEnabled 会递归到子 View(flAudioGrid 覆盖动态音频按钮)。
        val busy = isSessionBusy()
        for (id in SESSION_GATED_IDS) {
            findViewById<View>(id)?.isEnabled = !busy
        }
        // v6.7.188i: 门禁快照日志(宁可爆):每次会话态变化打印受门禁项的可点状态汇总
        if (busy != lastBusyLogged) {
            lastBusyLogged = busy
            val disabled = SESSION_GATED_IDS.count { findViewById<View>(it)?.isEnabled == false }
            DiagLog.logEvent("UI", "session_gate busy=$busy gated=${SESSION_GATED_IDS.size} disabledNow=$disabled state=${ScreenRecorderApp.recordState}")
        }
        // v6.7.188i: 状态流转埋点(含 busy 与白名单放行项)。
        val stNow = ScreenRecorderApp.recordState
        if (stNow != lastStateLogged) {
            lastStateLogged = stNow
            DiagLog.logEvent("UI", "state_change st=$stNow busy=$busy allowed=btnStart,btnPause")
        }

        // v6.7.81: 主按钮可见文本/可用态变化(含权限待授权、录制进行中等)落日志,
        // 帮助在日志中确证"页面按钮当时显示/可点为何值",并佐证状态流转时间。
        // v6.7.95: 扩展到覆盖 btnPause/pausedBanner/维护按钮——此前只记 btnStart 到日志,
        // 而恰好出问题的 btnPause 与 pausedBanner 一点痕迹都没有,只能靠配对反推。
        val pauseTxt = btnPause.text.toString()
        val bannerVisibility = findViewById<View>(R.id.pausedBanner).visibility
        if (lastUiButtonState !=
            "$startTextRes|$st|${btnStart.isEnabled}|${btnPause.visibility}|$pauseTxt|${btnPause.isEnabled}|$bannerVisibility|$busy") {
            lastUiButtonState =
                "$startTextRes|$st|${btnStart.isEnabled}|${btnPause.visibility}|$pauseTxt|${btnPause.isEnabled}|$bannerVisibility|$busy"
            DiagLog.logEvent("UI",
                "buttonState start='${getString(startTextRes)}'/$st/en=${btnStart.isEnabled} " +
                    "pause=vis${btnPause.visibility}/'$pauseTxt'/en=${btnPause.isEnabled} " +
                    "banner=$bannerVisibility maintEnabled=${!busy} gated=${SESSION_GATED_IDS.size}")
        }
    }

    // v6.7.74: 录制会话占用中(含 STOPPING 收尾窗口)。
    // 注意与 updateRecordingState() 里的 active 区分:active 刻意不含 STOPPING
    // (避免停止流程中把主按钮覆盖回「停止录制」),但维护类操作恰恰需要在
    // STOPPING 期间也保持禁用,故此处单独定义。
    // v6.7.188i: 集中声明受门禁 ID,新增控件必须在这里登记。
    // 说明:ViewGroup.setEnabled() 会经 dispatchSetEnabled 递归到子 View,
    // 故 flAudioGrid(动态音频按钮容器)放进来即可覆盖其全部子按钮。
    private val SESSION_GATED_IDS = intArrayOf(
        // 维护类
        R.id.btnExportLog, R.id.btnClearLog, R.id.btnClearAllVideos,
        // 输出/编码器
        R.id.cardOutput, R.id.cardEncoder,
        // 画质与编码
        R.id.settingsItemFps, R.id.settingsItemQuality, R.id.settingsItemResolution,
        R.id.settingsItemOrientation, R.id.settingsItemHevc, R.id.settingsItemCompressQuality,
        // 会话无关但会改 prefs 的设置项(v6.7.188i 补齐)
        R.id.settingsItemTheme, R.id.settingsItemCountdown, R.id.settingsItemDuration,
        R.id.settingsItemShake, R.id.settingsItemOverlayAlpha,
        // 限额
        R.id.settingsItemRecLimitBytes, R.id.settingsItemRecLimitDuration,
        // 开关
        R.id.swResumeProtect, R.id.swShowOverlay, R.id.swPowerSaveDowngrade,
        // 历史/修复
        R.id.rowStaleRepair, R.id.btnViewAll,
        // 音频来源容器(递归覆盖子按钮)
        R.id.flAudioGrid,
    )
    private var lastBusyLogged: Boolean? = null
    private var lastStateLogged: RecordState? = null

    private fun nameOf(id: Int): String =
        try { resources.getResourceEntryName(id) } catch (_: Exception) { id.toString() }

    /** v6.7.188i: 统一点击注册。会话中一律拦截并记日志——「默认禁点」的功能层保证。 */
    private fun bindClick(id: Int, action: () -> Unit) {
        findViewById<View>(id)?.setOnClickListener {
            if (isSessionBusy()) {
                DiagLog.logEvent("UI",
                    "click_blocked id=${nameOf(id)} state=${ScreenRecorderApp.recordState}")
                Toast.makeText(this, "录制进行中,该设置需在停止录制后修改", Toast.LENGTH_SHORT).show()
                return@setOnClickListener
            }
            DiagLog.logEvent("UI", "click id=${nameOf(id)} state=${ScreenRecorderApp.recordState}")
            action()
        }
    }

    /** v6.7.188i: 统一开关注册。会话中拦截,不写 prefs、不发 Intent,视觉回滚。 */
    private fun bindCheck(id: Int, initial: Boolean, onChecked: (Boolean) -> Unit) {
        (findViewById<View>(id) as? android.widget.CompoundButton)?.apply {
            setOnCheckedChangeListener(null)          // 先摘,避免初值赋值误触发
            isChecked = initial
            setOnCheckedChangeListener { _, checked ->
                if (isSessionBusy()) {
                    DiagLog.logEvent("UI",
                        "check_blocked id=${nameOf(id)} want=$checked state=${ScreenRecorderApp.recordState}")
                    isChecked = !checked              // 视觉回滚
                    return@setOnCheckedChangeListener
                }
                DiagLog.logEvent("UI", "check id=${nameOf(id)} -> $checked")
                onChecked(checked)
            }
        }
    }

    private fun isSessionBusy(): Boolean {
        val st = ScreenRecorderApp.recordState
        return st == RecordState.RECORDING || st == RecordState.PAUSED ||
            st == RecordState.STARTING || st == RecordState.PREPARING ||
            st == RecordState.STOPPING
    }

    override fun onStop() {
        super.onStop()
        // v6.7.180: 离开主窗口时清常亮标志,恢复系统自动熄屏;录制期由悬浮球窗口标志接管。
        window.clearFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
        if (isReceiverRegistered) {
            try { unregisterReceiver(historyReceiver) } catch (_: Exception) {}
            isReceiverRegistered = false
        }
    }

    override fun onDestroy() {
        super.onDestroy()
        // v6.7.144 (P0-1): 倒计时未结束就销毁 Activity,取消定时器防泄漏。
        cancelCountdown()
        // 兜底:若 Activity 未经 onStop 直接销毁(系统异常 kill 路径),
        // 确保 receiver 不泄漏
        if (isReceiverRegistered) {
            try { unregisterReceiver(historyReceiver) } catch (_: Exception) {}
            isReceiverRegistered = false
        }
    }

    // v6.7.129 (A): 系统 uiMode 变化(跟随系统态)时重刷主题 token(Material3 DayNight 自动重建,
    // 这里仅刷新显式设的背景色),避免浅<->深切换需等下次重建。
    override fun onConfigurationChanged(newConfig: android.content.res.Configuration) {
        val oldOrientation = resources.configuration.orientation
        super.onConfigurationChanged(newConfig)
        isDarkMode = isNightNow(this)
        applyTheme()
        // v6.7.177 (旋转方案A, 产品兜底): 画布方向 = 开录时方向(必剪/剪映同为锁定画布)。
        // 硬约束(Engine :5545 注释):VD 不可重建——API34+ 二次 createVirtualDisplay 会
        // SecurityException + 系统 onStop 杀掉录制;且 cleanupAndStop 无条件 projection.stop(),
        // 重启会话要重新授权。故录制中 90°/270° 旋转时画布方向不变,悬浮球由
        // RecordOverlay.onConfigurationChanged 自行重钳。此处把用户预期管住。
        if (oldOrientation != newConfig.orientation && ScreenRecorderApp.recordState == RecordState.RECORDING) {
            android.widget.Toast.makeText(
                this, "横竖屏切换不会改变录制画面方向", android.widget.Toast.LENGTH_SHORT
            ).show()
        }
    }

    private val historyReceiver = object : BroadcastReceiver() {
        override fun onReceive(context: Context, intent: Intent) {
            DiagLog.logEvent("UI", "historyReceiver action=${intent.action}")
            when (intent.action) {
                ScreenRecorderService.ACTION_RECORDING_STOPPED ->
                    onRecordingStopped(intent.getBooleanExtra(ScreenRecorderService.EXTRA_SAVED, false))
                // v6.7.65: Bug1 修复——录制真正开始时广播刷新按钮为「停止录制」,
                // 消除授权返回后按钮仍停在「开始录制」的竞态。
                // v6.7.89 (L-7): 顺带接收 clamp 后实际生效码率并刷到预览。
                ScreenRecorderService.ACTION_RECORDING_STARTED -> {
                    if (intent.hasExtra(ScreenRecorderService.EXTRA_EFFECTIVE_BITRATE)) {
                        // v6.7.101 (B7): 存到全局字段,Activity 回收重建后仍能恢复。
                        ScreenRecorderApp.effectiveBitrate = intent.getIntExtra(ScreenRecorderService.EXTRA_EFFECTIVE_BITRATE, -1)
                        updatePreviewCard()
                    }
                    // v6.7.128: 分辨率回显改用 encoder 实际输出值(等比 fit/clamp 后真实档位)。
                    if (intent.hasExtra(ScreenRecorderService.EXTRA_EFFECTIVE_WIDTH) &&
                        intent.hasExtra(ScreenRecorderService.EXTRA_EFFECTIVE_HEIGHT)) {
                        ScreenRecorderApp.effectiveWidth = intent.getIntExtra(ScreenRecorderService.EXTRA_EFFECTIVE_WIDTH, -1)
                        ScreenRecorderApp.effectiveHeight = intent.getIntExtra(ScreenRecorderService.EXTRA_EFFECTIVE_HEIGHT, -1)
                        updateSettingsValues()
                        updatePreviewCard()
                    }
                    updateRecordingState()
                }
                // v6.7.95 (P0): 暂停/恢复状态变更立即刷新。Service 已把 ScreenRecorderApp.recordState
                // 置为最新值,这里只调用 updateRecordingState(),让按钮/横幅与真实状态对齐。
                ScreenRecorderService.ACTION_RECORD_STATE_CHANGED -> updateRecordingState()
                else -> {
                    loadRecentHistory()
                    updateFreeSpace()
                }
            }
        }
    }

    private fun setupViews() {
        findViewById<Button>(R.id.btnStart).setOnClickListener { handleStartRecording() }
        // v6.7.88 (Ch4): 暂停/继续按钮。录播态点→暂停;暂停态点→恢复。
        findViewById<Button>(R.id.btnPause).setOnClickListener { handlePauseResume() }
        bindClick(R.id.cardOutput) { pickOutputDir() }
        bindClick(R.id.cardEncoder) { showEncoderDialog() }
        // v6.7.188 (【2】): 显示悬浮球开关——常驻球不录制,开关持久化到 prefs。
        // v6.7.188i: 走 bindCheck 拦截器,会话中拦截(收掉/重挂悬浮球会干扰录制)。
        bindCheck(R.id.swShowOverlay, prefsManager.isShowOverlayEnabled()) { checked ->
            if (checked) {
                if (!android.provider.Settings.canDrawOverlays(this)) {
                    findViewById<com.google.android.material.materialswitch.MaterialSwitch>(R.id.swShowOverlay).isChecked = false
                    prefsManager.setShowOverlayEnabled(false)
                    checkOverlayAndProceed()
                    return@bindCheck
                }
                prefsManager.setShowOverlayEnabled(true)
                startService(android.content.Intent(this, ScreenRecorderService::class.java).apply {
                    action = ScreenRecorderService.ACTION_SHOW_OVERLAY
                })
            } else {
                prefsManager.setShowOverlayEnabled(false)
                startService(android.content.Intent(this, ScreenRecorderService::class.java).apply {
                    action = ScreenRecorderService.ACTION_HIDE_OVERLAY
                })
            }
        }
        bindClick(R.id.settingsItemFps) { showFpsDialog() }
        bindClick(R.id.settingsItemQuality) { showQualityDialog() }
        bindClick(R.id.settingsItemResolution) { showResolutionDialog() }
        bindClick(R.id.settingsItemHevc) { toggleHevc() }
        // v6.7.161 (压缩画质模式): 开关——开启后分辨率/帧率/码率由引擎按必剪压缩形态托管。
        bindClick(R.id.settingsItemCompressQuality) { toggleCompressQuality() }
        bindClick(R.id.settingsItemOrientation) { showOrientationDialog() }
        bindClick(R.id.settingsItemTheme) { showThemeDialog() }
        // v6.7.144/145: 4 个新设置项(倒计时/时长上限/摇一摇/悬浮窗透明度)。
        bindClick(R.id.settingsItemCountdown) { showCountdownDialog() }
        bindClick(R.id.settingsItemDuration) { showDurationLimitDialog() }
        // v6.7.178 (⑥): 引擎级精确限额入口。
        bindClick(R.id.settingsItemRecLimitBytes) { showRecLimitBytesDialog() }
        bindClick(R.id.settingsItemRecLimitDuration) { showRecLimitDurationMsDialog() }
        bindClick(R.id.settingsItemShake) { showShakeDialog() }
        bindClick(R.id.settingsItemOverlayAlpha) { showOverlayAlphaDialog() }
        bindClick(R.id.btnViewAll) { showHistoryDialog() }
        bindClick(R.id.btnExportLog) { exportLogs() }
        bindClick(R.id.btnClearLog) { clearLogs() }
        bindClick(R.id.btnClearAllVideos) { clearAllVideos() }

        // v6.7.120: 被杀恢复保护开关——初值读持久化,变更即存;v6.7.188i 起走 bindCheck 拦截。
        bindCheck(R.id.swResumeProtect, prefsManager.isResumeProtectEnabled()) { checked ->
            prefsManager.setResumeProtectEnabled(checked)
            // v6.7.133: 开关变更时立即执行自动恢复(开关关→findStaleRecordings 静默删除残留)。
            autoRestoreStaleRecordings()
        }

        // v6.7.188h (改造2): 省电模式影响码率开关——默认开启(保持既有行为),关闭后
        // 省电模式不再触发浅降档(改造2 的 softPressure 失效)。
        bindCheck(R.id.swPowerSaveDowngrade, prefsManager.isAllowPowerSaveDowngrade()) { checked ->
            prefsManager.setAllowPowerSaveDowngrade(checked)
        }

        // v6.7.188i: setupViews 完成时打印一次全量门禁清单,便于静态核对是否漏登记。
        DiagLog.logEvent("UI", "gate_manifest ids=" + SESSION_GATED_IDS.joinToString(",") { nameOf(it) })

        val logDir = ScreenRecorderApp.logDir(this)
        val logFiles = logDir.listFiles() ?: emptyArray()
        val logPathText = logDir.absolutePath
        findViewById<TextView>(R.id.tvLogPath).text = "$logPathText (${logFiles.size} 个文件)"

        findViewById<TextView>(R.id.tvLogPath).setOnLongClickListener {
            try {
                val clipboard = getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager
                clipboard.setPrimaryClip(ClipData.newPlainText("log_path", logPathText))
                Toast.makeText(this, R.string.log_path_copied, Toast.LENGTH_SHORT).show()
            } catch (e: Exception) {
                Toast.makeText(this, "Copy failed: ${e.message}", Toast.LENGTH_SHORT).show()
            }
            true
        }

        setupAudioButtons()
        updateOutputPath()
        updateEncoderLabel()
    }

    // v6.7.133: 启动自动恢复——检测被杀/崩溃中断残留, 逐条重建 moov 为可播放 mp4 并写入历史,
    // 不弹任何 UI。修复失败的原样保留为 *_interrupted.mp4。开关关闭时 findStaleRecordings 静默删除全部残留。
    // 恢复写历史的时间戳用原始录制时间(从文件名解析 ScreenRecord_yyyyMMdd_HHmmss), 失败回退 tmp 最后修改时间,
    // 避免被杀旧录制排到新录制上方导致历史排序错乱。
    private fun autoRestoreStaleRecordings() {
        if (ScreenRecorderApp.recordState != RecordState.IDLE) {
            hideStaleRepairRow(); return
        }
        val enabled = prefsManager.isResumeProtectEnabled()
        Thread {
            if (enabled) {
                // v6.7.188c: 功能开启=只发现不修复。修复由用户到 RepairActivity 手动触发
                // (onResume 本函数即轻量刷新,返回主页自动重扫)。
                val orphans = try {
                    RecorderEngine.scanOrphans(this@MainActivity)
                } catch (e: Exception) { emptyList() }
                runOnUiThread { updateStaleRepairRow(orphans.size) }
                return@Thread
            }
            // 功能关闭:保持"静默清理残留"旧语义(不出现徽标行)。
            try {
                val stale = RecorderEngine.findStaleRecordings(this@MainActivity, false, skipActiveWindow = true)
                if (stale.isEmpty()) return@Thread
                var restored = 0
                var kept = 0
                for (f in stale) {
                    val o = RecorderEngine.restoreStale(this@MainActivity, f)
                    val playable = o.playable
                    if (playable != null) {
                        val safUri = try {
                            prefsManager.loadConfig().outputUri
                        } catch (_: Exception) { null }
                        val finalPath = if (safUri != null) {
                            val docUri = try {
                                RecorderEngine.exportFileToSaf(this@MainActivity, playable, safUri, playable.name)
                            } catch (_: Exception) { null }
                            if (docUri != null) {
                                RecorderEngine.safExportedSet(this@MainActivity, add = playable.absolutePath)
                                SafeDeleteUtil.delete(playable, "autoRestore_saf_exported")
                                docUri.toString()
                            } else playable.absolutePath
                        } else playable.absolutePath
                        historyManager.add(
                            RecordingEntry(
                                fileName = playable.name,
                                path = finalPath,
                                durationMs = o.durationMs,
                                sizeBytes = playable.length(),
                                width = o.width,
                                height = o.height,
                                timestamp = parseRecordingTimestamp(f.name)
                                    .let { if (it > 0L) it else f.lastModified() },
                                codecName = o.codecName
                            )
                        )
                        restored++
                    } else {
                        kept++
                    }
                }
                runOnUiThread {
                    loadRecentHistory()
                    updateFreeSpace()
                    if (restored > 0) {
                        android.widget.Toast.makeText(this@MainActivity,
                            "已保护并恢复 $restored 个上次未完成的录制",
                            android.widget.Toast.LENGTH_LONG).show()
                    }
                    if (kept > 0) {
                        android.widget.Toast.makeText(this@MainActivity,
                            "有 $kept 个残留文件损坏，已保留为 _interrupted.mp4",
                            android.widget.Toast.LENGTH_LONG).show()
                    }
                }
                android.util.Log.i("MainActivity", "autoRestoreStale restored=$restored kept=$kept")
            } catch (e: Exception) {
                android.util.Log.w("MainActivity", "autoRestoreStale error: ${e.message}", e)
                runOnUiThread {
                    android.widget.Toast.makeText(this@MainActivity,
                        "恢复上次录制时出错: ${e.message ?: "未知异常"}",
                        android.widget.Toast.LENGTH_LONG).show()
                }
            }
        }.start()
    }

    // v6.7.188c: 徽标行——发现残留时显示,点击进 RepairActivity 手动修复。
    private fun updateStaleRepairRow(n: Int) {
        val row = findViewById<View>(R.id.rowStaleRepair) ?: return
        if (n <= 0) { hideStaleRepairRow(); return }
        row.visibility = View.VISIBLE
        findViewById<TextView>(R.id.tvStaleRepair).text = "发现 $n 个待修复录制 · 点击处理"
        row.setOnClickListener {
            startActivity(android.content.Intent(this, RepairActivity::class.java))
        }
    }

    private fun hideStaleRepairRow() {
        findViewById<View>(R.id.rowStaleRepair)?.visibility = View.GONE
    }

    // v6.7.133: 从录制文件名解析原始时间戳。文件名格式 ScreenRecord_yyyyMMdd_HHmmss(.recording.tmp)。
    // 解析失败(格式不符)返回 -1, 调用方回退到 tmp 文件最后修改时间。
    private fun parseRecordingTimestamp(fileName: String): Long {
        val base = fileName.removeSuffix(".recording.tmp")
        val m = Regex("(?:_)?(\\d{8})_(\\d{6})").find(base) ?: return -1L
        return try {
            java.text.SimpleDateFormat("yyyyMMdd_HHmmss", java.util.Locale.US)
                .parse(m.groupValues[1] + "_" + m.groupValues[2])?.time ?: -1L
        } catch (_: Exception) { -1L }
    }

    private fun setupAudioButtons() {
        val container = findViewById<LinearLayout>(R.id.flAudioGrid)
        container.removeAllViews()
        AudioMode.entries.filter { it != AudioMode.AUTO }.forEach { mode ->
            val btn = Button(this)
            btn.text = mode.label
            btn.setTextSize(12f)
            btn.setPadding(8, 8, 8, 8)
            val lp = LinearLayout.LayoutParams(
                0,
                LinearLayout.LayoutParams.WRAP_CONTENT,
                1f
            )
            lp.setMargins(0, 0, 8, 0)
            btn.layoutParams = lp
            btn.isAllCaps = false
            val isSelected = currentConfig.audioMode == mode
            btn.setBackgroundResource(if (isSelected) R.drawable.audio_button_selected
                else R.drawable.audio_button_unselected)
            btn.setTextColor(if (isSelected) ContextCompat.getColor(this, R.color.mint_text)
                else ContextCompat.getColor(this, R.color.text_primary))
            btn.setOnClickListener {
                // v6.7.95: SET 日志带 recState,区分录制中/空闲时改动。
                DiagLog.logEvent("SET", "AUDIO_MODE=$mode recState=${ScreenRecorderApp.recordState}")
                currentConfig = currentConfig.copy(audioMode = mode)
                prefsManager.saveConfig(currentConfig)
                setupAudioButtons()
            }
            container.addView(btn)
        }
    }

    private fun pickOutputDir() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
            val intent = Intent(Intent.ACTION_OPEN_DOCUMENT_TREE).apply {
                addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION or
                        Intent.FLAG_GRANT_WRITE_URI_PERMISSION or
                        Intent.FLAG_GRANT_PERSISTABLE_URI_PERMISSION)
            }
            DiagLog.logEvent("OP", "pickOutputDir open doc tree sdk=${
                Build.VERSION.SDK_INT} currentUri=${currentConfig.outputUri}")
            safDirLauncher.launch(intent)
        } else {
            DiagLog.logEvent("OP", "pickOutputDir blocked sdk<Q sdk=${Build.VERSION.SDK_INT}")
            Toast.makeText(this, "Android 10+ required for custom output directory", Toast.LENGTH_SHORT).show()
        }
    }

    private val safDirLauncher = registerForActivityResult(ActivityResultContracts.StartActivityForResult()) { result ->
        if (result.resultCode == Activity.RESULT_OK) {
            result.data?.data?.let { uri ->
                DiagLog.logEvent("OP", "safPicker OK uri=${uri}")
                // v6.7.107 (U3): takePersistableUriPermission 在部分 ROM/文档提供者或
                // 用户经"最近文件"入口进入时不授予 persistable 权限会抛 SecurityException,
                // 回调在主线程直接执行,异常未捕获会致 Activity 崩溃,且崩溃前 outputUri
                // 已改但未保存导致状态不一致。包 try-catch,失败时 Toast 提示且不落盘。
                try {
                    contentResolver.takePersistableUriPermission(uri,
                        Intent.FLAG_GRANT_READ_URI_PERMISSION or Intent.FLAG_GRANT_WRITE_URI_PERMISSION)
                } catch (e: SecurityException) {
                    DiagLog.logEvent("OP", "safPicker persistable denied: ${e.message}")
                    Toast.makeText(this, "无该目录持久访问权限，请在文件管理器中选择目录", Toast.LENGTH_LONG).show()
                    return@let
                }
                currentConfig = currentConfig.copy(outputUri = uri)
                prefsManager.saveConfig(currentConfig)
                // v6.7.74: 明确告知存量归属。此前改目录后旧视频仍留在应用私有 Movies 目录,
                // 而历史条目仍指向旧绝对路径,用户会误以为"视频丢了"或"没迁移过去"。
                val oldDir = getExternalFilesDir(android.os.Environment.DIRECTORY_MOVIES)
                val oldCount = oldDir?.listFiles()
                    ?.count { it.isFile && it.name.endsWith(".mp4", ignoreCase = true) } ?: 0
                if (oldCount > 0) {
                    Toast.makeText(
                        this,
                        "原默认目录还有 $oldCount 个视频，不会自动移动，仍可在历史中查看",
                        Toast.LENGTH_LONG
                    ).show()
                }
                updateOutputPath()
            } ?: DiagLog.logEvent("OP", "safPicker OK but data null")
        } else {
            DiagLog.logEvent("OP", "safPicker canceled/ko code=${result.resultCode}")
        }
    }

    private fun updateOutputPath() {
        val path = findViewById<TextView>(R.id.tvOutputPath)
        path.text = if (currentConfig.outputUri != null) {
            try {
                val docId = android.provider.DocumentsContract.getTreeDocumentId(currentConfig.outputUri!!)
                val decoded = java.net.URLDecoder.decode(docId, "UTF-8")
                val displayPath = if (decoded.startsWith("primary:")) {
                    "/storage/emulated/0/${decoded.removePrefix("primary:")}"
                } else {
                    decoded
                }
                displayPath
            } catch (e: Exception) {
                currentConfig.outputUri.toString()
            }
        } else
            getString(R.string.output_default)
    }

    private fun updateEncoderLabel() {
        val label = findViewById<TextView>(R.id.tvEncoderLabel)
        val encoderName = prefsManager.selectedEncoder()
        label.text = encoderName ?: getString(R.string.encoder_auto)
    }

    private fun showEncoderDialog() {
        val encoders = RecorderEngine.listAllVideoEncoders()
        val names = encoders.toMutableList()
        names.add(0, getString(R.string.encoder_auto))
        val currentIdx = prefsManager.selectedEncoder()?.let { sel ->
            names.indexOfFirst { it == sel }.coerceAtLeast(0)
        } ?: 0

        MaterialAlertDialogBuilder(this)
            .setTitle(R.string.section_encoder)
            .setSingleChoiceItems(names.toTypedArray(), currentIdx) { dialog, which ->
                if (which == 0) prefsManager.setSelectedEncoder(null)
                else prefsManager.setSelectedEncoder(names[which])
                DiagLog.logEvent("SET", "ENCODER=${names[which]} recState=${ScreenRecorderApp.recordState}")
                updateEncoderLabel()
                dialog.dismiss()
            }
            .setNegativeButton(R.string.cancel, null)
            .show()
    }

    private fun showFpsDialog() {
        // v6.7.131: 帧率档位按当前分辨率裁切——4K 不显示 >60 档,2K 不显示 >120,1080P及以下全档。
        // 与分辨率切换联动(maxFpsForResolution)一致,避免用户选中无效组合。
        val maxFps = maxFpsForResolution(currentQuality.width, currentQuality.height)
        val allOptions = listOf("Auto", "144", "120", "90", "60", "50", "40", "30", "25", "20", "15")
        val options = allOptions.filter { it == "Auto" || (it.toIntOrNull() ?: 0) <= maxFps }
        // v6.7.100 (B1): Auto 语义为 frameRate=0,旧实现 indexOfFirst 找不到 Auto
        // (toIntOrNull() 为 null ≠ 0),回落到 index 0 恰好也是 "Auto",但语义不清;
        // 选择时把 "Auto" 兜底成 60,导致 Auto 选项从 UI 看得到但从未真正生效。
        // 现在显式区分 Auto(0) 与数字档位,Auto 保持 0 语义,交给引擎按屏幕刷新率自适应。
        val currentIdx = if (currentQuality.frameRate == 0) 0
            else options.indexOfFirst { it.toIntOrNull() == currentQuality.frameRate }.coerceAtLeast(0)
        DiagLog.logEvent("UI", "showFpsDialog current=${currentQuality.frameRate} maxFps=$maxFps")
        showBottomListDialog("帧率", options, currentIdx) { value ->
            val fps = if (value == "Auto") 0 else value.toIntOrNull() ?: 60
            currentQuality = currentQuality.copy(frameRate = fps)
            prefsManager.saveQuality(currentQuality)
            DiagLog.logEvent("SET", "FPS=$value($fps) recState=${ScreenRecorderApp.recordState}")
            updatePreviewCard()
            updateSettingsValues()
        }
    }

    private fun showQualityDialog() {
        val options = listOf("Auto", "80 Mbps", "72 Mbps", "64 Mbps", "56 Mbps", "48 Mbps", "40 Mbps", "32 Mbps", "24 Mbps", "16 Mbps", "12 Mbps", "10 Mbps", "8 Mbps", "6 Mbps", "4 Mbps", "2 Mbps", "1 Mbps")
        val bitrateValues = listOf(0, 80_000_000, 72_000_000, 64_000_000, 56_000_000, 48_000_000, 40_000_000, 32_000_000, 24_000_000, 16_000_000, 12_000_000, 10_000_000, 8_000_000, 6_000_000, 4_000_000, 2_000_000, 1_000_000)
        val currentIdx = bitrateValues.indexOf(currentQuality.videoBitRate).coerceAtLeast(0)
        DiagLog.logEvent("UI", "showQualityDialog current=${currentQuality.videoBitRate}")
        showBottomListDialog("视频质量", options, currentIdx) { value ->
            val idx = options.indexOf(value)
            val bitrate = bitrateValues.getOrElse(idx) { 24_000_000 }
            // v6.7.127 (S4): preferHevc 不再随码率 Auto 档强制绑定。旧实现 idx==0(Auto
            // 码率) 就把编码器硬切开 HEVC,码率语义与编码器选择被错误耦合。preferHevc
            // 现保持用户当前选择,由独立 HEVC 开关控制。
            currentQuality = currentQuality.copy(videoBitRate = bitrate)
            prefsManager.saveQuality(currentQuality)
            DiagLog.logEvent("SET", "BITRATE=${bitrate / 1_000_000}Mbps preferHevc=${currentQuality.preferHevc} recState=${ScreenRecorderApp.recordState}")
            updatePreviewCard()
            updateSettingsValues()
        }
    }

    // v6.7.127 (S4): 独立 HEVC 编码开关(不再随 Auto 码率强制绑定)。
    private fun toggleHevc() {
        currentQuality = currentQuality.copy(preferHevc = !currentQuality.preferHevc)
        prefsManager.saveQuality(currentQuality)
        DiagLog.logEvent("SET", "HEVC=${currentQuality.preferHevc} recState=${ScreenRecorderApp.recordState}")
        updateSettingsValues()
    }

    // v6.7.161 (压缩画质模式): 开关。开启后视频配置下的分辨率/帧率/码率由引擎按必剪压缩形态
    // 托管(见 ScreenRecorderService 的 qualityParams2 覆盖),此处只负责持久化与刷新 UI。
    // 默认关,开启不影响常规录制的画质/帧率。
    private fun toggleCompressQuality() {
        val next = !prefsManager.isCompressQualityEnabled()
        prefsManager.setCompressQualityEnabled(next)
        DiagLog.logEvent("SET", "COMPRESS_QUALITY=$next recState=${ScreenRecorderApp.recordState}")
        updatePreviewCard()
        updateSettingsValues()
    }

    private fun showResolutionDialog() {
        // v6.7.127 (S5): 加 2K/4K/屏幕原始分辨率档,参数放开的前置。服务层(≤屏幕 clamp)
        // 与引擎层(编码器能力 clamp)均放行这几档;UI 之前把分辨率上限钉死在 1080p,
        // 使 2K/4K 屏+旗舰 VPU 的能力无法被用户触达。
        // v6.7.174 (异形屏 P0): 参照系从 resources.displayMetrics(可用区)改为统一
        // ScreenRecorderApp.realScreenSize(物理整屏含 cutout),与服务层 clamp/fit 同口径,
        // 消除"预览撒谎"(本机 app 区 1200x2390 vs 物理屏 1200x2652)、选档后被 fit 改写。
        // 档位语义从"16:9 模板(1920x1080/1280x720…)"改为"短边档位":短边 480/540/720/1080/1440/
        // 原始,长边 = round(短边 × 屏幕真实比例) 再偶数对齐,标签直接显示实际等比尺寸,
        // 不再有"1080p"隐含 16:9 的承诺(现代 19.5:9~21:9 长条屏选 720p 即直观标 1280x2800)。
        val (realW, realH) = ScreenRecorderApp.realScreenSize(this)
        val shortEdge = minOf(realW, realH)
        val longEdge = maxOf(realW, realH)
        val aspect = if (shortEdge > 0) longEdge.toDouble() / shortEdge else 0.0
        // 短边档位:480/540/720/1080/1440/原始(短边)。长边按屏幕真实比例等比,再偶数对齐。
        val shortOptions = listOf(480, 540, 720, 1080, 1440).filter { it < shortEdge } +
            listOf(shortEdge)  // 最后补"原始(短边=真实短边)"
        val options = mutableListOf<String>()
        val resolutions = mutableListOf<QualityParams>()
        shortOptions.forEach { sh ->
            val lh = if (sh == shortEdge) longEdge
                else ((longEdge.toDouble() / shortEdge * sh) + 0.5).toInt().let {
                    if (it and 1 == 1) it + 1 else it }
            val isOriginal = sh == shortEdge && lh == longEdge
            val (outW, outH) = if (realW <= realH) sh to lh else lh to sh
            val label = if (isOriginal) "屏幕原始 (${outW}x${outH})"
                else "${outW}x${outH} (${sh}p 等比)"
            options += label
            resolutions += QualityParams(
                outW, outH, currentQuality.frameRate,
                currentQuality.videoBitRate, currentQuality.audioBitRate, resources.displayMetrics.densityDpi)
        }
        val currentIdx = resolutions.indexOfFirst { it.width == currentQuality.width && it.height == currentQuality.height }.coerceAtLeast(0)
        DiagLog.logEvent("UI", "showResolutionDialog current=${currentQuality.width}x${currentQuality.height}")
        MaterialAlertDialogBuilder(this)
            .setTitle("分辨率")
            .setSingleChoiceItems(options.toTypedArray(), currentIdx) { dialog, which ->
                val sel = resolutions[which]
                // v6.7.131: 分辨率-帧率联动——按分辨率修正帧率上限(1080P及以下144/2K120/4K60)。
                val maxFps = maxFpsForResolution(sel.width, sel.height)
                val fps = if (sel.frameRate > maxFps) maxFps else sel.frameRate
                val final = if (fps != sel.frameRate) sel.copy(frameRate = fps) else sel
                currentQuality = final
                prefsManager.saveQuality(currentQuality)
                DiagLog.logEvent("SET",
                    "RESOLUTION=${final.width}x${final.height} fps=${final.frameRate} max=$maxFps " +
                        "fpsOverridden=${fps != sel.frameRate} fpsFrom=${sel.frameRate} recState=${ScreenRecorderApp.recordState}")
                // v6.7.190 (P0-5): 分辨率切换导致帧率被下调时必须告知用户。
                // 此前只写日志、静默改配置,用户以为录的是 60fps 实际拿到 50fps,
                // 且这层静默改写是三层帧率(UI/配置/运行时)口径分叉的直接来源。
                if (fps != sel.frameRate) {
                    MaterialAlertDialogBuilder(this)
                        .setTitle("帧率已调整")
                        .setMessage("${final.width}x${final.height} 在本机最高支持 ${maxFps}fps，" +
                            "帧率已由 ${sel.frameRate}fps 调整为 ${maxFps}fps。")
                        .setPositiveButton(android.R.string.ok, null)
                        .show()
                }
                updatePreviewCard()
                updateSettingsValues()
                dialog.dismiss()
            }
            .setNegativeButton(R.string.cancel, null)
            .show()
    }

    // v6.7.131: 分辨率-帧率上限联动。对齐必剪(4K锁60/1080P可144)。
    // 宽<=1920(含1080p/720p及以下):144;2K(2560x1440):120;4K(3840x2160)及以上:60。
    // 判定按短边,避免竖屏(1080x1920)被误判为4K。
    // v6.7.188h (改造3): 静态档位表与官方 VideoCapabilities 实测区间取交集。
    // 静态表提供"产品策略上限",实测提供"本机能力上限",两者取小者。
    // 探测失败(返回 0)时退化为纯静态表,行为与改造前完全一致(零回归风险)。
    private fun maxFpsForResolution(width: Int, height: Int): Int {
        val short = minOf(width, height)
        val productTier = when {
            short >= 2160 -> 60
            short >= 1440 -> 120
            else -> 144
        }
        val px = if (width > 0 && height > 0) width.toLong() * height else 1L
        val throughputCap = (RecorderEngine.PIXEL_THROUGHPUT_CAP / px).toInt().coerceAtLeast(15)
        val staticCap = minOf(productTier, throughputCap)
        // 本机实测能力(按当前偏好编码器探测),与静态策略取交集
        val deviceCap = recorderEngineProbeMaxFps(width, height)
        return if (deviceCap > 0) minOf(staticCap, deviceCap) else staticCap
    }

    // v6.7.188h (改造3): 探测入口,结果缓存,避免每次刷新 UI 都查 codec 列表。
    private val fpsProbeCache = HashMap<String, Int>()
    private fun recorderEngineProbeMaxFps(width: Int, height: Int): Int {
        val mime = if (currentQuality.preferHevc)
            android.media.MediaFormat.MIMETYPE_VIDEO_HEVC
        else android.media.MediaFormat.MIMETYPE_VIDEO_AVC
        val key = "$mime:${width}x$height"
        return fpsProbeCache.getOrPut(key) { RecorderEngine.probeMaxFpsForConfig(mime, width, height) }
    }

    private fun showOrientationDialog() {
        val options = arrayOf("自动", "横屏", "竖屏")
        val values = intArrayOf(0, 1, 2)
        val currentIdx = values.indexOf(currentQuality.orientation).coerceAtLeast(0)
        DiagLog.logEvent("UI", "showOrientationDialog current=${currentQuality.orientation}")
        MaterialAlertDialogBuilder(this)
            .setTitle("方向")
            .setSingleChoiceItems(options, currentIdx) { dialog, which ->
                currentQuality = currentQuality.copy(orientation = values[which])
                prefsManager.saveQuality(currentQuality)
                DiagLog.logEvent("SET", "ORIENTATION=${values[which]} recState=${ScreenRecorderApp.recordState}")
                updateSettingsValues()
                dialog.dismiss()
            }
            .setNegativeButton(R.string.cancel, null)
            .show()
    }

    // v6.7.144 (P0-1/2/3) + v6.7.145 (P1-7): 4 个新设置项对话框,统一单选项风格。
    private fun showCountdownDialog() {
        val options = arrayOf("关闭", "3 秒", "5 秒", "10 秒")
        val values = intArrayOf(0, 3, 5, 10)
        val current = prefsManager.countdownSeconds()
        val currentIdx = values.indexOf(current).coerceAtLeast(0)
        DiagLog.logEvent("UI", "showCountdownDialog current=${current}")
        MaterialAlertDialogBuilder(this)
            .setTitle("录制倒计时")
            .setSingleChoiceItems(options, currentIdx) { dialog, which ->
                prefsManager.setCountdownSeconds(values[which])
                DiagLog.logEvent("SET", "COUNTDOWN=${values[which]} recState=${ScreenRecorderApp.recordState}")
                updateSettingsValues()
                dialog.dismiss()
            }
            .setNegativeButton(R.string.cancel, null)
            .show()
    }

    private fun showDurationLimitDialog() {
        val options = arrayOf("不限", "1 分钟", "5 分钟", "10 分钟", "30 分钟", "60 分钟")
        val values = intArrayOf(0, 1, 5, 10, 30, 60)
        val current = prefsManager.durationLimitMinutes()
        val currentIdx = values.indexOf(current).coerceAtLeast(0)
        DiagLog.logEvent("UI", "showDurationLimitDialog current=${current}")
        MaterialAlertDialogBuilder(this)
            .setTitle("录制时长上限")
            .setSingleChoiceItems(options, currentIdx) { dialog, which ->
                prefsManager.setDurationLimitMinutes(values[which])
                DiagLog.logEvent("SET", "DURATION_LIMIT=${values[which]}m recState=${ScreenRecorderApp.recordState}")
                updateSettingsValues()
                dialog.dismiss()
            }
            .setNegativeButton(R.string.cancel, null)
            .show()
    }

    // v6.7.178 (⑥): 引擎级字节限额。与 durationLimitMinutes 独立,0=不限。
    private fun showRecLimitBytesDialog() {
        val options = arrayOf("不限", "1 GB", "2 GB", "4 GB", "8 GB")
        val values = longArrayOf(0L, 1L * 1024 * 1024 * 1024, 2L * 1024 * 1024 * 1024,
            4L * 1024 * 1024 * 1024, 8L * 1024 * 1024 * 1024)
        val current = prefsManager.recLimitBytes()
        val currentIdx = values.indexOf(current).coerceAtLeast(0)
        DiagLog.logEvent("UI", "showRecLimitBytesDialog current=${current}")
        MaterialAlertDialogBuilder(this)
            .setTitle("录制大小上限")
            .setSingleChoiceItems(options, currentIdx) { dialog, which ->
                prefsManager.setRecLimitBytes(values[which])
                DiagLog.logEvent("SET", "REC_LIMIT_BYTES=${values[which]} recState=${ScreenRecorderApp.recordState}")
                updateSettingsValues()
                dialog.dismiss()
            }
            .setNegativeButton(R.string.cancel, null)
            .show()
    }

    // v6.7.178 (⑥): 引擎级时长限额(精确,ms)。UI 用分钟步进,写盘按 ms。
    private fun showRecLimitDurationMsDialog() {
        val minutes = intArrayOf(0, 1, 5, 10, 30, 60)
        val values = minutes.map { it * 60_000L }.toLongArray()
        val options = minutes.map { if (it == 0) "不限" else "$it 分钟" }.toTypedArray()
        val current = prefsManager.recLimitDurationMs()
        val currentIdx = values.indexOf(current).coerceAtLeast(0)
        DiagLog.logEvent("UI", "showRecLimitDurationMsDialog current=${current}")
        MaterialAlertDialogBuilder(this)
            .setTitle("录制时长上限(精确)")
            .setSingleChoiceItems(options, currentIdx) { dialog, which ->
                prefsManager.setRecLimitDurationMs(values[which])
                DiagLog.logEvent("SET", "REC_LIMIT_DURATION_MS=${values[which]} recState=${ScreenRecorderApp.recordState}")
                updateSettingsValues()
                dialog.dismiss()
            }
            .setNegativeButton(R.string.cancel, null)
            .show()
    }
    private fun showShakeDialog() {
        val options = arrayOf("开", "关")
        val currentIdx = if (prefsManager.isShakeToStopEnabled()) 0 else 1
        DiagLog.logEvent("UI", "showShakeDialog current=$currentIdx")
        MaterialAlertDialogBuilder(this)
            .setTitle("摇一摇停止")
            .setSingleChoiceItems(options, currentIdx) { dialog, which ->
                prefsManager.setShakeToStopEnabled(which == 0)
                DiagLog.logEvent("SET", "SHAKE=${which == 0} recState=${ScreenRecorderApp.recordState}")
                updateSettingsValues()
                dialog.dismiss()
            }
            .setNegativeButton(R.string.cancel, null)
            .show()
    }

    private fun showOverlayAlphaDialog() {
        val options = arrayOf("40%", "60%", "80%", "92%", "100%")
        val values = intArrayOf(40, 60, 80, 92, 100)
        val current = prefsManager.overlayAlphaPercent()
        val currentIdx = values.indexOf(current).coerceAtLeast(0)
        DiagLog.logEvent("UI", "showOverlayAlphaDialog current=${current}")
        MaterialAlertDialogBuilder(this)
            .setTitle("悬浮窗透明度")
            .setSingleChoiceItems(options, currentIdx) { dialog, which ->
                prefsManager.setOverlayAlphaPercent(values[which])
                DiagLog.logEvent("SET", "OVERLAY_ALPHA=${values[which]}% recState=${ScreenRecorderApp.recordState}")
                updateSettingsValues()
                // v6.7.145: 变更即广播,Service 收到后让已存在的悬浮窗 recolor 生效。
                try {
                    sendBroadcast(Intent(ScreenRecorderService.ACTION_THEME_CHANGED).setPackage(packageName))
                } catch (_: Exception) {}
                dialog.dismiss()
            }
            .setNegativeButton(R.string.cancel, null)
            .show()
    }

    private fun showThemeDialog() {
        // v6.7.129 (A): 深色三态——跟随系统(0)/浅色(1)/深色(2),与 AppCompatDelegate 对齐。
        val options = arrayOf("跟随系统", "浅色", "深色")
        val currentIdx = prefsManager.darkMode().coerceIn(0, 2)
        DiagLog.logEvent("UI", "showThemeDialog current=${prefsManager.darkMode()}")
        MaterialAlertDialogBuilder(this)
            .setTitle("外观")
            .setSingleChoiceItems(options, currentIdx) { dialog, which ->
                prefsManager.setDarkMode(which)
                applySavedNightMode()
                DiagLog.logEvent("SET", "THEME=${which}(${options[which]}) recState=${ScreenRecorderApp.recordState}")
                dialog.dismiss()
                // v6.7.188i: 录制会话中拒绝切主题——recreate() 会重建 Activity,
                // 打断 UI 与 receiver 绑定。正常应由 bindClick 拦在入口,此处为断言式兜底。
                if (isSessionBusy()) {
                    DiagLog.logEvent("UI", "theme_blocked state=${ScreenRecorderApp.recordState}")
                    return@setSingleChoiceItems
                }
                // 强制重建主界面,让 uiMode token 立即生效(不依赖系统重建)
                recreate()
            }
            .setNegativeButton(R.string.cancel, null)
            .show()
    }

    private fun showBottomListDialog(title: String, items: List<String>, currentIdx: Int, onSelect: (String) -> Unit) {
        MaterialAlertDialogBuilder(this)
            .setTitle(title)
            .setSingleChoiceItems(items.toTypedArray(), currentIdx) { dialog, which ->
                onSelect(items[which])
                dialog.dismiss()
            }
            .setNegativeButton(R.string.cancel, null)
            .show()
    }

    private var countdownTimer: android.os.CountDownTimer? = null

    private fun cancelCountdown() {
        countdownTimer?.cancel()
        countdownTimer = null
    }

    // v6.7.144 (P0-1): 倒计时延时录制。CountDownTimer 驱动全屏半透明 Dialog,
    // 结束才真正走 checkOverlayAndProceed()。倒计时中再点主按钮 → 取消回 IDLE。
    // 借鉴必剪 MediaConfig.countdownSwitch / 剪映 CountDownView(getOnCountDownEnd)。
    private fun startCountdownThenProceed() {
        val sec = prefsManager.countdownSeconds()
        if (sec <= 0) {
            checkOverlayAndProceed()
            return
        }
        // 倒计时 Dialog 用无标题半透明样式,内容仅一个倒计时数字。
        val q = currentQuality
        // v6.7.155: 录制前剩余容量估算,倒计时数字下方小字展示"预计可录制约 X 小时
        // (剩余 Y GB)"。满盘/异常返回空则不显示。与 RECORD_SUMMARY 的 remainingSec
        // 同公式(video bitrate + 128kbps 音频)。
        val estText = estimateRemainingText(q)
        val tv = TextView(this).apply {
            text = sec.toString()
            textSize = 96f
            setTextColor(android.graphics.Color.WHITE)
            gravity = android.view.Gravity.CENTER
            setPadding(0, resources.displayMetrics.heightPixels / 4, 0, 0)
        }
        val el = if (estText.isNotBlank())
            android.widget.LinearLayout(this).apply {
                addView(tv, android.widget.LinearLayout.LayoutParams(
                    android.view.ViewGroup.LayoutParams.MATCH_PARENT,
                    android.view.ViewGroup.LayoutParams.MATCH_PARENT))
                // v6.7.155: 倒计时数字下方追加剩余容量估算小字。
                addView(this@MainActivity.let { act ->
                    TextView(act).apply {
                        text = estText
                        textSize = 16f
                        setTextColor(android.graphics.Color.WHITE)
                        gravity = android.view.Gravity.CENTER
                    }
                }, android.widget.LinearLayout.LayoutParams(
                    android.view.ViewGroup.LayoutParams.MATCH_PARENT,
                    android.view.ViewGroup.LayoutParams.WRAP_CONTENT))
            }
        else tv
        // v6.7.147 (修复1 P0-1): dialogRef 用可空可变容器装 dialog 自身,
        // 供 setNegativeButton 的延迟闭包在 show() 之后 dismiss。闭包触发时
        // dialog 已赋值,故 !! 安全。
        var dialogRef: androidx.appcompat.app.AlertDialog? = null
        val dialog = MaterialAlertDialogBuilder(this)
            .setView(el)
            // v6.7.147 (修复1 P0-1): 倒计时取消分支此前不可达——setCancelable(false)
            // 禁了返回键、主按钮被模态 dialog 挡住,用户只能干等,handleStartRecording
            // 的取消分支实际是死代码。补显式「取消」按钮作为唯一取消出口。
            .setNegativeButton("取消") { _, _ ->
                DiagLog.logEvent("UI", "countdown cancelled by user")
                cancelCountdown()
                try { dialogRef?.dismiss() } catch (_: Exception) {}
            }
            .create()
        dialogRef = dialog
        dialog.window?.setBackgroundDrawableResource(android.R.color.transparent)
        // v6.7.147: 仍禁返回键,误触返回不取消;取消入口统一走「取消」按钮。
        dialog.setCancelable(false)
        try { dialog.show() } catch (_: Exception) {}
        countdownTimer = object : android.os.CountDownTimer(sec * 1000L, 1000L) {
            override fun onTick(millisUntilFinished: Long) {
                val remaining = ((millisUntilFinished + 999L) / 1000L).toInt()
                tv.text = remaining.toString()
            }

            override fun onFinish() {
                tv.text = "开始"
                countdownTimer = null
                try { dialog.dismiss() } catch (_: Exception) {}
                DiagLog.logEvent("UI", "countdown finished sec=$sec")
                checkOverlayAndProceed()
            }
        }.start()
    }

    private fun handleStartRecording() {
        // v6.7.81: 主按钮行为带墙钟时间记录,便于时间佐证用户何时点击开始/停止。
        DiagLog.logEvent("UI", "handleStartRecording st=${ScreenRecorderApp.recordState}")
        // v6.7.49: 判定改用全局 recordState,与按钮状态同一来源。
        // 录制中/暂停中/启动中/准备中 -> 点按为停止;否则为开始。
        val st = ScreenRecorderApp.recordState
        // v6.7.144 (P0-1): 倒计时进行中再点主按钮 → 取消倒计时(用户反悔),不进入停止。
        if (countdownTimer != null) {
            DiagLog.logEvent("UI", "handleStartRecording branch=cancel_countdown")
            cancelCountdown()
            return
        }
        val active = st == RecordState.RECORDING || st == RecordState.PAUSED ||
            st == RecordState.STARTING || st == RecordState.PREPARING
        if (active) {
            // v6.7.95: 明确落分支,暂停态点主按钮是"停止录制",区别于 btnPause 的"暂停/继续"。
            DiagLog.logEvent("UI", "handleStartRecording branch=stop_from_$st")
            stopRecording()
            return
        }
        // v6.7.65: Bug3 修复——STOPPING 期间(停止收尾中)禁止再次启动新录制。
        // 按钮虽在 STOPPING 被禁用,但保留在点击入口防御一次,避免竞态下过早
        // 重建投影/前台服务;防止旧会话未释放即开新会话。
        if (st == RecordState.STOPPING) {
            DiagLog.logEvent("UI", "handleStartRecording branch=ignored_stopping")
            writeButtonLog("start blocked: recording still stopping")
            return
        }
        // 停止收尾中(全局 STOPPING)或已停止/失败,均进入开始流程
        DiagLog.logEvent("UI", "handleStartRecording branch=begin_$st")
        startCountdownThenProceed()
    }

    private fun writeButtonLog(msg: String) {
        // v6.7.95: 此前走 android.util.Log.d,写不进导出文件,取证时等于没有。
        // 改走 DiagLog,统一落入诊断日志。
        DiagLog.logEvent("UI", msg)
    }

    private val audioPermissionLauncher =
        registerForActivityResult(ActivityResultContracts.RequestPermission()) { granted ->
            DiagLog.logEvent("PERM", "audioPermission granted=$granted mode=${currentConfig.audioMode}")
            // v6.7.101 (B6): MIC_ONLY/MIXED 模式在麦克风权限被拒时必须阻断录制,
            // 而不是弹一条 Toast 继续。这两种模式的语义就是"要麦克风音轨",
            // 无麦克风等于整段无声,与用户主动选择直接矛盾;且录制中禁用设置区,
            // 用户只能删掉重录。SPEAKER_ONLY/AUTO 保持原有降级语义(不阻断)。
            if (!granted) {
                val mode = currentConfig.audioMode
                if (mode == AudioMode.MIC_ONLY || mode == AudioMode.MIXED) {
                    DiagLog.logEvent("PERM", "audioPermission denied blocked mode=$mode")
                    Toast.makeText(
                        this,
                        "麦克风权限被拒绝,当前音频模式需要麦克风,请去系统设置开启或改用其他音频模式",
                        Toast.LENGTH_LONG
                    ).show()
                    return@registerForActivityResult
                }
                Toast.makeText(
                    this,
                    "麦克风权限被拒绝,内部音频仍可用",
                    Toast.LENGTH_SHORT
                ).show()
            }
            prepareServiceThenProjection()
        }

    private fun checkOverlayAndProceed() {
        DiagLog.logEvent("PERM", "checkOverlayAndProceed canDrawOverlays=${
            Build.VERSION.SDK_INT >= Build.VERSION_CODES.M && Settings.canDrawOverlays(this)}")
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M && !Settings.canDrawOverlays(this)) {
            // v6.7.65: Bug4——权限被拒跳设置页,置「待授权」标记并刷新按钮,
            // 返回后复查仍缺权限则按钮保持「待授权」,引导用户重新开始。
            pendingOverlayGrant = true
            updateRecordingState()
            startActivity(Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:$packageName")))
            Toast.makeText(this, R.string.permission_overlay_required, Toast.LENGTH_LONG).show()
            return
        }
        pendingOverlayGrant = false
        checkBatteryOptimizationAndProceed()
    }

    private fun checkBatteryOptimizationAndProceed() {
        DiagLog.logEvent("PERM", "checkBatteryOptimizationAndProceed")
        // v6.7.179: REQUEST_IGNORE_BATTERY_OPTIMIZATIONS 权限已按方案移除,
        // 无权限时 ACTION_REQUEST_IGNORE_BATTERY_OPTIMIZATIONS 不弹系统窗,
        // 此分支会触发 ActivityNotFoundException,故改为仅记录状态后直通。
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
            val pm = getSystemService(android.os.PowerManager::class.java)
            if (!pm.isIgnoringBatteryOptimizations(packageName)) {
                // v6.7.183: 原文案暗示存在可点开的电池优化入口,但本仓按设计不申请
                // REQUEST_IGNORE_BATTERY_OPTIMIZATIONS,用户无处可点。改为中性提示:
                // 告知后台录制可能受系统策略影响,并指向诊断日志。
                // 改为中性提示:告知后台录制可能受系统策略影响,并指向诊断日志。
                DiagLog.logEvent("PERM", "battery optimization ignored=false, no permission to request, proceed anyway")
                Toast.makeText(this, "当前为后台录制优化受限状态，长录制建议保持亮屏", Toast.LENGTH_SHORT).show()
            }
        }
        checkNotificationAndProceed()
    }

    private fun checkNotificationAndProceed() {
        DiagLog.logEvent("PERM", "checkNotificationAndProceed")
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
            if (ContextCompat.checkSelfPermission(this, android.Manifest.permission.POST_NOTIFICATIONS)
                != android.content.pm.PackageManager.PERMISSION_GRANTED) {
                DiagLog.logEvent("PERM", "notification permission not granted -> request")
                requestPermissionLauncher.launch(android.Manifest.permission.POST_NOTIFICATIONS)
                Toast.makeText(this, R.string.permission_notification_required, Toast.LENGTH_LONG).show()
                return
            }
        }
        requestAudioAndProceed()
    }

    private fun requestAudioAndProceed() {
        DiagLog.logEvent("PERM", "requestAudioAndProceed")
        if (ContextCompat.checkSelfPermission(this, android.Manifest.permission.RECORD_AUDIO)
            != android.content.pm.PackageManager.PERMISSION_GRANTED) {
            audioPermissionLauncher.launch(android.Manifest.permission.RECORD_AUDIO)
            return
        }
        prepareServiceThenProjection()
    }

    private fun prepareServiceThenProjection() {
        DiagLog.logEvent("PERM", "prepareServiceThenProjection")
        startMediaProjection()
    }

    private fun startMediaProjection() {
        DiagLog.logEvent("PERM", "startMediaProjection")
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
            val pm = getSystemService(MediaProjectionManager::class.java)
            mediaProjectionLauncher.launch(pm.createScreenCaptureIntent())
        }
    }

    private fun startServiceWithProjection() {
        DiagLog.logEvent("UI", "startServiceWithProjection")
        startPrepareService()
    }

    private fun startPrepareService() {
        DiagLog.logEvent("SVC", "startPrepareService quality=${currentQuality.width}x${currentQuality.height}@${currentQuality.frameRate} bitrate=${currentQuality.videoBitRate}")
        val intent = Intent(this, ScreenRecorderService::class.java).apply {
            action = ScreenRecorderService.ACTION_PREPARE
            putExtra(ScreenRecorderService.EXTRA_QUALITY_PARAMS, currentQuality)
            putExtra(ScreenRecorderService.EXTRA_CONFIG, currentConfig)
            if (currentConfig.outputUri != null) {
                putExtra(ScreenRecorderService.EXTRA_OUTPUT_URI, currentConfig.outputUri.toString())
            }
            if (ScreenRecorderApp.pendingResultData != null) {
                putExtra(ScreenRecorderService.EXTRA_PROJECTION_RESULT_CODE, ScreenRecorderApp.pendingResultCode)
                putExtra(ScreenRecorderService.EXTRA_PROJECTION_RESULT_DATA, ScreenRecorderApp.pendingResultData)
            }
        }
        try {
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
                startForegroundService(intent)
            } else {
                startService(intent)
            }
        } catch (e: Exception) {
            // v6.7.51: 从后台/已销毁 Activity 启动前台服务可能抛
            // ForegroundServiceStartNotAllowedException。不应静默,记录原因并提示。
            ScreenRecorderApp.lastError =
                "${e.javaClass.name}: ${e.message ?: "startForegroundService failed"}"
            android.util.Log.e("MainActivity", "startForegroundService failed", e)
            if (!isFinishing && !isDestroyed) {
                Toast.makeText(this, "启动录制服务失败，请重试", Toast.LENGTH_LONG).show()
            }
            return
        }
        // v6.7.49: 不再直接改按钮文本,统一由 updateRecordingState() 依全局状态驱动
        updateRecordingState()
    }

    // v6.7.88 (Ch4): 暂停/继续。录播态→发 PAUSE;暂停态→发 RESUME。
    // 按钮可见性/文案由 updateRecordingState() 按状态驱动,这里只发意图。
    // 界面刷新完全依赖 Service 广播 ACTION_RECORD_STATE_CHANGED(v6.7.95),
    // 不再在点击时盲目刷新(此前 startForegroundService 是异步的,刷新用的是旧状态,
    // 等于把界面钉死在旧态上,反而加剧了滞后 6.9s 的问题)。
    private fun handlePauseResume() {
        val st = ScreenRecorderApp.recordState
        DiagLog.logEvent("UI", "handlePauseResume st=$st")
        val action = when (st) {
            RecordState.RECORDING -> ScreenRecorderService.ACTION_PAUSE
            RecordState.PAUSED -> ScreenRecorderService.ACTION_RESUME
            else -> {
                // v6.7.95: 兜底分支(IDLE/STOPPING/STARTING/PREPARING 不应有点暂停的入口),
                // 不再静默发 PAUSE 意图被 Service 侧拒绝。若命中说明界面可点性与状态不一致,
                // 记录为诊断证据,不发意图。
                DiagLog.logEvent("UI", "handlePauseResume ignored_st=$st")
                return
            }
        }
        val intent = Intent(this, ScreenRecorderService::class.java).apply { this.action = action }
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            startForegroundService(intent)
        } else {
            startService(intent)
        }
    }

    private fun stopRecording() {
        DiagLog.logEvent("UI", "stopRecording requested, setting STOPPING")
        // v6.7.65: Bug2 修复——按钮状态改由 updateRecordingState() 单一驱动。
        // 之前直接 setText("停止中…")+禁用,与全局 recordState 双写,一旦 Service
        // 停止路径(already_stopping/无效状态)走不同分支,文本与真实状态会短期不一致。
        // 停止意图已提交(即将发送 ACTION_STOP),先同步置全局 STOPPING,再走统一刷新,
        // 保证「停止中…」立即显示并由全局状态持续驱动,符合 v6.7.49 单一来源原则。
        ScreenRecorderApp.recordState = RecordState.STOPPING
        updateRecordingState()
        val intent = Intent(this, ScreenRecorderService::class.java).apply {
            action = ScreenRecorderService.ACTION_STOP
        }
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            startForegroundService(intent)
        } else {
            startService(intent)
        }
    }

    fun onRecordingStopped(saved: Boolean = false) {
        // v6.7.100 (B2): 上一会话实际生效的 clamp 码率必须随会话结束清零,
        // 否则下次预览卡片会持续显示"实际 X Mbps"的过期标注,误导用户
        // (effectiveBitrate 只在 ACTION_RECORDING_STARTED 被写入,从不在此处复位)。
        ScreenRecorderApp.effectiveBitrate = -1
        // v6.7.100 (B2): 顺带刷新预览卡片,让旧的"实际 X Mbps"标注立即消失。
        updatePreviewCard()
        // v6.7.49: 停止完成(全局已 IDLE),统一刷新按钮为「开始录制」。
        updateRecordingState()
        // v6.7.74: 停止成功后给一次即时反馈。仅依赖历史列表刷新时,
        // 用户停在主界面常常感知不到"录完了"。lastShownError 为空白即代表成功路径。
        // v6.7.188c-fix: 仅当本次会话确已落盘(saved)且无错误,才给"已保存/分享"反馈;
        // 空 stop(只开浮球/被拒/已停)静默,不再误报"视频已保存"。
        if (saved && ScreenRecorderApp.lastError.isNullOrBlank()) {
            // v6.7.146 (P2-8): Toast 升级为 Snackbar,带「分享」动作直达最近一条。
            // Snackbar 需 View;若 Activity 已销毁/视图不可用则回退原 Toast 兜底。
            try {
                com.google.android.material.snackbar.Snackbar
                    .make(findViewById(android.R.id.content), "录制已保存",
                        com.google.android.material.snackbar.Snackbar.LENGTH_LONG)
                    .setAction("分享") { shareLatestRecording() }
                    .show()
            } catch (_: Exception) {
                Toast.makeText(this, "录制已保存", Toast.LENGTH_SHORT).show()
            }
            // v6.7.144 (P0-3): 摇一摇停止时额外反馈,让用户确认是摇动触发的。
            if (historyManager.getRecent(1).firstOrNull()?.stopReason == "SHAKE") {
                Toast.makeText(this, "已摇动停止", Toast.LENGTH_SHORT).show()
            }
            // v6.7.102 (B8): 成功路径清空 lastError 全局字段。
            // 旧逻辑 lastError 只在错误路径写入,从未复位。用户首次录制失败后
            // 退出 App,下次再进来 MainActivity.onStart 会读到残留的 lastError,
            // 与 lastShownError(新 Activity 实例为空)对比触发 Toast,
            // 用户没做任何操作就被"录制失败:..."打扰。此处成功收口清 lastError,
            // 让 onStart 的 lastError 提示只在当前会话有效。
            ScreenRecorderApp.lastError = null
        }
        // v6.7.179: 停止收尾最后刷新历史列表。广播接收路径与 onResume 之外还有
        // 直接回调路径(如 ACTION_RECORDING_STOPPED 已注销时),此处保证列表收口。
        loadRecentHistory()
    }

    private val requestPermissionLauncher = registerForActivityResult(ActivityResultContracts.RequestPermission()) { granted ->
        DiagLog.logEvent("PERM", "notificationPermission granted=$granted")
        // 通知权限被拒:Android 13+ 前台服务若无通知会被系统立即停止,故必须阻止继续。
        // 拒绝时提示并停止录制流程,避免静默失败。
        if (!granted) {
            Toast.makeText(this, R.string.permission_notification_required, Toast.LENGTH_LONG).show()
            return@registerForActivityResult
        }
        requestAudioAndProceed()
    }

    private fun updatePreviewCard() {
        val compress = prefsManager.isCompressQualityEnabled()
        // 压缩模式开启时,预览直接反映引擎将采用的必剪压缩参数(短边 640 等比 + 30fps + AVC),
        // 与服务层 computeCompressQuality 同源,保证"预览即所得"。
        // v6.7.174 (异形屏 P0): 短边基准改统一 helper(物理整屏含 cutout),不再用
        // resources.displayMetrics(可用区被系统栏削减,预览与成片尺寸不一致)。
        val (ew, eh, ebit) = if (compress) {
            val (rw, rh) = ScreenRecorderApp.realScreenSize(this)
            val sw = minOf(rw, rh)
            val sh = maxOf(rw, rh)
            computeCompressQuality(sw, sh)
        } else {
            Triple(currentQuality.width, currentQuality.height, currentQuality.videoBitRate)
        }
        val resolutionLabel = when {
            ew == 1920 && eh == 1080 -> "1080p"
            ew == 1280 && eh == 720 -> "720p"
            ew == 960 && eh == 540 -> "540p"
            ew == 640 && eh == 480 -> "480p"   // v6.7.161: 修正原 "640p" 误标(短边为 480)
            ew == 480 && eh == 360 -> "360p"
            ew == 320 && eh == 240 -> "240p"
            else -> "${ew}x${eh}"
        }
        val fpsText = if (compress) "30fps" else if (currentQuality.frameRate > 0) "${currentQuality.frameRate}fps" else "auto"
        val rawBitrateText = if (compress) "${ebit / 1_000_000}Mbps" else if (currentQuality.videoBitRate > 0) "${currentQuality.videoBitRate / 1_000_000}Mbps" else "auto"
        // v6.7.89 (L-7): 请求码率被 clamp 下调时,在预览中显式标出实际生效值,
        // 避免「预览 16 Mbps、实际 12 Mbps」对不上。
        // v6.7.101 (B7): 从 ScreenRecorderApp.effectiveBitrate 全局字段读取,
        // Activity 回收重建后仍能恢复,不再依赖 Activity 私有字段(重建后归 -1 即丢)。
        val eff = ScreenRecorderApp.effectiveBitrate
        val bitrateText = if (!compress && eff > 0 && currentQuality.videoBitRate > 0 && eff != currentQuality.videoBitRate) {
            "$rawBitrateText(实际 ${eff / 1_000_000}Mbps)"
        } else {
            rawBitrateText
        }
        val encText = if (compress) " · AVC" else if (currentQuality.preferHevc) " · HEVC" else " · AVC"
        findViewById<TextView>(R.id.tvPreviewResolution).text = "$resolutionLabel · $fpsText · $bitrateText$encText"
        findViewById<TextView>(R.id.tvPreviewFps).text = "${ew}x${eh}"
        val estimatedSize = if (compress) ebit.toLong() / 8 * 60 else estimateFileSize(currentQuality)
        findViewById<TextView>(R.id.tvPreviewSize).text = "预计 ${formatFileSize(estimatedSize)}/分钟"
    }

    private fun updateSettingsValues() {
        val q = currentQuality
        val compress = prefsManager.isCompressQualityEnabled()
        // 压缩模式开启时,分辨率/帧率/码率由引擎按必剪形态托管,这三行失效并淡化显示。
        val managedRows = listOf(
            R.id.settingsItemFps, R.id.settingsItemQuality,
            R.id.settingsItemResolution, R.id.settingsItemHevc
        )
        for (id in managedRows) {
            findViewById<View>(id).apply {
                isEnabled = !compress
                alpha = if (compress) 0.4f else 1.0f
            }
        }
        val autoCompress = if (compress) "Auto（压缩）" else null
        findViewById<TextView>(R.id.settingsValueFps).text = autoCompress
            ?: if (q.frameRate > 0) "${q.frameRate} FPS" else "Auto"
        findViewById<TextView>(R.id.settingsValueQuality).text = autoCompress
            ?: if (q.videoBitRate > 0) "${q.videoBitRate / 1_000_000} Mbps" else "Auto"
        val resolutionLabel = when {
            q.width == 2560 && q.height == 1440 -> "2K (2560x1440)"
            q.width == 3840 && q.height == 2160 -> "4K (3840x2160)"
            q.width == 1920 && q.height == 1080 -> "1080p (FHD)"
            q.width == 1280 && q.height == 720 -> "720p (HD)"
            q.width == 960 && q.height == 540 -> "540p"
            q.width == 640 && q.height == 480 -> "480p"   // v6.7.161: 修正原 "640p" 误标(短边为 480)
            q.width == 480 && q.height == 360 -> "360p"
            q.width == 320 && q.height == 240 -> "240p"
            else -> "${q.width}x${q.height}"
        }
        // v6.7.128: 录制中分辨率回显示 encoder 实际输出档位(等比 fit / 2K/4K clamp 后真实值),
        // 优先于 UI 请求值;仅当 encoder 已送达 OUTPUT_FORMAT_CHANGED(有效尺寸)才覆盖。
        val effW = ScreenRecorderApp.effectiveWidth
        val effH = ScreenRecorderApp.effectiveHeight
        val actualLabel = if (effW > 0 && effH > 0 && effW != q.width && effH != q.height) {
            "$resolutionLabel(实际 ${effW}x$effH)"
        } else resolutionLabel
        findViewById<TextView>(R.id.settingsValueResolution).text = autoCompress ?: actualLabel
        val orientationLabel = when (currentQuality.orientation) {
            1 -> "横屏"
            2 -> "竖屏"
            else -> "自动"
        }
        findViewById<TextView>(R.id.settingsValueOrientation).text = orientationLabel
        // v6.7.161: 二进制开关统一显示"已开启/已关闭",消除"开/关"与"显示最好"之类含糊措辞。
        // 压缩模式下 H.265 由引擎强制 AVC,这里直接显示"已关闭"而非用户的偏好值,避免误导。
        findViewById<TextView>(R.id.settingsValueHevc).text = if (compress) "已关闭" else if (q.preferHevc) "已开启" else "已关闭"
        // v6.7.144/145: 刷新 4 个新设置项显示值。
        findViewById<TextView>(R.id.settingsValueCountdown).text =
            if (prefsManager.countdownSeconds() == 0) "关闭" else "${prefsManager.countdownSeconds()} 秒"
        findViewById<TextView>(R.id.settingsValueDuration).text =
            if (prefsManager.durationLimitMinutes() == 0) "不限" else "${prefsManager.durationLimitMinutes()} 分钟"
        // v6.7.178 (⑥): 引擎级精确限额显示。字节按 GB、时长按分钟换算,0 显示"不限"。
        findViewById<TextView>(R.id.settingsValueRecLimitBytes).text =
            if (prefsManager.recLimitBytes() == 0L) "不限"
            else "${prefsManager.recLimitBytes() / (1024L * 1024 * 1024)} GB"
        findViewById<TextView>(R.id.settingsValueRecLimitDuration).text =
            if (prefsManager.recLimitDurationMs() == 0L) "不限"
            else "${prefsManager.recLimitDurationMs() / 60000L} 分钟"
        findViewById<TextView>(R.id.settingsValueShake).text =
            if (prefsManager.isShakeToStopEnabled()) "已开启" else "已关闭"
        findViewById<TextView>(R.id.settingsValueOverlayAlpha).text = "${prefsManager.overlayAlphaPercent()}%"
        findViewById<TextView>(R.id.settingsValueTheme).text = when (prefsManager.darkMode()) {
            1 -> "浅色"; 2 -> "深色"; else -> "跟随系统"
        }
        // v6.7.161 (压缩画质模式): 开关状态。
        findViewById<TextView>(R.id.settingsValueCompressQuality).text =
            if (compress) "已开启" else "已关闭"
    }

private fun estimateFileSize(q: QualityParams): Long {
        val bitrate = if (q.videoBitRate > 0) q.videoBitRate.toLong()
            else QualityParams.bitrateScheduler().autoBitrate(q.width, q.height, q.frameRate, q.preferHevc, false).toLong()
        return bitrate / 8 * 60
    }

    private fun formatFileSize(bytes: Long): String {
        return when {
            bytes < 1024 -> "$bytes B"
            bytes < 1024 * 1024 -> "${bytes / 1024} KB"
            else -> "${bytes / (1024 * 1024)} MB"
        }
    }

    private fun loadRecentHistory() {
        historyManager.reload()
        // v6.7.134: 刷新 SafeDeleteUtil 保护名单中的历史引用路径,
        // 防止 deleteVideo/clearAllVideos 之外的删除路径误删仍在历史里的视频。
        SafeDeleteUtil.setHistoryPaths(historyManager.getAll().map { it.path })
        val entries = historyManager.getRecent(3)
        val preview = findViewById<TextView>(R.id.tvHistoryPreview)
        if (entries.isEmpty()) {
            preview.text = getString(R.string.history_empty)
            return
        }
        preview.text = entries.joinToString("\n") { e ->
            "${e.formattedDuration} · ${e.formattedSize} · ${e.formattedResolution}"
        }
    }

    private fun showHistoryDialog() {
        DiagLog.logEvent("UI", "showHistoryDialog")
        historyManager.reload()
        val entries = historyManager.getAll()
        if (entries.isEmpty()) {
            Toast.makeText(this, R.string.history_empty, Toast.LENGTH_SHORT).show()
            return
        }
        // v6.7.145 (P1-5): 历史列表条目显示备注(非空时追加一行)。
        // v6.7.155: playable 校验——损坏产物加"已损坏"角标,播放改删除。
        val items = entries.map { e ->
            val base = "${e.formattedDuration} · ${e.formattedSize}\n${e.fileName}"
            val mark = if (!e.playable) "（已损坏）" else ""
            val body = if (e.note.isNotBlank()) "$base\n备注：${e.note}" else base
            "$mark$body"
        }.toTypedArray()
        MaterialAlertDialogBuilder(this)
            .setTitle(getString(R.string.section_history))
            .setItems(items) { _, which ->
                val entry = entries[which]
                showVideoActionDialog(entry)
            }
            .setPositiveButton(R.string.clear_history) { _, _ ->
                historyManager.clear()
                Toast.makeText(this, R.string.history_cleared, Toast.LENGTH_SHORT).show()
                loadRecentHistory()
            }
            .setNegativeButton(R.string.close, null)
            .show()
    }

    private fun showVideoActionDialog(entry: RecordingEntry) {
        // v6.7.144 (P0-4) + v6.7.145 (P1-5/P1-6): 菜单补重命名、添加备注,并在标题区显示停止原因。
        // v6.7.188c: 首位加"播放视频"(交给系统播放器,零代码零依赖)。
        val actions = arrayOf("播放视频", "分享视频", "复制视频路径", "重命名", "添加备注", "删除此视频")
        // v6.7.137 (改进3 步骤1): 多分片录制在历史详情弹窗展示分片清单(总时长/总大小之外的
        // 细粒度信息),让用户知道该条目由多个独立可播分片组成。永不合并(各分片独立可播)。
        val segMsg = if (entry.segmentPaths.size > 1) {
            val totalSegDurMs = entry.durationMs
            "（多分片 ${entry.segmentPaths.size} 段 · 共 ${entry.formattedDuration}）"
        } else ""
        // v6.7.145 (P1-6): 停止原因中文映射,与 P0-2/P0-3 联动诊断"为什么停了"。
        val stopLabel = when (entry.stopReason) {
            "MANUAL" -> "手动停止"
            "DURATION_LIMIT" -> "时长上限"
            "SHAKE" -> "摇一摇"
            "SYSTEM_KILL" -> "系统清理"
            "ERROR" -> "录制错误"
            else -> entry.stopReason
        }
        val stopMsg = " · 停止：$stopLabel"
        MaterialAlertDialogBuilder(this)
            .setTitle(entry.fileName + segMsg + stopMsg)
            .setItems(actions) { _, which ->
                when (which) {
                    0 -> playVideo(entry)
                    1 -> shareVideo(entry)
                    2 -> copyVideoPath(entry)
                    3 -> showRenameDialog(entry)
                    4 -> showNoteDialog(entry)
                    5 -> deleteVideo(entry)
                }
            }
            .setNegativeButton("取消", null)
            .show()
    }

    // v6.7.144 (P0-4): 历史重命名。仅改本地私有副本(File.renameTo 同分区原子),
    // SAF 导出副本(content://)不变名,仅改历史显示名并提示。
    // 借鉴剪映 com/vega/screenrecord/widget/RenameDialog。
    private fun showRenameDialog(entry: RecordingEntry) {
        DiagLog.logEvent("OP", "showRenameDialog path=${entry.path}")
        val isContentPath = entry.path.startsWith("content://")
        val input = android.widget.EditText(this).apply {
            setText(if (isContentPath) entry.fileName else File(entry.path).name)
            // 去掉扩展名预填,让用户只输入主名。
            if (text.toString().endsWith(".mp4")) setText(text.toString().dropLast(4))
            setSingleLine(true)
        }
        val pad = (resources.displayMetrics.density * 20).toInt()
        val container = android.widget.FrameLayout(this).apply {
            setPadding(pad, pad / 2, pad, 0)
            addView(input)
        }
        MaterialAlertDialogBuilder(this)
            .setTitle("重命名")
            .setView(container)
            .setPositiveButton("确定") { _, _ ->
                // v6.7.144 (决策3): 校验非法字符 + 首尾空格;空输入拒绝。
                var name = input.text.toString().trim()
                name = name.replace(Regex("[/\\\\:*?\"<>|]"), "_")
                if (name.isBlank()) {
                    Toast.makeText(this, "文件名不能为空", Toast.LENGTH_SHORT).show()
                    return@setPositiveButton
                }
                // v6.7.147 (修复2a P0-4): 用户可能自行输入带 .mp4 的名字,统一拼接会得
                // xxx.mp4.mp4。大小写不敏感判断,输入 MP4/Mp4/.MP4 均不重复追加。
                val newName = if (name.endsWith(".mp4", ignoreCase = true)) name else "$name.mp4"
                if (isContentPath) {
                    // SAF 导出副本:仅改历史显示名,不动系统文件管理器中的副本。
                    historyManager.update({ it.path == entry.path }) { it.copy(fileName = newName) }
                    Toast.makeText(this, "SAF 导出副本请在系统文件管理器改名", Toast.LENGTH_LONG).show()
                } else {
                    val oldFile = File(entry.path)
                    val dir = oldFile.parentFile ?: return@setPositiveButton
                    val newFile = File(dir, newName)
                    // v6.7.147 (修复2b P0-4): renameTo 对已存在目标会静默覆盖(或返回 false)。
                    // renameTo 前检查存在性,newFile != oldFile 排除"未改名直接确定"的误报,
                    // 避免覆盖同名旧录像。SAF 分支只改显示名,无需此检查。
                    if (newFile != oldFile && newFile.exists()) {
                        DiagLog.logEvent("OP", "rename blocked: target exists ${newFile.path}")
                        Toast.makeText(this, "同名文件已存在，请换一个名字", Toast.LENGTH_SHORT).show()
                        return@setPositiveButton
                    }
                    if (!oldFile.renameTo(newFile)) {
                        DiagLog.logEvent("OP", "rename FAILED path=${entry.path} -> ${newFile.path}")
                        Toast.makeText(this, "重命名失败（文件被占用或已移动）", Toast.LENGTH_SHORT).show()
                        return@setPositiveButton
                    }
                    historyManager.update({ it.path == entry.path }) {
                        it.copy(path = newFile.path, fileName = newName)
                    }
                    Toast.makeText(this, "已重命名为 $newName", Toast.LENGTH_SHORT).show()
                }
                DiagLog.logEvent("OP", "rename OK path=${entry.path} newName=$newName")
                loadRecentHistory()
            }
            .setNegativeButton("取消", null)
            .show()
    }

    // v6.7.145 (P1-5): 历史备注。纯元数据扩展,不动录制/编码。
    private fun showNoteDialog(entry: RecordingEntry) {
        DiagLog.logEvent("OP", "showNoteDialog path=${entry.path}")
        val input = android.widget.EditText(this).apply {
            setText(entry.note)
            setHint("备注（可选）")
            setSingleLine(false)
        }
        val pad = (resources.displayMetrics.density * 20).toInt()
        val container = android.widget.FrameLayout(this).apply {
            setPadding(pad, pad / 2, pad, 0)
            addView(input)
        }
        MaterialAlertDialogBuilder(this)
            .setTitle("添加备注")
            .setView(container)
            .setPositiveButton("保存") { _, _ ->
                val note = input.text.toString().trim()
                historyManager.update({ it.path == entry.path }) { it.copy(note = note) }
                DiagLog.logEvent("OP", "note saved path=${entry.path} len=${note.length}")
                loadRecentHistory()
            }
            .setNegativeButton("取消", null)
            .show()
    }

    // v6.7.188c: 播放交给系统播放器(ACTION_VIEW)。SAF 条目直接播 content://,
    // 本地条目走 FileProvider(与分享同通道)。无任何解码代码,零依赖。
    private fun playVideo(entry: RecordingEntry) {
        try {
            val uri = if (entry.path.startsWith("content://")) {
                Uri.parse(entry.path)
            } else {
                val file = File(entry.path)
                if (!file.exists()) {
                    Toast.makeText(this, R.string.file_not_found, Toast.LENGTH_SHORT).show(); return
                }
                androidx.core.content.FileProvider.getUriForFile(
                    this, "${packageName}.fileprovider", file)
            }
            startActivity(android.content.Intent(android.content.Intent.ACTION_VIEW)
                .setDataAndType(uri, "video/mp4")
                .addFlags(android.content.Intent.FLAG_GRANT_READ_URI_PERMISSION))
        } catch (e: Exception) {
            Toast.makeText(this, "没有可用的视频播放器,可先分享", Toast.LENGTH_SHORT).show()
        }
    }

    private fun shareVideo(entry: RecordingEntry) {
        try {
            // v6.7.83 (问题B): SAF 输出历史记录指向 content:// document URI(本地 temp
            // 拷贝后已删除),分享时直接以该 URI 发起,不必经 FileProvider。
            // v6.7.89 (P2-4.6): 对 content:// 不再实例化 File 并调用 File.exists()
            // (File.exists() 对 content URI 恒为 false,属无效判断且误导日志)。
            val isContentPath = entry.path.startsWith("content://")
            if (isContentPath) {
                val uri = Uri.parse(entry.path)
                if (contentResolver.query(uri, null, null, null, null)?.use { it.count > 0 } == true) {
                    val shareIntent = Intent(Intent.ACTION_SEND).apply {
                        type = "video/mp4"
                        putExtra(Intent.EXTRA_STREAM, uri)
                        addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
                    }
                    startActivity(Intent.createChooser(shareIntent, "分享录制"))
                } else {
                    Toast.makeText(this, R.string.file_not_found, Toast.LENGTH_SHORT).show()
                }
            } else {
                val file = File(entry.path)
                if (file.exists()) {
                    val uri = androidx.core.content.FileProvider.getUriForFile(this, "${packageName}.fileprovider", file)
                    val shareIntent = Intent(Intent.ACTION_SEND).apply {
                        type = "video/mp4"
                        putExtra(Intent.EXTRA_STREAM, uri)
                        addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
                    }
                    startActivity(Intent.createChooser(shareIntent, "分享录制"))
                } else {
                    Toast.makeText(this, R.string.file_not_found, Toast.LENGTH_SHORT).show()
                }
            }
        } catch (e: Exception) {
            Toast.makeText(this, "分享失败: ${e.message}", Toast.LENGTH_SHORT).show()
        }
    }

    private fun copyVideoPath(entry: RecordingEntry) {
        try {
            val clipboard = getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager
            clipboard.setPrimaryClip(ClipData.newPlainText("video_path", entry.path))
            DiagLog.logEvent("OP", "copyVideoPath path=${entry.path}")
            Toast.makeText(this, "视频路径已复制到剪贴板", Toast.LENGTH_SHORT).show()
        } catch (e: Exception) {
            DiagLog.logEvent("OP", "copyVideoPath FAILED ${e.message}")
            Toast.makeText(this, "复制失败: ${e.message}", Toast.LENGTH_SHORT).show()
        }
    }

    private fun deleteVideo(entry: RecordingEntry) {
        DiagLog.logEvent("OP", "deleteVideo begin path=${entry.path}")
        MaterialAlertDialogBuilder(this)
            .setTitle("删除视频")
            .setMessage("确定删除 \"" + entry.fileName + "\" 及其历史记录？")
            .setPositiveButton("确定") { _, _ ->
                // v6.7.83 (问题B): SAF 记录为 content URI,删除走 ContentResolver.delete。
                // v6.7.84 (新增-4): 删除有三条失败路径——(1) persistable 权限被撤销 →
                // SecurityException;(2) 文件已在文件管理器里被删 → delete 返回 0;
                // (3) Uri 失效 → 抛异常。旧代码全吞掉后无条件删历史,结果是"文件还在、
                // 记录没了",只剩孤儿文件堆在用户目录。改成: 真正删掉(或本就不存在)才删
                // 历史,否则保留历史并提示。
                val removed = if (entry.path.startsWith("content://")) {
                    try {
                        // v6.7.93 (P0): contentResolver.delete() 对 DocumentsProvider
                        // 的文档 URI 无效——跨 6 版本 20 次清空 deleted 恒为 0。
                        // 删除 SAF 文档必须用 DocumentsContract.deleteDocument()(与
                        // RecorderEngine.kt 回滚路径同一 API)。不依赖其返回值(不同 API
                        // level 签名不同),以"删完还在不在"为准。
                        android.provider.DocumentsContract.deleteDocument(
                            contentResolver, Uri.parse(entry.path))
                        !safFileStillExists(entry.path)
                    } catch (e: Exception) {
                        DiagLog.logEvent("OP",
                            "deleteVideo SAF delete failed: ${e.javaClass.simpleName}: ${e.message}")
                        false
                    }
                } else {
                    // v6.7.134: 本地删除统一收口 safeDelete(保护名单 + 审计)。
                    // SAF 分支仍走 DocumentsContract.deleteDocument(见上方),safeDelete 只管本地 File 路径。
                    // force=true: 用户显式删除历史条目,该路径虽在历史引用名单内但业务已确认可删。
                    SafeDeleteUtil.delete(File(entry.path), "deleteVideo", force = true)
                }
                if (removed || !safFileStillExists(entry.path)) {
                    historyManager.delete { it.path == entry.path }
                    DiagLog.logEvent("OP", "deleteVideo done path=${entry.path}")
                    loadRecentHistory()
                    updateFreeSpace()
                    Toast.makeText(this, "已删除", Toast.LENGTH_SHORT).show()
                } else {
                    DiagLog.logEvent("OP", "deleteVideo aborted, file still exists path=${entry.path}")
                    loadRecentHistory()
                    Toast.makeText(
                        this, "删除失败：没有该文件的写入权限，历史记录已保留",
                        Toast.LENGTH_LONG).show()
                }
            }
            .setNegativeButton("取消", null)
            .show()
    }

    // v6.7.84 (新增-4): 判断历史路径对应的文件是否真的还在。SAF 记录为 content URI
    // 时 query SIZE;本地路径用 File.exists()。query 失败(权限/失效)保守地当"还在",
    // 以保留历史记录,避免误删造成孤儿。
    // v6.7.92 (P0): 旧实现在 catch 里 return true,把"查询抛异常"当"文件还在"。
    // 而 SAF provider 对"文档不存在"正是抛异常,于是"文件已被外部删除"被判成"文件仍在"
    // -> 永远计 failed -> 叠上 v6.7.90 A-4(失败条目保留历史)变成一条删不掉的历史。
    // 改为正向枚举:枚举文档树子项,找得到才算存在。API 组合复用
    // ScreenRecorderService.resolveSafUniqueName() 已验证可用的同一套写法。
    private fun safFileStillExists(path: String): Boolean {
        if (!path.startsWith("content://")) return File(path).exists()
        val uri = Uri.parse(path)
        return try {
            val treeId = android.provider.DocumentsContract.getTreeDocumentId(uri)
            val docId = android.provider.DocumentsContract.getDocumentId(uri)
            val childrenUri = android.provider.DocumentsContract
                .buildChildDocumentsUriUsingTree(uri, treeId)
            val cursor = contentResolver.query(
                childrenUri,
                arrayOf(android.provider.DocumentsContract.Document.COLUMN_DOCUMENT_ID),
                null, null, null)
            if (cursor == null) {
                true
            } else {
                var found = false
                cursor.use { c ->
                    val idx = c.getColumnIndex(
                        android.provider.DocumentsContract.Document.COLUMN_DOCUMENT_ID)
                    if (idx < 0) {
                        found = true
                    } else {
                        while (c.moveToNext()) {
                            if (c.getString(idx) == docId) { found = true; break }
                        }
                    }
                }
                found
            }
        } catch (_: Exception) {
            true
        }
    }

    private fun exportLogs() {
        // v6.7.81: 导出/清除日志等维护操作为时间敏感操作,落带墙钟日志佐证触发时刻。
        DiagLog.logEvent("OP", "exportLogs begin busy=${isSessionBusy()}")
        // v6.7.74: 防御性拦截。按钮已由 updateRecordingState() 置灰,此处兜底
        // 防止状态切换瞬间的点击竞态,以及无障碍/脚本直接触发。
        if (isSessionBusy()) {
            Toast.makeText(this, "录制进行中，请停止录制后再操作", Toast.LENGTH_SHORT).show()
            return
        }
        val logDir = ScreenRecorderApp.logDir(this)
        val allFiles = mutableListOf<File>()
        collectLogFiles(logDir, allFiles)
        // 兼容兜底场景：外部存储未就绪时日志可能落在 filesDir/logs，一并收集
        try {
            val privateLogDir = File(filesDir, "logs")
            if (privateLogDir != logDir) collectLogFiles(privateLogDir, allFiles)
        } catch (_: Exception) {}
        if (allFiles.isEmpty()) {
            Toast.makeText(this, R.string.no_logs, Toast.LENGTH_SHORT).show()
            return
        }
        // v6.7.50: 日志压缩移到后台线程,避免大日志在主线程同步 zip 造成卡顿/ANR。
        Thread {
            var zipFile: File? = null
            try {
                val zf = File(ScreenRecorderApp.logDir(this), "logs_${System.currentTimeMillis()}.zip")
                val base = logDir.parentFile ?: logDir   // .../files，作为压缩包内相对路径根
                ZipOutputStream(FileOutputStream(zf)).use { zos ->
                    allFiles.forEach { file ->
                        try {
                            // 用相对路径作条目名，保留 logs/、logs/crashes/ 层级，避免双目录同名冲突
                            val entryName = file.absolutePath.removePrefix(base.absolutePath + File.separator)
                            zos.putNextEntry(ZipEntry(entryName))
                            file.inputStream().use { it.copyTo(zos) }
                            zos.closeEntry()
                        } catch (_: Exception) {
                            // skip unreadable / no-longer-existing entries
                        }
                    }
                }
                zipFile = zf
            } catch (e: Exception) {
                android.util.Log.e("MainActivity", "export logs failed", e)
            }
            val finalZip = zipFile
            runOnUiThread {
                // v6.7.100 (B6): 后台线程压缩日志期间 Activity 可能被系统回收(切出后
                // 内存压力下回收、用户主动关页面)。若已销毁则不再调 Toast / startActivity
                // (在已销毁 Activity 上调 UI 会抛 IllegalStateException 或触发
                // BadTokenException 崩溃)。直接跳过 UI 反馈,但保留日志落盘。
                if (isFinishing || isDestroyed) {
                    DiagLog.logEvent("OP", "exportLogs skipped_ui activity_destroyed zip=${finalZip?.name}")
                    return@runOnUiThread
                }
                if (finalZip == null) {
                    DiagLog.logEvent("OP", "exportLogs FAILED files=${allFiles.size}")
                    Toast.makeText(this, "导出日志失败", Toast.LENGTH_SHORT).show()
                    return@runOnUiThread
                }
                DiagLog.logEvent("OP", "exportLogs ok files=${allFiles.size} zip=${finalZip.name} bytes=${finalZip.length()}")
                val uri = androidx.core.content.FileProvider.getUriForFile(this, "$packageName.fileprovider", finalZip)
                val shareIntent = Intent(Intent.ACTION_SEND).apply {
                    type = "application/zip"
                    putExtra(Intent.EXTRA_STREAM, uri)
                    addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
                }
                startActivity(Intent.createChooser(shareIntent, "导出日志(全集)"))
            }
        }.start()
    }

    private fun collectLogFiles(root: File, out: MutableList<File>) {
        val children = root.listFiles() ?: return
        for (child in children) {
            if (child.isDirectory) {
                collectLogFiles(child, out)
            } else {
                out.add(child)
            }
        }
    }

    private fun clearLogs() {
        // v6.7.74: 防御性拦截。按钮已由 updateRecordingState() 置灰,此处兜底
        // 防止状态切换瞬间的点击竞态,以及无障碍/脚本直接触发。
        // v6.7.95: 补 begin 日志,避免中途抛异常时无从区分"没点到"和"点了但炸了"。
        DiagLog.logEvent("OP", "clearLogs begin busy=${isSessionBusy()} recState=${ScreenRecorderApp.recordState}")
        if (isSessionBusy()) {
            DiagLog.logEvent("OP", "clearLogs blocked_busy")
            Toast.makeText(this, "录制进行中，请停止录制后再操作", Toast.LENGTH_SHORT).show()
            return
        }
        // v6.7.104 (B4): 清除前先 stop DiagLog,再删除目录,然后重启 DiagLog。
        // 旧逻辑直接 deleteRecursively,但 DiagLog 后台 flush 线程按 500ms 节拍运行
        // (DiagLog.stop() 在整个代码库里从未被调用),删完立即被下一次 flush 重建。
        // 更严重的:rollover 里的 File.renameTo 与 deleteRecursively 存在时间窗,
        // 可能产生"归档名指向不存在文件"的空文件。此处先 stop 掐掉后台线程,
        // 再删除,最后 restart 恢复日志能力(后续录制/交互事件仍能被记录)。
        DiagLog.stop()
        val logDir = ScreenRecorderApp.logDir(this)
        // v6.7.177 (P2-B): 保留最近 KEEP_DIAG_LOGS 份 diag_*.log,而非全清。
        // 旧逻辑 deleteRecursively(整目录)会删掉上次崩溃的诊断日志——App 崩溃后用户再启动,
        // 上一次崩溃的现场已被清空,排障无据(仅清 files/logs,不动 Movies/分段/.idx,故不威胁崩溃恢复)。
        // 按 lastModified 降序取前 N 个 diag_*.log 进 keepSet,逐条删除其余,keep 文件原样保留。
        val keepSet = if (logDir.isDirectory) {
            logDir.listFiles { f, name -> f.isFile && name.startsWith("diag_") && name.endsWith(".log") }
                ?.sortedByDescending { it.lastModified() }
                ?.take(KEEP_DIAG_LOGS)
                ?.associateWith { it.lastModified() }
                ?: emptyMap()
        } else emptyMap()
        val allDeleted = try {
            var allOk = true
            for (entry in logDir.listFiles() ?: emptyArray()) {
                if (keepSet.containsKey(entry) && entry.lastModified() == keepSet[entry]) continue
                if (!deleteRecursively(entry)) allOk = false
            }
            allOk
        } finally {
            DiagLog.start(this)
        }
        if (keepSet.isNotEmpty()) {
            DiagLog.logEvent("OP", "clearLogs kept=${keepSet.size} diag files (last ${KEEP_DIAG_LOGS})")
        }
        DiagLog.logEvent("OP", "clearLogs done dir=$logDir allDeleted=$allDeleted")
        // v6.7.137 (改进2): 受白名单保护的日志文件(manifest.txt 等)会被拦截而非删除。
        // 既然没能 100% 清空,明确提示用户,避免误以为日志已全部清除。只提示一次,不弹阻塞对话框。
        if (!allDeleted) {
            runOnUiThread {
                try {
                    Toast.makeText(this, "部分日志被白名单保护，未全部删除（详见 SafeDelete 日志）",
                        Toast.LENGTH_LONG).show()
                } catch (_: Exception) {}
            }
        }
        val logPathText = logDir.absolutePath
        findViewById<TextView>(R.id.tvLogPath).text = "$logPathText (0 个文件)"
        Toast.makeText(this, "日志已清除", Toast.LENGTH_SHORT).show()
    }

    private fun clearAllVideos() {
        MaterialAlertDialogBuilder(this)
            .setTitle("清除全部视频")
            .setMessage("将删除所有录制视频文件并清空录制历史，此操作不可恢复。确定继续？")
            .setPositiveButton("确定") { _, _ ->
                // v6.7.74: 确认弹窗可能已停留一段时间,期间状态可能变化,
                // 在真正执行删除前再校验一次(精简文案)。
                // v6.7.95: 补 begin 日志(busy=true 视为被拦截,便于区分"没点到/点了被拦/真执行")。
                DiagLog.logEvent("OP", "clearAllVideos begin busy=${isSessionBusy()} recState=${ScreenRecorderApp.recordState}")
                if (isSessionBusy()) {
                    DiagLog.logEvent("OP", "clearAllVideos blocked_busy")
                    Toast.makeText(this, "录制进行中，请停止录制后再操作", Toast.LENGTH_SHORT).show()
                    return@setPositiveButton
                }
                // v6.7.109 (BUG-2): 删除操作(遍历历史、逐文件 File.delete/SAF 删除)同步跑在
                // 主线程,历史条目多或 SAF 授权缓慢时阻塞 UI 触发 ANR。迁到后台线程执行,
                // 完成后回主线程刷新列表与弹窗。
                Thread {
                    // v6.7.72: 删除必须"以盘为准",不能只遍历历史条目。
                    // 历史 JSON 未登记的文件(录制中断、引擎兜底文件名、JSON 损坏漏写)
                    // 只靠 entries 是删不掉的,表现为"列表已空但目录里还有 mp4"。
                    var deleted = 0
                    var failed = 0
                    // v6.7.90 (A-4): 收集删除失败的条目路径。删除失败的文件还在磁盘上,
                    // 历史里必须留着对应条目,否则再也无法定位删除(删除逻辑由历史条目驱动)。
                    val failedPaths = mutableSetOf<String>()
                    for (e in historyManager.getAll()) {
                        try {
                            // v6.7.83 (问题B): SAF 记录为 content URI,删除走 ContentResolver。
                            // v6.7.84 (新增-5): delete 返回 0 有两种可能——权限不够(文件还在)/
                            // 文件本来就已被外部删除。后者必须算成功,否则历史永远清不干净,
                            // 每次清空都报同样的失败。
                            if (e.path.startsWith("content://")) {
                                var ok = false
                                try {
                                    // v6.7.93 (P0): contentResolver.delete() 对 SAF 文档 URI 无效,
                                    // 改用 DocumentsContract.deleteDocument();不依赖返回值,
                                    // 以 safFileStillExists 反查为准(删成功=不在、本就不在都算 ok)。
                                    android.provider.DocumentsContract.deleteDocument(
                                        contentResolver, Uri.parse(e.path))
                                    ok = !safFileStillExists(e.path)
                                } catch (e: Exception) {
                                    DiagLog.logEvent("OP",
                                        "clearAllVideos SAF delete failed: ${e.javaClass.simpleName}: ${e.message}")
                                }
                                if (ok) deleted++ else { failed++; failedPaths.add(e.path) }
                            } else {
                                // v6.7.134: 本地删除收口 safeDelete。force=true: 用户显式"清除全部",
                                // 历史条目路径虽在保护名单内但业务已确认可删。
                                val f = File(e.path)
                                if (SafeDeleteUtil.delete(f, "clearAllVideos_history", force = true)) deleted++
                                else if (f.exists()) { failed++; failedPaths.add(e.path) }
                            }
                        } catch (_: Exception) {
                            failed++
                            failedPaths.add(e.path)
                        }
                    }
                    val moviesDir = getExternalFilesDir(android.os.Environment.DIRECTORY_MOVIES)
                    moviesDir?.listFiles()?.forEach { f ->
                        if (!f.isFile) return@forEach
                        val n = f.name
                        if (!n.endsWith(".mp4", true)) return@forEach
                        val before = f.exists()
                        // v6.7.134: 收口 safeDelete。未命中保护名单的正常删除;
                        // 活跃 tmp(30s 窗)/_restored.mp4/manifest.txt 会被拒绝,不会误删。
                        val ok = SafeDeleteUtil.delete(f, "clearAllVideos_moviesDir")
                        val after = f.exists()
                        if (before && ok && !after) deleted++
                        else if (before) failed++
                        android.util.Log.d("MainActivity",
                            "delete_video path=${f.absolutePath} existsBefore=$before deleteResult=$ok existsAfter=$after")
                    }
                    // v6.7.90 (A-4): 只移除成功删除的历史条目,失败的留在历史里便于重试。
                    // failedPaths 为空时等价于原 clear()(全部移除)。
                    historyManager.delete { it.path !in failedPaths }
                    android.util.Log.d("MainActivity", "clear_all_videos deleted=$deleted failed=$failed")
                    DiagLog.logEvent("OP", "clearAllVideos deleted=$deleted failed=$failed")
                    runOnUiThread {
                        if (failedPaths.isNotEmpty()) {
                            DiagLog.logEvent("OP", "clearAllVideos_failed paths=${failedPaths.joinToString()}")
                        }
                        loadRecentHistory()
                        updateFreeSpace()
                        // v6.7.90 (A-4): Toast 按实际结果分叉,不再无脑报"已清除全部"。
                        val msg = if (failed > 0) "已删除 $deleted 个，$failed 个删除失败"
                                   else "已清除全部视频和历史记录"
                        Toast.makeText(this, msg, Toast.LENGTH_SHORT).show()
                        // v6.7.92 (P0): 走到这里说明有条目真的删不掉(SAF 授权失效最可能)。
                        // 此时 ContentResolver 既删不掉也枚举不了,若不给出路,这条历史会永远留在
                        // 列表里、每次清空都重复报错。不擅自丢弃(会静默丢数据),而是明确告知
                        // 文件仍在磁盘,由用户决定是否仅从列表移除。
                        // 此时历史里剩下的正好只有 failedPaths 这些条目,delete { true }
                        // 不会误伤成功删除的条目。
                        if (failedPaths.isNotEmpty()) {
                            MaterialAlertDialogBuilder(this)
                                .setTitle("有 $failed 个文件删除失败")
                                .setMessage("这些文件可能已被外部删除，或应用已失去该目录的写入授权。"
                                    + "是否仅将它们从列表移除？（文件本身仍保留在磁盘上，不会被删除）")
                                .setPositiveButton("仅从列表移除") { _, _ ->
                                    historyManager.delete { true }
                                    loadRecentHistory()
                                    updateFreeSpace()
                                    Toast.makeText(this, "已移出列表，文件仍在磁盘", Toast.LENGTH_SHORT).show()
                                }
                                .setNegativeButton("保留", null)
                                .show()
                        }
                    }
                }.start()
            }
            .setNegativeButton("取消", null)
            .show()
    }

    // v6.7.93 (P0): 日志目录删除必须配合 DiagLog.stop()/start()(见 clearLogs),
    // 否则 DiagLog 后台 flush 线程按 500ms 节拍运行,删完立即被下一次 flush 重建;
    // 更严重的:rollover 里的 File.renameTo 与 deleteRecursively 存在时间窗,
    // 可能产生"归档名指向不存在文件"的空文件。此处由调用方先 stop 再删、删后 start。
    // v6.7.134: 收口 safeDelete 递归版。allowDirectory=false —— 不整目录强删,
    // 受保护目录(含未处理 manifest 的录制目录)整体跳过,防误删未恢复会话。
    private fun deleteRecursively(file: File): Boolean {
        // v6.7.137 (改进2): 返回是否全部删除成功,供 clearLogs 判断是否有白名单残留并提示用户。
        return SafeDeleteUtil.deleteRecursively(file, "clearLogs", allowDirectory = false)
    }

    private fun updateFreeSpace() {
        try {
            val stat = StatFs(Environment.getExternalStorageDirectory().absolutePath)
            val free = stat.availableBlocksLong * stat.blockSizeLong
            findViewById<TextView>(R.id.tvFreeSpace).text = "剩余空间: ${formatFileSize(free)}"
        } catch (_: Exception) {}
    }

    // v6.7.155: 剩余可录时长估算文案。复用 estimateFileSize(每分钟字节数) + StatFs
    // 剩余容量,返回"预计可录制约 X 小时(剩余 Y GB)";满盘/异常返回空串(不显示)。
    private fun estimateRemainingText(q: QualityParams): String {
        return try {
            val stat = StatFs(Environment.getExternalStorageDirectory().absolutePath)
            val free = stat.availableBlocksLong * stat.blockSizeLong
            val bytesPerMin = estimateFileSize(q)
            if (bytesPerMin <= 0 || free <= 0) return ""
            val minutes = free / bytesPerMin
            if (minutes < 1) return ""
            val h = minutes / 60
            val m = minutes % 60
            val label = when {
                h >= 1 && m > 0 -> "${h}小时${m}分"
                h >= 1 -> "${h}小时"
                else -> "${m}分"
            }
            "预计可录制约 $label · 剩余 ${free / (1024 * 1024 * 1024)} GB"
        } catch (_: Exception) { "" }
    }

    private fun applyTheme() {
        // v6.7.129 (A): token 由 uiMode 限定符自动解析(深色用 values-night),不再手动选 _dark。
        content_root.setBackgroundColor(ContextCompat.getColor(this, R.color.background))
    }

    /** 读取已保存的三态(0=跟随系统/1=浅色/2=深色)并驱动 AppCompatDelegate,替代手动 setTheme。 */
    private fun applySavedNightMode() {
        val mode = prefsManager.darkMode()
        AppCompatDelegate.setDefaultNightMode(
            when (mode) {
                1 -> AppCompatDelegate.MODE_NIGHT_NO
                2 -> AppCompatDelegate.MODE_NIGHT_YES
                else -> AppCompatDelegate.MODE_NIGHT_FOLLOW_SYSTEM
            })
    }
}

private val Activity.content_root get() = findViewById<android.widget.FrameLayout>(R.id.content_root)

// v6.7.129 (A): 统一深色判断。跟随系统时按 configuration.uiMode 解析,悬浮球与 Activity 共用。
fun isNightNow(ctx: Context): Boolean = when (AppCompatDelegate.getDefaultNightMode()) {
    AppCompatDelegate.MODE_NIGHT_YES -> true
    AppCompatDelegate.MODE_NIGHT_NO -> false
    else -> (ctx.resources.configuration.uiMode and
        android.content.res.Configuration.UI_MODE_NIGHT_MASK) ==
        android.content.res.Configuration.UI_MODE_NIGHT_YES
}