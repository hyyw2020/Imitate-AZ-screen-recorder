package com.monkeycode.screenrecorder

import android.app.Application
import android.content.ComponentCallbacks2
import android.media.projection.MediaProjection
import android.os.Build
import android.util.Log

class ScreenRecorderApp : Application(), ComponentCallbacks2 {

    override fun onCreate() {
        super.onCreate()
        instance = this
        DiagLog.appContext = applicationContext
        // v6.7.164: App 启动即开诊断 writer。start() 内部对 writer 创建已 try/catch,
        // 外部存储未就绪时优雅降级(不崩),故当初"冷启动移除"的理由已不成立。
        // 幂等(@Synchronized + started 判断),与 Service.handleStart 的重复调用安全。
        try { DiagLog.start(applicationContext) } catch (_: Throwable) {}
        installCrashLogger()
    }

    private fun installCrashLogger() {
        val previousDefaultUncaughtExceptionHandler =
            Thread.getDefaultUncaughtExceptionHandler()
        Thread.setDefaultUncaughtExceptionHandler { thread: Thread, throwable: Throwable ->
            try {
                DiagLog.logCrash(
                    thread.name,
                    android.util.Log.getStackTraceString(throwable),
                    recordState.toString(),
                    lastError ?: ""
                )
            } catch (_: Exception) {
            }
            previousDefaultUncaughtExceptionHandler?.uncaughtException(thread, throwable)
                ?: run {
                    // No previous handler: kill process as the platform would
                    android.os.Process.killProcess(android.os.Process.myPid())
                    System.exit(2)
                }
        }
    }

    // v6.7.134 (必剪式回收·内存层): 分级清理,替代"仅打日志"。
    // 取舍:录屏本体的可释放对象极少(无图片缓存库、无缩略图缓存),真正能安全释放的是
    // DiagLog 的内存日志队列。此处只清"可安全释放的缓存",绝不触碰编码器/缓冲/正在写入的 tmp。
    // UI_HIDDEN(20) 直接豁免:前台录制界面切后台但录制仍活跃时不动资源(对齐必剪豁免策略)。
    override fun onTrimMemory(level: Int) {
        // UI_HIDDEN: 界面不可见但录制活跃,不触发清理。
        if (level == ComponentCallbacks2.TRIM_MEMORY_UI_HIDDEN) return
        if (recordState == RecordState.RECORDING) {
            // 录制中:任何 level 都只做最轻量清理(日志队列收敛到 128 条),
            // 避免在录制关键路径产生重 IO 或抖动。
            if (level >= ComponentCallbacks2.TRIM_MEMORY_RUNNING_MODERATE) {
                DiagLog.trimQueue(128)
                Log.w(TAG, "trim_memory level=$level during RECORDING, diagQueue trimmed to 128")
            }
            return
        }
        // 非录制态:按 level 递进清理。
        if (level >= ComponentCallbacks2.TRIM_MEMORY_COMPLETE) {
            DiagLog.trimQueue(16)
            Log.w(TAG, "trim_memory level=$level COMPLETE (non-recording), diagQueue trimmed to 16")
        } else if (level >= ComponentCallbacks2.TRIM_MEMORY_RUNNING_MODERATE) {
            DiagLog.trimQueue(256)
            Log.w(TAG, "trim_memory level=$level (non-recording), diagQueue trimmed to 256")
        }
    }

    override fun onConfigurationChanged(newConfig: android.content.res.Configuration) {}
    // v6.7.134: onLowMemory 只告警不清理——低内存回调时序不稳,不在录制关键路径做任何删除。
    override fun onLowMemory() {
        if (recordState == RecordState.RECORDING) {
            Log.w(TAG, "low memory during recording, recording may be affected")
        }
    }

    companion object {
        private val TAG = "ScreenRecorderApp"
        // v6.7.95 (P0): Application 实例引用,供 Service 同伴对象 setState() 发广播用。
        // Service.setState 位于 companion(无 context),需经此处拿到包级 context 才能 sendBroadcast。
        @Volatile var instance: ScreenRecorderApp? = null
        @Volatile var recordState = RecordState.IDLE
        @Volatile var lastError: String? = null
        @Volatile var pendingMediaProjection: MediaProjection? = null
        @Volatile var pendingResultCode = 0
        @Volatile var pendingResultData: android.content.Intent? = null
        // v6.7.101 (B7): 当前录制会话 clamp 后实际生效的码率(bps),-1 表示未知/未记录。
        // Service 在 ACTION_RECORDING_STARTED 广播里写入,MainActivity 读取显示
        // "实际 X Mbps" 标注。放在全局字段而非 Activity 私有,保证 Activity 被
        // 系统回收重建后仍能恢复该值,避免录制中途切回时 UI 与真实录制参数脱钩。
        @Volatile var effectiveBitrate = -1
        // v6.7.128: encoder 实际输出尺寸(等比 fit / 2K/4K clamp 后的真实档位),同码率存全局。
        @Volatile var effectiveWidth = -1
        @Volatile var effectiveHeight = -1
        // v6.7.104 (B2): MediaProjection 系统已失效标志。
        // projection 对象字段可能仍非 null 但系统已 kill(onStop 回调已触发),
        // 此时若仍走常规 signalEndOfInputStream,编码器无新关键帧、EOS 永不返回,
        // awaitDrainCompletion 30s 超时后强制 flush 砍掉尾部帧。Service 在
        // MediaProjectionCallback.onStop 里置位,engine 在 stop/forceStop/stopAsync
        // 三处判定;新会话开始(handleStart)时清零。
        @Volatile var projectionInvalid = false

        fun logDir(context: android.content.Context): java.io.File {
            val baseDir = context.getExternalFilesDir(null)
                ?: context.filesDir
                ?: java.io.File(context.applicationInfo.dataDir)
            val dir = java.io.File(baseDir, "logs")
            if (!dir.exists()) dir.mkdirs()
            return dir
        }

        // v6.7.174 (异形屏 P0): 全仓唯一"物理整屏尺寸"来源(含 cutout,非可用区)。
        // UI/MainActivity 原先用 resources.displayMetrics(可用区,被系统栏削减),导致预览撒谎、
        // 选档后被 fit 改写(本机 app 区 1200x2390 vs 物理屏 1200x2652);服务层原 getRealSize
        // 在 Android12+(API30+)弃用,个别 OEM 返回偏差。统一到此,三端共用同一口径:
        //   - Android12+(R): currentWindowMetrics.bounds 整屏 bounds(含 cutout);
        //   - 更早:<R 用 defaultDisplay.getRealSize(弃用但仍是正确 API)。
        // 返回 (width, height),失败兜底 1080x1920 不让调用链崩。
        fun realScreenSize(context: android.content.Context): Pair<Int, Int> {
            return try {
                val wm = context.getSystemService(android.content.Context.WINDOW_SERVICE) as android.view.WindowManager
                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.R) {
                    val b = wm.currentWindowMetrics.bounds
                    b.width() to b.height()
                } else {
                    val p = android.graphics.Point()
                    @Suppress("DEPRECATION")
                    wm.defaultDisplay.getRealSize(p)
                    p.x to p.y
                }
            } catch (_: Exception) { 1080 to 1920 }
        }
    }
}

enum class RecordState {
    IDLE, PREPARING, STARTING, RECORDING, PAUSED, STOPPING, FAILED
}

enum class AudioMode(val label: String, val desc: String) {
    AUTO("自动", "智能选择"),
    MUTE("静音", "不录制音频"),
    MIC_ONLY("麦克风", "仅麦克风"),
    SPEAKER_ONLY("内部音频", "系统内部音频"),
    MIXED("混合", "麦克风+内部音频")
}

// v6.7.145 (P1-6): 停止原因结构化,借鉴必剪 RecordInfo4Report.StopReason。
// 5 值枚举:MANUAL(用户主动/通知栏/悬浮球)、DURATION_LIMIT(时长上限到点)、
// SHAKE(摇一摇)、SYSTEM_KILL(进程被系统回收)、ERROR(引擎报错)。
// 未来加"定时停止"再补 SCHEDULED_STOP。不放 COUNTDOWN_TIMEOUT——倒计时结束是
// "录制开始"语义,停止动作轮不到它,该值永远不可能产生,属死字段。
enum class StopReason { MANUAL, DURATION_LIMIT, SHAKE, SYSTEM_KILL, ERROR }

data class QualityParams(
    val width: Int,
    val height: Int,
    val frameRate: Int,
    val videoBitRate: Int,
    val audioBitRate: Int,
    val dpi: Int,
    // v6.7.135: HEVC 默认开。同码率下 HEVC 画质更优、体积约减半,现代设备普遍有 HEVC 硬编,
    // 对齐必剪/剪映默认策略。保留开关作兼容性兜底(老设备/老播放器),开关语义经打分压分修复后真实生效。
    val preferHevc: Boolean = true,
    val orientation: Int = 0
) : java.io.Serializable {
    companion object {
        // v6.7.132: Auto 档默认码率改"基准×系数"统一模型(替代旧静态表 defaultBitrateForHeight)。
        // 模型: baseBitrate × 分辨率系数 × 帧率系数 × HEVC系数 × HDR系数,超 uiMaxBitrate(80M) 封顶。
        // 系数默认值取自剪映 Hw.java 实证(720p/fps50/原始>4K/CRF上限/原始按4K 为插值/待实测)。
        fun defaultBitrateForHeight(height: Int): Int = bitrateScheduler().autoBitrate(0, height, 0, false, false)

        // 统一码率调度配置(可下发,后续调优免发版)。
        // 字段对齐剪映 Hw.java: bitrate=基准, fullHd/the2k/the4k/sd=分辨率系数,
        // hFps=帧率系数, hevc/hdr=比例, gop=GOP。num/den 结构对齐必剪。
        // 注: 纯 data class(不引 kotlinx.serialization 新依赖),JSON 下发走 org.json。
        data class BitrateSchedulerConfig(
            val baseBitrate: Int = 15_000_000,          // 基准(剪映 Hw.bitrate=15M)
            val ratio480p: Float = 0.4f,                // 实证(剪映 sdBitrateRatio)
            val ratio720p: Float = 0.8f,                // 插值(剪映无此字段,待实测校准)
            val ratio1080p: Float = 1.6f,               // 实证(剪映 fullHdBitrateRatio)
            val ratio2K: Float = 4.666f,                // 实证(剪映 the2kBitrateRatio)
            val ratio4K: Float = 4.866f,                // 实证(剪映 the4kBitrateRatio)
            val ratioFps60: Float = 1.428f,             // 实证(剪映 hFpsBitrateRatio,120/144 沿用,待实测)
            val ratioFps50: Float = 1.0f,               // 预留 1.2,默认 1.0(待实测)
            val hevcRatioNum: Int = 1,                  // HEVC 系数 num/den,默认 1/1(码率 max 取向)
            val hevcRatioDen: Int = 1,
            val hdrRatioNum: Int = 1,                   // HDR 系数 num/den,默认 1/1
            val hdrRatioDen: Int = 1,
            val gopFrames: Int = 120,                   // GOP 帧数(剪映 Hw.gop=120)
            val crfMaxBitrate: Int = 50_000_000,        // CRF 防失控上限(估计值,待实测)
            val uiMaxBitrate: Int = 80_000_000,          // UI 上限(实证必剪/剪映 80M)

            // v6.7.174 (异形屏 P2-b): 超长比屏码率补偿。20:9/21:9 等打孔长屏单帧像素量与
            // 同档位 16:9 相同,但纵向滚动内容多,编码器按横向 CTU 分块时纵向信息更密,等码率下
            // 更容易出现长边方向块状失真。long/short>=2.2 视为超长比,额外乘 ratioUltraLong。
            val ultraLongAspectThreshold: Float = 2.2f,  // 超长比判定阈值(20:9≈2.22,19.5:9≈2.17)
            val ratioUltraLong: Float = 1.1f             // 超长比码率补偿(10%,处于方案 10~15% 下沿)
        ) {
            // 最终码率 = 基准 × 分辨率系数 × 帧率系数 × HEVC系数 × HDR系数,封顶 uiMaxBitrate。
            // width=0 表示未定宽(仅按高度);fps=0 表示 Auto(按 1.0 处理,引擎按屏幕刷新率自适应)。
            fun autoBitrate(width: Int, height: Int, fps: Int, hevc: Boolean, hdr: Boolean): Int {
                val short = if (width <= 0) height else minOf(width, height)
                val resRatio = when {
                    short >= 2160 -> ratio4K          // 含原始>4K 按 4K 处理(推测,待实测)
                    short >= 1440 -> ratio2K
                    short >= 1080 -> ratio1080p
                    short >= 720 -> ratio720p
                    short >= 480 -> ratio480p
                    else -> ratio480p
                }
                val fpsRatio = when {
                    fps >= 60 -> ratioFps60           // 120/144 同用高帧率系数
                    fps == 50 -> ratioFps50
                    else -> 1.0f                       // 24/25/30 及 Auto
                }
                val hevcRatio = if (hevc) hevcRatioNum.toFloat() / hevcRatioDen else 1.0f
                val hdrRatio = if (hdr) hdrRatioNum.toFloat() / hdrRatioDen else 1.0f
                // v6.7.174 (异形屏 P2-b): 超长比屏(+10%)。基于传入宽高的等比,
                // clamp 未起效时即物理屏真实比例;起效后档位仍等比例缩小,比值不变。
                val ultraRatio = if (width > 0 && height > 0) {
                    val long = maxOf(width, height).toFloat()
                    val short = minOf(width, height).toFloat()
                    if (short > 0 && long / short >= ultraLongAspectThreshold) ratioUltraLong else 1.0f
                } else 1.0f
                val raw = baseBitrate.toLong() * resRatio * fpsRatio * hevcRatio * hdrRatio * ultraRatio
                return minOf(raw.toLong(), uiMaxBitrate.toLong()).toInt()
            }
        }

        private var _schedulerConfig: BitrateSchedulerConfig = BitrateSchedulerConfig()

        // 取当前调度配置(可被远程/本地下发覆盖,见 setBitrateSchedulerConfig)。
        fun bitrateScheduler(): BitrateSchedulerConfig = _schedulerConfig

        fun setBitrateSchedulerConfig(cfg: BitrateSchedulerConfig) {
            _schedulerConfig = cfg
        }
    }
}

data class RecorderConfig(
    val audioMode: AudioMode = AudioMode.SPEAKER_ONLY,
    val fileNamePattern: String = "ScreenRecord_%Y%m%d_%H%M%S",
    @Transient val outputUri: android.net.Uri? = null
) : java.io.Serializable

// v6.7.161 (压缩画质模式): 必剪压缩形态参数。服务层与 UI 预览共用同一公式,
// 保证"预览看到什么就录到什么"。短边锚定 640 等比缩放,30fps,AVC,bpp=0.155。
// 返回 Triple(width, height, bitrate)。纯整型运算,无新依赖;验证脚本可逐位复刻。
// ponytail: 横竖屏由 ScreenRecorderService 现有 orientation 逻辑接管(这里只给短边基准尺寸),
// 故 width 恒为短边、height 为长边,服务层再据屏幕朝向交换。
fun computeCompressQuality(shortEdge: Int, longEdge: Int): Triple<Int, Int, Int> {
    val targetShort = 640
    val s = shortEdge.coerceAtLeast(1)
    val scale = targetShort.toFloat() / s
    val rawLong = ((longEdge * scale) + 0.5f).toInt()
    val alignedLong = if (rawLong and 1 == 1) rawLong + 1 else rawLong
    val width = targetShort
    val height = alignedLong
    val bpp = 0.155
    val bitrate = (bpp * width * height * 30 + 0.5).toInt().coerceIn(1_000_000, 20_000_000)
    return Triple(width, height, bitrate)
}