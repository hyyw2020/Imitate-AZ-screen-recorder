package com.monkeycode.screenrecorder

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.content.pm.ServiceInfo
import android.graphics.PixelFormat
import android.hardware.Sensor
import android.hardware.SensorEvent
import android.hardware.SensorEventListener
import android.hardware.SensorManager
import android.media.projection.MediaProjection
import android.media.projection.MediaProjectionManager
import android.os.Build
import android.os.SystemClock
import java.util.concurrent.atomic.AtomicInteger
import android.os.IBinder
import android.os.PowerManager
import android.os.Handler
import android.os.HandlerThread
import android.os.Looper
import android.provider.Settings
import android.util.Log
import android.view.Gravity
import android.view.View
import android.view.WindowManager
import androidx.core.app.NotificationCompat
import java.io.File
import java.io.FileWriter
import java.io.IOException
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import java.util.concurrent.atomic.AtomicBoolean
import java.util.concurrent.atomic.AtomicReference

class ScreenRecorderService : Service() {

    companion object {
        private const val TAG = "ScreenRecorderService"

        const val ACTION_START = "com.monkeycode.screenrecorder.action.START"
        const val ACTION_PREPARE = "com.monkeycode.screenrecorder.action.PREPARE"
        const val ACTION_STOP = "com.monkeycode.screenrecorder.action.STOP"
        const val ACTION_PAUSE = "com.monkeycode.screenrecorder.action.PAUSE"
        const val ACTION_RESUME = "com.monkeycode.screenrecorder.action.RESUME"
        const val ACTION_HISTORY_CHANGED = "com.monkeycode.screenrecorder.action.HISTORY_CHANGED"
        // v6.7.95 (P0): 暂停/恢复状态变更广播。始终以 Service 为真相源,由 setState()
        // 统一发出,让主界面按钮/横幅随真实状态即时刷新,消除此前最长 6.9s 的界面滞后。
        const val ACTION_RECORD_STATE_CHANGED = "com.monkeycode.screenrecorder.action.RECORD_STATE_CHANGED"
        const val EXTRA_RECORD_STATE = "record_state"
        const val ACTION_RECORDING_STOPPED = "com.monkeycode.screenrecorder.action.RECORDING_STOPPED"
        // v6.7.188c-fix: 广播时带出"本会话是否真落盘",让 onRecordingStopped 不空报"已保存"。
        const val EXTRA_SAVED = "com.monkeycode.screenrecorder.extra.SAVED"
        const val ACTION_RECORDING_STARTED = "com.monkeycode.screenrecorder.action.RECORDING_STARTED"
        const val ACTION_THEME_CHANGED = "com.monkeycode.screenrecorder.action.THEME_CHANGED"
        // v6.7.188 (【2】): 常驻悬浮球开关。
        const val ACTION_SHOW_OVERLAY = "com.monkeycode.screenrecorder.action.SHOW_OVERLAY"
        const val ACTION_HIDE_OVERLAY = "com.monkeycode.screenrecorder.action.HIDE_OVERLAY"

        const val EXTRA_OUTPUT_PATH = "output_path"
        const val EXTRA_CONFIG = "config"
        const val EXTRA_OUTPUT_URI = "output_uri"
        const val EXTRA_QUALITY_PARAMS = "quality_params"
        const val EXTRA_PROJECTION_RESULT_CODE = "projection_result_code"
        const val EXTRA_PROJECTION_RESULT_DATA = "projection_result_data"
        // v6.7.89 (L-7): clamp 后的实际生效码率(单位 bps,随 ACTION_RECORDING_STARTED 下发)
        const val EXTRA_EFFECTIVE_BITRATE = "effective_bitrate"
        // v6.7.128: encoder 实际输出尺寸(等比 fit / 2K/4K clamp 后的真实档位),与码率同广播
        const val EXTRA_EFFECTIVE_WIDTH = "effective_width"
        const val EXTRA_EFFECTIVE_HEIGHT = "effective_height"

        private const val NOTIFICATION_ID_RECORDING = 1002
        private const val CHANNEL_ID_RECORDING = "screen_recorder_recording"
        private const val CHANNEL_NAME_RECORDING = "屏幕录制"
        // v6.7.188 (【2】): 常驻悬浮球独立通知 id/channel,不与录制通知冲突。
        private const val NOTIFICATION_ID_OVERLAY = 1003
        private const val CHANNEL_OVERLAY = "screen_recorder_overlay"
        // v6.7.181: PARTIAL_WAKE_LOCK 只保 CPU、不亮屏、不保射频,是锁屏录制所需的最小持锁。
        // 注意:持有任何 WakeLock(含 PARTIAL)都必须在 Manifest 声明 android.permission.WAKE_LOCK,
        // 否则 acquire() 抛 SecurityException。该项是普通权限,安装自动授予、不弹窗、
        // 不触发电池优化引导,与"不申请 REQUEST_IGNORE_BATTERY_OPTIMIZATIONS"目标不冲突。
        // 用途是锁屏后长录制期间 CPU 不被 Doze 挂起,否则编码器与麦克风线程停滞,
        // 录制产生黑帧+静音空洞。带 30 分钟超时由 onProgress 每秒续期,避免无限持锁被系统
        // 审计策略 kill;前台服务的保活上限是 10 分钟级且不防 CPU 休眠,不能替代这个持锁。
        private const val WAKE_LOCK_TAG = "ScreenRecorderService:WakeLock"
        private const val WAKE_LOCK_TIMEOUT_MS = 30L * 60 * 1000L
 
        private val state = AtomicReference(RecordState.IDLE)
        // v6.9.10: 实例字段 floatOverlay 的 companion 镜像,供 setState() 刷新子球①三态。
        // 由 floatOverlay 的 setter 同步;实例销毁后置 null 避免悬挂引用。
        @Volatile private var floatOverlayMirror: RecordOverlay? = null

        private fun setState(newState: RecordState) {
            val prev = state.getAndSet(newState)
            ScreenRecorderApp.recordState = newState
            // v6.7.95 (P0): 暂停/恢复态变化时广播,让 ACTIVITY 立即刷新按钮/横幅。
            // 与 ACTION_RECORDING_STOPPED 保持一致,必须 setPackage,避免其它应用收到。
            // 放在 setState() 而非 handlePause()/handleResume() 里,保证"任何改状态路径"都带通知。
            // 新增:开始播放/开始准备/开始停止等本身由 RECORDING_STARTED / RECORDING_STOPPED 覆盖,
            // 这里只针对"进入/退出暂停"的状态变化补发,避免与既有广播重复刷屏。
            val pausedRelated =
                when {
                    newState == RecordState.PAUSED -> true
                    prev == RecordState.PAUSED -> true
                    else -> false
                }
            if (prev != newState && pausedRelated) {
                try {
                    val ctx = com.monkeycode.screenrecorder.ScreenRecorderApp.instance
                    if (ctx != null) {
                        ctx.sendBroadcast(
                            Intent(ACTION_RECORD_STATE_CHANGED)
                                .setPackage(ctx.packageName)
                                .putExtra(EXTRA_RECORD_STATE, newState.name))
                    }
                } catch (_: Exception) {}
            }
            // v6.9.10 (AZ 一体四子球): 子球①随时反映三态。RECORDING/PAUSED 算"录制态",
            // 其余态(IDLE/FAILED/STOPPING)回到"开始录制"红点。
            try {
                val recNow = newState == RecordState.RECORDING || newState == RecordState.PAUSED
                floatOverlayMirror?.updateRecordingState(recNow)
            } catch (_: Exception) {}
        }
    }

    private lateinit var notificationManager: NotificationManager
    private lateinit var historyManager: RecordingHistoryManager
    private lateinit var preferencesManager: PreferencesManager
    // v6.7.145 (P1-6): 最近一次停止原因。默认 MANUAL,各停止入口写入,
    // recordToHistory 时读出落到历史 JSON 与 DiagLog。
    @Volatile private var lastStopReason: StopReason = StopReason.MANUAL
    // v6.7.188c-fix: 本会话是否真落盘过一段录制。仅 recordToHistory 成功写入时置 true,
    // 用于区分"真录完"与"IDLE/被拒/已停的空 stop",让 onRecordingStopped 不误报"已保存"。
    @Volatile private var sessionRecorded = false
    // v6.7.144 (P0-3): 摇一摇停止——加速度传感器监听。仅在 RECORDING 态注册,
    // 停止路径幂等注销。借鉴必剪 MediaConfig.shakeToStopRecord。
    private var sensorManager: SensorManager? = null
    private var shakeDetectedAt: Long = 0L
    private var shakeCount = 0
    private val shakeListener = object : SensorEventListener {
        override fun onSensorChanged(e: SensorEvent) {
            // v6.7.144 (决策4): PAUSED/其他态不触发,避免暂停时误停。
            if (state.get() != RecordState.RECORDING) return
            val x = e.values[0]; val y = e.values[1]; val z = e.values[2]
            val g = kotlin.math.sqrt(x * x + y * y + z * z) / SensorManager.GRAVITY_EARTH
            if (g < 2.5f) return
            val now = SystemClock.elapsedRealtime()
            if (now - shakeDetectedAt <= 500L) {
                shakeCount++
                if (shakeCount >= 2) {
                    shakeCount = 0
                    writeLog("shake-to-stop triggered g=$g")
                    unregisterShakeSensor()
                    handleStop(StopReason.SHAKE)
                }
            } else {
                shakeCount = 1
            }
            shakeDetectedAt = now
        }

        override fun onAccuracyChanged(s: Sensor?, a: Int) {}
    }
    private var mediaProjectionManager: MediaProjectionManager? = null
    private var mediaProjection: MediaProjection? = null
    private var engine: RecorderEngine? = null
    private var wakeLock: PowerManager.WakeLock? = null
    // v6.7.184: 持锁状态不再在 Service 侧冗余存一份,统一以 RecorderEngine 的
    // wakeLockHeld / wakeLockLostCount 为唯一源(经 setWakeLockHeld / onWakeLockLost 同步),
    // 报告从 engine 直接读,避免双源不一致。
    private var screenStateReceiver: BroadcastReceiver? = null
    private var floatOverlay: RecordOverlay? = null
        // v6.9.10: companion 内 setState() 无法访问本实例字段,但需在任何改状态路径
        // 刷新子球①三态。setter 同步到 companion 镜像,零调用点改动。
        set(value) {
            field = value
            floatOverlayMirror = value
        }
    // v6.7.188 (【2】): 常驻悬浮球开关态。true 时停止录制不收球、不 stopSelf。
    private var overlayPersistent = false
    // v6.7.68 (AZ 兼容): 全屏透明承载窗口(复刻 AZ zg/t)。与交互小球(RecordOverlay,即
    // AZ zg/o)组成双窗口结构:承载层铺满全屏、FLAG_NOT_TOUCHABLE(不拦截触摸),让厂商
    // 合成层把本应用视为"正常全屏窗口 + 内部交互控件",而非"被判定的小悬浮球",降低被
    // 静默抑制概率。承载层不绘制任何内容,仅提供全屏窗口存在性。
    private var fullScreenCarrier: View? = null
    // v6.7.89 (L-3): 全屏承载窗口默认关闭。它不绘制内容,只提供"存在性",
    // 代价是每帧多合成一层全屏 layer(且在 AUTO_MIRROR 录制中占编码像素)。
    // 保留开关以便 A/B 验证是否真有必要。
    private val ENABLE_FULL_SCREEN_CARRIER = false
    private var projectionCallback: MediaProjectionCallback? = null
    private var serviceHandler: Handler? = null
    private var serviceThread: HandlerThread? = null
    private val mainUiHandler = Handler(Looper.getMainLooper())
    private val isCleaningUp = AtomicBoolean(false)
    // v6.7.66 (P3-4): 悬浮窗"挂载成功但不可见"自动重挂载计数,最多 2 次兜底
    private var overlayRemountCount = 0
    private val OVERLAY_REMOUNT_MAX = 2
    private val OVERLAY_REMOUNT_DELAY_MS = 300L
    // v6.7.67 (P1-2): 放行引导去重——同一次录制会话内只提示 1 次,避免打扰录制
    private var overlayGuideShown = false
    // 排队重试:前一段录制未完全释放时,新 PREPARE 延迟 200ms 重试(最多 5 次)
    private val prepareRetryCount = AtomicInteger(0)
    private val MAX_PREPARE_RETRY = 5
    private val PREPARE_RETRY_DELAY_MS = 200L
    // v6.7.109 (SVC-3): @Volatile 保证不同线程(serviceThread/AsyncDrainThread/UI)间可见。
    // v6.7.108 起 stopAsync 收尾可能晚于 cleanupAndStop 读它,非 volatile 可能读到过期引用。
    @Volatile
    private var currentQualityParams: QualityParams? = null
    // 最近一次从 intent 解析成功的音频模式,用于启动时判断前台类型,
    // 以及在 intent 无可解析配置时兜底使用
    private var previousResolvedAudioMode: AudioMode? = null
    private var currentOutputUri: String? = null
    private var currentOutputPath: String? = null
    private var lastProgressSeconds = 0L
    // v6.7.88 (Ch5.3): 通知由 chronometer 自动计秒,仅文件大小跨 1MB 步进才刷新通知体。
    private var lastNotifiedSizeStep = -1L
    // v6.7.88 (Ch5.2): 缓存最近 durationMs,供暂停/恢复路径(无 durationMs 参数)
    // 重建通知时正确设置 chronometer 基准,避免恢复后计时归零。
    private var lastDurationMs = 0L
    private var pendingSafFileName: String? = null
    // v6.7.128: 多分片录制暂存的分片路径(onSegments 回调写入,recordToHistory 读取)。
    private var pendingSegmentPaths: List<String> = emptyList()

    private val recorderCallback = object : RecorderEngineCallback {
        override fun onStarted() {
            writeLog("engine onStarted")
            setState(RecordState.RECORDING)
            // v6.7.144 (P0-3): 录制真正开始处注册摇一摇传感器。仅开关开启时注册,
            // 未开启时零开销。注销在 cleanupAndStop() 幂等处理。
            registerShakeSensor()
            // v6.7.88 (Ch5.2/5.3): 新会话开始,重置通知追踪器,避免上一会话的
            // lastNotifiedSizeStep/lastDurationMs 残留导致首帧不刷新或计时基准错位。
            lastNotifiedSizeStep = -1L
            lastDurationMs = 0L
            updateNotification(buildRecordingNotification())
            // 录制真正开始:广播通知 UI 即时刷新按钮为「停止录制」。
            // 此前缺少 START 广播,Activity 仅在 onStart/停止广播时刷新,
            // 与 handleStart 异步状态切换竞态,导致按钮常停在「开始录制」。
            try {
                // v6.7.89 (L-7): 回传 clamp 后的实际生效码率,让参数预览显示「16 Mbps(实际 12 Mbps)」。
                val effectiveBitrate = engine?.getCurrentBitrate() ?: -1
                if (effectiveBitrate > 0) {
                    DiagLog.logEvent("CFG", "effective bitrate broadcast=$effectiveBitrate")
                }
                // v6.7.128: 同广播回传 encoder 实际输出尺寸(等比 fit / clamp 后真实档位)。
                val effW = engine?.getActualWidth() ?: -1
                val effH = engine?.getActualHeight() ?: -1
                sendBroadcast(
                    Intent(ACTION_RECORDING_STARTED)
                        .setPackage(packageName)
                        .putExtra(EXTRA_EFFECTIVE_BITRATE, effectiveBitrate)
                        .putExtra(EXTRA_EFFECTIVE_WIDTH, effW)
                        .putExtra(EXTRA_EFFECTIVE_HEIGHT, effH)
                )
            } catch (e: Exception) {
                writeLog("broadcast recording started error: ${e.message}")
            }
        }

        override fun onStopped(durationMs: Long, fileSize: Long, outputPath: String) {
            // v6.7.97 (改进2): 直接使用引擎回调给的 URI 字符串。
            // 引擎已在 stop/forceStop/stopAsync 里完成 renameToFinal(finalSafUri 已是 .mp4 document),
            // 此处不再用 pendingSafFileName 拼本地 File 路径伪造"历史目录名"。
            // v6.7.96 那套拼法把 SAF 产物映射到 /sdcard/包名/Movies/xxx.mp4 的假路径,
            // 与实际 .mp4 document URI 不一致,历史点开可能定位不到。
            writeLog("engine onStopped durationMs=$durationMs fileSize=$fileSize path=$outputPath")
            // v6.7.128: 用暂存的分片路径(若多分片)写历史条目
            recordToHistory(durationMs, fileSize, outputPath, pendingSegmentPaths)
            // 不在这里直接置 IDLE:handleStop 已置 STOPPING,若此处强行置 IDLE 会
            // 覆写状态并导致 UI 收到 STOPPING→IDLE 的异常广播顺序。
            // 统一由 cleanupAndStop 末尾置 IDLE。
            cleanupAndStop()
        }

        // v6.7.128: 多分片录制结束时引擎回调分片路径列表,暂存供 recordToHistory 用。
        override fun onSegments(segments: List<String>) {
            pendingSegmentPaths = segments
            // v6.7.189 (P0-1): 去掉 >1 门限,单片也登记,保证可观测。
            writeLog("engine onSegments count=${segments.size}")
        }

        override fun onError(exception: Exception) {
            // v6.7.145 (P1-6): 引擎报错 → 停止原因 ERROR。
            lastStopReason = StopReason.ERROR
            writeLog("engine onError: ${exception.message ?: exception.javaClass.name}")
            writeLog("engine onError stack:\n${android.util.Log.getStackTraceString(exception)}")
            Log.e(TAG, "RecorderEngine error", exception)
            ScreenRecorderApp.lastError =
                "${exception.javaClass.name}: ${exception.message}\n${android.util.Log.getStackTraceString(exception)}"
            setState(RecordState.FAILED)
            // v6.7.50: onError 可能从编码线程回调(如磁盘满 checkFreeSpace)。
            // 若在此线程同步 cleanupAndStop -> engine.forceStop -> awaitDrainCompletion,
            // 会 await 编码线程自身 countDown 的 videoDrainDone,卡死最多 30s。
            // 因此把清理投递到 serviceHandler 串行执行,脱离回调线程。
            val h = serviceHandler
            if (h != null) h.post { cleanupAndStop() } else cleanupAndStop()
        }

        override fun onEncoderChanged(codec: String) {
            writeLog("engine onEncoderChanged codec=$codec")
        }

        override fun onProgress(durationMs: Long, fileSize: Long) {
            DiagLog.recordOnProgressGap()
            // v6.7.181: 录制期间持 PARTIAL_WAKE_LOCK 保证锁屏时 CPU 不挂起(连续录制);
            // PARTIAL 须声明 android.permission.WAKE_LOCK(普通权限,安装自授,非电池豁免),
            // 与"不申请电池优化豁免"目标不冲突。
            // 屏幕常亮由悬浮球/MainActivity 的 FLAG_KEEP_SCREEN_ON 负责(防超时熄屏)。
            // onProgress 每秒回调,这里顺带续期,防 30 分钟超时后 CPU 释放。
            renewWakeLock()
            // v6.7.144 (P0-2): 时长上限检查。onProgress 每秒回调天然满足检查粒度,
            // durationMs 语义为累计录制时长(暂停不计时)。到点自动停,复用 handleStop
            // 保存链路,保证分片收口 + 历史入库。借鉴必剪 MediaConfig.recordDuration。
            val limitMin = preferencesManager.durationLimitMinutes()
            if (limitMin > 0 && durationMs >= limitMin * 60_000L) {
                writeLog("duration limit reached ${limitMin}m, auto stop")
                handleStop(StopReason.DURATION_LIMIT)
                return
            }
            val secondsChanged = (durationMs / 1000L) != lastProgressSeconds
            lastProgressSeconds = durationMs / 1000L
            lastDurationMs = durationMs
            if (secondsChanged) {
                // 悬浮球计时器每秒刷新(无 binder 开销,纯进程内 invalidate)
                // v6.7.128: 降档激活时在计时后追加降档码率标记(▼=降档 L=锁死)
                val timerText = formatDuration(durationMs)
                val engine = engine
                if (engine != null && engine.isDowngradeActive()) {
                    val br = engine.getCurrentBitrate()
                    val brMb = if (br > 0) br / 1_000_000.0 else 0.0
                    val suffix = if (engine.isDowngradeLatched()) " ▼L${brMb}M" else " ▼${brMb}M"
                    floatOverlay?.updateTimer(timerText + suffix)
                } else {
                    floatOverlay?.updateTimer(timerText)
                }
            }
            // v6.7.88 (Ch5.3): 通知栏用 chronometer 自动计秒,无需每秒 updateNotification。
            // 仅文件大小跨 1MB 步进才刷新通知体,把每秒一次的 binder IPC 降到 ~1 次/MB。
            val sizeStep = fileSize / (1024L * 1024L)
            if (sizeStep != lastNotifiedSizeStep) {
                lastNotifiedSizeStep = sizeStep
                updateNotification(buildRecordingNotification(durationMs, fileSize))
            }
        }

        // v6.7.48: 非致命运行期预警,仅记录排查,不打断录制。
        override fun onWarning(warning: String) {
            writeLog("engine warning: $warning")
        }
    }

    override fun onCreate() {
        super.onCreate()
        try {
            writeLog("onCreate")
            notificationManager = getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
            try {
                // v6.7.101 (B1): 与 MainActivity 共享进程级单例,消除跨实例内存竞争。
            historyManager = RecordingHistoryManager.get(this)
            } catch (e: Exception) {
                writeLog("RecordingHistoryManager init error: ${e.message}")
            }
            preferencesManager = PreferencesManager(this)
            mediaProjectionManager = getSystemService(Context.MEDIA_PROJECTION_SERVICE) as MediaProjectionManager

            try {
                createNotificationChannels()
            } catch (e: Exception) {
                writeLog("createNotificationChannels error: ${e.message}")
            }
            serviceThread = HandlerThread("ScreenRecorderServiceThread")
            serviceThread?.start()
            serviceHandler = Handler(serviceThread!!.looper)
            // v6.7.116/121: 上次异常中断残留的 .recording.tmp 处理已前移到 MainActivity
            // (findStaleRecordings + 横幅[继续]/[丢弃]), Service 不再自动处理, 仅清理超龄
            // emergency 日志, 避免脚本/重复弹提示。
            try {
                serviceHandler?.post {
                    com.monkeycode.screenrecorder.RecorderEngine.cleanEmergencyLogs(this)
                }
            } catch (e: Exception) {
                writeLog("cleanStale post error: ${e.message}")
            }
        } catch (e: Exception) {
            Log.e(TAG, "onCreate failed: ${e.message}", e)
        }
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        try {
            if (intent == null) {
                // v6.7.188 (【2】): 无 intent 复活时按 pref 复活常驻球。
                // 若开关仍开且当前未在录制/暂停，则以常驻态拉起悬浮球；否则清 stale 状态并停服务。
                if (PreferencesManager(this).isShowOverlayEnabled()) {
                    overlayPersistent = true
                    if (currentRecordState() != RecordState.RECORDING && currentRecordState() != RecordState.PAUSED) {
                        if (!RecorderEngine.isRecordingActive(this)) {
                            postPersistentOverlayNotification()
                            showFloatOverlay()
                            return START_STICKY
                        }
                    }
                }
                // 进程因内存压力被杀后 START_STICKY 复活,但此时无 MediaProjection,
                // 无法恢复录制,且不应凭空声明带 mediaProjection 类型的前台服务
                // (Android 14+ 校验失败会被系统强杀)。检测到残留录制状态则清理,
                // 不启动前台服务,直接停止,避免被杀-重启循环。
                writeLog("onStartCommand null intent (START_STICKY revive), cannot resume without projection")
                if (RecorderEngine.isRecordingActive(this)) {
                    writeLog("recording active before restart, clearing stale state (cannot resume)")
                    RecorderEngine.clearRecordingState(this)
                    setState(RecordState.IDLE)
                }
                stopSelf()
                return START_NOT_STICKY
            }
            val action = intent.action ?: return START_STICKY
            writeLog("onStartCommand action=$action")

            // v6.7.188 (【2】): 常驻悬浮球开关。
            // 打开：非录制态拉起悬浮球并常驻前台通知；已在录制时仅置位标志。
            // 关闭：非录制态立即收球+停服务；已在录制时仅清标志，停止后再收。
            when (action) {
                ACTION_SHOW_OVERLAY -> {
                    overlayPersistent = true
                    if (currentRecordState() != RecordState.RECORDING && currentRecordState() != RecordState.PAUSED) {
                        postPersistentOverlayNotification()
                        showFloatOverlay()
                    }
                    return START_STICKY
                }
                ACTION_HIDE_OVERLAY -> {
                    overlayPersistent = false
                    if (currentRecordState() != RecordState.RECORDING && currentRecordState() != RecordState.PAUSED) {
                        dismissFloatOverlay()
                        try { stopForeground(STOP_FOREGROUND_REMOVE) } catch (_: Exception) {}
                        stopSelf()
                    }
                    return START_STICKY
                }
                else -> {}
            }

            // 决定前台服务类型:优先解析 intent 中的音频模式,使 MIC_ONLY/MIXED
            // 场景在 startForeground 一步就带上 MICROPHONE 类型,避免先以纯
            // mediaProjection 启动后 Android 14+ 因 FGS mic-type 与 manifest 不符
            // 或 mic-access 超时被中途切断。解析失败回退无麦克风。
            val includeMic = extractAudioModeNeedsMic(intent)
            goForeground(includeMic)

            when (action) {
                ACTION_START, ACTION_PREPARE -> {
                    serviceHandler?.post { handleStart(intent) }
                }
                ACTION_STOP -> handleStop()
                ACTION_PAUSE -> handlePause()
                ACTION_RESUME -> handleResume()
                ACTION_THEME_CHANGED -> {
                    writeLog("theme changed, recolor float overlay")
                    floatOverlay?.recolor()
                }
                else -> {
                    writeLog("onStartCommand unhandled action=$action")
                }
            }
        } catch (e: Exception) {
            Log.e(TAG, "onStartCommand top-level error: ${e.message}", e)
            goForeground(false)
        }

        return START_STICKY
    }

    // v6.7.188: 当前录制态便捷读法(避免各分支直接访问 ScreenRecorderApp)。
    private fun currentRecordState(): RecordState = ScreenRecorderApp.recordState

    // v6.7.188 (【2】): 常驻悬浮球前台通知。前台类型 mediaProjection, 无麦克风, 点回主页,
    // 通知带"隐藏悬浮球"动作 -> 广播 ACTION_HIDE_OVERLAY。
    private fun postPersistentOverlayNotification() {
        if (!android.provider.Settings.canDrawOverlays(this)) return
        val notifyId = NOTIFICATION_ID_OVERLAY
        val channel = android.app.NotificationChannel(
            CHANNEL_OVERLAY,
            "悬浮球常驻",
            android.app.NotificationManager.IMPORTANCE_LOW
        ).apply { setShowBadge(false) }
        val mgr = getSystemService(NotificationManager::class.java)
        runCatching { mgr?.createNotificationChannel(channel) }

        val openMain = android.content.Intent(this, MainActivity::class.java).apply {
            flags = android.content.Intent.FLAG_ACTIVITY_NEW_TASK or android.content.Intent.FLAG_ACTIVITY_CLEAR_TOP
        }
        val content = android.app.PendingIntent.getActivity(
            this, 0, openMain,
            android.app.PendingIntent.FLAG_UPDATE_CURRENT or android.app.PendingIntent.FLAG_IMMUTABLE
        )

        val hideIntent = android.content.Intent(this, ScreenRecorderService::class.java).apply {
            action = ACTION_HIDE_OVERLAY
        }
        val hidePi = android.app.PendingIntent.getService(
            this, 1, hideIntent,
            android.app.PendingIntent.FLAG_UPDATE_CURRENT or android.app.PendingIntent.FLAG_IMMUTABLE
        )
        val hideAction = androidx.core.app.NotificationCompat.Action.Builder(
            android.R.drawable.ic_menu_close_clear_cancel,
            "隐藏悬浮球",
            hidePi
        ).build()

        val builder = androidx.core.app.NotificationCompat.Builder(this, CHANNEL_OVERLAY)
            .setSmallIcon(R.drawable.ic_recording_mono)
            .setContentTitle("悬浮球常驻中")
            .setContentText("不录制，可随时开始/暂停/截图")
            .setContentIntent(content)
            .addAction(hideAction)
            .setOngoing(true)
            .setCategory(androidx.core.app.NotificationCompat.CATEGORY_SERVICE)
            .setPriority(androidx.core.app.NotificationCompat.PRIORITY_LOW)

        try {
            startForeground(notifyId, builder.build(), android.content.pm.ServiceInfo.FOREGROUND_SERVICE_TYPE_MEDIA_PROJECTION)
        } catch (_: Exception) {
            try { startForeground(notifyId, builder.build()) } catch (_: Exception) {}
        }
    }

    // 从 intent 中安全解析音频模式并判断是否需要 microphone 前台类型。
    // 不依赖 EXTRA_CONFIG 的 Serializable 全量解析(ClassLoader 隔离可能抛异常),
    // 单独读取 audioMode。解析失败默认 false(无麦克风类型)。
    // v6.7.107 (S1): 仅当 intent 携带 EXTRA_CONFIG(cfg 非 null) 时才更新 previousResolvedAudioMode。
    // 旧实现无条件覆盖为 cfg?.audioMode,STOP/PAUSE/RESUME/主题变更等不带 config 的 intent
    // 会把缓存清空为 null,随后 goForeground(false) 在麦克风仍在采集/drain 期间重新声明
    // 不带 MICROPHONE 的 FGS 类型,Android 14+ 可能静默回收 mic 或抛 SecurityException,
    // 导致 MIC_ONLY/MIXED 录制尾段无声甚至中断。
    private fun extractAudioModeNeedsMic(intent: Intent): Boolean {
        return try {
            val cfg = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
                intent.getSerializableExtra(EXTRA_CONFIG, RecorderConfig::class.java)
            } else {
                @Suppress("DEPRECATION")
                intent.getSerializableExtra(EXTRA_CONFIG)
            } as? RecorderConfig
            val mode = cfg?.audioMode ?: previousResolvedAudioMode
            if (cfg != null) {
                previousResolvedAudioMode = cfg.audioMode
            }
            mode == AudioMode.MIC_ONLY || mode == AudioMode.MIXED
        } catch (e: Exception) {
            writeLog("extractAudioModeNeedsMic fallback, cannot parse config: ${e.message}")
            val prev = previousResolvedAudioMode
            prev == AudioMode.MIC_ONLY || prev == AudioMode.MIXED
        }
    }

    fun goForeground(includeMic: Boolean = false) {
        val notification = buildRecordingNotification()
        var type = 0
        try {
            if (Build.VERSION.SDK_INT >= 29) {
                type = ServiceInfo.FOREGROUND_SERVICE_TYPE_MEDIA_PROJECTION
                // App records internal audio (and optionally mic). Declare both
                // types so Android 14+ does not throw with the manifest.
                // includeMic=true 仅在 MIC_ONLY/MIXED 模式下传入,避免无麦克风
                // 录制时也申请 mic 前台类型。
                if (includeMic) {
                    type = type or ServiceInfo.FOREGROUND_SERVICE_TYPE_MICROPHONE
                }
                startForeground(NOTIFICATION_ID_RECORDING, notification, type)
                writeLog("startForeground called, type=$type (sdk>=29 three-arg)")
            } else {
                @Suppress("DEPRECATION")
                startForeground(NOTIFICATION_ID_RECORDING, notification)
                writeLog("startForeground called, two-arg legacy (sdk<29, manifest type in effect)")
            }
        } catch (e: Exception) {
            writeLog("startForeground failed: ${e.message}")
            // Last resort: retry without type-specific flags.
            try {
                @Suppress("DEPRECATION")
                startForeground(NOTIFICATION_ID_RECORDING, notification)
            } catch (e2: Exception) {
                writeLog("startForeground fallback failed: ${e2.message}")
                // v6.7.50: 两参数兜底也失败,说明服务无法进入前台(可能因类型受限)。
                // 若继续运行会被系统强制清理或处于非法前台态,安全起见主动停止。
                try { stopSelf() } catch (_: Exception) {}
            }
        }
    }

    override fun onBind(intent: Intent?): IBinder? = null

    /** v6.7.45(层级四 超越AZ点): 用户从最近任务划掉本应用时,尽力 finalize 当前录制,
     * 避免整段 MP4 因 moov 未写而损坏。onDestroy 不保证划掉任务栈时必执行,
     * 而 onTaskRemoved 恰好是"划掉"信号。转发到 cleanupAndStop 复用既有收尾路径。
     * v6.7.107 (S2): 投递到 serviceHandler 串行执行,不再在主线程同步跑 cleanupAndStop。
     * 旧实现直接在主线程调 cleanupAndStop → engine.forceStop → awaitDrainCompletion(最长
     * 30s)+ flushMuxer + SAF 拷贝 IO,导致划掉任务时主线程阻塞数十秒 → ANR("应用无响应"),
     * 且 moov 反而可能因超时被砍,与本方法"尽力 finalize"的意图相反。 */
    override fun onTaskRemoved(rootIntent: Intent?) {
        writeLog("onTaskRemoved, safe stop")
        try {
            if (state.get() != RecordState.IDLE) {
                val h = serviceHandler
                if (h != null) {
                    h.post { runCatching { cleanupAndStop() } }
                } else {
                    cleanupAndStop()
                }
            }
        } catch (_: Exception) {}
        super.onTaskRemoved(rootIntent)
    }

    override fun onDestroy() {
        writeLog("onDestroy")
        // v6.7.180: 主线程兜底注销屏幕状态接收器,防 cleanupAndStop 未跑到时泄漏。
        unregisterScreenStateReceiver()
        // v6.7.181: 兜底释放 WakeLock,防 cleanupAndStop 未跑到时持锁到 30 分钟超时。
        releaseWakeLock()
        // v6.7.107 (S2): 与 onTaskRemoved 同理,主线程同步 cleanupAndStop 会阻塞数十秒。
        // 先投递收尾到 serviceHandler,再 quitSafely 等其排空;cleanupAndStop 已幂等
        // (isCleaningUp CAS),后续 onStopped/onStop 回调触发的重复调用会安全跳过。
        val h = serviceHandler
        if (h != null) {
            h.post { runCatching { cleanupAndStop() } }
        } else {
            try { cleanupAndStop() } catch (_: Exception) {}
        }
        // 统一日志已由 writeToLogFile 写入 DiagLog，无需额外清理
        serviceThread?.quitSafely()
        serviceThread = null
        serviceHandler = null
        super.onDestroy()
    }

    // v6.7.75-F3: Service 声明了 configChanges=orientation|screenSize|keyboardHidden,
    // 旋转时 Service 不会重建,必须手动把方向变化转发给悬浮窗,让它在主线程重新
    // 钳制坐标,避免沿用旧方向的坐标系/导航条 inset。未挂载时安全跳过。
    override fun onConfigurationChanged(newConfig: android.content.res.Configuration) {
        super.onConfigurationChanged(newConfig)
        val overlay = floatOverlay
        if (overlay != null) {
            if (Looper.myLooper() != Looper.getMainLooper()) {
                mainUiHandler.post { overlay.onScreenOrientationChanged() }
            } else {
                overlay.onScreenOrientationChanged()
            }
        }
    }

    private fun handleStart(intent: Intent) {
        newSession()   // v6.7.189 (P2-14): 签发新会话 token,cleanupAndStop 按会话幂等
        // v6.7.51: DiagLog 提前到 handleStart 最开头启动,确保所有失败路径
        // (如 MediaProjection 投影重建失败在早期 return)的写盘日志都能落盘,
        // 避免"投影重建失败 + DiagLog 未 start + 无任何日志"的排查盲区。
        DiagLog.start(this)
        writeLog("handleStart")
        // v6.7.104 (B2): 新会话清零 projection 失效标志,防止上一会话 onStop
        // 遗留的 true 值污染本次会话的 EOS 判定。
        ScreenRecorderApp.projectionInvalid = false
        // v6.7.67 (P1-2): 新录制会话复位放行引导去重标记(每次会话提示 1 次)
        overlayGuideShown = false
        // 状态机串行化:前一段录制未完全释放则延迟重试,
        // 避免旧 MediaProjection/FGS 未清理时重建导致 Android 15+ 报错。
        val currentState = state.get()
        if (currentState != RecordState.IDLE && currentState != RecordState.FAILED) {
            val retry = prepareRetryCount.incrementAndGet()
            if (retry <= MAX_PREPARE_RETRY) {
                writeLog("handleStart queued: state=$currentState retry=$retry, retrying in ${PREPARE_RETRY_DELAY_MS}ms")
                val currentIntent = intent
                serviceHandler?.postDelayed({ handleStart(currentIntent ?: return@postDelayed) }, PREPARE_RETRY_DELAY_MS)
            } else {
                prepareRetryCount.set(0)
                writeLog("handleStart exhausted retries: state=$currentState")
                // v6.7.107 (S3): 重试耗尽时必须收口资源,旧实现只发广播,前台通知残留
                // "录制中"、wake lock 不释放、engine/projection 不回收;且 state 仍停在
                // 非 IDLE,下一次 ACTION_START 会再次进入重试队列,形成耗尽死循环。
                // cleanupAndStop 内 isCleaningUp CAS 幂等,且在 serviceHandler 上串行安全。
                try { cleanupAndStop() } catch (e: Exception) {
                    writeLog("cleanup on exhausted retries error: ${e.message}")
                }
                // v6.7.102 (B3): STOPPED 广播也补 setPackage,与 STARTED/HISTORY_CHANGED/
                // RECORD_STATE_CHANGED 保持一致,避免荣耀/华为 MagicOS 拦截隐式广播。
                val i = Intent(ACTION_RECORDING_STOPPED).setPackage(packageName)
                i.putExtra("rejected", true)
                i.putExtra("reason", "state=$currentState after ${MAX_PREPARE_RETRY} retries")
                try { sendBroadcast(i) } catch (_: Exception) {}
            }
            return
        }
        prepareRetryCount.set(0)
        setState(RecordState.STARTING)
        sessionRecorded = false   // v6.7.188c-fix: 新会话起点复位,避免上一会话残留 true

        try {
            currentOutputPath = intent.getStringExtra(EXTRA_OUTPUT_PATH) ?: currentOutputPath
            currentOutputUri = intent.getStringExtra(EXTRA_OUTPUT_URI) ?: currentOutputUri

            // EXTRA_QUALITY_PARAMS / EXTRA_CONFIG 用 Serializable 传递。
            // API 33+ 的 typed getSerializableExtra 在某些 ROM/ClassLoader 隔离
            // 场景会抛异常,必须整体防御,失败则回退到持久化偏好,避免录制直接崩溃。
            val qualityParams = try {
                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
                    intent.getSerializableExtra(EXTRA_QUALITY_PARAMS, QualityParams::class.java)
                } else {
                    @Suppress("DEPRECATION")
                    intent.getSerializableExtra(EXTRA_QUALITY_PARAMS) as? QualityParams
                }
            } catch (e: Exception) {
                writeLog("EXTRA_QUALITY_PARAMS deserialize fallback: ${e.message}")
                null
            }
            currentQualityParams = qualityParams ?: currentQualityParams

            val config = try {
                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
                    intent.getSerializableExtra(EXTRA_CONFIG, RecorderConfig::class.java)
                } else {
                    @Suppress("DEPRECATION")
                    intent.getSerializableExtra(EXTRA_CONFIG)
                } as? RecorderConfig
            } catch (e: Exception) {
                writeLog("EXTRA_CONFIG deserialize fallback to prefs: ${e.message}")
                null
            } ?: preferencesManager.loadConfig()
            previousResolvedAudioMode = config.audioMode

            val outputPath = resolveOutputUri(config, currentQualityParams)

            // AZ 6.9.9 风格:录制前按设备真实屏幕能力 clamp 分辨率与帧率,
            // 避免用户选择超出设备物理极限的档位（如 144fps 设备仅 60Hz），
            // 防止 VirtualDisplay 以系统刷新率持续投帧但编码器帧率虚高。
            // v6.7.174 (异形屏 P0): 尺寸改走统一 helper realScreenSize(Android12+ currentWindowMetrics、
            // <12 getRealSize,与 UI/引擎同口径),替代此处弃用的 display.getRealSize(local wm)。
            val displaySize = ScreenRecorderApp.realScreenSize(this)
            // v6.7.177 (顺手·双口径对照): 只观测不改行为。realScreenSize 在 Android12+ 押
            // currentWindowMetrics.bounds,<12 用 getRealSize;个别 OEM 两口径会偏差且无法实验室
            // 穷举。此处取两口径对照打 screen_ref_mismatch,线上灰度收集,不一致时再决策是否改默认
            // 口径。不影响本行返回值与下游逻辑。
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.R) {
                try {
                    val legacy = android.graphics.Point()
                    @Suppress("DEPRECATION")
                    val wm = getSystemService(WINDOW_SERVICE) as android.view.WindowManager
                    @Suppress("DEPRECATION")
                    wm.defaultDisplay.getRealSize(legacy)
                    if (legacy.x != displaySize.first || legacy.y != displaySize.second) {
                        writeLog("screen_ref_mismatch metrics=${displaySize.first}x${displaySize.second} " +
                            "getRealSize=${legacy.x}x${legacy.y}")
                    }
                } catch (_: Exception) {}
            }
            val isPortraitDevice = displaySize.first < displaySize.second
            val screenW = minOf(displaySize.first, displaySize.second)
            val screenH = maxOf(displaySize.first, displaySize.second)
            // 屏幕原始分辨率档的真实宽高(a,b 可能是竖屏 w<h),供诊断与档位用。
            val rawScreen = if (isPortraitDevice) displaySize else (displaySize.second to displaySize.first)
            // v6.7.161 (压缩画质模式): 开启后完全自动(分辨率/帧率/码率均 Auto),
            // 按必剪压缩形态录制:短边 640 等比缩放 + 30fps + AVC(bpp≈0.155 算码率)。
            // 覆盖 qualityParams2,下游 clamp/fit/引擎配置自然继承,无需各处打补丁;
            // 默认关时不牺牲常规录制的画质与帧率。放在 screenW/screenH 定义之后(公式需短边基准)。
            val qualityParams2 = if (preferencesManager.isCompressQualityEnabled()) {
                val (cw, ch, cbr) = computeCompressQuality(screenW, screenH)
                QualityParams(cw, ch, 30, cbr, 128_000, 320, preferHevc = false, orientation = 0)
            } else {
                currentQualityParams
            }
            // v6.7.156 (修1): maxFps 取支持模式的最大刷新率,不再用实时 refreshRate。
            // 实时 refreshRate 是"当前生效刷新率"(本机锁 60Hz),面板物理上限可能是 120/144;
            // 用实时值会把用户手选的 144 档静默钳成 60,与 MainActivity 的 maxFpsForResolution()
            // (产品表给 144)口径不一致。改后 config.fps=144,像素吞吐预检再按数学上限合法落到 50。
            val maxFps = try {
                val display = (getSystemService(Context.WINDOW_SERVICE) as android.view.WindowManager).defaultDisplay
                (display.supportedModes.maxOfOrNull { it.refreshRate }?.toInt()
                    ?: display.refreshRate.toInt()).coerceAtLeast(60)
            } catch (_: Exception) { 60 }

            val rawW = qualityParams2?.width ?: (if (displaySize.first > 0) displaySize.first else 1080)
            val rawH = qualityParams2?.height ?: (if (displaySize.second > 0) displaySize.second else 1920)
            val isLandscapeQuality = rawW > rawH
            val (clampW, clampH) = if (isPortraitDevice) {
                if (isLandscapeQuality)
                    rawH.coerceIn(1, screenW) to rawW.coerceIn(1, screenH)
                else
                    rawW.coerceIn(1, screenW) to rawH.coerceIn(1, screenH)
            } else {
                if (isLandscapeQuality)
                    rawW.coerceIn(1, screenH) to rawH.coerceIn(1, screenW)
                else
                    rawH.coerceIn(1, screenH) to rawW.coerceIn(1, screenW)
            }
            // v6.7.127 (S1/S2): Auto(frameRate<=0) = 屏幕刷新率(144Hz→144),交给引擎/硬件;
            // 数字档才钳到 [1,maxFps]。旧实现 frameRate=0 被 coerceIn 钳成 1,与 MainActivity
            // "Auto 保持 0 语义、交给引擎按屏幕刷新率自适应"完全脱节,auto 录出 1fps。
            // v6.7.151 (缺陷D): Auto 封顶 60。屏幕内容几乎全是 30/60fps,录 144fps 编码开销≈60fps
            // 的 2.4 倍,反而加剧发热掉帧,且 120/144fps 产物在多数播放器/剪辑软件支持很差、难编辑。
            // 手动数字档仍保留到 maxFps(满足高刷游戏录屏需求),只钳 Auto 这一条默认路径。
            val qp = qualityParams2
            val clampFps = if (qp == null || qp.frameRate <= 0) maxFps.coerceAtMost(60)
            else qp.frameRate.coerceIn(1, maxFps)

// v6.7.89 (L-2): 输出分辨率按屏幕宽高比等比 fit,消除左右/上下黑边。
            // 屏幕 1280x2800(0.4571) 但输出 1080x1920(0.5625),合成时左右各补 101px 黑边,
            // 19% 的编码像素是纯黑。等比 fit 后输出 878x1920,画面铺满且像素少 19%。
            // v6.7.95 (P1): 参照系修正——此前用 resources.displayMetrics(应用可用区,不含系统栏),
            // 而这台设备 getRealSize=1200x2652 而 apply usable≈1200x2390,MediaProjection 抓的是
            // 整屏 1200x2652,按 2390 适配会得到 964x1920,合成时左右各补 ~48px 黑边且横向拉伸 11%。
            // 改用 getRealSize(System metrics 重建一个高度=真实屏高的 DisplayMetrics)做等比 fit,
            // 输出铺满且消除形变与黑边,省下约 10% 编码预算给真实内容。
            val realMetrics = android.util.DisplayMetrics()
            realMetrics.setTo(resources.displayMetrics)
            realMetrics.widthPixels = screenW
            realMetrics.heightPixels = screenH
            // v6.7.95: 补一行诊断日志直接记录 getRealSize 与 displayMetrics 的 w/h/dpi,
            // 用于验证上述参照系反推(避免重蹈 v6.7.88 用假设反推参数的教训)。
            writeLog("screen_metrics real=${displaySize.first}x${displaySize.second} " +
                "app=${resources.displayMetrics.widthPixels}x${resources.displayMetrics.heightPixels} " +
                "dpi=${resources.displayMetrics.densityDpi}")
            val (fitW, fitH) = fitToScreenAspect(clampW, clampH, realMetrics)
            if (fitW != clampW || fitH != clampH) {
                writeLog("aspect_fit ${clampW}x${clampH} -> ${fitW}x${fitH} (screen=${screenW}x${screenH})")
            }

        // v6.7.169 (P1 方案B): 有效采集帧率=显示刷新率,供码率预算使用。
        // 与 640 行 maxFps 同公式(取支持模式最大刷新率),不直接复用因作用域受限。
        val maxOfFpsForCapture = try {
            (display.supportedModes.maxOfOrNull { it.refreshRate }?.toInt()
                ?: display.refreshRate.toInt()).coerceAtLeast(60)
        } catch (_: Exception) { 60 }
        // v6.7.169 (P1 方案B): Auto 码率按"有效采集帧率"而非配置帧率进模型。
        // AZ 架构下 Surface 按显示刷新率投帧、编码器照单全收(本机 60Hz 即 ~60fps),
        // 配置 fps 仅作码率 hint。若按配置 30fps 预算码率(系数 1.0),实际 60fps 每帧只分到
        // 一半比特,同等码率下画质低于"真 30fps"预期。改为 max(clampFps, 采集刷新率):
        // 配置高于采集能力时用配置值(已钳过),低于时用采集值(反映真实帧数),
        // 60Hz 屏选 30fps 即按 ~60fps 进模型拿 ratioFps60 系数,码率与真实帧数匹配。
        val effectiveFpsForBitrate = maxOf(clampFps, maxOfFpsForCapture)
        val engineConfig = RecorderEngine.RecorderConfig(
            width = fitW,
            height = fitH,
            fps = clampFps,
            bitrate = qualityParams2?.videoBitRate?.takeIf { it > 0 }
                ?: QualityParams.bitrateScheduler().autoBitrate(
                    clampW, clampH, effectiveFpsForBitrate,
                    qualityParams2?.preferHevc == true, false),
            useAudio = config.audioMode != AudioMode.MUTE,
            useInternalAudio = config.audioMode == AudioMode.SPEAKER_ONLY || config.audioMode == AudioMode.AUTO || config.audioMode == AudioMode.MIXED,
            useMicAudio = config.audioMode == AudioMode.MIC_ONLY || config.audioMode == AudioMode.MIXED,
            useHevc = qualityParams2?.preferHevc == true,
            outputFilePath = outputPath,
            densityDpi = qualityParams2?.dpi ?: resources.displayMetrics.densityDpi,
            orientation = qualityParams2?.orientation ?: 0,
            recLimitBytes = preferencesManager.recLimitBytes(),
            recLimitDurationMs = preferencesManager.recLimitDurationMs()
        )

        var projection = ScreenRecorderApp.pendingMediaProjection ?: mediaProjection
        if (projection == null) {
            // Fallback: rebuild the MediaProjection from the authorization extras
            // passed in the start intent (avoids cross-activity static race).
            val resultCode = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
                intent.getIntExtra(EXTRA_PROJECTION_RESULT_CODE, 0)
            } else {
                intent.getIntExtra(EXTRA_PROJECTION_RESULT_CODE, 0)
            }
            val resultData = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
                intent.getParcelableExtra(EXTRA_PROJECTION_RESULT_DATA, Intent::class.java)
            } else {
                @Suppress("DEPRECATION")
                intent.getParcelableExtra(EXTRA_PROJECTION_RESULT_DATA)
            }
            if (resultCode == android.app.Activity.RESULT_OK && resultData != null) {
                try {
                    projection = mediaProjectionManager?.getMediaProjection(resultCode, resultData)
                    writeLog("rebuilt MediaProjection from extras: ${projection != null}")
                } catch (e: Exception) {
                    writeLog("rebuilt MediaProjection failed: ${e.message}")
                }
            }
        }
        if (projection == null) {
            writeLog("MediaProjection not ready: pending=null instance=${mediaProjection != null} "
                    + "lastError=${ScreenRecorderApp.lastError ?: "none"}")
            setState(RecordState.IDLE)
            // 投影不可用则无法录制:主动清理并广播,避免 UI 停留在"录制中"。
            // 先移除本次 handleStart 已完成的状态/字段再 cleanup,确保广播复位 UI。
            cleanupAndStop()
            return
        }
        ScreenRecorderApp.pendingMediaProjection = null
        mediaProjection = projection

        registerMediaProjectionCallback(projection)

        val engine = RecorderEngine(this)
        engine.logSink = { msg -> writeLog("[engine] $msg") }
        engine.callback = recorderCallback
        engine.foregroundMicCallback = { mainUiHandler.post { goForeground(true) } }
        this.engine = engine

        if (currentOutputUri != null) {
            val uri = android.net.Uri.parse(currentOutputUri)
            engine.setSafOutput(uri, pendingSafFileName ?: generateFileName(config.fileNamePattern))
            pendingSafFileName = null
        }

        try {
            DiagLog.start(this)
            DiagLog.log("handleStart begin config=$engineConfig")
            writeLog("engine.start calling width=${engineConfig.width} useAudio=${engineConfig.useAudio}")
            // currentQualityParams 此时已解析完成;再次 goForeground(),确保
            // Android 14+ 前台服务带上 MICROPHONE 类型(MIC_ONLY/MIXED 模式下
            // 否则麦克风会因 FGS mic-access timeout 被系统中途切断)。
            if (config.audioMode == AudioMode.MIC_ONLY || config.audioMode == AudioMode.MIXED) {
                goForeground(true)
            }
            engine.start(engineConfig, projection)
            acquireWakeLock()
            registerScreenStateReceiver()
            // 录制启动后将状态持久化,进程重启时可检测到
            RecorderEngine.saveRecordingState(this, engine)
            showFloatOverlay()
            writeLog("engine.start returned (async), state=${state.get()}")
        } catch (e: Exception) {
            // 统一交由外层 catch 处理清理,避免此处与 455 行外层 catch 重复 cleanup
            throw RuntimeException("engine.start failed", e)
        }
        } catch (e: Exception) {
            writeLog("handleStart error: ${e.message ?: e.javaClass.name}")
            val root = e as? RuntimeException ?: e
            val cause = root.cause ?: root
            writeLog("handleStart error stack:\n${android.util.Log.getStackTraceString(cause)}")
            // v6.7.100 (B3): 删除 engine?.forceStop()。cleanupAndStop() 内部已经
            // 显式调用 engine?.forceStop() 后再置 null,此处再调一次会与随后
            // 的 cleanupAndStop() 双重进入 forceStop,在 forceStop 异步触发
            // onStopped 回调的路径下可能导致 cleanupAndStop 二次进入并提前
            // 把 state 置 IDLE,而外层仍在处理 FAILED。统一交由 cleanupAndStop。
            ScreenRecorderApp.lastError =
                "${cause.javaClass.name}: ${cause.message}\n${android.util.Log.getStackTraceString(cause)}"
            setState(RecordState.FAILED)
            goForeground()
            cleanupAndStop()
        }
    }

    private fun handleStop(reason: StopReason = StopReason.MANUAL) {
        // v6.7.145 (P1-6): 记录停止原因。所有既有调用点不传参 → MANUAL,零破坏。
        lastStopReason = reason
        writeLog("handleStop reason=${reason.name}")
        // v6.7.60: 停止命令一到达立即移除悬浮窗(毫秒级反馈),不等引擎收尾。
        // 此前悬浮窗仅在 cleanupAndStop() 末尾才 release(),点击停止后悬浮窗
        // 会滞留整个 drain/落盘过程(数秒),感知明显卡顿。此处提前释放,
        // cleanupAndStop 里的 dismissFloatOverlay() 因 floatOverlay==null 幂等跳过。
        dismissFloatOverlay()
        // v6.7.60: 停止路径计时——命令到达即打点(相对引擎 drain 起点),复测定位用
        writeLog("ui_ack overlay_dismissed")
        val currentState = state.get()
        if (currentState == RecordState.STOPPING) {
            writeLog("handleStop already stopping, ignoring")
            // v6.7.72: 原分支只发广播不复位状态,若上一次收尾异常中断,Activity
            // 收到的仍是 STOPPING,按钮被永久钉死。这里显式收口到 IDLE 再广播。
            setState(RecordState.IDLE)
            try {
                val i = Intent(ACTION_RECORDING_STOPPED)
                i.setPackage(packageName)
                i.putExtra("already_stopped", true)
                sendBroadcast(i)
            } catch (e: Exception) {
                writeLog("stop_broadcast_error: ${e.message}")
            }
            return
        }
        if (currentState != RecordState.RECORDING && currentState != RecordState.PAUSED) {
            writeLog("handleStop invalid state: $currentState, scheduling cleanup")
            // No recording session is active. Release the wake lock and stop the
            // service safely so a stale/duplicate STOP (or a stop issued while
            // IDLE/FAILED/STARTING) does not leak foreground or wake-lock resources.
            // Run on the serviceHandler queue to serialize with any in-flight
            // handleStart, avoiding a cross-thread engine/projection teardown race.
            serviceHandler?.post {
                val s2 = state.get()
                if (s2 == RecordState.STOPPING) return@post
                if (s2 == RecordState.RECORDING || s2 == RecordState.PAUSED) {
                    // Start completed before the stop landed; stop the live session.
                    setState(RecordState.STOPPING)
                    // 立即更新通知为"停止中",不等 drain 完成
                    updateNotification(buildStopNotification())
                    try {
                        val h = serviceHandler
                        if (h != null) engine?.stopAsync(h) else writeLog("engine stop skipped: handler null")
                    } catch (e: Exception) {
                        writeLog("engine stop error: ${e.message}")
                        recorderCallback.onError(e)
                    }
                } else if (s2 == RecordState.IDLE || s2 == RecordState.FAILED) {
                    cleanupAndStop()
                } else if (s2 == RecordState.STARTING || s2 == RecordState.PREPARING) {
                    setState(RecordState.FAILED)
                    cleanupAndStop()
                }
            }
            return
        }
        serviceHandler?.post {
            setState(RecordState.STOPPING)
            // 立即更新通知为"停止中",不等 drain 完成,避免用户感知 10s+ 延迟
            updateNotification(buildStopNotification())
            try {
                val h = serviceHandler
                if (h != null) engine?.stopAsync(h) else writeLog("engine stop skipped: handler null")
            } catch (e: Exception) {
                writeLog("engine stop error: ${e.message}")
                recorderCallback.onError(e)
            }
        }
    }

    private fun handlePause() {
        writeLog("handlePause")
        if (state.get() != RecordState.RECORDING) {
            writeLog("handlePause invalid state: ${state.get()}")
            return
        }
        setState(RecordState.PAUSED)
        updateNotification(buildRecordingNotification())
        engine?.pause()
        showFloatOverlay()
        floatOverlay?.updatePauseState(true)
    }

    private fun handleResume() {
        writeLog("handleResume")
        if (state.get() != RecordState.PAUSED) {
            writeLog("handleResume invalid state: ${state.get()}")
            return
        }
        setState(RecordState.RECORDING)
        updateNotification(buildRecordingNotification())
        engine?.resume()
        showFloatOverlay()
        floatOverlay?.updatePauseState(false)
    }

    private fun recordToHistory(durationMs: Long, fileSize: Long, outputPath: String, segmentPaths: List<String> = emptyList()) {
        // v6.7.188c-fix: 真实成片入库(仅真录完成时调用),才允许后续弹"已保存"。
        sessionRecorded = true
        writeLog("recordToHistory durationMs=$durationMs fileSize=$fileSize path=$outputPath segments=${segmentPaths.size}")
        try {
            val qualityParams = currentQualityParams
            // v6.7.128: 多分片时总时长/总大小为各分片之和(引擎回传的 durationMs 是总时长,fileSize 是最后一片)
            val totalSize = if (segmentPaths.size > 1) {
                segmentPaths.sumOf { p -> try { File(p).length() } catch (_: Exception) { 0L } }
            } else fileSize
            val totalDuration = durationMs  // 引擎回传的是总时长
            val entry = RecordingEntry(
                // v6.7.84 (新增-3): outputPath 现在可能是 SAF 的 content:// URI。File(URI串).name
                // 取的是最后一个 '/' 之后的内容,而 SAF documentId 里的路径分隔符是 URL 编码的
                // %2F,File 不会在那里切分,fileName 会变成 85 个字符的百分号乱码直接显示在
                // 历史列表与删除确认框。统一走 resolveDisplayName 解出真实文件名。
                fileName = resolveDisplayName(outputPath),
                path = outputPath,
                durationMs = totalDuration,
                sizeBytes = totalSize,
                width = (engine?.getActualWidth() ?: -1).let { if (it > 0) it else (qualityParams?.width ?: 0) },
                height = (engine?.getActualHeight() ?: -1).let { if (it > 0) it else (qualityParams?.height ?: 0) },
                timestamp = System.currentTimeMillis(),
                codecName = engine?.getVideoEncoderName() ?: "",
                // v6.7.128: 多分片路径列表
                segmentPaths = if (segmentPaths.size > 1) segmentPaths else emptyList(),
                // v6.7.128: 降档元数据
                downgradeActive = engine?.getDowngradeMeta()?.first ?: false,
                downgradeFirstAtMs = engine?.getDowngradeMeta()?.second ?: 0L,
                downgradeMinBitrate = engine?.getDowngradeMeta()?.third ?: -1,
                downgradeLatched = engine?.getDowngradeLatchedAtStop() ?: false,
                // v6.7.145 (P1-6): 停止原因结构化,与 DiagLog 一致,历史详情展示。
                stopReason = lastStopReason.name,
                // v6.7.155: 产物可播放性校验。正常 MediaMuxer stop + merge 的产物有 moov
                // 视为可播;若 moov 缺失(被杀瞬间仍可能)则该条入库置 playable=false,
                // 历史显示"已损坏"角标、播放改为删除,避免给用户打不开的条目。
                playable = outputPath.let { path ->
                    if (path.startsWith("content://")) true
                    else Mp4Repairer.isPlayableFile(path)
                }
            )
            historyManager.add(entry)
            // v6.7.155: 成功率聚合埋点桶。必剪 success-rate 的轻量替代——累计 total/success/
            // 各停止原因计数,存 SharedPreferences。每次录制结束进历史时累加,便于事后回答
            // "保护到底救回多少 / 自学习是否生效",无需人工翻源码。记录文件目录自清理。
            runCatching {
                val prefs = getSharedPreferences("record_report_buckets", Context.MODE_PRIVATE)
                val total = prefs.getInt("total", 0) + 1
                val success = prefs.getInt("success", 0) + if (lastStopReason == StopReason.MANUAL) 1 else 0
                val reasonKey = "reason_${lastStopReason.name}"
                val reason = prefs.getInt(reasonKey, 0) + 1
                prefs.edit()
                    .putInt("total", total)
                    .putInt("success", success)
                    .putInt(reasonKey, reason)
                    .apply()
                writeLog("record_report_bucket total=$total success=$success $reasonKey=$reason")
            }
            // v6.7.74: 与 ACTION_RECORDING_STOPPED 保持一致,必须 setPackage。
            // 两个广播发给同一个以 RECEIVER_NOT_EXPORTED 注册的接收器,荣耀/华为
            // MagicOS 会拦截未指定包名的隐式广播(同应用也不例外)。此前 STOPPED
            // 已修而 HISTORY_CHANGED 未修,表现为"按钮已恢复但历史列表不刷新"。
            val historyIntent = Intent(ACTION_HISTORY_CHANGED).setPackage(packageName)
            sendBroadcast(historyIntent)
            writeLog("history entry added and broadcast sent")
            // v6.7.188g: 录制收尾成功登记历史后,轻量 GC(60s 节流 + 内存列表,不扫盘)
            StorageGc.maybeGc(this)
        } catch (e: Exception) {
            writeLog("recordToHistory error: ${e.message}")
        }
    }

    // v6.7.84 (新增-3): 解析历史/删除框要显示的文件名。SAF 输出时 outputPath 是 content://
    // URI,其 documentId 里路径分隔符是 URL 编码的 %2F,File(URI串).name 会取到一整串百分号
    // 乱码。改为优先用录制开始时算好的 pendingSafFileName(若仍保留),否则解码 documentId
    // 取最后一段真实文件名;本地路径直接 File.name。
    // v6.7.97 (改进2): pendingSafFileName 存的是录制中的 .recording.tmp 名,直接显示会带
    // .tmp 后缀。改名后引擎已在 finalSafUri 里写入 .mp4 document,优先解码 URI 的
    // lastPathSegment(此时后缀已是 .mp4),pendingSafFileName 作为最末兜底并去掉 .tmp。
    private fun resolveDisplayName(outputPath: String): String {
        if (!outputPath.startsWith("content://")) return File(outputPath).name
        try {
            val seg = android.net.Uri.parse(outputPath).lastPathSegment
            val decoded = android.net.Uri.decode(seg ?: "").substringAfterLast('/')
            if (decoded.isNotBlank()) return decoded
        } catch (_: Exception) {}
        pendingSafFileName?.let { name ->
            if (name.isNotBlank()) {
                return if (name.endsWith(".recording.tmp"))
                    name.dropLast(".recording.tmp".length) + ".mp4"
                else name
            }
        }
        return File(outputPath).name
    }

    // v6.7.89 (L-2): 输出分辨率按屏幕宽高比等比 fit,消除左右/上下黑边。
    // 只缩小不放大:scale = min(w/sw, h/sh),把目标分辨率收敛到屏幕同宽高比,
    // 再向下取偶(H.264 要求宽高偶数)。配合 v6.7.88 的等比 clampToCapabilities 使用,
    // 两处都保证纵横比不变,叠加安全。
    // v6.7.89 (L-2): 输出分辨率按屏幕宽高比等比 fit,消除左右/上下黑边。
    // v6.7.90 (A-5): 显式把缩放比夹到 1.0,不再依赖上游 coerceIn 兜底;
    // 删除 screenW/screenH 死参数(旧实现用 dm,调用方传进来的两值被静默丢弃)。
    private fun fitToScreenAspect(
        w: Int,
        h: Int,
        dm: android.util.DisplayMetrics
    ): Pair<Int, Int> {
        val sw = dm.widthPixels
        val sh = dm.heightPixels
        if (sw <= 0 || sh <= 0 || w <= 0 || h <= 0) return w to h
        // 不放大:scale>=1 时请求尺寸已 >= 屏幕,直接返回请求的 w×h,
        // 跳过浮点乘法 + 偶数对齐(对齐可能减 1 产生 1px 误差)。
        val scale = minOf(1f, w.toFloat() / sw, h.toFloat() / sh)
        if (scale >= 1f) return w to h
        var ow = (sw * scale + 0.5f).toInt()
        var oh = (sh * scale + 0.5f).toInt()
        if (ow % 2 != 0) ow--                          // H.264 要求偶数
        if (oh % 2 != 0) oh--
        if (ow < 2 || oh < 2) return w to h
        return ow to oh
    }

    private fun resolveOutputUri(config: RecorderConfig, qualityParams: QualityParams?): String {
        val safUriStr = currentOutputUri
        val baseName = generateFileName(config.fileNamePattern)
        val dir = getExternalFilesDir(android.os.Environment.DIRECTORY_MOVIES)
            ?: File("/sdcard/${packageName}/Movies")
        if (safUriStr != null) {
            val uri = android.net.Uri.parse(safUriStr)
            val uniqueName = resolveSafUniqueName(uri, baseName)
            // v6.7.95 (改进4): SAF 路径也使用临时名,.tmp 后缀保证录制中文件对相册不可见。
            // 录制正常收尾后由 RecorderEngine 重命名,异常中断时残留 .tmp 文件不影响用户。
            val pendingName = if (uniqueName.endsWith(".mp4")) {
                "${uniqueName.dropLast(4)}.recording.tmp"
            } else {
                "$uniqueName.recording.tmp"
            }
            currentOutputPath = File(dir, pendingName).absolutePath
            pendingSafFileName = pendingName
            writeLog("using SAF output URI: $safUriStr, local path: ${currentOutputPath}, uniqueName: $pendingName")
        } else {
            // v6.7.95 (改进4): 本地路径也使用临时名
            val pendingName = if (baseName.endsWith(".mp4")) {
                "${baseName.dropLast(4)}.recording.tmp"
            } else {
                "$baseName.recording.tmp"
            }
            val file = ensureUniqueFile(dir, pendingName)
            currentOutputPath = file.absolutePath
            writeLog("using local output path: ${file.absolutePath}")
        }
        return currentOutputPath ?: ""
    }

    // AZ 6.9.9 风格:本地输出目录文件已存在时加后缀_(1)/_(2)...避免覆盖。
    private fun ensureUniqueFile(dir: File, baseName: String): File {
        if (!dir.exists()) dir.mkdirs()
        var candidate = File(dir, baseName)
        var i = 1
        while (candidate.exists()) {
            val name = if (baseName.endsWith(".mp4")) {
                "${baseName.dropLast(4)}_(${i}).mp4"
            } else {
                "${baseName}_(${i}).mp4"
            }
            candidate = File(dir, name)
            i++
            if (i > 100) break
        }
        return candidate
    }

    // SAF 输出同样处理:用 SAF 的 openDocument/getName 语义,
    // 通过 ContentResolver.query 探知当前路径下是否已有同基名文件,有则追加序号后缀。
    private fun resolveSafUniqueName(uri: android.net.Uri, baseName: String): String {
        val resolver = contentResolver
        // 单次枚举所有子文档名到 HashSet,后续 O(1) 查重
        val names = try {
            val treeId = android.provider.DocumentsContract.getTreeDocumentId(uri)
            val childrenUri = android.provider.DocumentsContract
                .buildChildDocumentsUriUsingTree(uri, treeId)
            val set = java.util.HashSet<String>()
            resolver.query(childrenUri,
                arrayOf(android.provider.DocumentsContract.Document.COLUMN_DISPLAY_NAME),
                null, null, null)?.use { c ->
                val idx = c.getColumnIndex(
                    android.provider.DocumentsContract.Document.COLUMN_DISPLAY_NAME)
                if (idx >= 0) while (c.moveToNext()) {
                    c.getString(idx)?.let { set.add(it) }
                }
            }
            set
        } catch (_: Exception) { null }
        if (names == null || !names.contains(baseName)) return baseName
        var i = 1
        while (true) {
            val name = if (baseName.endsWith(".mp4"))
                "${baseName.dropLast(4)}_(${i}).mp4"
            else "${baseName}_(${i}).mp4"
            if (!names.contains(name)) return name
            i++
            if (i > 100) return "${baseName.dropLast(4)}_${System.currentTimeMillis()}.mp4"
        }
    }

    private fun generateFileName(pattern: String): String {
        val now = Date()
        val dateStr = SimpleDateFormat("yyyyMMdd_HHmmss", Locale.getDefault()).format(now)
        val result = pattern
            .replace("%Y", SimpleDateFormat("yyyy", Locale.getDefault()).format(now))
            .replace("%m", SimpleDateFormat("MM", Locale.getDefault()).format(now))
            .replace("%d", SimpleDateFormat("dd", Locale.getDefault()).format(now))
            .replace("%H", SimpleDateFormat("HH", Locale.getDefault()).format(now))
            .replace("%M", SimpleDateFormat("mm", Locale.getDefault()).format(now))
            .replace("%S", SimpleDateFormat("ss", Locale.getDefault()).format(now))
        val base = if (result.contains("%")) {
            dateStr
        } else {
            result
        }
        return if (base.lowercase().endsWith(".mp4")) base else "$base.mp4"
    }

    private fun registerMediaProjectionCallback(projection: MediaProjection) {
        writeLog("registerMediaProjectionCallback")
        projectionCallback = MediaProjectionCallback()
        projection.registerCallback(projectionCallback!!, null)
    }

    private inner class MediaProjectionCallback : MediaProjection.Callback() {
        override fun onStop() {
            writeLog("MediaProjection onStop - system killed projection")
            // v6.7.104 (B2): 系统已 kill projection。置 projectionInvalid 让 engine
            // 在 stop/forceStop/stopAsync 三处跳过 signalEndOfInputStream,直接置
            // muxerVideoDone=true 走快速 drain,避免 c2.avc 编码器在缺关键帧前提下
            // EOS 永不返回导致 30s 超时+尾帧被砍。
            ScreenRecorderApp.projectionInvalid = true
            serviceHandler?.post {
                try {
                    try {
                        engine?.forceStop()
                    } catch (e: Exception) {
                        writeLog("forceStop after projection stop error: ${e.message}")
                    }
                    // forceStop() 内部已通过 onStopped 回调触发 recordToHistory,
                    // 此处不再重复记录同名文件历史,避免重复入库
                } catch (e: Exception) {
                    writeLog("recordToHistory after projection stop error: ${e.message}")
                } finally {
                    // v6.7.102 (B1): 不再在这里 setState(IDLE)。用户点停止时 state 已置 STOPPING
                    // 且 cleanupAndStop 正在跑,此处强制 IDLE 会与 cleanupAndStop 内 finally 的
                    // setState(IDLE) 抢占状态机,并可能把 STOPPING 覆盖成 IDLE 造成 UI 抖动
                    // (MainActivity 收到 IDLE 广播后按"开始录制"渲染,实际还在 drain)。
                    // 状态收敛唯一入口保留在 cleanupAndStop。
                    cleanupAndStop()
                }
            }
        }
    }

    private fun createNotificationChannels() {
        // NotificationChannel 为 API 26+ 类;API 24/25 (Android 7.0/7.1) 上
        // 类不存在会抛 NoSuchMethodError(属 Error,外层 catch(Exception) 捕不到),
        // 必须显式按版本守卫,否则 Android 7 上服务在 onCreate 即崩溃。
        if (Build.VERSION.SDK_INT < Build.VERSION_CODES.O) {
            return
        }
        val recordingChannel = NotificationChannel(
            CHANNEL_ID_RECORDING,
            CHANNEL_NAME_RECORDING,
            NotificationManager.IMPORTANCE_LOW
        ).apply {
            description = "屏幕录制通知"
            setShowBadge(false)
        }

        notificationManager.createNotificationChannel(recordingChannel)
    }

    private fun buildRecordingNotification(
        durationMs: Long? = null,
        fileSize: Long? = null
    ): Notification {
        val isPaused = state.get() == RecordState.PAUSED
        val title = if (isPaused) "录制已暂停" else "屏幕录制中"
        // v6.7.88 (Ch5.2): 暂停/恢复路径无 durationMs 参数,回退到最近缓存的值,
        // 保证 chronometer 基准连续(恢复后从暂停前时长继续,而非归零)。
        val dur = durationMs ?: lastDurationMs

        val builder = NotificationCompat.Builder(this, CHANNEL_ID_RECORDING)
            .setContentTitle(title)
            .setSmallIcon(R.drawable.ic_recording_mono)
            .setOngoing(true)
            .setPriority(NotificationCompat.PRIORITY_LOW)

        if (isPaused) {
            // v6.7.88 (Ch5.2): 暂停态冻结计时——chronometer 关闭,显示静态时长。
            builder.setUsesChronometer(false)
            builder.setShowWhen(false)
            builder.setContentText(
                if (dur > 0L) "${formatDuration(dur)} · 点击恢复" else "点击恢复继续"
            )
        } else {
            // v6.7.88 (Ch5.2): 录制态用 chronometer 自动计秒,通知体由系统每秒自绘,
            // 配合 Ch5.3 的 sizeStep 刷新,免去每秒 updateNotification 的 binder 开销。
            builder.setUsesChronometer(true)
            builder.setChronometerCountDown(false)
            builder.setShowWhen(true)
            builder.setWhen(SystemClock.elapsedRealtime() - dur)
            builder.setContentText(fileSize?.let { formatFileSize(it) } ?: "录制进行中...")
        }

        // v6.7.88 (Ch5.1/5.3): 仅创建实际用到的 PendingIntent(旧实现每次都建 3 个,
        // 其中 resume/pause 必有一个闲置)。顺序 [暂停/恢复][停止],停止用专属红方块图标。
        val secondaryAction = if (isPaused) ACTION_RESUME else ACTION_PAUSE
        val secondaryIcon = if (isPaused) android.R.drawable.ic_media_play
                            else android.R.drawable.ic_media_pause
        val secondaryLabel = if (isPaused) "恢复" else "暂停"
        builder.addAction(secondaryIcon, secondaryLabel, createActionIntent(secondaryAction))
        builder.addAction(R.drawable.ic_action_stop, "停止", createActionIntent(ACTION_STOP))

        return builder.build()
    }

    private fun buildStopNotification(): Notification {
        val stopIntent = createActionIntent(ACTION_STOP)
        return NotificationCompat.Builder(this, CHANNEL_ID_RECORDING)
            .setContentTitle("正在停止录制")
            .setContentText("请稍候...")
            .setSmallIcon(R.drawable.ic_recording_mono)
            .setOngoing(false)
            .setPriority(NotificationCompat.PRIORITY_LOW)
            .setContentIntent(stopIntent)
            .build()
    }

    // 用固定 requestCode 而非 action 字符串哈希,避免哈希碰撞导致
    // 不同通知动作复用了相同的 PendingIntent,误触发错误动作。
    private fun createActionIntent(action: String): PendingIntent {
        val requestCode = when (action) {
            ACTION_STOP -> 1
            ACTION_PAUSE -> 2
            ACTION_RESUME -> 3
            else -> (action.hashCode() and 0x7fffffff)
        }
        val intent = Intent(this, ScreenRecorderService::class.java).apply {
            this.action = action
        }
        return PendingIntent.getService(
            this,
            requestCode,
            intent,
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )
    }

    private fun updateNotification(notification: Notification) {
        notificationManager.notify(NOTIFICATION_ID_RECORDING, notification)
    }

    private fun showFloatOverlay() {
        writeLog("showFloatOverlay")
        // RecordOverlay 的 View 构造与 addView 必须统一在主线程执行
        // (RecordOverlay.attach() 内部已 post 主线程,这里保证构造也在主线程)。
        if (Looper.myLooper() != Looper.getMainLooper()) {
            mainUiHandler.post { showFloatOverlay() }
            return
        }
        // P0-3a: 入口统一权限闸门，缺失则记录并提示，不执行挂载
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M
            && !Settings.canDrawOverlays(this)) {
            writeLog("showFloatOverlay skipped: no SYSTEM_ALERT_WINDOW permission")
            notifyOverlayUnavailable()
            return
        }
        // v6.7.68 (AZ 兼容): 权限通过后先挂载全屏透明承载窗口(FLAG_NOT_TOUCHABLE 不拦截
        // 触摸),再挂交互小球,组成 AZ zg/t + zg/o 双窗口结构。
        showFullScreenCarrier()
        if (floatOverlay == null) {
            floatOverlay = RecordOverlay(this, object : RecordOverlayListener {
                override fun onStopClicked() {
                    handleStop()
                }
                override fun onPauseClicked() {
                    handlePause()
                }
                override fun onResumeClicked() {
                    handleResume()
                }
                // v6.9.10 (AZ 一体四子球): 子球①在非录制态是"开始录制"红点。
                // 仅 IDLE/FAILED 态可发起;授权必须走 Activity 承载,故调起透明 CaptureActivity。
                override fun onStartClicked() {
                    val st = ScreenRecorderApp.recordState
                    if (st != RecordState.IDLE && st != RecordState.FAILED) {
                        writeLog("float sub start ignored, state=$st")
                        return
                    }
                    writeLog("float sub start clicked")
                    try {
                        val i = android.content.Intent(
                            this@ScreenRecorderService,
                            CaptureActivity::class.java
                        ).apply {
                            putExtra(CaptureActivity.EXTRA_MODE, "record")
                            // 从 Service(非 Activity)上下文起 Activity 必须 NEW_TASK,
                            // 否则抛 AndroidRuntimeException 被 catch 吞 → 点了没反应。
                            addFlags(android.content.Intent.FLAG_ACTIVITY_NEW_TASK)
                        }
                        startActivity(i)
                    } catch (e: Exception) {
                        writeLog("launch CaptureActivity failed: ${e.message}")
                    }
                }
                // v6.7.73 (三球): 返回设置子球——工程没有独立 SettingsActivity,复用 MainActivity
                override fun onSettingsClicked() {
                    writeLog("float sub settings clicked")
                    try {
                        val intent = android.content.Intent(
                            this@ScreenRecorderService,
                            Class.forName("com.monkeycode.screenrecorder.MainActivity")
                        ).apply {
                            addFlags(android.content.Intent.FLAG_ACTIVITY_NEW_TASK)
                        }
                        startActivity(intent)
                    } catch (e: Exception) {
                        writeLog("launch MainActivity failed: $e")
                    }
                }
                // v6.7.152: 第四颗子球——超级截图。复用录制中的 projection 抓一帧，
                // 不重新走授权。pending 授权完成后会被置 null（见 startRecording），
                // 所以优先用持有的 mediaProjection，回退 pending。
                override fun onScreenshotClicked() {
                    // v6.7.153: 录制中截图 = 切录制 VirtualDisplay 的输出面抓一帧再切回,
                    // 全程只有一条 VirtualDisplay。绝不能再新建 VD——目标 API34+ 对同一
                    // MediaProjection 二次 createVirtualDisplay 抛 SecurityException,系统
                    // 随后 onStop 终止投影,录制被强制停止(v6.7.152 实测炸录制)。
                    val eng = engine
                    val vd = eng?.recordingVirtualDisplay()
                    if (vd == null) {
                        // v6.9.10 (AZ 一体四子球): 非录制态不再弹"请先录屏"的死路,
                        // 改为走独立投影截一帧(透明 CaptureActivity 承载授权)。
                        writeLog("float sub screenshot: no vd -> standalone")
                        try {
                            val i = android.content.Intent(
                                this@ScreenRecorderService,
                                CaptureActivity::class.java
                            ).apply {
                                putExtra(CaptureActivity.EXTRA_MODE, "shot")
                                addFlags(android.content.Intent.FLAG_ACTIVITY_NEW_TASK)
                            }
                            startActivity(i)
                        } catch (e: Exception) {
                            writeLog("launch CaptureActivity(shot) failed: ${e.message}")
                        }
                        return
                    }
                    // v6.7.154 (BUG-1): 恢复目标面必须尊重暂停态。暂停中 VD 已被
                    // setSurface(null) 摘除投帧，restore 目标必须是 null——若写死
                    // inputSurface，画面会重新投给编码器但 isPaused 仍为 true，录制在
                    // 用户以为暂停时被静默续录，状态机矛盾。暂停中 encS 为 null 是正常态。
                    val encS = eng.currentFeedSurface()
                    writeLog("float sub screenshot: vd ready paused=${eng.isPausedNow()} enc=${encS != null}")
                    // v6.7.157 (改动5): 用录制 VD 的尺寸,不用 getRealMetrics(屏幕尺寸)。
                    // ImageReader 必须与 VD 尺寸匹配否则 VD 不投帧 -> 恒超时 failed。
                    // 录 720p/1080p、屏 2K/4K 时两者不等,截图即超时(原 v6.7.154 注释误以为要整屏)。
                    val sw = eng.recordingWidth(); val sh = eng.recordingHeight()
                    if (sw > 0 && sh > 0) {
                        writeLog("float sub screenshot: ${sw}x${sh} vdsize")
                    } else {
                        // 兜底:engine 尚未起好则退回整屏真实尺寸
                        val m = android.util.DisplayMetrics()
                        val dm = getSystemService(Context.DISPLAY_SERVICE)
                            as android.hardware.display.DisplayManager
                        dm.getDisplay(android.view.Display.DEFAULT_DISPLAY).getRealMetrics(m)
                    }
                    ScreenshotHelper.captureDuringRecording(
                        this@ScreenRecorderService, vd, encS,
                        sw, sh
                    ) { uri ->
                        if (uri != null) {
                            writeLog("float sub screenshot: saved $uri")
                            android.widget.Toast.makeText(
                                this@ScreenRecorderService,
                                "截图已保存",
                                android.widget.Toast.LENGTH_SHORT
                            ).show()
                        } else {
                            writeLog("float sub screenshot: failed")
                            android.widget.Toast.makeText(
                                this@ScreenRecorderService,
                                "截图失败",
                                android.widget.Toast.LENGTH_SHORT
                            ).show()
                        }
                    }
                }
                // P0-2: 失败时写业务日志，便于 diag 排查
                override fun onOverlayFailed(reason: String) {
                    writeLog("float overlay failed: $reason")
                    // v6.7.66: P3-3 + P3-4 ——仅为"挂载成功但不可见/上屏失败"类原因做
                    // 省级提示与自动重挂载兜底;权限缺失/addView 异常走原路径不重挂载。
                    if (isOnScreenFailure(reason)) {
                        notifyOverlayPowerSaveHint()
                        // v6.7.69 (Bug 1+2 修复): 放行引导仅在此"挂载成功但被系统隐藏"
                        // 分支触发,不再无条件弹。scheduleOverlayGuide 内部还会再判
                        // canDrawOverlays,已授权则不弹。
                        scheduleOverlayGuide()
                        remountOverlayIfNeeded()
                    }
                }
                // P2-3: 挂载成功写业务日志，diag 可区分 成功/权限缺失/addView 异常/挂载但不可见
                override fun onOverlayAttached() {
                    writeLog("float overlay attached")
                    // 成功挂载即复位重挂载计数,避免一次会话内反复累计
                    overlayRemountCount = 0
                    // v6.7.69 (Bug 1 修复): 挂载成功不再无条件调度放行引导。
                    // 旧实现在 attach 成功即弹引导,权限已授权也弹(Bug 1),
                    // 且引导内 startActivity 跳系统设置页会切走录制前台(Bug 2)。
                    // 引导改为仅在 isOnScreenFailure 分支(not actually on screen /
                    // window hidden by system)经 remountOverlayIfNeeded 链路后触发。
                }
            })
        }
        floatOverlay?.attach()
    }

    // v6.7.68 (AZ 兼容): 全屏透明承载窗口。窗口类型走与 RecordOverlay 相同的标准降级
    // (API>=26 TYPE_APPLICATION_OVERLAY / ==25 TYPE_PHONE / <25 TYPE_SYSTEM_ERROR),
    // flags 对齐 AZ zg/t 的 LAYOUT_IN_SCREEN|LAYOUT_NO_LIMITS,并加 FLAG_NOT_TOUCHABLE
    // 使全屏窗口不拦截触摸、不抢焦点,完全不影响用户在录制期间操作其他应用。
    // 承载层不绘制内容,仅提供"全屏正常窗口"存在性以降低被合成层抑制的概率。
    private fun showFullScreenCarrier() {
        // v6.7.89 (L-3): 默认关闭全屏承载窗口
        if (!ENABLE_FULL_SCREEN_CARRIER) return
        if (Looper.myLooper() != Looper.getMainLooper()) {
            mainUiHandler.post { showFullScreenCarrier() }
            return
        }
        if (fullScreenCarrier != null) return
        val wm = getSystemService(Context.WINDOW_SERVICE) as WindowManager
        val windowType = when {
            Build.VERSION.SDK_INT >= Build.VERSION_CODES.O ->
                WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY
            Build.VERSION.SDK_INT == Build.VERSION_CODES.N_MR1 -> {
                @Suppress("DEPRECATION")
                WindowManager.LayoutParams.TYPE_PHONE
            }
            else -> {
                @Suppress("DEPRECATION")
                WindowManager.LayoutParams.TYPE_SYSTEM_ERROR
            }
        }
        val dm = resources.displayMetrics
        val lp = WindowManager.LayoutParams(
            dm.widthPixels,
            dm.heightPixels,
            windowType,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or
                WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE or
                WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN or
                WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS,
            PixelFormat.TRANSLUCENT
        ).apply {
            gravity = Gravity.TOP or Gravity.START
        }
        val carrier = View(this)
        carrier.layoutParams = lp
        try {
            wm.addView(carrier, lp)
            fullScreenCarrier = carrier
            writeLog("full-screen carrier added ${dm.widthPixels}x${dm.heightPixels} type=$windowType")
        } catch (e: Exception) {
            writeLog("full-screen carrier add failed: ${e.message}")
        }
    }

    // v6.7.68 (AZ 兼容): 移除全屏承载窗口。
    private fun dismissFullScreenCarrier() {
        if (Looper.myLooper() != Looper.getMainLooper()) {
            mainUiHandler.post { dismissFullScreenCarrier() }
            return
        }
        val carrier = fullScreenCarrier ?: return
        fullScreenCarrier = null
        try {
            (getSystemService(Context.WINDOW_SERVICE) as WindowManager).removeViewImmediate(carrier)
            writeLog("full-screen carrier removed")
        } catch (e: Exception) {
            writeLog("full-screen carrier remove failed: ${e.message}")
        }
    }

    // v6.7.66 P3-3/P3-4: 判定是否"挂载成功但不可见/上屏失败"类原因(仅此类触发省电
    // 提示与自动重挂载;权限缺失/addView 异常不在此列)。
    private fun isOnScreenFailure(reason: String): Boolean =
        reason.contains("not actually on screen") ||
            reason.contains("attached but not visible") ||
            reason.contains("window hidden by system")

    // v6.7.66 P3-3: 华为/荣耀省电模式下,上屏失败时追加针对性引导。
    private fun notifyOverlayPowerSaveHint() {
        if (!isHwRom() || !isPowerSaveMode()) return
        try {
            android.widget.Toast.makeText(
                this,
                "检测到华为省电模式，悬浮球可能被系统隐藏，请关闭省电或在应用启动管理中允许后台活动",
                android.widget.Toast.LENGTH_LONG
            ).show()
            writeLog("overlay hidden: HUAWEI power-save mode detected, advise disable power save or whitelist")
        } catch (e: Exception) {
            writeLog("notifyOverlayPowerSaveHint error: ${e.message}")
        }
    }

    // v6.7.66 P3-4: 上屏失败自动重挂载兜底(最多 2 次)。华为设备重建窗口常能绕开
    // 首次挂载被系统抑制的问题:dismiss 释放旧窗口 -> 延迟 300ms 重建 -> 触发 surface
    // 重新创建。应保持主线程执行(dismissFloatOverlay/showFloatOverlay 内部已切主线程)。
    private fun remountOverlayIfNeeded() {
        if (overlayRemountCount >= OVERLAY_REMOUNT_MAX) {
            writeLog("overlay remount exhausted (max=$OVERLAY_REMOUNT_MAX), give up")
            overlayRemountCount = 0
            return
        }
        overlayRemountCount++
        writeLog("overlay remount attempt $overlayRemountCount/$OVERLAY_REMOUNT_MAX after $OVERLAY_REMOUNT_DELAY_MS ms")
        mainUiHandler.postDelayed({
            dismissFloatOverlay()
            showFloatOverlay()
        }, OVERLAY_REMOUNT_DELAY_MS)
    }

    // v6.7.69 (Bug 修复): 仅在"挂载成功但被系统隐藏"分支由 isOnScreenFailure 驱动调用,
    // 不再在 onOverlayAttached 无条件调度。且触发前判权限:已授予悬浮窗权限直接 return,
    // 避免"权限已给仍弹需要授权"的误报(Bug 1)。
    private fun scheduleOverlayGuide() {
        if (overlayGuideShown) return
        // v6.7.69 (Bug 1): 已授权不弹引导——权限给了仍弹根因就是旧实现不判 canDrawOverlays
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M
            && Settings.canDrawOverlays(this)) {
            writeLog("overlay guide skipped: overlay permission already granted")
            return
        }
        overlayGuideShown = true
        // v6.7.67 (P1-3): 电池统计旁证仅作日志参考字段(厂商省电可能不走 isPowerSaveMode,
        // 用 EXTRA_IS_SAVING_MODE sticky extra 补充,便于实机对照,不改变逻辑分支)。
        val batterySaving = readBatterySavingMode()
        writeLog("overlay guide scheduled, hwPowerSave=${isPowerSaveMode()} batterySavingExtra=$batterySaving")
        mainUiHandler.postDelayed({
            if (floatOverlay == null) return@postDelayed
            guideOverlayPermission()
        }, 1500L)
    }

    // v6.7.67 (P1-3): 读取电池 sticky extra 的 EXTRA_IS_SAVING_MODE 作为省电旁证。
    // EXTRA_IS_SAVING_MODE 为新增/变动常量,直接用字符串名避免编译期 API 差异。
    private fun readBatterySavingMode(): String {
        return try {
            val sticky = registerReceiver(null, IntentFilter(Intent.ACTION_BATTERY_CHANGED))
            val saving = sticky?.getBooleanExtra(
                "android.os.BatteryManager.EXTRA_IS_SAVING_MODE", false
            ) ?: false
            saving.toString()
        } catch (e: Exception) {
            "unavailable:${e.message}"
        }
    }

    // v6.7.69 (Bug 修复): 放行引导只弹 Toast,不再 startActivity 跳系统设置页。
    // v6.7.67 旧实现会在录制开始约 1.5s 后强制 startActivity(ACTION_MANAGE_OVERLAY_PERMISSION)
    // 与 ACTION_REQUEST_IGNORE_BATTERY_OPTIMIZATIONS,把前台从录制界面切走弹到系统设置页,
    // 导致用户在录制 App 上"完全点不了屏幕"(Bug 2)。改为纯 Toast 提示,不抢前台。
    private fun guideOverlayPermission() {
        writeLog("overlay maybe hidden, guide user (toast only, no settings jump)")
        try {
            val base = "检测到悬浮球可能被系统隐藏。请到系统设置中允许本应用显示悬浮窗，" +
                "并在「应用启动管理 / 电池优化」中允许后台活动，否则录制控制按钮不可见。"
            android.widget.Toast.makeText(this, base, android.widget.Toast.LENGTH_LONG).show()
        } catch (e: Exception) {
            writeLog("guideOverlayPermission error: ${e.message}")
        }
    }

    // P0-3b: 悬浮窗不可用时用户可见提示 + 写入诊断日志
    // P2-2: 华为/荣耀 ROM 省电模式下追加针对性引导
    private fun notifyOverlayUnavailable() {
        try {
            val base = "未获得悬浮窗权限，录制悬浮球无法显示，请在设置中开启"
            val hwPowerSave = isHwRom() && isPowerSaveMode()
            val toast = android.widget.Toast.makeText(
                this,
                if (hwPowerSave) {
                    "$base；且检测到华为省电模式，悬浮球可能被系统隐藏，请在" +
                        "设置-电池-更多电池设置中关闭省电模式，或在应用启动管理中允许本应用后台活动"
                } else {
                    base
                },
                android.widget.Toast.LENGTH_LONG
            )
            toast.show()
            if (hwPowerSave) {
                writeLog("overlay unavailable on HUAWEI power-save mode, please disable power save or whitelist background activity")
            } else {
                writeLog("overlay unavailable, please grant SYSTEM_ALERT_WINDOW")
            }
        } catch (e: Exception) {
            writeLog("notifyOverlayUnavailable error: ${e.message}")
        }
    }

    private fun isHwRom(): Boolean {
        val m = Build.MANUFACTURER?.lowercase(Locale.ROOT) ?: return false
        return m == "huawei" || m == "honor"
    }

    private fun isPowerSaveMode(): Boolean =
        try {
            val pm = getSystemService(Context.POWER_SERVICE) as? PowerManager
            pm?.isPowerSaveMode ?: false
        } catch (_: Exception) {
            false
        }

    private fun dismissFloatOverlay() {
        writeLog("dismissFloatOverlay")
        if (Looper.myLooper() != Looper.getMainLooper()) {
            mainUiHandler.post { dismissFloatOverlay() }
            return
        }
        // v6.7.68 (AZ 兼容): 交互小球释放后一并移除全屏承载窗口
        floatOverlay?.release()
        floatOverlay = null
        dismissFullScreenCarrier()
    }

    // v6.7.181: PARTIAL_WAKE_LOCK 三件套——锁屏录制保 CPU。只保 CPU 不亮屏,
    // 与 FLAG_KEEP_SCREEN_ON(防超时熄屏)是两件独立的事,两者叠加才等于"锁屏连续录制"。
    // 依赖 Manifest 的 android.permission.WAKE_LOCK 声明(普通权限,安装自授)。
    private fun acquireWakeLock() {
        try {
            val pm = getSystemService(Context.POWER_SERVICE) as PowerManager
            if (wakeLock?.isHeld == true) wakeLock?.release()
            wakeLock = pm.newWakeLock(PowerManager.PARTIAL_WAKE_LOCK, WAKE_LOCK_TAG)
            wakeLock?.acquire(WAKE_LOCK_TIMEOUT_MS)
            engine?.setWakeLockHeld(true)
            DiagLog.logEvent("WAKE_LOCK", "acquired timeout=$WAKE_LOCK_TIMEOUT_MS isHeld=${wakeLock?.isHeld}")
            writeLog("wake lock acquired (timeout=$WAKE_LOCK_TIMEOUT_MS ms)")
        } catch (e: Exception) {
            // v6.7.182: 持锁失败必须显式告警,否则"锁形同虚设"会静默表现为录屏正常启动。
            // 典型原因: Manifest 缺 android.permission.WAKE_LOCK 声明 -> SecurityException。
            engine?.setWakeLockHeld(false)
            DiagLog.logEvent("WAKE_LOCK", "ACQUIRE FAILED (lock not held, screen-off recording will stall): ${e.message}")
            writeLog("acquireWakeLock error: ${e.message}")
        }
    }

    private fun renewWakeLock() {
        try {
            wakeLock?.let {
                if (!it.isHeld) {
                    // v6.7.184: 续期前发现锁已丢,先记一次丢失再补持。
                    // 结尾快照(wakeLockHeld)会因随后的恢复而回 true,只有计数留痕。
                    engine?.onWakeLockLost()
                    DiagLog.logEvent("WAKE_LOCK", "LOST detected during renew, re-acquiring")
                    it.acquire(WAKE_LOCK_TIMEOUT_MS)
                }
                engine?.setWakeLockHeld(it.isHeld)
            }
        } catch (e: Exception) {
            engine?.setWakeLockHeld(false)
            DiagLog.logEvent("WAKE_LOCK", "RENEW FAILED: ${e.message}")
            writeLog("renewWakeLock error: ${e.message}")
        }
    }

    private fun releaseWakeLock() {
        try {
            if (wakeLock?.isHeld == true) {
                wakeLock?.release()
                writeLog("wake lock released")
            }
        } catch (_: Exception) {}
        engine?.setWakeLockHeld(false)
        wakeLock = null
    }

    // v6.7.180: 屏幕状态接收器——锁屏/解锁只观测,绝不调用 stopAsync/handleStop。
    // 屏幕真熄灭后 MediaProjection 捕获的是锁屏/黑帧,这是 Android 机制上限;
    // 这里保证的是"会话不崩、解锁即续、打点可诊断",而不是"锁屏期间画面是亮的"。
    private fun registerScreenStateReceiver() {
        if (screenStateReceiver != null) return
        screenStateReceiver = object : BroadcastReceiver() {
            override fun onReceive(c: Context?, intent: Intent?) {
                when (intent?.action) {
                    Intent.ACTION_SCREEN_OFF -> {
                        DiagLog.log("screen_state off -> recording continues (locked)")
                        engine?.markScreenLocked()
                    }
                    Intent.ACTION_SCREEN_ON -> {
                        DiagLog.log("screen_state on -> resync capture")
                        engine?.markScreenUnlocked()
                    }
                }
            }
        }
        try {
            registerReceiver(screenStateReceiver, IntentFilter().apply {
                addAction(Intent.ACTION_SCREEN_OFF)
                addAction(Intent.ACTION_SCREEN_ON)
            })
        } catch (e: Exception) {
            writeLog("registerScreenStateReceiver error: ${e.message}")
            screenStateReceiver = null
        }
    }

    private fun unregisterScreenStateReceiver() {
        try { screenStateReceiver?.let { unregisterReceiver(it) } } catch (_: Exception) {}
        screenStateReceiver = null
    }

    // v6.7.189 (P2-14): 单次会话幂等。停止路径上 cleanupAndStop 会被
    // onStopped / MediaProjection.onStop / onDestroy 并发调用 3~4 次(真机实测),
    // dismissFloatOverlay 与 RECORDING_STOPPED 广播各刷 4 遍。用"会话 token"而非
    // 布尔量:录制开始时签发新 token,同一 token 只真正执行一次。
    @Volatile private var cleanupSessionId = 0L
    @Volatile private var cleanupDoneForSession = -1L

    private fun newSession() { cleanupSessionId++ }

    private fun callerOf(): String = try {
        Thread.currentThread().stackTrace[3].let { "${it.className}.${it.methodName}:${it.lineNumber}" }
    } catch (_: Throwable) { "unknown" }

    private fun cleanupAndStop() {
        val sid = cleanupSessionId
        if (cleanupDoneForSession == sid) {
            // v6.7.190 (P1-1): 幂等 skip 是设计内的正常路径(单次录制被调 4~5 次),
            // 降级为 Log.d 不写文件日志。此前每次 skip 都落一条 writeLog 且 callerOf()
            // 取 stackTrace[3] 深浅不一,同一入口打出不同行号,噪音淹没真正的收尾记录。
            android.util.Log.d(TAG, "cleanupAndStop skip (already done for session=$sid)")
            return
        }
        cleanupDoneForSession = sid
        writeLog("cleanupAndStop session=$sid caller=${callerOf()}")
        // v6.7.97 (改进2): 不清理 pendingSafFileName。engine 内部改名后的最终名通过
        // finalSafUri 传给 onStopped，resolveDisplayName 会优先从 URI 解析出 .mp4 名；
        // pendingSafFileName 仅在 URI 解码失败时兜底使用。
        if (!isCleaningUp.compareAndSet(false, true)) {
            writeLog("cleanupAndStop already in progress")
            return
        }
        unregisterScreenStateReceiver()
        releaseWakeLock()
        val caller = Thread.currentThread().stackTrace
            .firstOrNull { it.className.startsWith("com.monkeycode.screenrecorder") && !it.className.contains("cleanupAndStop") }
        writeLog("cleanupAndStop caller=${caller?.className}.${caller?.methodName}:${caller?.lineNumber}")
        writeLog("cleanupAndStop")

        // v6.7.144 (P0-3): 停止/收尾必注销摇一摇传感器(幂等)。
        unregisterShakeSensor()

        // v6.7.145 (P1-6): 若清理时仍处于 RECORDING(进程被系统 kill 路径,
        // MediaProjection onStop 触发),标记停止原因为 SYSTEM_KILL。
        if (state.get() == RecordState.RECORDING) {
            lastStopReason = StopReason.SYSTEM_KILL
            writeLog("cleanupAndStop during RECORDING -> SYSTEM_KILL")
        }

        // v6.7.188 (【2】): overlayPersistent 时不收球、不摘前台通知、不 stopSelf,常驻等待下一次开始。
        if (!overlayPersistent) {
            dismissFloatOverlay()
        }

        try {
            projectionCallback?.let { callback ->
                try {
                    mediaProjection?.unregisterCallback(callback)
                } catch (e: Exception) {
                    writeLog("unregister projection callback error: ${e.message}")
                }
            }
            projectionCallback = null
        } catch (e: Exception) {
            writeLog("cleanup projection callback error: ${e.message}")
        }

        try {
            mediaProjection?.stop()
        } catch (e: Exception) {
            writeLog("mediaProjection stop error: ${e.message}")
        }
        mediaProjection = null

        // v6.7.108 (修复): 不再清空 currentQualityParams。它是用户画质配置,不属于会话
        // 资源,而 stopAsync 路径下 recordToHistory 可能晚于本 cleanupAndStop 执行
        // (MediaProjection onStop 触发的 cleanup 与 AsyncDrainThread 的 saf_copy/rename
        // 并发,后者收尾才回调 onStopped)。此时若已置 null,历史条目 width/height 恒为 0、
        // codecName 恒为空。currentOutputUri/currentOutputPath 是会话输出路径,仍需清空。
        currentOutputUri = null
        currentOutputPath = null

        ScreenRecorderApp.pendingMediaProjection = null

        // v6.7.102 (B11): stopForeground 提前到 engine.forceStop() 之前。
        // 旧顺序 forceStop → stopForeground:forceStop 可能因编码器 drain 卡 30s,
        // 这段窗口 FGS 类型仍声明 MEDIA_PROJECTION/MICROPHONE,而 projection 已置 null、
        // 引擎正在收尾,资源使用与 FGS 类型脱钩,Android 14/15 严格检测可能触发
        // "Foreground service declared but resource not in use" 违规。先摘 FGS,
        // 再让 forceStop 在干净状态下 drain。
        // v6.7.188 (【2】): overlayPersistent 时保留常驻前台通知,不摘。
        if (overlayPersistent) {
            postPersistentOverlayNotification()
        } else {
            try {
                stopForeground(STOP_FOREGROUND_REMOVE)
            } catch (e: Exception) {
                writeLog("stopForeground error: ${e.message}")
            }
        }

        // 主动停止引擎释放 MediaCodec/MediaMuxer/VirtualDisplay 等资源。
        // 不能只依赖 MediaProjection.onStop 回调里的 engine?.forceStop():
        // onStop 是异步的,可能在本方法之后才触发,届时 engine 已置空,
        // forceStop 被跳过 → 资源泄漏。此处显式停止,回调里再 forceStop
        // 也因 isRunning=false / stopCompleted CAS 幂等而安全。
        try {
            engine?.forceStop()
        } catch (e: Exception) {
            writeLog("engine forceStop in cleanup error: ${e.message}")
        }
        // engine 置空放在最后,确保 MediaProjectionCallback.onStop 中的
        // engine?.forceStop() 在 callback 注册被移除前仍可访问。
        engine = null

        // v6.7.188 (【2】): overlayPersistent 时不清全通知,常驻通知由 postPersistentOverlayNotification 单独刷新。
        if (overlayPersistent) {
            notificationManager.cancel(NOTIFICATION_ID_RECORDING)
        } else {
            notificationManager.cancelAll()
        }

        // 清除录制状态持久化标记
        try {
            RecorderEngine.clearRecordingState(this)
        } catch (e: Exception) {
            writeLog("clearRecordingState error: ${e.message}")
        }

        setState(RecordState.IDLE)

        try {
            val diagPath = DiagLog.getDiagFilePath()
            if (diagPath.isNotEmpty()) {
                Log.d(TAG, "diag file = $diagPath")
                try {
                    preferencesManager.lastDiagPath = diagPath
                    writeLog("diag log = $diagPath")
                } catch (_: Exception) {}
            }
        } catch (_: Exception) {}

        try {
            // v6.7.72: 必须 setPackage。荣耀/华为 MagicOS 会拦截未指定包名的
            // 隐式广播,即使收发双方是同一应用;而 Activity 侧在 SDK33+ 以
            // RECEIVER_NOT_EXPORTED 注册,不指定包名时收不到,按钮会永久
            // 停在"停止中…"(全局 recordState 其实已是 IDLE)。
            sendBroadcast(Intent(ACTION_RECORDING_STOPPED).setPackage(packageName)
                .putExtra(EXTRA_SAVED, sessionRecorded))   // v6.7.188c-fix: 只在该会话真录过才 true
        } catch (e: Exception) {
            writeLog("broadcast recording stopped error: ${e.message}")
        }
        sessionRecorded = false   // v6.7.188c-fix: 收口复位,下一会话 IDLE-stop 不会误带 true

        // v6.7.188 (【2】): overlayPersistent 时不 stopSelf,常驻服务保悬浮球。
        if (!overlayPersistent) {
            stopSelf()
        }
        // v6.7.109 (SVC-1): isCleaningUp 复位从收尾中段(原 setState 之后)挪到方法最末。
        // 原位置复位后,异步 MediaProjection.onStop/onStopped 回调与本方法并发,可二次放行
        // cleanupAndStop,重发 STOPPED 广播并重复收尾。整个方法执行期间保持置位,一次性收尾,
        // 服务 stopSelf 后即将消亡也无需再复位。
        isCleaningUp.set(false)
    }

    // v6.7.144 (P0-3): 摇一摇传感器注册/注销。注册点见 recorderCallback.onStarted,
    // 注销点见 cleanupAndStop(幂等)。SENSOR_DELAY_UI 约 20ms 频率,足够 500ms 双阈值检测。
    private fun registerShakeSensor() {
        if (!preferencesManager.isShakeToStopEnabled()) return
        try {
            sensorManager = getSystemService(Context.SENSOR_SERVICE) as SensorManager
            val sensor = sensorManager?.getDefaultSensor(Sensor.TYPE_ACCELEROMETER) ?: return
            sensorManager?.registerListener(shakeListener, sensor, SensorManager.SENSOR_DELAY_UI)
            shakeDetectedAt = 0L
            shakeCount = 0
            writeLog("shake sensor registered")
        } catch (e: Exception) {
            writeLog("shake sensor register error: ${e.message}")
            sensorManager = null
        }
    }

    private fun unregisterShakeSensor() {
        try {
            sensorManager?.unregisterListener(shakeListener)
        } catch (_: Exception) {}
        sensorManager = null
        shakeCount = 0
        shakeDetectedAt = 0L
    }

    private fun writeLog(message: String) {
        Log.d(TAG, message)
        writeToLogFile(message)
    }

    private fun writeToLogFile(message: String) {
        // 统一日志：服务生命周期日志也写入 DiagLog 主文件，实现单文件覆盖全部模块
        DiagLog.log(message)
    }

    private fun formatDuration(durationMs: Long): String {
        val totalSec = durationMs / 1000
        val h = totalSec / 3600
        val m = (totalSec % 3600) / 60
        val s = totalSec % 60
        return if (h > 0) "%d:%02d:%02d".format(h, m, s)
        else "%d:%02d".format(m, s)
    }

    private fun formatFileSize(sizeBytes: Long): String {
        return when {
            sizeBytes >= 1_073_741_824 -> "%.1f GB".format(sizeBytes / 1_073_741_824.0)
            sizeBytes >= 1_048_576 -> "%.1f MB".format(sizeBytes / 1_048_576.0)
            sizeBytes >= 1024 -> "%.1f KB".format(sizeBytes / 1024.0)
            else -> "$sizeBytes B"
        }
    }
}