package com.monkeycode.screenrecorder

import android.util.Log
import java.io.File

/**
 * v6.7.134: 删除操作统一收口工具(必剪式回收方案·文件层)。
 *
 * 三个职责:
 * 1. 白名单保护——命中保护名单则拒绝删除,返回 false 并告警;
 * 2. 统一执行——所有 File.delete 收口到 [delete]/[deleteRecursively];
 * 3. 审计日志——每次删除输出 safeDelete 行,可按关键字检索。
 *
 * 设计取舍(明文不混淆前提):
 * - 用源码层显式调用取代字节码插桩(Lancet 等)。效果等价,零构建侵入,反编译可审计。
 * - 保护名单为静态注册 + 轻量判定(字符串/时间窗比对),禁止在删除路径做全盘扫描。
 * - 性能损耗:每次删除一次名单比对 + 一行日志,微秒级,可忽略。
 */
object SafeDeleteUtil {

    private const val TAG = "SafeDelete"

    // 活跃录制 tmp 保护窗(与 RecorderEngine.STALE_ACTIVE_WINDOW_MS 对齐:30s 内修改的 .recording.tmp 视为正在写入)。
    const val ACTIVE_WINDOW_MS: Long = 30_000L

    /** 保护名单注册项:path 判断谓词 + 可读原因(进日志)。 */
    private data class Guard(val reason: String, val matches: (File) -> Boolean)

    // v6.7.165: 换 CopyOnWriteArrayList——读多写少 + 迭代安全。原 mutableListOf 底层
    // ArrayList 非线程安全,isProtected/protectedReason 的 for 迭代与 guardPaths 的
    // removeAll+add 并发会抛 ConcurrentModificationException,导致 delete 流程中断。
    // COW 迭代走数组快照永不 CME,写时复制天然线程安全,读路径无需加锁,不拖慢删除热路径。
    private val guards = java.util.concurrent.CopyOnWriteArrayList<Guard>()

    // 历史记录引用路径(由 MainActivity 在加载/变更后注册)。空集表示未注册,此时退化为不依赖历史保护。
    @Volatile private var historyPaths: Set<String> = emptySet()

    init {
        // 1) 活跃录制分片:30s 内修改的 *.recording.tmp(正在写入,绝对不可删)。
        guards.add(Guard("active_recording_tmp") { f ->
            f.name.endsWith(".recording.tmp") &&
                (System.currentTimeMillis() - f.lastModified()) < ACTIVE_WINDOW_MS
        })
        // 2) 已恢复产物:名称含 _restored 的 .mp4(RecorderEngine.restoreStale 产物,用户可再编辑/分享)。
        guards.add(Guard("restored_mp4") { f ->
            f.name.contains("_restored") && f.name.endsWith(".mp4", ignoreCase = true)
        })
        // 3) manifest 未处理目录中的文件:禁止整目录删除(防止误删未恢复会话)。
        // 具体文件的保护由调用方 deleteRecursively 的 allowDirectory 判定处理,此处仅拦 manifest.txt 本身。
        guards.add(Guard("unrecovered_manifest") { f ->
            f.name == "manifest.txt"
        })
        // 4) v6.7.189 (P0-4): _interrupted 保留产物(崩溃录制修复失败的兜底现场)及其 .idx。
        // .idx 是唯一能重建 moov 的数据,在修复成功或用户显式丢弃前,任何路径不得删除。
        guards.add(Guard("interrupted_kept") { f ->
            f.name.contains("_interrupted") &&
                (f.name.endsWith(".mp4", ignoreCase = true) || f.name.endsWith(".idx", ignoreCase = true))
        })
    }

    /** 注册/刷新历史记录引用路径(调用方在 loadRecentHistory 后更新)。 */
    @JvmStatic
    fun setHistoryPaths(paths: Collection<String>) {
        historyPaths = paths.toSet()
    }

    /** 追加临时保护路径(如 SAF 导出目录)。 */
    @JvmStatic
    fun guardPaths(paths: Collection<String>, reason: String) {
        // v6.7.165: 按 reason 去重,避免反复调用(如 SAF 导出)导致 guards 无界增长。
        // CopyOnWriteArrayList 的 removeIf/add 各自原子,无需手写 synchronized;
        // 两条之间短暂可能读到旧/新注册态,但均为"多一条/少一条保护",绝不 CME。
        guards.removeIf { it.reason == reason }
        guards.add(Guard(reason) { f -> f.absolutePath in paths.toSet() })
    }

    /** 判定是否受保护(纯判定,不做任何删除)。 */
    @JvmStatic
    fun isProtected(f: File): Boolean {
        if (!f.exists()) return false
        if (f.absolutePath in historyPaths) return true
        for (g in guards) if (g.matches(f)) return true
        return false
    }

    /** 受保护原因(仅供日志/调试,无保护时返回 "none")。 */
    @JvmStatic
    fun protectedReason(f: File): String {
        if (f.absolutePath in historyPaths) return "history_referenced"
        for (g in guards) if (g.matches(f)) return g.reason
        return "none"
    }

    /**
     * 统一删除入口。
     * @param caller 调用点标识(进审计日志,便于定位误删来源)
     * @param force true 时跳过保护名单(用于"业务已确认可删"的场景,如已处理完的封口 manifest);
     * 仍保留审计日志,便于追溯
     * @return true=已删除;false=被保护名单拦截 或 删除失败
     */
    @JvmStatic
    fun delete(f: File, caller: String, force: Boolean = false): Boolean {
        if (!f.exists()) {
            log("path=${f.absolutePath} protected=false result=false caller=$caller note=not_exists")
            return false
        }
        if (!force && isProtected(f)) {
            val reason = protectedReason(f)
            log("path=${f.absolutePath} protected=true result=false caller=$caller reason=$reason")
            return false
        }
        val ok = try {
            f.delete()
        } catch (e: Exception) {
            log("path=${f.absolutePath} protected=false result=false caller=$caller error=${e.message}")
            return false
        }
        log("path=${f.absolutePath} protected=${if (force) "overridden" else "false"} result=$ok caller=$caller")
        return ok
    }

    /**
     * 递归删除。[allowDirectory] 为 false 时跳过受保护目录(整目录不动,避免误删未恢复会话)。
     */
    @JvmStatic
    fun deleteRecursively(f: File, caller: String, allowDirectory: Boolean = true): Boolean {
        if (!f.exists()) return false
        if (!allowDirectory && f.isDirectory && isProtected(f)) {
            log("path=${f.absolutePath} protected=true result=false caller=$caller note=dir_skipped")
            return false
        }
        if (f.isDirectory) {
            if (isProtected(f)) {
                log("path=${f.absolutePath} protected=true result=false caller=$caller note=dir_protected")
                return false
            }
            val children = f.listFiles() ?: return false
            var allOk = true
            // v6.7.137 (必修1): 修复短路残留。旧实现用 allOk = allOk && deleteRecursively(...) 串联,
            // 只要某子项被白名单拦截返回 false,其后所有子项整体跳过删除,日志/批量清理会残留大量
            // 本可删除的文件。改为无条件遍历所有子项,再累加结果;目录自身删除也并入返回值。
            for (child in children) {
                val childOk = deleteRecursively(child, caller, allowDirectory)
                if (!childOk) allOk = false
            }
            // 目录本身可能为空且不再受保护,尝试删除;失败不再吞掉子项结果
            if (f.exists() && !isProtected(f)) {
                val ok = try { f.delete() } catch (_: Exception) { false }
                log("path=${f.absolutePath} protected=false result=$ok caller=$caller note=dir")
                return allOk && ok
            }
            return allOk
        }
        return delete(f, caller)
    }

    private fun log(msg: String) {
        // Log 走系统日志保证 release 可查;DiagLog 走内存环形缓冲(仅 debug 落盘)。
        android.util.Log.d(TAG, "safeDelete $msg")
        DiagLog.logEvent("DELETE", "safeDelete $msg")
    }
}
