import java.util.Properties

plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
}

android {
    namespace = "com.monkeycode.screenrecorder"
    compileSdk = 36

    defaultConfig {
        applicationId = "com.monkeycode.screenrecorder"
        minSdk = 24
        targetSdk = 36
        versionCode = 327
        versionName = "6.7.191"
    }

    signingConfigs {
        create("release") {
            // v6.7.84: 绝对路径写了 /workspace/1234567890.key,换机器/换目录/CI 全都编译不过。
            // 改相对路径(相对 app 模块目录 -> ../1234567890.key = 仓库根目录的 key),并支持
            // 通过环境变量 SR_STORE_FILE 覆盖(CI 注入 secret)。密钥/口令不进仓库,见 .gitignore。
            storeFile = file(System.getenv("SR_STORE_FILE") ?: "../1234567890.key")
            // v6.7.171: 签名口令去明文。硬编码 storePassword/keyPassword 违反 C2(源码不得含密钥明文),
            // 改为环境变量读取,缺省回退到旧值保证本地构建不破坏。
            storePassword = System.getenv("SR_STORE_PASS") ?: "1234567890"
            keyAlias = "1234567890"
            keyPassword = System.getenv("SR_KEY_PASS") ?: "1234567890"
            storeType = "PKCS12"
        }
    }

    buildTypes {
        release {
            // 项目无需混淆：保留明文代码便于排查日志/堆栈，代码安全由 release 签名保证
            isMinifyEnabled = false
            isShrinkResources = false
            signingConfig = signingConfigs.getByName("release")
        }
    }

    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_17
        targetCompatibility = JavaVersion.VERSION_17
    }

    kotlinOptions {
        jvmTarget = "17"
    }

    buildFeatures {
        viewBinding = true
        dataBinding = false
        buildConfig = true
    }
}

dependencies {
    implementation("androidx.core:core-ktx:1.15.0")
    implementation("androidx.appcompat:appcompat:1.7.0")
    implementation("com.google.android.material:material:1.12.0")
    implementation("androidx.activity:activity-ktx:1.9.3")
}