# ScreenRecorder Testkit

对 `com.monkeycode.screenrecorder` 落地测试脚本。当前版本基线 v6.7.105。

设计约束：
- **沙箱无可读 adb / 真机 / /dev/kvm**。所有脚本通过可插拔 `adb` 抽象调用，
  若 `ADB` 环境变量或 PATH 中缺 adb，脚本自动降级为自检（用 `mock/adb` 验证自身检测逻辑，不产生真机结论）。
- **真机必须补验**：省电降频、温控、PSNR/SSIM 画质——模拟器数字不写入结论。

## 测试目录

| # | 脚本 | 测什么 | 时长 | 判据 |
|---|---|---|---|---|
| T1 | `t1_4gb_boundary.py` | 4GiB 单文件边界 | 45 min（16Mbps）| 不中断 + ffprobe 时长/帧数完整 + 全量解码零错误 + 可 seek 尾部 |
| T2 | `t2_resource_drift.py` | 长时资源漂移（fd/线程/PSS） | 6 h | fd/线程波动 <±5，PSS 漂移 <2% |
| T4 | `t4_crash_recover.py` | kill -9 自恢复 + 已录保留 | 1 h | 30s 内恢复，已录丢失 <5s |
| T6 | `t6_clock_jump.py` | wall clock 跳变回归 | 20 min | av_pts_delta 无变化（预期单调时钟免疫） |

## 4GB 边界（T1，当前唯一已源码确认的缺陷）

v6.7.105 已加 `MUXER_4G_SAFE_LIMIT_BYTES = 4GiB - 64MiB` 安全水线，逐帧在
`handleVideoOutput` 检查 `videoBytesWritten`，到水线触发 `onMuxer4GLimitReached()`
→ `onError` → 完整 finalize。产物内容截止在水线附近、可 seek、可解码。

脚本验证：撞线前不中断、文件 ffprobe 时长/帧数完整、`ffmpeg -v error` 全量解码零错误、
能 seek 到文件尾部。

撞线时间参考（MP4 32-bit 偏移上限 4GiB）：

| 码率 | 写入速率 | 撞 4GiB |
|---|---|---|
| 10 Mbps（默认）| 1.19 MiB/s | 约 57 min |
| 16 Mbps（UI 最高）| 1.91 MiB/s | 约 36 min |
| 20 Mbps（HEVC 上限）| 2.38 MiB/s | 约 29 min |

## 运行方式

```bash
# 真机 + adb
ADB=adb python3 t1_4gb_boundary.py --bitrate 16000000 --duration 2700

# 沙箱（无 adb，跑自检，验证脚本自身逻辑）
ADB=mock/adb python3 t1_4gb_boundary.py --mock
```