#!/usr/bin/env python3
"""T3: 磁盘写满 —— 触发 500MB 阈值自动停止后，文件必须仍可播放。

代码已有 MIN_FREE_SPACE_BYTES=500MB 磁盘保护（checkFreeSpace），
录制中剩余空间 <500MB 即 onError → 完整 finalize。关键验证点是：
**写满时的 muxer 收尾是否产出可播放文件，不静默损坏**。

判据：触发停止后文件 ffprobe 时长/帧数有效、可解码、可 seek（moov 完整）。
--mock 跑自检。
"""

import argparse, os, sys, subprocess, re, time

def run(args):
    return subprocess.run(args, capture_output=True, text=True)

def main():
    p = argparse.ArgumentParser()
    p.add_argument("--adb", default=os.environ.get("ADB", "adb"))
    p.add_argument("--mock", action="store_true")
    p.add_argument("--mp4", help="触发停止后产出的 mp4 路径")
    args = p.parse_args()
    mock = args.mock or args.adb.startswith("mock")

    if mock:
        # 健康：写满后正常 finalize，文件完整可播 → PASS
        healthy = check_mp4_mock(7200000000, 432000, seek_ok=True, dec_err=0)
        # 静默损坏：写满时 muxer 收尾产出 moov 损坏但仍被 rename 成 .mp4 → FAIL
        silent_corrupt = check_mp4_mock(0, 0, seek_ok=False, dec_err=500)
        print("写满后正常收尾->", "PASS ✓" if healthy else "FAIL")
        print("写满后moov损坏(被rename成mp4)->", "FAIL ✓ 已检出" if not silent_corrupt else "PASS ✗ 漏检(静默损坏)")
        return 0 if healthy and not silent_corrupt else 1

    if not args.mp4 or not os.path.exists(args.mp4):
        print("[INFO] 需 --mp4 指定触发停止后的产物；沙箱请用 --mock。")
        return 1

    dur, frames = read_probe(args.mp4)
    dec_err = decode_error_count(args.mp4)
    seekok = seek_to_tail(args.mp4, dur)
    ok = dur > 0 and frames > 0 and dec_err == 0 and seekok
    if not ok:
        print(f"[FAIL] 磁盘写满触发后产物损坏: dur={dur} frames={frames} "
              f"decode_err={dec_err} seek={seekok} —— 静默损坏！")
        return 1
    print("[PASS] 磁盘写满触发后文件完整可播")
    return 0

def read_probe(mp4):
    r = run(["ffprobe","-show_entries","format=duration","-of","csv=p=0",mp4])
    dur = float(r.stdout.strip()) if r.returncode==0 and r.stdout.strip() else 0.0
    r = run(["ffprobe","-count_frames","-select_streams","v:0",
             "-show_entries","stream=nb_read_frames","-of","csv=p=0",mp4])
    frames = int(r.stdout.strip()) if r.returncode==0 and r.stdout.strip() else 0
    return dur, frames

def decode_error_count(mp4):
    r = run(["ffmpeg","-v","error","-i",mp4,"-f","null","-"])
    return len(re.findall(r"(?i)error", r.stderr or ""))

def seek_to_tail(mp4, dur):
    r = run(["ffmpeg","-v","error","-ss",str(max(0,dur-1)),"-i",mp4,"-frames","1","-f","null","-"])
    return r.returncode == 0

def check_mp4_mock(dur_us, frames, seek_ok, dec_err):
    return dur_us > 0 and frames > 0 and seek_ok and dec_err == 0

if __name__ == "__main__":
    sys.exit(main())