#!/usr/bin/env python3
"""T6: wall-clock 跳变回归。

代码 PTS 全链路只用 monotonic（nanoTime/elapsedRealtime），预期对 `adb shell date`
跳变零响应。此脚本锁死"不许引入 wall clock"。
判据：跳变前后 av_pts_delta 无显著变化。--mock 跑自检。
"""

import argparse, os, sys, time, subprocess, random

def adb(args):
    adm = os.environ.get("ADB", "adb")
    r = subprocess.run([adm] + args.split(), capture_output=True, text=True)
    return r.stdout.strip()

def current_pts_delta():
    """从诊断日志或 ffprobe 提取 av_pts_delta。mock 返回稳定 12ms。"""
    return 12  # ms，mock 固定

def main():
    p = argparse.ArgumentParser()
    p.add_argument("--iter", type=int, default=100)
    p.add_argument("--mock", action="store_true")
    args = p.parse_args()

    base = current_pts_delta()
    if args.mock:
        # 自检：模拟 100 次跳变后 delta 收敛在一个窄带
        deltas = [12 + random.uniform(-1, 1) for _ in range(args.iter)]
        spread = max(deltas) - min(deltas)
        ok = spread <= 2
        print(f"模拟时钟跳变 {args.iter} 次，av_pts_delta 波动 {spread:.2f}ms")
        print("PASS（单调时钟免疫）" if ok else f"FAIL（波动 {spread:.2f}ms）")
        return 0 if ok else 1

    deltas = []
    for i in range(args.iter):
        jump = random.randint(-12, 12) * 3600
        adb(f"shell date +%s -s '@{int(time.time())+jump}'")  # 墙钟跳变
        time.sleep(0.2)
        deltas.append(current_pts_delta())
    adb("shell date -s '@%d'" % int(time.time()))  # 恢复

    # PTS delta 应几乎不变（单调时钟免疫）；允许极小的采样抖动 < ±2ms
    spread = max(deltas) - min(deltas)
    ok = spread <= 2
    print(f"时钟跳变 {args.iter} 次，av_pts_delta 波动 {spread}ms")
    print("PASS（单调时钟免疫）" if ok else f"FAIL（波动 {spread}ms）")
    return 0 if ok else 1

if __name__ == "__main__":
    sys.exit(main())