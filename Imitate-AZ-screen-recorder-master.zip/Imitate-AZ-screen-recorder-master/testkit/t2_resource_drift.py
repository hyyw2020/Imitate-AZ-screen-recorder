#!/usr/bin/env python3
"""T2: 长时资源漂移（fd / 线程 / PSS）。

采样间隔 10 分钟，判据：fd/线程数波动 <±5，PSS 漂移 <2%。
--mock 模式跑自检。
"""

import argparse, os, sys, time, statistics

def probe_resources(pid):
    """返回 (fd, threads, pss_kb)。mock 返回稳定值。"""
    try:
        fd = len(os.listdir(f"/proc/{pid}/fd"))
        th = len(os.listdir(f"/proc/{pid}/task"))
        statmi = open(f"/proc/{pid}/status").read()
        pss = 0
        for line in statmi.splitlines():
            if line.startswith("VmRSS"):
                pss = int(line.split()[1])
        return fd, th, pss
    except Exception:
        return 0, 0, 0

def main():
    p = argparse.ArgumentParser(description="T2 资源漂移")
    p.add_argument("--pid", type=int, help="录制进程 pid")
    p.add_argument("--interval", type=int, default=600, help="采样间隔秒")
    p.add_argument("--mock", action="store_true")
    args = p.parse_args()

    if args.mock:
        return mock()

    samples = []
    while len(samples) < 6:  # 1h 演示；实跑 6h 需放宽
        pid = args.pid
        fd, th, pss = probe_resources(pid)
        if fd == 0:
            print(f"[WARN] {pid} 不可读，等待...")
        else:
            samples.append((fd, th, pss))
        time.sleep(args.interval)

    fds = [s[0] for s in samples]; ths = [s[1] for s in samples]; pss = [s[2] for s in samples]
    fd_drift = max(fds) - min(fds); th_drift = max(ths) - min(ths)
    pss_mean = statistics.mean(pss); pss_drift = (max(pss) - min(pss)) / max(1, pss_mean)

    ok = fd_drift <= 5 and th_drift <= 5 and pss_drift < 0.02
    print(f"fd漂移={fd_drift} 线程漂移={th_drift} PSS漂移={pss_drift:.2%}")
    print("PASS" if ok else "FAIL")
    return 0 if ok else 1

def mock():
    # 健康：稳定
    stable = [(10, 12, 100000)] * 6
    healthy = check(stable)
    # 泄漏：PSS 持续涨
    leak = [(10, 12, 100000 + i*5000) for i in range(6)]
    leaky = check(leak)
    print("健康->", "PASS" if healthy else "FAIL")
    print("泄漏->", "FAIL ✓" if not leaky else "PASS ✗ 漏检")
    return 0 if healthy and not leaky else 1

def check(samples):
    fds=[s[0] for s in samples]; ths=[s[1] for s in samples]; pss=[s[2] for s in samples]
    return (max(fds)-min(fds)<=5 and max(ths)-min(ths)<=5 and
            (max(pss)-min(pss))/max(1,statistics.mean(pss))<0.02)

if __name__ == "__main__":
    sys.exit(main())