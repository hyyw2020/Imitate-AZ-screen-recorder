# ScreenRecorder

纯标准 Android SDK（Kotlin）实现的屏幕录制 App，兼容 Android 7.0（API 24）到 Android 16（API 36）。

## 特性

- MediaProjection 屏幕捕获，写入 MediaCodec（H.264/HEVC 可选）+ MediaMuxer 生成 MP4
- 音频：Android 10+ 支持内部音频（AudioPlaybackCapture），低版本回退麦克风
- 前台服务 + 悬浮控制窗（停止/暂停/恢复）
- 参数可调：分辨率、帧率、码率、音频源、输出目录（SAF）
- 过载降级与编码器失败回退，保证录制稳定性
- 录制历史与诊断日志导出

 ## 版本历史

  ### v6.7.139 - 改进1 隔次循环修复(hevcSuppressedByLearn)
  - 根因: v6.7.138 落盘 reason 依赖 `cfg.useHevc`,但回灌会覆盖 `this.config=effConfig`(useHevc=false),导致下次录制结束时 `!cfg.useHevc` 命中→写 reason="manual",破坏 device_cap 连续状态,隔次翻转
  - 方案: 新增类字段 `hevcSuppressedByLearn`;start() 回灌命中分支置 true,else 分支与 start() 开头复位 false;saveRecordingLearnState 落盘改用 when{hevcConfigureFailed→device_cap, hevcSuppressedByLearn→device_cap, else→manual},不再依赖 cfg.useHevc
  - 文件: RecorderEngine.kt :1079 字段声明, :1144/:1150 start() 复位与置位, :3607-3611 落盘 when 替换
  - 验证: compileDebugKotlin PASS;assembleRelease BUILD SUCCESSFUL;模拟 scripts/verify_v6137_sim.py 35/36 PASS(必修1+必修2+改进1-3+已确认项全 PASS;选修1 可选未实现不计分)
  - 遗留: 选修1 MediaCodecList 惰性单例与选修2 双路混音缓冲对齐待真机数据评估后实施

  ### v6.7.138 - 改进 1 缺陷修复(reason 字段)
  - 根因: v6.7.137 学习态回灌用 `learned=="avc" && config.useHevc` 判断,未区分 AVC 是"设备能力回退"还是"用户显式选择",导致弱机用户真开 HEVC 开关被永久压制
  - 方案: 新增 `KEY_LEARN_REASON`(常量 + learnedReason() 方法);saveRecordingLearnState 落盘时按 `hevcConfigureFailed` 写 reason("device_cap"=设备回退/"manual"=用户主动);start() 回灌条件改 `learned=="avc" && learnedReasonVal=="device_cap" && config.useHevc`;旧数据无 reason 视为 manual(少回灌,不压制)
  - 文件: RecorderEngine.kt 常量区加 KEY_LEARN_REASON,learnedReason() 新方法(:3545-3552),start() 回灌段(:1141-1144),saveRecordingLearnState 写原因段(:3607-3612)
  - 验证: compileDebugKotlin PASS;assembleRelease BUILD SUCCESSFUL;模拟 scripts/verify_v6137_sim.py 35/36 PASS(必修1+必修2+改进1-3+已确认1-7 全 PASS;选修1 可选未实现不计分)
  - 遗留: 选修1(MediaCodecList 惰性单例)与选修2(双路混音缓冲对齐)待真机采集数据后评估实施

  ### v6.7.137 - 必修1/2 修复 + 改进项落地
  - 必修1 修复 SafeDeleteUtil.deleteRecursively 短路残留：for 循环拆分 `val childOk = deleteRecursively(...) if (!childOk) allOk = false`，替代 `allOk = allOk && deleteRecursively(...)`；目录删除 `return allOk && ok` 不再吞掉子项结果；allowDirectory/白名单语义保留
  - 必修2 修复 BLACKLIST_PATTERNS 与 exynos +30 自相矛盾：黑名单移除 "omx.exynos."（保留 vp9/secure/decoder/omx.google.），注释更新 v6.7.137；exynos +30 加分分支(:1641) 保留，Exynos 硬编进入候选池并被优先
  - 改进1 编码器学习态回灌：新增 learnedEncoderPref() 方法（读取 LEARN_PREFS_NAME/KEY_LEARN_ENCODER_PREF）；start() 在组装 config 后判断 learned=="avc" 且 config.useHevc=true 时覆盖为 false，日志 learn_encoder_reuse
  - 改进2 clearLogs 白名单残留提示：deleteRecursively 改为返回 Boolean；clearLogs 接收 allDeleted，false 时在 runOnUiThread 弹出 Toast "部分日志被白名单保护，未全部删除（详见 SafeDelete 日志）"
  - 改进3 多分片历史展示（步骤1）：showVideoActionDialog 标题加 segMsg 后缀，多分片条目显示"（多分片 N 段 · 共 X:XX）"
  - 选修1/2 未实现：MediaCodecList 惰性单例与双路混音丢采样评估待真机采集数据后评估
  - 验证：compileDebugKotlin PASS；assembleRelease BUILD SUCCESSFUL；模拟 scripts/verify_v6137_sim.py 33/34 PASS（必修1+必修2+改进1/2/3+已确认项1-7 全 PASS；选修1 可选未实现不计分）；真机验收待有设备时
  - 本版本与 v6.7.136 改动正交叠加，合入 v6.7.136 的必剪式回收方案

  ### v6.7.136 - 必剪式回收（明文不混淆加密版）
  - 内存层分级清理：`onTrimMemory` 从"仅打日志"升级为有实际动作。UI_HIDDEN(20) 豁免；录制态 level>=RUNNING_MODERATE 时仅轻量收敛 DiagLog 队列到 128 条（不触碰编码器/缓冲/正在写入的 tmp）；非录制态 COMPLETE→16、RUNNING_MODERATE→256；`onLowMemory` 仍只告警不清理（低内存回调时序不稳，不在录制关键路径做任何删除）
  - 新增 `SafeDeleteUtil` 统一收口：白名单保护（活跃 `.recording.tmp` 30s 窗、`_restored.mp4`、`manifest.txt`、历史记录引用路径）+ 统一删除入口 + 审计日志（`safeDelete path=... protected=... result=... caller=...`）；`force=true` 用于业务已确认可删场景（如已处理完的封口 manifest、用户显式删除历史条目），仍保留审计
  - 删除点收口：RecorderEngine 的 findStale（SAF 导出副本 tmp/mp4、开关关静默删、KEEP_STALE 超龄）、recoverSegmentManifests（封口分片 .idx、已处理 manifest）、restoreStale（repaired 重试、dest 冲突、tmp/idx 清理）、discardStale、deleteStale；MainActivity 的 deleteVideo（本地分支）、clearAllVideos（历史条目 + movie 目录）、deleteRecursively（日志目录，allowDirectory=false 防整目录误删）
  - SAF 分支保持走 DocumentsContract.deleteDocument 不变；KEEP_STALE=3、v6.7.93 日志目录 DiagLog.stop→删→start 语义、v6.7.133 自动恢复语义均保留
  - 明确不引入：Lancet 及任何字节码插桩插件、混淆/加固/R8 自定义规则改动、加密/加壳依赖；纯 Kotlin 源码实现，构建链零新增插件
  - 本方案为稳定性/正确性/可维护性改善，不承诺 fps/码率提升；性能回归基线：删除路径仅一次名单比对 + 一行日志（微秒级）
  - 验证：compileDebugKotlin PASS；模拟 `scripts/verify_v6136_sim.py` 44/44 PASS（白名单四档拦截 + force 放行留审计 + 审计字段完整 + onTrimMemory 分级 + trimQueue 保留最新 + onLowMemory 只告警 + 无插桩无全盘扫描 + 既有能力不降级）；真机验收待有设备时

  ### v6.7.135 - HEVC 开关语义真实生效 + 默认开
  - 打分修复：`selectBestVideoEncoder` 的 HEVC 加分改为 `if (isHevc) score += if (preferHevc) 200 else -50`。旧逻辑 preferHevc=false 仍给 HEVC +50，高通硬编 HEVC=230 > AVC=180 恒胜出，用户关闭 HEVC 开关后实际仍强制 HEVC，开关失效；压分后 HEVC=130 < AVC=180，AVC 明确胜出
  - HEVC 默认开：`QualityParams.preferHevc` 与 `PreferencesManager.loadQuality` 默认值均改 true（仅影响全新用户/未设置项，老用户已存偏好不变）
  - 保留机制不变：HEVC_PREFERRED_BITRATE_CAP=80M 优先 AVC 分支、configureEncoderWithRetry 失败回退 AVC、无 HEVC 候选兜底
  - 打分/选择阶段无 HEVC 硬排除（黑名单不含 hevc），仅 HEVC 可用设备仍能正常编码
  - 验证：compileDebugKotlin PASS；模拟 `scripts/verify_v6135_sim.py` 19/19 PASS（关闭开关 AVC 胜出、开启 HEVC 胜出、仅 HEVC 设备不空选、2K/4K 档开关语义、>80M cap 分支、黑名单过滤正确项）；真机验收待有设备时

  ### v6.7.134 - 修复 HEVC 编码器永远选不上
  - 根因：`BLACKLIST_PATTERNS` 把 "hevc" 一并过滤，`listAllCodecCandidates` 候选池里根本没有 HEVC 编码器，`preferHevc` 的 +200 加分与 `HEVC_PREFERRED_BITRATE_CAP=80M` 全部落空，只能选 AVC（现象：useHevc=true 但日志输出 mime=video/avc）
  - 修复：黑名单移除 "hevc"，保留 vp9/secure/decoder/omx.google/omx.exynos.，让 OMX.qcom.video.encoder.hevc / c2.qti.hevc.encoder 等进入候选池
  - 打分逻辑不变（isHevc&&preferHevc +200；码率>80M 优先 AVC）；回退机制不变（无 HEVC 硬编/configure 失败/资源不足自动回退 AVC，不崩溃）
  - HEVC 系数 1.0（统一码率模型同码率取向），码率值不受影响
  - 验证：compileDebugKotlin PASS；模拟 `scripts/verify_v6134_sim.py` 17/17 PASS（HEVC 进入候选池 + preferHevc 选中 HEVC + 无 HEVC 设备回退 AVC + >80M 选 AVC + 黑名单仍过滤正确项）；真机验收待有设备时

  ### v6.7.133 - 自动保留（废横幅）
  - 删除被杀恢复横幅及控件（interruptedBanner/tvInterruptedHint/btnResumeLast/btnDiscardLast 布局 + refreshInterruptedBanner/onResumeLast/onDiscardLast 三方法 + 全部调用点）
  - 改为启动时自动恢复：onResume 检测 .recording.tmp 残留逐条 restoreStale 修复，成功的 _restored.mp4 自动写入历史，不弹任何 UI；修复失败的原样保留为 *_interrupted.mp4
  - 修复 findStaleRecordings 前置短路缺陷：旧实现 `if (isRecordingActive) return emptyList()` 在进程被杀后因 KEY_RECORDING_ACTIVE 残留 true 永远返回空（被杀后重启提示隔次才出现的根因）；改为仅当存在最近 30s 内修改的活跃 .recording.tmp 才跳过，否则正常扫描
  - 自动恢复写历史的时间戳用原始录制时间：从文件名解析 ScreenRecord_yyyyMMdd_HHmmss，解析失败回退 -1；避免被杀旧录制用 System.currentTimeMillis() 排到新录制上方导致历史排序错乱
  - 保留被杀恢复开关 swResumeProtect 语义：开关关闭时 findStaleRecordings 静默删除全部残留，不残留文件
  - 验证：compileDebugKotlin PASS；模拟 `scripts/verify_v6133_sim.py` 14/14 PASS（两残留场景自动恢复 + 历史按真实时间排序 + 开关关闭静默删除 + 30s 活跃窗短路 + 时间戳解析回退）；真机验收待有设备时

  ### v6.7.132 - 统一码率调度（基准×系数模型，必剪×剪映方案全集）
  - 码率模型从一维档位表改为"基准×系数"统一模型：最终码率 = 基准(15M) × 分辨率系数 × 帧率系数 × HEVC系数 × HDR系数，封顶 80M（对齐剪映 Hw.java）
  - 新增 `BitrateSchedulerConfig`（可下发配置）：base=15M、480p=0.4/720p=0.8(插值待实测)/1080p=1.6/2K=4.666/4K=4.866、hFps=1.428(120/144 沿用待实测)、hevc=1/1(码率 max 取向)、hdr=1/1、gop=120、crfMax=50M(估计待实测)、uiMax=80M；支持本地下发调优免发版
  - UI 码率档位抬到 80Mbps（Auto/80/72/64/56/48/40/32/24/16/12/10/8/6/4/2/1）
  - HEVC 偏好码率上限 64M→80M：2K/4K/高码率档全部优先 HEVC；HEVC 不可用仍自动回退 AVC
  - 默认码率 16M→24M（QualityParams 初值 + PreferencesManager 默认 + UI fallback 三处同步）
  - Auto 档码率由引擎联动模型实时计算（含帧率系数），替代静态查表
  - 144fps 档 profile 放开 AVCProfileHigh（`ALLOW_HIGH_AT_HIGH_FPS=true`，v6.3.15 已修 surface 消费不稳风险由降档兜底）
  - GOP 可配置（默认 120 帧，KEY_I_FRAME_INTERVAL 按帧率换算秒）
  - 验证：compileDebugKotlin PASS；assembleRelease PASS；模拟 `scripts/verify_v6132_sim.py` 26/26 PASS（码率表 2K=70M/4K=73M 与剪映实证吻合，4K60 raw=104M 封顶 80M，clampToCapabilities 在 hw<80M 时正确钳制）；真机画质/帧率稳定性待真机验收

  ### v6.7.131 - 码率规格对齐必剪剪映（放开到硬件上限）
  - UI 码率档位扩到 64Mbps：Auto/64/48/40/32/25/20/16/12/10/8/6/4/2/1（原封顶 16Mbps），实际生效值由引擎 `clampToCapabilities` 按硬件 `bitrateRange.upper` 兜底
  - 高分辨率默认码率提档（已在引擎层 `defaultBitrateForHeight`：2K=25M/4K=40M，v6.7.127 S3 落地）；用户显式码率一律尊重
  - HEVC 偏好码率上限 `HEVC_PREFERRED_BITRATE_CAP` 20M→64M：让 2K/4K/高码率档优先 HEVC（同码率画质更优、编码负载更低）；HEVC 不可用仍由编码器选择与 configure 失败自动回退 AVC
  - 分辨率-帧率上限联动：1080P及以下144帧/2K上限120/4K上限60（对齐必剪 4K锁60、1080P可144）；分辨率切换时修正帧率合法性，帧率对话框按当前分辨率裁掉非法高档
  - 丢帧 off-by-one 修复（v6.7.130 已落地）：`DROP_EVERY_45=3`/`DROP_EVERY_30=1`，使 60fps 源准确降到 45/30fps
  - 运行时降档逻辑（maybeStepDowngrade）保持原样，作为放开码率后的过热兜底
  - 验证：compileDebugKotlin PASS；模拟 `scripts/verify_v6131_sim.py` 25/25 PASS（clampToCapabilities 钳制 + 丢帧数学 + 联动裁档）；真机画质/帧率稳定性待真机验收

  ### v6.7.130 - 画质对齐（编码参数层）
  - H.264 profile 按帧率分档：帧率<=60fps 提档 `AVCProfileHigh`（CABAC/8x8，同码率画质+10~20%）；>60fps（144档）保留 `AVCProfileBaseline`（不回归 v6.3.15 已修的 surface 消费稳定性）
  - 色彩范围声明 `COLOR_RANGE_FULL`（原 `COLOR_RANGE_LIMITED`）：屏幕内容经 SurfaceFlinger 合成为 full range，声明 full 与内容一致，消除播放器按 16-235 解码导致的发灰
  - HEVC 分支显式 `HEVCProfileMain`：此前依赖编码器默认，设备间档位漂移不可控
  - 仅动 MediaFormat 声明，不触碰 surface 消费/丢帧/降档链路
  - 验证：compileDebugKotlin PASS；真机画质验收（PSNR + 色彩目测）留待有设备时

  ### v6.7.129 - 降档可视化 + 日志补全 + 历史元数据
 - 降档可视化：录制中悬浮球计时后追加降档码率标记（`▼12.8M`），锁死态显示 `▼L` 前缀
 - Engine 暴露 `isDowngradeActive()`/`isDowngradeLatched()`/`getDowngradeReason()`/`getDowngradeMeta()` 供 UI 查询
 - 日志补全：`downgrade enter` 日志补降档原因（`temp>=45C`/`battery<20%`）+ 回弹条件（`temp<40&&battery>=30 for 10s`）+ `latched` 标记
 - 历史元数据：`RecordingEntry` 新增 `downgradeActive`/`downgradeFirstAtMs`/`downgradeMinBitrate`/`downgradeLatched` 字段（向后兼容），记录本次是否降档、首次降档时刻、最低码率、是否锁死
 - 源码审计：降档触发链 `maybeStepDowngrade` → 电量/温度读取 → `downgradeActive` → 丢帧 实现正确（边界：温度 `>=45` 触发/`<45` 不触发，电量 `<20` 触发/`>=20` 不触发，读取失败不触发）
 - Python 模拟：丢帧 60→40fps（DROP_EVERY_30=2 每 3 帧丢 1 + 关键帧打断）、渐进降码率 7 档到 floor、回弹多档到 userBitrate、锁死不回弹、边界无假触发 全部 PASS

 ### v6.7.128 - 多分片 MP4 + manifest（剪映式分段）
 - 单文件 4GiB 水线整体改造为多分片：每片独立普通 MP4（moov 自包含、独立可播、moov 32-bit 索引绝对安全），API24~37 全版本原生可用
 - 分段阈值：时间 60s 主控 + 字节 1GiB 兜底，先到先切；4GiB 水线保留为最后保险
 - `switchSegment()` 全程在 muxerLock 内串行，编码器不重启——用已 start 的 track format（含 csd）重新 addTrack 到新建 MediaMuxer，帧流不中断
 - 分片内 PTS 重基：写 muxer 前减本片起点全局 PTS，每片时间轴从 0 起（视频全局单调钳制锚定保留，音频惰性锚定首帧快照）
 - manifest.txt 清单：`# ImitateAZ manifest v1` + 每片一行（seq/时长/字节/分辨率）+ fsync + `FINAL` 标记
 - 恢复逻辑以 manifest 为主：已封口分片保留磁盘（独立可播），当前 .tmp 片走 restoreStale 修复，manifest 处理后删除
 - 历史条目 `segmentPaths` 字段（向后兼容），多分片总时长/总大小累加；`onSegments` 回调传递分片清单
 - SAFAF 路径退化为单片（不支持目录遍历），本地路径启用分片
 - 自检验证：manifest 往返 + PTS 重基单调 + 阈值先到先切状态机全 PASS

 ### v6.7.127 - 参数放开 + 日志分级 + runtime 降档 + 外观升级
#### 参数放开（对齐必剪/剪映）
- S1/S2: 修复 Auto 帧率被钳成 1fps 的 bug——Auto(0) 不再被 min/max clamp 拉低
- S3: Auto 码率按高度提档(4K=40M/2K=25M/1080p=16M/720p=10M/540p=6M/480p=4.5M),用户显式码率不再被压
- S4: HEVC 独立开关,解除与 Auto 码率的隐式绑定(此前选 Auto 才可 HEVC)
- S5: 分辨率档新增 2K(2560x1440)/4K(3840x2160)/屏幕原始
- S6: 废弃启动期 FPS/码率摆测降档(applyHistoricalFpsCap 全链死代码删除)
- crc32+commit: learnState 指纹校验,loadRead 失败回退默认,保存显式一致写回+落盘

#### 日志分级 + 分辨率回显
- DiagLog: L1 帧级环形缓冲(512KB零IO)/L2 周期健康快照落盘;RecorderEngine 暴露 logDetailL1/logHealth
- encoder 实际尺寸(2K/4K clamp 后)全局回传并回显在主界面"分辨率"值

#### runtime 降档一二（过热/低电热降档,防过热丢帧死机）
- 触发: 电量<20% 或 温度>45°C;回弹: 温度<40 且 电量>30 持续 10s
- 一级降码率: setParameters 热改,每 5s 一档 20%,floor=用户设定/4 与 4M 取高,回弹至用户设定档
- 二级丢帧: 非关键帧按 targetFps 丢(45=每4丢1/30=每2丢1),关键帧必写,丢帧不更新 PTS 时间轴不打洞
- 失败锁死: 回弹后 30s 内再次触发 → 本次录制锁死降档档位不再回弹(防震荡)
- selfCheck: DOWNGRADE-CHECK PASS(含 lock/stability/userBitrate 分支)

#### 外观（三态暗色 + 视觉 + 动画）
- 深色三态: 跟随系统/浅色/深色(AppCompatDelegate 驱动),悬浮球与主界面统一 isNightNow
- values-night 深色 token 修正对比度(bg #13141F/card #1F2130/border #3A3D50),删除 Theme.ScreenRecorder.Dark
- 卡片圆角统一 16dp token;主按钮触发式按压缩放(scale 0.97,GPU 合成)

### v6.7.126 - 周期 flush 失败即停写（对齐 124 行为）
- 周期 flush 失败置 failed=true(与 BOS 自动 flush 失败同语义),避免缓冲仅 ~5.6KB 时
  flush 被吞而后续 write 只写内存、磁盘 .idx 永久缺段导致修复 stco 错位
- 仅 fd.sync 失败允许跳过(不影响已成功写入的索引)

### v6.7.125 - .idx 周期 fsync 落盘（断电恢复粒度细化）
- Tracker 每 256 样本对 .idx 做 flush+fd.sync,丢尾窗口从 25~99s 压到 4~9s
- 新增 fileOut(底层 FileOutputStream)引用,修复 v6.7.122 flushHeader 的
  (out as? FileOutputStream) 恒 null 问题(该 cast 因 out 是 BufferedOutputStream)
- 注:124 的 ensureIndexTracker 已有 (indexOut as? FileOutputStream)?.fd.sync() 兜底,头部一直有效

### v6.7.124 - 被杀后重建音画修复（Bug1-3）
- Mp4Repairer: SampleSpec 记录真实 AU 起点，scan 重建 stco 指向真实偏移（不再按累计尺寸推导，避免跳过 SPS/PPS/SEI 前导字节导致解码垃圾）
- Mp4Repairer: 修复 >4GiB 时 largesize box 解析漏加 box 起点(pos)
- RecorderEngine: 拆分 firstInputAudioPtsUs，消除 encode-input/drain-output 两线程对 firstAudioFrameTimeUs 的绝对值/零基数竞争
- RecorderEngine: 视频 PTS 改用编码器渲染时间戳，避免 capture_stall 时视频 PTS 塌陷导致音频领先（音画不同步）
- selfCheckScan 新增 stco 偏移断言，回归保护 Bug1

### v6.7.123 - NAL 扫描容错修复
- readUe 解析失败时将 VCL NAL 当作新帧(保证最差情况仍可播)
- flushHeader 加 fd.sync() 确保进程被杀时头部真正落盘

### v6.7.122 - NAL 扫描重建 moov（对齐 mp4parser 路径）
- .idx 无样本时通过 AVCC NAL 扫描重建 moov
- Tracker.flushHeader() 抢写头部参数(csd/fps/尺寸)先落盘
- restoreStale 接入 NAL 扫描回退路径
- JVM selfCheck/selfCheckScan 双路径验证

### v6.7.121 - 被杀恢复入口横幅
- 主界面显示 [继续]/[丢弃] 横幅，检测中断/被杀录制
- 支持从 sidecar .idx 重建 moov，恢复为可播放 mp4
- 防覆盖：目标已存在时先删除再改名

### v6.7.120 - kill保护 moov 重建
- 热路径写 sidecar .idx 索引（22B/sample: sync+pts+size+reloff）
- 被杀后可快速重建 moov，无需重扫整段 mdat
- 启动清理残留 .recording.tmp 和 emergency logs

### v6.7.119 - 中断录制可见性
- 中断文件默认保留，用户可选择恢复或丢弃
- 颜色元数据写入历史记录

### v6.7.112 - 帧率自学习闭环
- 实时学习实际帧率，动态调整编码参数
- S-SLEEP 状态管控，省电模式下降低帧率

### v6.7.96 - 对标 AZ 6.9.10
- 5 项关键改进：音频时钟校准、PTS 精度、悬浮窗健壮性等

### 悬浮窗交互升级（v6.7.70-95）
- 三球系统：主球 + 动态子球数
- 展开态拖动 1:1 跟踪，停靠还原
- 玻璃球分层外观，动画错峰 320ms
- 命中测试优化，误触率降低

### 音频视频同步修复
- MIXED 混音模式生效（v6.7.110）
- PTS 增量累加，消除 168ms 音画不同步（v6.7.90）
- 音频时钟差分估计，稳定采样率 44100Hz
- 暂停恢复音画对齐（v6.7.111）

### 文件管理增强
- 4GiB 单文件边界防护
- SAF deleteDocument API 使用
- 已导出标记防重复清理

## 构建

需要 Android SDK（compileSdk 36）、JDK 17、Gradle 8.10.2+。

```bash
./gradlew assembleRelease --no-daemon
```

输出：`app/build/outputs/apk/release/app-release.apk`（debug 签名，可直接安装）。

## 技术栈

- Kotlin 2.1.0，minSdk 24 / targetSdk 36 / compileSdk 36
- AGP 8.7.3，纯 Android 框架，无广告/统计/付费 SDK