# AI 在 Gitee 上行发布操作必须遵守的约束

本文件记录本仓库（Imitate-AZ-screen-recorder，远端 `https://gitee.com/nlxxai/Imitate-AZ-screen-recorder.git`）在 **Gitee Releases（发行版）** 上的发布纪律与已踩过的坑。任何 AI 在本仓库做“出 release / 发布版 / 排序发行版 / 重传附件”相关操作前，必须通读全文。

所有陈述均基于 2026-09 实测，非推测。

---

## 1. 平台硬规则（不可抗争）

### 1.1 Releases 列表按“创建时间正序”排列
Gitee 的发行版列表**只按 release 的创建时间从早到晚排列**，不接受任何 tag 名/语义化排序参数（`sort` 参数全部无效）。

**推论**：
- 版本号必须**单调递增**，且**增强连续**。若某版本号被跳过、后补，它会被排到序列末尾，列表即“乱”。
- 只要保证“按版本号顺序、从小到大、一次性连续新建”，创建时间递增 = 显示顺序正确。
- **严禁在已发布的序列里补建旧的缺失版本**，否则它落尾、打乱排列（这是本项目“列表变乱”的唯一根因——曾补建 v6.7.130/131/140~147 到 148 之后）。

### 1.2 zip / tar.gz 附件是平台自动归档，不要手动传
每个 release 上出现的 `vX.Y.Z.zip` 与 `vX.Y.Z.tar.gz`（`browser_download_url` 含 `/archive/refs/tags/`）是 **Gitee 根据该 tag 自动生成的源码归档**，会随 release 自动带上。
- **不要**用 `attach_files` 手动上传 zip/tar.gz——那是重复（你会看到每个 release 出现两份同名 zip/tar）。
- 手动要传的**只有 APK**。

---

## 2. Release 必须携带正式签名 APK

### 2.1 正式签名
- keystore：仓库根 `1234567890.key`（正式签名，密码/别名/密钥口令均 `1234567890`）。
- 签名证书 SHA-256：`c3055b4575820de36bbf847c51d131e734f4f86b893eff10f29b773c5a3a8d19`。
- 发布前务必用 `apksigner` 校验指纹完全一致。若不一致，说明签名环境/密钥不对，禁止发布。

### 2.2 构建命令
```bash
SR_STORE_FILE=/workspace/1234567890.key \
ANDROID_HOME=/opt/android-sdk ANDROID_SDK_ROOT=/opt/android-sdk \
JAVA_HOME=/usr/lib/jvm/java-17-openjdk-amd64 \
./gradlew --no-daemon assembleRelease
```
产物：`app/build/outputs/apk/release/app-release.apk`。

校验签名：
```bash
/opt/android-sdk/build-tools/34.0.0/apksigner verify \
  --print-certs app/build/outputs/apk/release/app-release.apk \
  | grep 'SHA-256'
```
输出必须含上面那串 `c305...`。

---

## 3. 踩过的坑与对策

### 3.1 曾发生：release 列表“停住/变乱”
现象：页面只显示到某版本、或新增版本排到末尾。
根因：Gitee 按创建时间排，而我曾补建缺失版本（130/131/140~147），它们创建时间晚，被排到 148 之后。
对策：遵循 1.1——版本号连续、逐个按序新建。**若必须修排序，唯一的彻底办法是删掉整段按序重建**，且：
- 删之前必须先下载备份全部 APK 附件（zip/tar 是归档可再生成，APK 一旦删 release 即丢）；
- 备份目录建议 `/tmp/release-backup/assets/<tag>/`，每个版本一个目录，下载后校验 zip 结构/APK 签名再删；
- 删 + 重建必须严格按版本号从小到大逐个进行。

### 3.2 曾发生：Release 无 APK
现象：release 页只有 tag 说明，没有可下载的 apk。
根因：补建的 release 只传了 tag 元数据、没传 APK。
对策：按 2 构建并上传 APK（`attach_files`），禁止发布“裸 release”。

### 3.3 APK 签名校验误报
有的历史 APK（如 v6.7.112）**只带 v1 签名、无 v2**（targetSdk=36 环境下 apksigner 会报 “DOES NOT VERIFY”）。
- 这是**历史上传时即如此**，文件本身 zip 结构完整、v1 可验，可正常安装。
- 判断“是否备份成功/文件是否损坏”要用 `unzip -tq`（zip 结构）+ APK 签名指纹是否匹配；**不要以 v2/v3 缺失去判坏**。
- 该版本 APK 按原样重传，不要重签名。

---

## 4. Gitee API 速查（本仓库）

Token 不写入本文件（必要时由用户提供）。
Base：`https://gitee.com/api/v5/repos/nlxxai/Imitate-AZ-screen-recorder`
- 列 release（分页）：`?page=<n>&per_page=100`
- 新建：`POST /releases`，body `{tag_name,target_commitish:"master",name,body,prerelease:false}`，头 `Authorization: token <T>`
- 附件上传：`POST /releases/<id>/attach_files`，multipart `file=@<path>`
- 删除：`DELETE /releases/<id>`

---

## 5. 最终核对清单（发布/重建后必跑）

- [ ] release 列表 `70→…→最新` 严格递增、无跳号错位
- [ ] 最新版本带 APK，指纹 = `c305...`
- [ ] 每个 release 有且只有一份手动 APK + Gitee 自动归档（zip/tar 各 1，不重复上传）
- [ ] 仓库 `app/build.gradle.kts` 的 `versionCode`/`versionName` 与 release tag 一致
